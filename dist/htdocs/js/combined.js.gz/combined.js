"use strict";
/*
 Native JavaScript for Bootstrap v3.0.3 (https://thednp.github.io/bootstrap.native/)
 Copyright 2015-2020 ? dnp_theme
 Licensed under MIT (https://github.com/thednp/bootstrap.native/blob/master/LICENSE)
*/
var $jscomp=$jscomp||{};$jscomp.scope={};$jscomp.ASSUME_ES5=!1;$jscomp.ASSUME_NO_NATIVE_MAP=!1;$jscomp.ASSUME_NO_NATIVE_SET=!1;$jscomp.SIMPLE_FROUND_POLYFILL=!1;$jscomp.ISOLATE_POLYFILLS=!1;$jscomp.FORCE_POLYFILL_PROMISE=!1;$jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION=!1;$jscomp.defineProperty=$jscomp.ASSUME_ES5||"function"==typeof Object.defineProperties?Object.defineProperty:function(h,t,B){if(h==Array.prototype||h==Object.prototype)return h;h[t]=B.value;return h};
$jscomp.getGlobal=function(h){h=["object"==typeof globalThis&&globalThis,h,"object"==typeof window&&window,"object"==typeof self&&self,"object"==typeof global&&global];for(var t=0;t<h.length;++t){var B=h[t];if(B&&B.Math==Math)return B}throw Error("Cannot find global object");};$jscomp.global=$jscomp.getGlobal(this);$jscomp.IS_SYMBOL_NATIVE="function"===typeof Symbol&&"symbol"===typeof Symbol("x");$jscomp.TRUST_ES6_POLYFILLS=!$jscomp.ISOLATE_POLYFILLS||$jscomp.IS_SYMBOL_NATIVE;$jscomp.polyfills={};
$jscomp.propertyToPolyfillSymbol={};$jscomp.POLYFILL_PREFIX="$jscp$";var $jscomp$lookupPolyfilledValue=function(h,t){var B=$jscomp.propertyToPolyfillSymbol[t];if(null==B)return h[t];B=h[B];return void 0!==B?B:h[t]};$jscomp.polyfill=function(h,t,B,F){t&&($jscomp.ISOLATE_POLYFILLS?$jscomp.polyfillIsolated(h,t,B,F):$jscomp.polyfillUnisolated(h,t,B,F))};
$jscomp.polyfillUnisolated=function(h,t,B,F){B=$jscomp.global;h=h.split(".");for(F=0;F<h.length-1;F++){var P=h[F];if(!(P in B))return;B=B[P]}h=h[h.length-1];F=B[h];t=t(F);t!=F&&null!=t&&$jscomp.defineProperty(B,h,{configurable:!0,writable:!0,value:t})};
$jscomp.polyfillIsolated=function(h,t,B,F){var P=h.split(".");h=1===P.length;F=P[0];F=!h&&F in $jscomp.polyfills?$jscomp.polyfills:$jscomp.global;for(var T=0;T<P.length-1;T++){var M=P[T];if(!(M in F))return;F=F[M]}P=P[P.length-1];B=$jscomp.IS_SYMBOL_NATIVE&&"es6"===B?F[P]:null;t=t(B);null!=t&&(h?$jscomp.defineProperty($jscomp.polyfills,P,{configurable:!0,writable:!0,value:t}):t!==B&&($jscomp.propertyToPolyfillSymbol[P]=$jscomp.IS_SYMBOL_NATIVE?$jscomp.global.Symbol(P):$jscomp.POLYFILL_PREFIX+P,P=
$jscomp.propertyToPolyfillSymbol[P],$jscomp.defineProperty(F,P,{configurable:!0,writable:!0,value:t})))};$jscomp.polyfill("Array.from",function(h){return h?h:function(t,B,F){B=null!=B?B:function(H){return H};var P=[],T="undefined"!=typeof Symbol&&Symbol.iterator&&t[Symbol.iterator];if("function"==typeof T){t=T.call(t);for(var M=0;!(T=t.next()).done;)P.push(B.call(F,T.value,M++))}else for(T=t.length,M=0;M<T;M++)P.push(B.call(F,t[M],M));return P}},"es6","es3");
(function(h,t){"object"===typeof exports&&"undefined"!==typeof module?module.exports=t():"function"===typeof define&&define.amd?define(t):(h=h||self,h.BSN=t())})(this,function(){function h(a,e){return a.classList.contains(e)}function t(a,e){a.classList.remove(e)}function B(a,e,n,x){a.addEventListener(e,n,x||!1)}function F(a,e,n,x){a.removeEventListener(e,n,x||!1)}function P(a,e,n,x){B(a,e,function v(z){z.target===a&&(n(z),F(a,e,v,x))},x)}function T(a){a=fa?window.getComputedStyle(a)[ua]:0;a=parseFloat(a);
return a="number"!==typeof a||isNaN(a)?0:1E3*a}function M(a,e){var n=0;T(a)?P(a,va,function(x){!n&&e(x);n=1}):setTimeout(function(){!n&&e();n=1},17)}function H(a,e){e=e&&e instanceof Element?e:document;return a instanceof Element?a:e.querySelector(a)}function V(a,e){try{a()}catch(n){console.error(e+": "+n)}}function K(a,e,n){a=new CustomEvent(a+".bs."+e,{cancelable:!0});a.relatedTarget=n;return a}function J(a){this&&this.dispatchEvent(a)}function ha(a){function e(r){y=r&&r.target.closest(".alert");
(a=H('[data-dismiss="alert"]',y))&&y&&(a===r.target||a.contains(r.target))&&x.close()}function n(){F(a,"click",e);y.parentNode.removeChild(y);J.call(y,v)}var x=this,y,z=K("close","alert"),v=K("closed","alert");x.close=function(){y&&a&&h(y,"show")&&(J.call(y,z),z.defaultPrevented||(x.dispose(),t(y,"show"),h(y,"fade")?M(y,n):n()))};x.dispose=function(){F(a,"click",e);delete a.Alert};V(function(){a=H(a);y=a.closest(".alert");a.Alert&&a.Alert.dispose();a.Alert||B(a,"click",e);x.element=a;a.Alert=x},"BSN.Alert")}
function C(a,e){a.classList.add(e)}function ia(a){function e(m){var u,q="LABEL"===m.target.tagName?m.target:m.target.closest("LABEL")?m.target.closest("LABEL"):null;if(u=q&&q.getElementsByTagName("INPUT")[0]){J.call(u,l);J.call(a,l);if("checkbox"===u.type){if(l.defaultPrevented)return;u.checked?(t(q,"active"),u.getAttribute("checked"),u.removeAttribute("checked"),u.checked=!1):(C(q,"active"),u.getAttribute("checked"),u.setAttribute("checked","checked"),u.checked=!0);a.toggled||(a.toggled=!0)}if("radio"===
u.type&&!a.toggled){if(l.defaultPrevented)return;if(!u.checked||0===m.screenX&&0==m.screenY)C(q,"active"),C(q,"focus"),u.setAttribute("checked","checked"),u.checked=!0,a.toggled=!0,Array.from(r).map(function(A){var g=A.getElementsByTagName("INPUT")[0];A!==q&&h(A,"active")&&(J.call(g,l),t(A,"active"),g.removeAttribute("checked"),g.checked=!1)})}setTimeout(function(){a.toggled=!1},50)}}function n(m){32===(m.which||m.keyCode)&&m.target===document.activeElement&&e(m)}function x(m){32===(m.which||m.keyCode)&&
m.preventDefault()}function y(m){var u="focusin"===m.type?C:t;"INPUT"===m.target.tagName&&u(m.target.closest(".btn"),"focus")}function z(m){m(a,"click",e);m(a,"keyup",n);m(a,"keydown",x);m(a,"focusin",y);m(a,"focusout",y)}var v=this,r,l=K("change","button");v.dispose=function(){z(F);delete a.Button};V(function(){a=H(a);a.Button&&a.Button.dispose();r=a.getElementsByClassName("btn");r.length&&(a.Button||z(B),a.toggled=!1,a.Button=v,Array.from(r).map(function(m){!h(m,"active")&&H("input:checked",m)&&
C(m,"active");h(m,"active")&&!H("input:checked",m)&&t(m,"active")}))},"BSN.Button")}function ja(a,e){function n(){!1===f.interval||h(a,"paused")||(C(a,"paused"),!b.isSliding&&(clearInterval(b.timer),b.timer=null))}function x(){!1!==f.interval&&h(a,"paused")&&(t(a,"paused"),!b.isSliding&&(clearInterval(b.timer),b.timer=null),!b.isSliding&&c.cycle())}function y(d){d.preventDefault();if(!b.isSliding){if((d=d.target)&&!h(d,"active")&&d.getAttribute("data-slide-to"))b.index=parseInt(d.getAttribute("data-slide-to"));
else return!1;c.slideTo(b.index)}}function z(d){d.preventDefault();b.isSliding||(d=d.currentTarget||d.srcElement,d===G?b.index++:d===D&&b.index--,c.slideTo(b.index))}function v(d){if(!b.isSliding){switch(d.which){case 39:b.index++;break;case 37:b.index--;break;default:return}c.slideTo(b.index)}}function r(d){f.pause&&f.interval&&(d(a,Y[0],n),d(a,Y[1],x),d(a,X.start,n,U),d(a,X.end,x,U));f.touch&&1<p.length&&d(a,X.start,m,U);G&&d(G,"click",z);D&&d(D,"click",z);N&&d(N,"click",y);f.keyboard&&d(window,
"keydown",v)}function l(d){d(a,X.move,u,U);d(a,X.end,q,U)}function m(d){b.isTouch||(b.touchPosition.startX=d.changedTouches[0].pageX,a.contains(d.target)&&(b.isTouch=!0,l(B)))}function u(d){if(b.isTouch){if(b.touchPosition.currentX=d.changedTouches[0].pageX,"touchmove"===d.type&&1<d.changedTouches.length)return d.preventDefault(),!1}else d.preventDefault()}function q(d){if(b.isTouch&&!b.isSliding&&(b.touchPosition.endX=b.touchPosition.currentX||d.changedTouches[0].pageX,b.isTouch)){if(a.contains(d.target)&&
a.contains(d.relatedTarget)||!(75>Math.abs(b.touchPosition.startX-b.touchPosition.endX)))b.touchPosition.currentX<b.touchPosition.startX?b.index++:b.touchPosition.currentX>b.touchPosition.startX&&b.index--,b.isTouch=!1,c.slideTo(b.index);else return!1;l(F)}}function A(d){Array.from(O).map(function(k){t(k,"active")});O[d]&&C(O[d],"active")}function g(d){if(b.touchPosition){var k=b.index;d=d&&d.target!==p[k]?1E3*d.elapsedTime+100:20;var E=c.getActiveIndex(),R="left"===b.direction?"next":"prev";b.isSliding&&
setTimeout(function(){b.touchPosition&&(b.isSliding=!1,C(p[k],"active"),t(p[E],"active"),t(p[k],"carousel-item-"+R),t(p[k],"carousel-item-"+b.direction),t(p[E],"carousel-item-"+b.direction),J.call(a,w),document.hidden||!f.interval||h(a,"paused")||c.cycle())},d)}}e=e||{};var c=this,b,f,L,w,p,D,G,N,O;c.cycle=function(){b.timer&&(clearInterval(b.timer),b.timer=null);b.timer=setInterval(function(){var d=b.index||c.getActiveIndex(),k=a.getBoundingClientRect();k.top<=(window.innerHeight||document.documentElement.clientHeight)&&
0<=k.bottom&&(d++,c.slideTo(d))},f.interval)};c.slideTo=function(d){if(!b.isSliding){var k=c.getActiveIndex();if(k!==d){if(k<d||0===k&&d===p.length-1)b.direction="left";else if(k>d||k===p.length-1&&0===d)b.direction="right";0>d?d=p.length-1:d>=p.length&&(d=0);var E="left"===b.direction?"next":"prev";L=K("slide","carousel",p[d]);w=K("slid","carousel",p[d]);J.call(a,L);L.defaultPrevented||(b.index=d,b.isSliding=!0,clearInterval(b.timer),b.timer=null,A(d),T(p[d])&&h(a,"slide")?(C(p[d],"carousel-item-"+
E),p[d].offsetWidth,C(p[d],"carousel-item-"+b.direction),C(p[k],"carousel-item-"+b.direction),M(p[d],g)):(C(p[d],"active"),p[d].offsetWidth,t(p[k],"active"),setTimeout(function(){b.isSliding=!1;f.interval&&a&&!h(a,"paused")&&c.cycle();J.call(a,w)},100)))}}};c.getActiveIndex=function(){return Array.from(p).indexOf(a.getElementsByClassName("carousel-item active")[0])||0};c.dispose=function(){var d=["left","right","prev","next"];Array.from(p).map(function(k,E){h(k,"active")&&A(E);d.map(function(R){return t(k,
"carousel-item-"+R)})});clearInterval(b.timer);r(F);b={};f={};delete a.Carousel};V(function(){a=H(a);a.Carousel&&a.Carousel.dispose();p=a.getElementsByClassName("carousel-item");D=a.getElementsByClassName("carousel-control-prev")[0];G=a.getElementsByClassName("carousel-control-next")[0];O=(N=a.getElementsByClassName("carousel-indicators")[0])&&N.getElementsByTagName("LI")||[];if(!(2>p.length)){var d=a.getAttribute("data-interval");d="false"===d?0:parseInt(d);var k="false"===a.getAttribute("data-touch")?
0:1,E="hover"===a.getAttribute("data-pause")||!1,R="true"===a.getAttribute("data-keyboard")||!1,S=e.interval,W=e.touch;f={};f.keyboard=!0===e.keyboard||R;f.pause="hover"===e.pause||E?"hover":!1;f.touch=W||k;f.interval="number"===typeof S?S:!1===S||0===d||!1===d?0:isNaN(d)?5E3:d;0>c.getActiveIndex()&&(p.length&&C(p[0],"active"),O.length&&A(0));b={direction:"left",index:0,timer:null,isSliding:!1,isTouch:!1,touchPosition:{startX:0,currentX:0,endX:0}};r(B);f.interval&&c.cycle();a.Carousel=c}},"BSN.Carousel")}
function ka(a,e){function n(g,c){J.call(g,m);m.defaultPrevented||(g.isAnimating=!0,C(g,"collapsing"),t(g,"collapse"),g.style.height=g.scrollHeight+"px",M(g,function(){g.isAnimating=!1;g.setAttribute("aria-expanded","true");c.setAttribute("aria-expanded","true");t(g,"collapsing");C(g,"collapse");C(g,"show");g.style.height="";J.call(g,u)}))}function x(g,c){J.call(g,q);q.defaultPrevented||(g.isAnimating=!0,g.style.height=g.scrollHeight+"px",t(g,"collapse"),t(g,"show"),C(g,"collapsing"),g.offsetWidth,
g.style.height="0px",M(g,function(){g.isAnimating=!1;g.setAttribute("aria-expanded","false");c.setAttribute("aria-expanded","false");t(g,"collapsing");C(g,"collapse");g.style.height="";J.call(g,A)}))}e=e||{};var y=this,z=null,v=null,r,l,m,u,q,A;y.toggle=function(g){(g&&"A"===g.target.tagName||"A"===a.tagName)&&g.preventDefault();if(a.contains(g.target)||g.target===a)h(v,"show")?y.hide():y.show()};y.hide=function(){v.isAnimating||(x(v,a),C(a,"collapsed"))};y.show=function(){z&&(l=(r=z.getElementsByClassName("collapse show")[0])&&
(H('[data-target="#'+r.id+'"]',z)||H('[href="#'+r.id+'"]',z)));v.isAnimating||(l&&r!==v&&(x(r,l),C(l,"collapsed")),n(v,a),t(a,"collapsed"))};y.dispose=function(){F(a,"click",y.toggle);delete a.Collapse};V(function(){a=H(a);a.Collapse&&a.Collapse.dispose();var g=a.getAttribute("data-parent");m=K("show","collapse");u=K("shown","collapse");q=K("hide","collapse");A=K("hidden","collapse");v=H(e.target||a.getAttribute("data-target")||a.getAttribute("href"));v.isAnimating=!1;z=a.closest(e.parent||g);a.Collapse||
B(a,"click",y.toggle);a.Collapse=y},"BSN.Collapse")}function aa(a){a.focus?a.focus():a.setActive()}function la(){return{y:window.pageYOffset||document.documentElement.scrollTop,x:window.pageXOffset||document.documentElement.scrollLeft}}function ma(a,e,n,x){var y=/\b(top|bottom|left|right)+/,z=e.offsetWidth,v=e.offsetHeight,r=document.documentElement.clientWidth||document.body.clientWidth,l=document.documentElement.clientHeight||document.body.clientHeight;a=a.getBoundingClientRect();x=x===document.body?
la():{x:x.offsetLeft+x.scrollLeft,y:x.offsetTop+x.scrollTop};var m=a.right-a.left,u=a.bottom-a.top,q=h(e,"popover"),A=H(".arrow",e),g=0>a.top+u/2-v/2,c=0>a.left+m/2-z/2,b=a.left+z/2+m/2>=r,f=a.top+v/2+u/2>=l,L=0>a.top-v,w=0>a.left-z;l=a.top+v+u>=l;var p=a.left+z+m>=r;n=("left"===n||"right"===n)&&w&&p?"top":n;n="top"===n&&L?"bottom":n;n="bottom"===n&&l?"top":n;n="left"===n&&w?"right":n;n="right"===n&&p?"left":n;-1===e.className.indexOf(n)&&(e.className=e.className.replace(y,n));y=A.offsetWidth;l=A.offsetHeight;
if("left"===n||"right"===n){var D="left"===n?a.left+x.x-z-(q?y:0):a.left+x.x+m;if(g){var G=a.top+x.y;var N=u/2-y}else f?(G=a.top+x.y-v+u,N=v-u/2-y):(G=a.top+x.y-v/2+u/2,N=v/2-(q?.9*l:l/2))}else if("top"===n||"bottom"===n)if(G="top"===n?a.top+x.y-v-(q?l:0):a.top+x.y+u,c){D=0;var O=a.left+m/2-y}else b?(D=r-1.01*z,O=z-(r-a.left)+m/2-y/2):(D=a.left+x.x-z/2+m/2,O=z/2-(q?y:y/2));e.style.top=G+"px";e.style.left=D+"px";N&&(A.style.top=N+"px");O&&(A.style.left=O+"px")}function na(a,e){function n(w){(w.href&&
"#"===w.href.slice(-1)||w.parentNode&&w.parentNode.href&&"#"===w.parentNode.href.slice(-1))&&this.preventDefault()}function x(){var w=a.open?B:F;w(document,"click",y);w(document,"keydown",v);w(document,"keyup",r);w(document,"focus",y,!0)}function y(w){if(void 0!==w.target.getAttribute){var p=w.target,D=p&&(p.getAttribute("data-toggle")||p.parentNode&&p.parentNode.getAttribute&&p.parentNode.getAttribute("data-toggle"));if("focus"!==w.type||p!==a&&p!==b&&!b.contains(p))if(p!==b&&!b.contains(p)||!L&&
!D)g=p===a||a.contains(p)?a:null,l.hide(),n.call(w,p)}}function z(w){g=a;l.show();n.call(w,w.target)}function v(w){var p=w.which||w.keyCode;38!==p&&40!==p||w.preventDefault()}function r(w){var p=w.keyCode;w=w.which||p;var D=document.activeElement;p=D===a;var G=b.contains(D),N=D.parentNode===b||D.parentNode.parentNode===b;D=f.indexOf(D);if(N){do if(D=p?0:38===w?1<D?D-1:0:40===w?D<f.length-1?D+1:D:D,0===D||D===f[length]-1)break;while(!f[D].offsetHeight);f[D]&&aa(f[D])}(f.length&&N||!f.length&&(G||p)||
!G)&&a.open&&27===w&&(l.toggle(),g=null)}var l=this,m,u,q,A,g=null,c,b,f=[],L;l.show=function(){m=K("show","dropdown",g);J.call(c,m);m.defaultPrevented||(C(b,"show"),C(c,"show"),a.setAttribute("aria-expanded",!0),a.open=!0,F(a,"click",z),setTimeout(function(){aa(b.getElementsByTagName("INPUT")[0]||f.length&&f[0]||a);x();u=K("shown","dropdown",g);J.call(c,u)},1))};l.hide=function(){q=K("hide","dropdown",g);J.call(c,q);q.defaultPrevented||(t(b,"show"),t(c,"show"),a.setAttribute("aria-expanded",!1),
a.open=!1,x(),aa(a),setTimeout(function(){a.Dropdown&&B(a,"click",z)},1),A=K("hidden","dropdown",g),J.call(c,A))};l.toggle=function(){h(c,"show")&&a.open?l.hide():l.show()};l.dispose=function(){h(c,"show")&&a.open&&l.hide();F(a,"click",z);delete a.Dropdown};V(function(){a=H(a);a.Dropdown&&a.Dropdown.dispose();c=a.parentNode;b=H(".dropdown-menu",c);Array.from(b.children).map(function(w){Array.from(w.children).map(function(p){"A"===p.tagName&&f.push(p)});"A"===w.tagName&&f.push(w)});a.Dropdown||("tabindex"in
b||b.setAttribute("tabindex","0"),B(a,"click",z));L=!0===e||"true"===a.getAttribute("data-persist")||!1;a.open=!1;a.Dropdown=l},"BSN.Dropdown")}function oa(a,e){function n(){var k=h(document.body,"modal-open"),E=parseInt(getComputedStyle(document.body).paddingRight),R=document.documentElement.clientHeight!==document.documentElement.scrollHeight||document.body.clientHeight!==document.body.scrollHeight,S=c.clientHeight!==c.scrollHeight;D=y();c.style.paddingRight=!S&&D?D+"px":"";document.body.style.paddingRight=
S||R?E+(k?0:D)+"px":"";O.length&&O.map(function(W){var Z=getComputedStyle(W).paddingRight;W.style.paddingRight=S||R?parseInt(Z)+(k?0:D)+"px":parseInt(Z)+"px"})}function x(){document.body.style.paddingRight="";c.style.paddingRight="";O.length&&O.map(function(k){k.style.paddingRight=""})}function y(){var k=document.createElement("div");k.className="modal-scrollbar-measure";document.body.appendChild(k);var E=k.offsetWidth-k.clientWidth;document.body.removeChild(k);return E}function z(){(G=H(".modal-backdrop"))&&
!document.getElementsByClassName("modal show")[0]&&(document.body.removeChild(G),G=null);null===G&&(t(document.body,"modal-open"),x())}function v(k){k(window,"resize",g.update,U);k(c,"click",A);k(document,"keydown",q)}function r(){c.style.display="block";n();!document.getElementsByClassName("modal show")[0]&&C(document.body,"modal-open");C(c,"show");c.setAttribute("aria-hidden",!1);h(c,"fade")?M(c,l):l()}function l(){aa(c);c.isAnimating=!1;v(B);f=K("shown","modal",p);J.call(c,f)}function m(k){c.style.display=
"";a&&aa(a);G=H(".modal-backdrop");1!==k&&G&&h(G,"show")&&!document.getElementsByClassName("modal show")[0]?(t(G,"show"),M(G,z)):z();v(F);c.isAnimating=!1;w=K("hidden","modal");J.call(c,w)}function u(k){if(!c.isAnimating){var E=k.target,R="#"+c.getAttribute("id"),S=E.getAttribute("data-target")||E.getAttribute("href"),W=a.getAttribute("data-target")||a.getAttribute("href");!h(c,"show")&&(E===a&&S===R||a.contains(E)&&W===R)&&(p=c.modalTrigger=a,g.show(),k.preventDefault())}}function q(k){k=k.which;
!c.isAnimating&&d.keyboard&&27==k&&h(c,"show")&&g.hide()}function A(k){if(!c.isAnimating){var E=k.target,R="modal"===E.getAttribute("data-dismiss"),S=E.closest('[data-dismiss="modal"]');h(c,"show")&&(S||R||E===c&&"static"!==d.backdrop)&&(g.hide(),p=null,k.preventDefault())}}e=e||{};var g=this,c,b,f,L,w,p=null,D,G,N,O,d={};g.toggle=function(){h(c,"show")?g.hide():g.show()};g.show=function(){if(!h(c,"show")||!c.isAnimating)if(b=K("show","modal",p),J.call(c,b),!b.defaultPrevented){c.isAnimating=!0;var k=
document.getElementsByClassName("modal show")[0];k&&k!==c&&(k.modalTrigger&&k.modalTrigger.Modal.hide(),k.Modal&&k.Modal.hide());if(d.backdrop){var E=document.createElement("div");G=H(".modal-backdrop");null===G&&(E.setAttribute("class","modal-backdrop"+(d.animation?" fade":"")),G=E,document.body.appendChild(G))}!G||k||h(G,"show")||(G.offsetWidth,N=T(G),C(G,"show"));k?r():setTimeout(r,G&&N?N:0)}};g.hide=function(k){h(c,"show")&&(L=K("hide","modal"),J.call(c,L),L.defaultPrevented||(c.isAnimating=!0,
t(c,"show"),c.setAttribute("aria-hidden",!0),h(c,"fade")&&1!==k?M(c,m):m()))};g.setContent=function(k){H(".modal-content",c).innerHTML=k};g.update=function(){h(c,"show")&&n()};g.dispose=function(){g.hide(1);a?(F(a,"click",u),delete a.Modal):delete c.Modal};V(function(){a=H(a);var k=H(a.getAttribute("data-target")||a.getAttribute("href"));c=h(a,"modal")?a:k;O=Array.from(document.getElementsByClassName("fixed-top")).concat(Array.from(document.getElementsByClassName("fixed-bottom")));h(a,"modal")&&(a=
null);a&&a.Modal&&a.Modal.dispose();c&&c.Modal&&c.Modal.dispose();d.keyboard=!1===e.keyboard||"false"===c.getAttribute("data-keyboard")?!1:!0;d.backdrop="static"===e.backdrop||"static"===c.getAttribute("data-backdrop")?"static":!0;d.backdrop=!1===e.backdrop||"false"===c.getAttribute("data-backdrop")?!1:d.backdrop;d.animation=h(c,"fade")?!0:!1;d.content=e.content;c.isAnimating=!1;a&&!a.Modal&&B(a,"click",u);d.content&&g.setContent(d.content.trim());a?(c.modalTrigger=a,a.Modal=g):c.Modal=g},"BSN.Modal")}
function pa(a,e){function n(I){null!==q&&I.target===H(".close",q)&&u.hide()}function x(){return{0:e.title||a.getAttribute("data-title")||null,1:e.content||a.getAttribute("data-content")||null}}function y(){null===q&&a.focus()}function z(I){"hover"===f.trigger?(I(a,qa.down,u.show),I(a,Y[0],u.show),f.dismissible||I(a,Y[1],u.hide)):"click"==f.trigger?I(a,f.trigger,u.toggle):"focus"==f.trigger&&(g&&I(a,"click",y),I(a,f.trigger,u.toggle))}function v(I){q&&q.contains(I.target)||I.target===a||a.contains(I.target)||
u.hide()}function r(I){f.dismissible?I(document,"click",n):("focus"==f.trigger&&I(a,"blur",u.hide),"hover"==f.trigger&&I(document,X.start,v,U));I(window,"resize",u.hide,U)}function l(){r(B);J.call(a,k)}function m(){r(F);f.container.removeChild(q);q=A=null;J.call(a,R)}e=e||{};var u=this,q=null,A=0,g=/(iPhone|iPod|iPad)/.test(navigator.userAgent),c,b,f={},L,w,p,D,G,N,O,d,k,E,R,S,W,Z,ba,ca,da;u.toggle=function(){null===q?u.show():u.hide()};u.show=function(){clearTimeout(A);A=setTimeout(function(){if(null===
q&&(J.call(a,d),!d.defaultPrevented)){c=x()[0]||null;b=(b=x()[1])?b.trim():null;q=document.createElement("div");var I=document.createElement("div");C(I,"arrow");q.appendChild(I);if(null!==b&&null===f.template)q.setAttribute("role","tooltip"),null!==c&&(I=document.createElement("h3"),C(I,"popover-header"),I.innerHTML=f.dismissible?c+O:c,q.appendChild(I)),I=document.createElement("div"),C(I,"popover-body"),I.innerHTML=f.dismissible&&null===c?b+O:b,q.appendChild(I);else{I=document.createElement("div");
I.innerHTML=f.template.trim();q.className=I.firstChild.className;q.innerHTML=I.firstChild.innerHTML;I=H(".popover-header",q);var ra=H(".popover-body",q);c&&I&&(I.innerHTML=c.trim());b&&ra&&(ra.innerHTML=b.trim())}f.container.appendChild(q);q.style.display="block";!h(q,"popover")&&C(q,"popover");!h(q,f.animation)&&C(q,f.animation);!h(q,da)&&C(q,da);ma(a,q,f.placement,f.container);!h(q,"show")&&C(q,"show");f.animation?M(q,l):l()}},20)};u.hide=function(){clearTimeout(A);A=setTimeout(function(){q&&null!==
q&&h(q,"show")&&(J.call(a,E),E.defaultPrevented||(t(q,"show"),f.animation?M(q,m):m()))},f.delay)};u.dispose=function(){u.hide();z(F);delete a.Popover};V(function(){a=H(a);a.Popover&&a.Popover.dispose();L=a.getAttribute("data-trigger");w=a.getAttribute("data-animation");p=a.getAttribute("data-placement");D=a.getAttribute("data-dismissible");G=a.getAttribute("data-delay");N=a.getAttribute("data-container");O='<button type="button" class="close">\u00d7</button>';d=K("show","popover");k=K("shown","popover");
E=K("hide","popover");R=K("hidden","popover");S=H(e.container);W=H(N);Z=a.closest(".modal");ba=a.closest(".fixed-top");ca=a.closest(".fixed-bottom");f.template=e.template?e.template:null;f.trigger=e.trigger?e.trigger:L||"hover";f.animation=e.animation&&"fade"!==e.animation?e.animation:w||"fade";f.placement=e.placement?e.placement:p||"top";f.delay=parseInt(e.delay||G)||200;f.dismissible=e.dismissible||"true"===D?!0:!1;f.container=S?S:W?W:ba?ba:ca?ca:Z?Z:document.body;da="bs-popover-"+f.placement;var I=
x();c=I[0];if((b=I[1])||f.template)a.Popover||z(B),a.Popover=u},"BSN.Popover")}function sa(a,e){function n(){f.style.height="";t(f,"collapsing");m.isAnimating=!1}function x(){f?G?n():setTimeout(function(){f.style.height=N+"px";f.offsetWidth;M(f,n)},50):m.isAnimating=!1;A=K("shown","tab",L);J.call(b,A)}function y(){f&&(w.style.float="left",p.style.float="left",D=w.scrollHeight);q=K("show","tab",L);c=K("hidden","tab",b);J.call(b,q);q.defaultPrevented||(C(p,"active"),t(w,"active"),f&&(N=p.scrollHeight,
G=N===D,C(f,"collapsing"),f.style.height=D+"px",f.offsetHeight,w.style.float="",p.style.float=""),h(p,"fade")?setTimeout(function(){C(p,"show");M(p,x)},20):x(),J.call(L,c))}function z(){var d=m.getElementsByClassName("active"),k;1!==d.length||h(d[0].parentNode,"dropdown")?1<d.length&&(k=d[d.length-1]):k=d[0];return k}function v(d){d.preventDefault();b=d.currentTarget;!m.isAnimating&&r.show()}e=e||{};var r=this,l,m,u,q,A,g,c,b,f=!1,L,w,p,D,G,N,O;r.show=function(){b=b||a;h(b,"active")||(p=H(b.getAttribute("href")),
L=z(),w=H(z().getAttribute("href")),g=K("hide","tab",b),J.call(L,g),g.defaultPrevented||(m.isAnimating=!0,t(L,"active"),L.setAttribute("aria-selected","false"),C(b,"active"),b.setAttribute("aria-selected","true"),u&&(h(a.parentNode,"dropdown-menu")?h(u,"active")||C(u,"active"):h(u,"active")&&t(u,"active")),h(w,"fade")?(t(w,"show"),M(w,y)):y()))};r.dispose=function(){F(a,"click",v);delete a.Tab};V(function(){a=H(a);a.Tab&&a.Tab.dispose();l=a.getAttribute("data-height");u=(m=a.closest(".nav"))&&H(".dropdown-toggle",
m);O=fa&&!1!==e.height&&"false"!==l?!0:!1;m.isAnimating=!1;a.Tab||B(a,"click",v);O&&(f=H(z().getAttribute("href")).parentNode);a.Tab=r},"BSN.Tab")}function ta(a,e){function n(){t(r,"showing");C(r,"show");J.call(r,c);f.autohide&&v.hide()}function x(){C(r,"hide");J.call(r,b)}function y(){t(r,"show");f.animation?M(r,x):x()}function z(){clearTimeout(l);F(a,"click",v.hide);delete a.Toast}e=e||{};var v=this,r,l=0,m,u,q,A,g,c,b,f={};v.show=function(){r&&!h(r,"show")&&(J.call(r,A),A.defaultPrevented||(f.animation&&
C(r,"fade"),t(r,"hide"),r.offsetWidth,C(r,"showing"),f.animation?M(r,n):n()))};v.hide=function(L){r&&h(r,"show")&&(J.call(r,g),g.defaultPrevented||(L?y():l=setTimeout(y,f.delay)))};v.dispose=function(){f.animation?M(r,z):z()};V(function(){a=H(a);a.Toast&&a.Toast.dispose();r=a.closest(".toast");m=a.getAttribute("data-animation");u=a.getAttribute("data-autohide");q=a.getAttribute("data-delay");A=K("show","toast");g=K("hide","toast");c=K("shown","toast");b=K("hidden","toast");f.animation=!1===e.animation||
"false"===m?0:1;f.autohide=!1===e.autohide||"false"===u?0:1;f.delay=parseInt(e.delay||q)||500;a.Toast||B(a,"click",v.hide);a.Toast=v},"BSN.Toast")}var va="webkitTransition"in document.body.style?"webkitTransitionEnd":"transitionend",fa="webkitTransition"in document.body.style||"transition"in document.body.style,ua="webkitTransition"in document.body.style?"webkitTransitionDuration":"transitionDuration",X={start:"touchstart",end:"touchend",move:"touchmove",cancel:"touchcancel"},Y="onmouseleave"in document?
["mouseenter","mouseleave"]:["mouseover","mouseout"],U=function(){var a=!1;try{var e=Object.defineProperty({},"passive",{get:function(){a=!0}});P(document,"DOMContentLoaded",function(){},e)}catch(n){}return a}()?{passive:!0}:!1,qa={down:"mousedown",up:"mouseup"},Q={},ea=function(a){a=a||document;var e=function(x,y){Array.from(y).map(function(z){return new x(z)})},n;for(n in Q)e(Q[n][0],a.querySelectorAll(Q[n][1]))};Q.Alert=[ha,'[data-dismiss="alert"]'];Q.Button=[ia,'[data-toggle="buttons"]'];Q.Carousel=
[ja,'[data-ride="carousel"]'];Q.Collapse=[ka,'[data-toggle="collapse"]'];Q.Dropdown=[na,'[data-toggle="dropdown"]'];Q.Modal=[oa,'[data-toggle="modal"]'];Q.Popover=[pa,'[data-toggle="popover"],[data-tip="popover"]'];Q.ScrollSpy=[function(a,e){function n(){var A=m.getElementsByTagName("A");v.length!==A.length&&(v.items=[],v.targets=[],Array.from(A).map(function(g){var c=g.getAttribute("href");if(c=c&&"#"===c.charAt(0)&&"#"!==c.slice(-1)&&H(c))v.items.push(g),v.targets.push(c)}),v.length=A.length)}function x(){n();
v.scrollOffset=v.isWindow?la().y:a.scrollTop;v.items.map(function(A,g){a:{A=v.items[g];var c=v.targets[g],b=h(A,"dropdown-item")&&A.closest(".dropdown-menu");b=b&&b.previousElementSibling;var f=A.nextElementSibling,L=f&&f.getElementsByClassName("active").length,w=v.isWindow&&c.getBoundingClientRect();f=h(A,"active")||!1;c=(v.isWindow?w.top+v.scrollOffset:c.offsetTop)-q.offset;w=v.isWindow?w.bottom+v.scrollOffset-q.offset:v.targets[g+1]?v.targets[g+1].offsetTop-q.offset:a.scrollHeight;c=L||v.scrollOffset>=
c&&w>v.scrollOffset;if(!f&&c)C(A,"active"),b&&!h(b,"active")&&C(b,"active"),J.call(a,K("activate","scrollspy",v.items[g]));else if(f&&!c)t(A,"active"),b&&h(b,"active")&&!A.parentNode.getElementsByClassName("active").length&&t(b,"active");else if(f&&c||!c&&!f){g=void 0;break a}g=void 0}return g})}function y(A){A(u,"scroll",z.refresh,U);A(window,"resize",z.refresh,U)}e=e||{};var z=this,v,r,l,m,u,q={};z.refresh=function(){x()};z.dispose=function(){y(F);delete a.ScrollSpy};V(function(){a=H(a);a.ScrollSpy&&
a.ScrollSpy.dispose();r=a.getAttribute("data-target");l=a.getAttribute("data-offset");m=H(e.target||r);u=a.offsetHeight<a.scrollHeight?a:window;m&&(q.target=m,q.offset=parseInt(e.offset||l)||10,v={length:0,items:[],targets:[]},v.isWindow=u===window,a.ScrollSpy||y(B),z.refresh(),a.ScrollSpy=z)},"BSN.ScrollSpy")},'[data-spy="scroll"]'];Q.Tab=[sa,'[data-toggle="tab"]'];Q.Toast=[ta,'[data-dismiss="toast"]'];Q.Tooltip=[function(a,e){function n(){return a.getAttribute("title")||a.getAttribute("data-title")||
a.getAttribute("data-original-title")}function x(E){l&&l.contains(E.target)||E.target===a||a.contains(E.target)||r.hide()}function y(){B(document,X.start,x,U);B(window,"resize",r.hide,U);J.call(a,f)}function z(){F(document,X.start,x,U);F(window,"resize",r.hide,U);k.container.removeChild(l);m=l=null;J.call(a,w)}function v(E){E(a,qa.down,r.show);E(a,Y[0],r.show);E(a,Y[1],r.hide)}e=e||{};var r=this,l=null,m=0,u,q,A,g,c,b,f,L,w,p,D,G,N,O,d,k={};r.show=function(){clearTimeout(m);m=setTimeout(function(){if(null===
l&&(J.call(a,b),!b.defaultPrevented)){if(u=n()){l=document.createElement("div");if(k.template){var E=document.createElement("div");E.innerHTML=k.template.trim();l.className=E.firstChild.className;l.innerHTML=E.firstChild.innerHTML;H(".tooltip-inner",l).innerHTML=u.trim()}else E=document.createElement("div"),C(E,"arrow"),l.appendChild(E),E=document.createElement("div"),C(E,"tooltip-inner"),l.appendChild(E),E.innerHTML=u;l.style.left="0";l.style.top="0";l.setAttribute("role","tooltip");!h(l,"tooltip")&&
C(l,"tooltip");!h(l,k.animation)&&C(l,k.animation);!h(l,d)&&C(l,d);k.container.appendChild(l)}ma(a,l,k.placement,k.container);!h(l,"show")&&C(l,"show");k.animation?M(l,y):y()}},20)};r.hide=function(){clearTimeout(m);m=setTimeout(function(){l&&h(l,"show")&&(J.call(a,L),L.defaultPrevented||(t(l,"show"),k.animation?M(l,z):z()))},k.delay)};r.toggle=function(){l?r.hide():r.show()};r.dispose=function(){v(F);r.hide();a.setAttribute("title",a.getAttribute("data-original-title"));a.removeAttribute("data-original-title");
delete a.Tooltip};V(function(){a=H(a);a.Tooltip&&a.Tooltip.dispose();q=a.getAttribute("data-animation");A=a.getAttribute("data-placement");g=a.getAttribute("data-delay");c=a.getAttribute("data-container");b=K("show","tooltip");f=K("shown","tooltip");L=K("hide","tooltip");w=K("hidden","tooltip");p=H(e.container);D=H(c);G=a.closest(".modal");N=a.closest(".fixed-top");O=a.closest(".fixed-bottom");k.animation=e.animation&&"fade"!==e.animation?e.animation:q||"fade";k.placement=e.placement?e.placement:
A||"top";k.template=e.template?e.template:null;k.delay=parseInt(e.delay||g)||200;k.container=p?p:D?D:N?N:O?O:G?G:document.body;d="bs-tooltip-"+k.placement;if(u=n())a.Tooltip||(a.setAttribute("data-original-title",u),a.removeAttribute("title"),v(B)),a.Tooltip=r},"BSN.Tooltip")},'[data-toggle="tooltip"],[data-tip="tooltip"]'];document.body?ea():P(document,"DOMContentLoaded",ea);return{Alert:ha,Button:ia,Carousel:ja,Collapse:ka,Dropdown:na,Modal:oa,Popover:pa,Tab:sa,Toast:ta,initCallback:ea,removeDataAPI:function(a){a=
a||document;var e=function(x,y){Array.from(y).map(function(z){return z[x].dispose()})},n;for(n in Q)e(n,a.querySelectorAll(Q[n][1]))},componentsInit:Q,Version:"3.0.3"}});
var locales=[{"code":"de-DE","desc":"Deutsch"},{"code":"en-US","desc":"English"},{"code":"es-VE","desc":"Español"},{"code":"fi-FI","desc":"Finnish"},{"code":"fr-FR","desc":"Français"},{"code":"it-IT","desc":"Italiano"},{"code":"ko-KR","desc":"한국어"},{"code":"nl-NL","desc":"Nederlands"}];var phrases={"%{name} added to queue":{"de-DE":"%{name} hinzugefügt","es-VE":"%{name} agregado a la cola de reproducción","fi-FI":"%{name} lisätty jonoon","fr-FR":"%{name} ajouté à la queue","it-IT":"%{name} aggiunto alla coda","ko-KR":"순서에 %{name} 추가함","nl-NL":"%{name} toegevoegd"},"%{name} added to queue position %{to}":{"de-DE":"%{name} an Warteschlangenposition %{to} hinzugefügt","es-VE":"%{name} agregado a la cola de reproducción en la posición %{to}","fi-FI":"%{name} lisätty jonossa kohtaan %{to}","fr-FR":"%{name} à la queue en position %{to}","it-IT":"%{name} aggiunto alla coda in posizione %{to}","ko-KR":"%{to} 순서 위치에 %{name} 추가함","nl-NL":"%{name} toegevoegd aan wachtrijpositie %{to}"},"1.0":{},"2.0":{},"2.1":{},"3.0":{},"AP Mode":{},"About":{"de-DE":"Über myMPD","es-VE":"Acerca de","fi-FI":"Tietoja","fr-FR":"A propos","it-IT":"Informazioni","ko-KR":"정보","nl-NL":"Over myMPD"},"Action":{"de-DE":"Aktion","es-VE":"Acción","fi-FI":"Toiminto","fr-FR":"Action","it-IT":"Azione","ko-KR":"기능","nl-NL":"Aktie"},"Add":{"de-DE":"Hinzufügen","es-VE":"Agregar","fi-FI":"Lisää","fr-FR":"Ajouter","it-IT":"Aggiungi","ko-KR":"추가","nl-NL":"Toevoegen"},"Add after current playing song":{"de-DE":"Nach aktuellem Lied hinzufügen","es-VE":"Añadir despues de la canción actual","fi-FI":"Lisää soivan kappaleen jälkeen","fr-FR":"Ajouter après la chanson en cours","it-IT":"Aggiungi dopo il brano corrente","ko-KR":"지금 연주 중인 곡 다음에 추가","nl-NL":"Als volgende afspelen"},"Add and play playlist":{"de-DE":"Spiele Wiedergabeliste ab","it-IT":"Aggiungi e riproduci la lista si riproduzione","ko-KR":"연주목록에 추가하고 연주하기"},"Add bookmark":{"de-DE":"Lesezeichen hinzufügen","es-VE":"Agregar marcador","fi-FI":"Lisää kirjanmerkki","fr-FR":"Ajouter marque-page","it-IT":"Aggiungi segnalibro","ko-KR":"즐겨찾기 추가","nl-NL":"Voeg bladwijzer toe"},"Add random":{"de-DE":"Zufällig hinzufügen","es-VE":"Agregar aleatorio","fi-FI":"Lisää satunnainen","fr-FR":"Ajout aléatoire","it-IT":"Aggiunta casuale","ko-KR":"무작위 추가","nl-NL":"Voeg willekeurige toe"},"Add smart playlist":{"de-DE":"Neue intelligente Wiedergabeliste","es-VE":"Agregar Lista de reproducción inteligente","fi-FI":"Lisää älykäs soittolista","fr-FR":"Ajouter une liste de lecture intelligente","it-IT":"Aggiungi lista di riproduzione smart","ko-KR":"스마트 연주목록 추가","nl-NL":"Slimme afspeellijst toevoegen"},"Add stream":{"de-DE":"Stream hinzufügen","es-VE":"Agregar fuente","fi-FI":"Lisää streami","fr-FR":"Ajouter flux","it-IT":"Aggiungi flusso","ko-KR":"스트리밍 추가","nl-NL":"Stream toevoegen"},"Add to home screen":{"de-DE":"Zum Startbildschirm hinzufügen","es-VE":"Agregar a pantalla de inicio","fi-FI":"Lisää aloitus näkymään","fr-FR":"Ajouter à l'écran d'accueil","it-IT":"Aggiungi alla schermata home","ko-KR":"홈 화면에 추가","nl-NL":"Aan startscherm toevoegen"},"Add to homescreen":{"de-DE":"Zum Homescreen hinzufügen","it-IT":"Aggiungi alla pagina di home","ko-KR":"홈 화면에 추가"},"Add to playlist":{"de-DE":"Zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar a lista de reproducción","fi-FI":"Lisää soittolistaan","fr-FR":"Ajouter à la liste de lecture","it-IT":"Aggingi alla lista di riproduzione","ko-KR":"연주목록에 추가","nl-NL":"Aan afspeellijst toevoegen"},"Add to queue":{"de-DE":"Zu Warteschlange hinzufügen","es-VE":"Agregar a la cola de reproducción","fi-FI":"Lisää jonoon","fr-FR":"Ajouter à la queue","it-IT":"Aggiungi alla coda","ko-KR":"순서에 추가","nl-NL":"Aan wachtrij toevoegen"},"Added %{uri} to playlist %{playlist}":{"de-DE":"%{uri} zu Wiedergabeliste %{playlist} hinzugefügt","es-VE":"%{uri} agregado a lista de reproducción %{playlist}","fi-FI":"%{uri} lisätty soittolistaan %{playlist}","fr-FR":"Ajout de %{uri} à la iste de lecture %{playlist}","it-IT":"Aggiunta di %{uri} alla lista di riproduzione %{playlist}","ko-KR":"%{uri}의 %{playlist} 연주목록 추가에 실패함","nl-NL":"%{uri} aan afspeellijst %{playlist} toegevoegd"},"Added all songs":{"de-DE":"Alle Lieder hinzugefügt","es-VE":"Agregadas todas las canciones","fi-FI":"Kaikki kappaleet lisätty","fr-FR":"Toutes les chansons ont été ajoutées","it-IT":"Tutti i brani sono stati aggiunti","ko-KR":"모든 곡을 추가함","nl-NL":"Alle nummers toegevoegd"},"Added songs to %{playlist}":{"de-DE":"Lieder zur Wiedergabeliste %{playlist} hinzugefügt","es-VE":"Canciones agregadas a la lista de reproducción %{playlist}","fi-FI":"Kappaleet lisätty soittolistaan %{playlist}","fr-FR":"Chansons ajoutées à la liste de lecture %{playlist}","it-IT":"Canzoni aggiunte alla lista di riproduzione %{playlist}","ko-KR":"%{playlist}에 곡 추가함","nl-NL":"Nummers aan %{playlist} toegevoegd"},"Added songs to queue":{"de-DE":"Lieder zur Warteschlange hinzugefügt","es-VE":"Canciones agregadas a la cola de reproducción","fi-FI":"Kappaleet lisätty jonoon","fr-FR":"Chansons ajoutées à la queue","it-IT":"Canzoni aggiunte alla coda","ko-KR":"순서에 곡 추가함","nl-NL":"Nummer aan wachtrij toegevoegd"},"Added stream %{streamUri} to queue":{"de-DE":"Stream %{streamUri} zu Warteschlange hinzugefügt","es-VE":"Agregar Fuente %{streamUri} a la cola de reproducción","fi-FI":"Streami %{streamUri} lisätty jonoon","fr-FR":"Flux %{streamUri} ajouté à la queue","it-IT":"Flusso %{streamUri} aggiunto alla coda","ko-KR":"%{streamUri} 스트리밍을 순서에 추가함","nl-NL":"Stream %{streamUri} aan wachtrij toevoegen"},"Adding random songs to queue failed":{"de-DE":"Zufällige Lieder konnten nicht zur Warteschlange hinzugefügt werden","es-VE":"Error al agregar canciones aleatorias a la cola de reproducción","fi-FI":"Satunnaisten kappaleiden lisääminen jonoon epäonnistui","fr-FR":"Echec de l'ajout aléatoire de chansons à la queue","it-IT":"Aggiunta di brani casuali alla coda fallita","ko-KR":"순서에 무작위 곡 추가 안 됨","nl-NL":"Toevoegen willekeurig nummer mislukt"},"Adding timer failed":{"de-DE":"Timer konnte nicht hinzugefügt werden","es-VE":"Fallo al agregar Temporizador","fi-FI":"Ajastimen lisäys epäonnistui","fr-FR":"Echec de l'ajout de temporisation","it-IT":"Impossibile aggiungere il timer","ko-KR":"타이머를 추가할 수 없음","nl-NL":"Toevoegen timer mislukt"},"Advanced":{"de-DE":"Erweitert","es-VE":"Avanzado","fi-FI":"Lisäasetukset","fr-FR":"Avancé","it-IT":"Avanzato","ko-KR":"고급","nl-NL":"Geavanceerd"},"AirPlay":{},"Akkordion Music Player":{},"Album":{"de-DE":"Album","es-VE":"Álbum","fi-FI":"Albumi","fr-FR":"Album","it-IT":"Album","ko-KR":"음반","nl-NL":"Album"},"AlbumArtist":{"de-DE":"Album Interpret","en-US":"Albumartist","es-VE":"Artista álbum","fi-FI":"Albumi Esittäjä","fr-FR":"Artiste de l'album","it-IT":"Artista dell'album","ko-KR":"음반 연주자","nl-NL":"Albumartiest"},"AlbumArtistSort":{"de-DE":"Album Interpret","es-VE":"Artista álbum","fi-FI":"AlbumiArtistiJärjestely","fr-FR":"Artiste de l'album","it-IT":"Artist dell'album per ordinamento","ko-KR":"음반 연주자 정렬","nl-NL":"Albumartiest"},"AlbumSort":{"de-DE":"Album","es-VE":"Álbum","fi-FI":"AlbumiJärjestely","fr-FR":"Album","it-IT":"Album per ordinamento","ko-KR":"음반 정렬","nl-NL":"Album"},"Albumart":{"de-DE":"Albumcover","es-VE":"Carátula del álbum","fi-FI":"Albumcover","fr-FR":"Jaquette","it-IT":"Copertina","ko-KR":"음반 표지","nl-NL":"Albumcover"},"Albums":{"de-DE":"Alben","es-VE":"Álbumes","fi-FI":"Albumit","fr-FR":"Albums","it-IT":"Album","ko-KR":"음반","nl-NL":"Albums"},"All":{"de-DE":"Alle","ko-KR":"모두"},"Allo Boss DAC":{},"Allo Digione":{},"Allo Katana DAC":{},"Allo Piano DAC 2.0/2.1":{},"Allo Piano DAC Plus 2.1":{},"Allo Piano DAC Plus 2.1 with Kali":{},"Any Tag":{"de-DE":"Alle Tags","es-VE":"Cualquier etiqueta","fi-FI":"Mikä tahansa tagi","fr-FR":"Tous les Tags","it-IT":"Qualunque tag","ko-KR":"모든 태그","nl-NL":"Alle tags"},"App":{"de-DE":"App","it-IT":"App","ko-KR":"앱"},"Appearance":{"de-DE":"Design","es-VE":"Apariencia","fi-FI":"Ulkoasu","fr-FR":"Apparence","it-IT":"Aspetto","ko-KR":"외관","nl-NL":"Uiterlijk"},"Append item to playlist":{"de-DE":"Ausgewähltes Element zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar elemento a lista de reproducción","fi-FI":"Lisää kohde soittolistaan","fr-FR":"Ajouter l'élément à la liste de lecture","it-IT":"Aggiungi l'elemento alla lista di riproduzione","ko-KR":"연주목록에 항목 추가","nl-NL":"Selectie aan afspeellijst toevoegen"},"Append item to queue":{"de-DE":"Ausgewähltes Element an Warteschlange anhängen","es-VE":"Agregar elemento a la cola de reproducción","fi-FI":"Lisää kohde jonoon","fr-FR":"Ajouter l'élément à la queue","it-IT":"Aggiungi elemento alla coda","ko-KR":"순서에 항목 추가","nl-NL":"Selectie aan wachtrij toevoegen"},"Append to queue":{"de-DE":"An Warteschlange anhängen","es-VE":"Añadir a la cola de reproducción","fi-FI":"Lisää jonoon","fr-FR":"Ajouter à la queue","it-IT":"Aggiungi in fondo alla coda","ko-KR":"순서에 추가","nl-NL":"Aan wachtrij toevoegen"},"ApplePi-DAC (Orchard Audio)":{},"Apply":{"de-DE":"Anwenden","es-VE":"Aplicar","fi-FI":"Käytä","fr-FR":"Appliquer","it-IT":"Applica","ko-KR":"적용","nl-NL":"Toepassen"},"Applying settings":{"de-DE":"Einstellungen werden angewendet","es-VE":"Aplicando configuraciones","fi-FI":"Asetuksia otetaan käyttöön","fr-FR":"Application des paramètres","it-IT":"Applicazione parametri","ko-KR":"설정 적용","nl-NL":"Instellingen toepassen"},"Arguments":{"de-DE":"Parameter","fr-FR":"Paramètres","it-IT":"Argomenti","ko-KR":"변수","nl-NL":"Argumenten"},"Artist":{"de-DE":"Künstler","es-VE":"Artista","fi-FI":"Artisti","fr-FR":"Artiste","it-IT":"Artista","ko-KR":"연주자","nl-NL":"Artiest"},"ArtistSort":{"de-DE":"Künstler","es-VE":"Artista","fi-FI":"ArtistiJärjestely","fr-FR":"Artiste","it-IT":"ArtistSort","ko-KR":"연주자 정렬","nl-NL":"Artiest"},"Artists":{"de-DE":"Interpreten","es-VE":"Artistas","fi-FI":"Artistit","fr-FR":"Artistes","it-IT":"Artisti","ko-KR":"연주자","nl-NL":"Artiesten"},"Audio":{},"Audio Settings":{},"Audio settings":{},"Audioinjector.net audio add on":{},"Audioinjector.net ultra":{},"Audiophonics I-SABRE Q2M DAC":{},"Audioquality":{},"Audiosense-pi":{},"Author":{"de-DE":"Autor","es-VE":"Autor","fi-FI":"Luoja","fr-FR":"Auteur","it-IT":"Autore","ko-KR":"저자","nl-NL":"Auteur"},"Auto":{"de-DE":"Auto","es-VE":"Auto","fi-FI":"Auto","fr-FR":"Auto","it-IT":"Auto","ko-KR":"자동","nl-NL":"Auto"},"Autodetect":{"de-DE":"Automatisch","es-VE":"Auto detectar","fi-FI":"Automaattinen tunnistus","fr-FR":"Détection automatique","it-IT":"Rilevamento automatico","ko-KR":"자동 감지","nl-NL":"Automatisch"},"Autoplay":{"de-DE":"Automatische Wiedergabe","es-VE":"Reproducción automática","fi-FI":"Automaattitoisto","fr-FR":"Jouer automatiquement","it-IT":"Riproduzione automatica","ko-KR":"자동 연주","nl-NL":"Auto-afspelen"},"Backend uri":{"de-DE":"Einzuhängende URL","es-VE":"URL Back-End","fi-FI":"Järjestelmä uri","fr-FR":"URL du backend","it-IT":"URI del backend","ko-KR":"백엔드 URL","nl-NL":"Backend-url"},"Background":{"de-DE":"Hintergrund","es-VE":"Fondo","fi-FI":"Tausta","fr-FR":"Fond","it-IT":"Sfondo","ko-KR":"배경","nl-NL":"Achtergrond"},"Background color":{"de-DE":"Hintergrundfarbe","es-VE":"Color de fondo","fi-FI":"Taustaväri","fr-FR":"Couleur d'arrière plan","it-IT":"Colore sfondo","ko-KR":"배경색","nl-NL":"Achtergrondkleur"},"Best rated":{"de-DE":"Am Besten bewertet","es-VE":"Mejor calificado","fi-FI":"Paras arvostelu","fr-FR":"Mieux notés","it-IT":"Più votati","ko-KR":"최고 평점","nl-NL":"Best beoordeeld"},"Blokas Labs pisound card":{},"Booklet":{"de-DE":"Booklet","es-VE":"Folleto","fi-FI":"Booklet","fr-FR":"Booklet","it-IT":"Libretto","ko-KR":"책자","nl-NL":"Boekje"},"Booklet filename":{"de-DE":"Booklet Dateiname","es-VE":"Archivo de folleto","fi-FI":"Bookletin tiedostonimi","fr-FR":"Nom des fichiers Booklet","it-IT":"Nome file Libretto","ko-KR":"책자 파일 이름","nl-NL":"Bestandsnaam boekje"},"Bookmark URI":{"de-DE":"Lesezeichen URL","es-VE":"URL de marcador","fi-FI":"Kirjanmerkin URL","fr-FR":"URL du marque-page","it-IT":"URI segnalibro","ko-KR":"즐겨찾기 주소","nl-NL":"Url bladwijzer"},"Bookmark name":{"de-DE":"Name","es-VE":"Nombre de marcador","fi-FI":"Kirjanmerkin nimi","fr-FR":"Nom du marque-page","it-IT":"Nome segnalibro","ko-KR":"즐겨찾기 이름","nl-NL":"Naam"},"Bookmarks":{"de-DE":"Lesezeichen","es-VE":"Marcadores","fi-FI":"Kirjanmerkit","fr-FR":"Marque-pages","it-IT":"Segnalibro","ko-KR":"즐겨찾기","nl-NL":"Bladwijzers"},"Browse":{"de-DE":"Durchsuchen","es-VE":"Explorar","fi-FI":"Selaa","fr-FR":"Parcourir","it-IT":"Sfoglia","ko-KR":"열기","nl-NL":"Browse"},"Browse directories":{"de-DE":"Verzeichnisse anzeigen","es-VE":"Explorar directorios","fi-FI":"Selaa kansioita","fr-FR":"Parcourir les dossiers","it-IT":"Sfoglia le cartelle","ko-KR":"디렉터리 열기","nl-NL":"Browse bestanden"},"Browser default":{"de-DE":"Browsereinstellung","es-VE":"Por defecto del navegador","fi-FI":"Selaimen asetus","fr-FR":"Explorateur par défaut","it-IT":"Default del browser","ko-KR":"기본 열기","nl-NL":"Browserinstelling"},"CSS filter":{"de-DE":"CSS Filter","es-VE":"Filtro CSS","fi-FI":"CSS suodatin","fr-FR":"Filtre CSS","it-IT":"Filtro CSS","ko-KR":"CSS 필터","nl-NL":"CSS filter"},"Calculate":{"de-DE":"Berechne Fingerabdruck","es-VE":"Calcular","fi-FI":"Laske","fr-FR":"Calculer","it-IT":"Calcolare","ko-KR":"계산","nl-NL":"Bereken"},"Can not crop the queue":{"de-DE":"Die Warteschlange konnte nicht abgeschnitten werden","fi-FI":"Ei voi rajata jonoa","fr-FR":"La queue ne peut être coupée","it-IT":"La coda non può essere troncata","ko-KR":"순서에 남길 수 없음","nl-NL":"Kan wachtrij niet inkorten"},"Can not delete home icon":{"de-DE":"Icon konnte nicht gelöscht werden","it-IT":"Impossibile cancellare l'icona della home","ko-KR":"홈 아이콘을 지울 수 없음"},"Can not get home icon":{"de-DE":"Konnte Homeicon nicht abrufen","it-IT":"Impossibile trovare l'icona della home","ko-KR":"홈 화면을 가져올 수 없음"},"Can not move home icon":{"de-DE":"Homeicon konnte nicht verschoben werden","it-IT":"Impossibile spostare l'icona della home","ko-KR":"홈 화면을 옮길 수 없음"},"Can not open directory pics":{"de-DE":"Konnte Verzeichnis pics nicht öffnen","it-IT":"Impossibile aprire la cartella pics","ko-KR":"디렉터리 그림을 열 수 없음"},"Can not open scriptfile":{"de-DE":"Skript konnte nicht geöffnet werden","fr-FR":"Le fichier de script ne peut être ouvert","it-IT":"Impossibile aprire il file dello script","ko-KR":"스크립트 파일을 열 수 없음","nl-NL":"Kan script niet openen"},"Can not parse settings":{"de-DE":"Einstellungen können nicht geladen werden","es-VE":"Error al leer configuraciones","fi-FI":"Asetusten käsittely ei onnistu","fr-FR":"Les paramètres ne peuvent être lus","it-IT":"Impossibile analizzare i parametri","ko-KR":"설정을 분석할 수 없음","nl-NL":"Laden instellingen mislukt "},"Can not parse smart playlist file":{"de-DE":"Intelligente Wiedergabeliste konnte nicht geparsed werden","es-VE":"No se puede interpretar el archivo de lista de reproducción inteligente","fi-FI":"Älykkään soittolista tiedoston käsittely ei onnistu","fr-FR":"Le fichier de liste de lecture intelligente ne peut être analysé","it-IT":"Impossibile elaborare il file di lista di riproduzione smart","ko-KR":"스마트 연주목록 파일을 분석할 수 없음","nl-NL":"Kan slimme afspeellijst niet inlezen"},"Can not read smart playlist file":{"de-DE":"Intelligente Wiedergabeliste konnte nicht eingelesen werden","es-VE":"No se puede leer el archivo de lista de reproducción inteligente","fi-FI":"Älykkään soittolista tiedoston luku ei onnistu","fr-FR":"Le fichier de liste de lecture intelligente ne peut être lu","it-IT":"Impossibile leggere il file di lista di riproduzione smart","ko-KR":"스마트 연주목록 파일을 읽을 수 없음","nl-NL":"Kan slimme afspeellijst niet lezen"},"Can not save home icon":{"de-DE":"Icon konnte nicht gespeichert werden","it-IT":"Impossibile salvare l'icona della home","ko-KR":"홈 아이콘을 저장할 수 없음"},"Can't access music directory":{"de-DE":"Musik Verzeichnis ist nicht verfügbar","es-VE":"No se puede acceder al directorio de música","fi-FI":"Musiikkikansiota ei pysty avaamaan","fr-FR":"Dossier de musiques non accessible","it-IT":"Cartella musicale non accessibile","ko-KR":"음원 디렉터리에 접근할 수 없음","nl-NL":"Map niet toegankelijk"},"Can't create mympd_script thread":{"de-DE":"Konnte mympd_script Thread nicht erstellen","fr-FR":"Création du thread mympd_script échoué","it-IT":"Impossibile creare il thread per mympd_script","ko-KR":"mympd_script 스레드를 만들 수 없음","nl-NL":"Kan mympd_script Thread niet maken"},"Can't save setting %{setting}":{"de-DE":"%{setting} konnte nicht gespeichert werden","es-VE":"Error al guardar la configuración: %{setting}","fi-FI":"Ei voi tallentaa asetusta %{setting}","fr-FR":"Ne peut enregistrer le paramètre %{setting}","it-IT":"Impossibile salvare i parametri %{setting}","ko-KR":"%{setting} 설정 저장할 수 없음","nl-NL":"Kan instelling %{setting} niet saven"},"Cancel":{"de-DE":"Abbrechen","es-VE":"Cancelar","fi-FI":"Peruuta","fr-FR":"Annuler","it-IT":"Annulla","ko-KR":"취소","nl-NL":"Annuleren"},"Check":{},"Check for updates":{},"Cirrus Logis Audio Card":{},"Clear":{"de-DE":"Löschen","es-VE":"Limpiar","fi-FI":"Tyhjennä","fr-FR":"Vider","it-IT":"Svuota","ko-KR":"지우기","nl-NL":"Wissen"},"Clear app cache and reload":{"de-DE":"Browser Cache löschen und neu laden","es-VE":"Borrar caché de la app y recargar","fi-FI":"Tyhjennä ohjelman välimuisti ja lataa uudelleen","fr-FR":"Vider le cache de l'application et recharger","it-IT":"Svuota cache applicazione e ricarica","ko-KR":"앱 캐시를 지우고 다시 읽기","nl-NL":"Wis app-cache en herlaad"},"Clear covercache":{"de-DE":"Covercache löschen","es-VE":"Limpiar Covercache","fi-FI":"Tyhjennä Covercache","fr-FR":"Vider le cache des jaquettes","it-IT":"Svuota cache copertine","ko-KR":"표지 캐시 지우기","nl-NL":"Wis covercache"},"Clear playlist":{"de-DE":"Playlist leeren","es-VE":"Limpiar lista de reproducción","fi-FI":"Tyhjää soittolista","fr-FR":"Vider la liste de lecture","it-IT":"Svuota lista di riproduzione","ko-KR":"연주목록 비우기","nl-NL":"Wis afspeellijst"},"Clear queue":{"de-DE":"Warteschlange leeren","es-VE":"Borrar cola de reproducción","fi-FI":"Tyhjennä jono","fr-FR":"Vider la queue","it-IT":"Svuota la coda","ko-KR":"순서 비우기","nl-NL":"Wachtrij wissen"},"Clearing bookmarks failed":{"de-DE":"Löschen aller Lesezeichen fehlgeschlagen","es-VE":"Error al borrar marcadores","fi-FI":"Kirjanmerkkien tyhjentäminen epäonnistui","fr-FR":"Echec de suppression des marque-pages","it-IT":"Errore svuotamento segnalibri","ko-KR":"즐겨찾기 지우기 안 됨","nl-NL":"Wissen bladwijzers mislukt"},"Close":{"de-DE":"Schließen","es-VE":"Cerrar","fi-FI":"Sulje","fr-FR":"Fermer","it-IT":"Chiudi","ko-KR":"닫기","nl-NL":"Sluit"},"Collybia OS Version":{},"Columns":{"de-DE":"Spalten","it-IT":"Colonne","ko-KR":"열"},"Comment":{"de-DE":"Kommentar","es-VE":"Comentario","fi-FI":"Kommenttti","fr-FR":"Commentaire","it-IT":"Commento","ko-KR":"설명","nl-NL":"Commentaar"},"Composer":{"de-DE":"Komponist","es-VE":"Compositor","fi-FI":"Säveltäjä","fr-FR":"Compositeur","it-IT":"Compositore","ko-KR":"작곡가","nl-NL":"Componist"},"Conductor":{"de-DE":"Dirigent","es-VE":"Director","fi-FI":"Kapelllimestari","fr-FR":"Chef d'orchestre","it-IT":"Direttore d'orchestra","ko-KR":"지휘자","nl-NL":"Dirigent"},"Connect to websocket":{"de-DE":"Websocketverbindung wird hergestellt","es-VE":"Conectando a websocket","fi-FI":"Yhdistetään websockettiin","fr-FR":"Connection à la websocket","it-IT":"Canessione a websocket","ko-KR":"웹소켓에 연결","nl-NL":"Verbinden met websocket"},"Connected to MPD":{"de-DE":"Verbindung zu MPD hergestellt","es-VE":"Conectado a MPD","fi-FI":"Yhdistetty MPD:hen","fr-FR":"Connecté à MPD","it-IT":"Connesso a MPD","ko-KR":"MPD로 연결됨","nl-NL":"Verbonden met MPD"},"Connected to myMPD":{"de-DE":"Verbindung zu myMPD hergestellt","es-VE":"Conectado a myMPD","fi-FI":"Yhdistetty myMPD:hen","fr-FR":"Connecté à myMPD","it-IT":"Connesso a myMPD","ko-KR":"myMPD로 연결됨","nl-NL":"Verbonden met myMPD"},"Connecting to stream...":{"de-DE":"Verbinde...","es-VE":"Conectando fuente...","fi-FI":"Yhdistetään...","fr-FR":"Connection au flux...","it-IT":"Connessione al flusso...","ko-KR":"스트리밍에 연결 중...","nl-NL":"Verbinden..."},"Connection":{"de-DE":"Verbindung","es-VE":"Conexión","fi-FI":"Yhteys","fr-FR":"Connection","it-IT":"Connessione","ko-KR":"연결","nl-NL":"Verbinding"},"Consume":{"de-DE":"Konsumieren","es-VE":"Consumir","fi-FI":"Kuluta","fr-FR":"Consumer","it-IT":"Consuma","ko-KR":"써버리기","nl-NL":"Consumeren"},"Consume must be enabled":{"de-DE":"Konsumieren muss aktiviert sein","es-VE":"Modo Consumir debe estar habilitado","fi-FI":"Kulutuksen oltava päällä","fr-FR":"Consummer doit être activé","it-IT":"Il modo Consumo deve essere abilitato","ko-KR":"소비를 선택해야 함","nl-NL":"Consumeren moet zijn ingeschakeld"},"Could not delete script":{"de-DE":"Skript konnte nicht gelöscht werden","fr-FR":"Le fichier de script ne peut être supprimé","it-IT":"Impossibile cancellare lo script","ko-KR":"스크립트를 지울 수 없음","nl-NL":"Kan script niet deleten"},"Could not delete trigger":{"de-DE":"Konnte Trigger nicht löschen","fr-FR":"Le déclencheur ne peut être supprimé","it-IT":"Impossibile cancellare il trigger","ko-KR":"트리거를 지울 수 없음","nl-NL":"Kan trigger niet deleten"},"Could not remove song from jukebox queue":{"de-DE":"Konnte Lied nicht aus der Jukebox Warteschlange entfernen","it-IT":"Impossibile togliere il brano dalla lista del jukebox","ko-KR":"뮤직박스 순서의 곡을 지울 수 없음"},"Could not save script":{"de-DE":"Skript konnte nicht gespeichert werden","fr-FR":"Le fichier de script ne peut être enregistré","it-IT":"Impossibile salvare lo script","ko-KR":"스크립트를 저장할 수 없음","nl-NL":"Kan script niet saven"},"Could not save trigger":{"de-DE":"Konnte Trigger nicht speichern","fr-FR":"Le déclencheur ne peut être enregistré","it-IT":"Impossibile salvare il trigger","ko-KR":"트리거를 저장할 수 없음","nl-NL":"Kan trigger niet saven"},"Create Playlist":{"de-DE":"Neue Wiedergabeliste erstellen","es-VE":"Crear lista de reproducción","fi-FI":"Luo soittolista","fr-FR":"Nouvelle liste de lecture","it-IT":"Crea lista di riproduzione","ko-KR":"연주목록 만들기","nl-NL":"Maak afspeellijst"},"Crop":{"de-DE":"Abschneiden","es-VE":"Cortar","fi-FI":"Rajaa","fr-FR":"Couper","it-IT":"Taglia","ko-KR":"잘라내기","nl-NL":"Inkorten"},"Crop queue":{"de-DE":"Warteschlange abschneiden","es-VE":"Cortar cola de reproducción","fi-FI":"Rajaa jono","fr-FR":"Couper la queue","it-IT":"Tronca la coda","ko-KR":"순서 남기기","nl-NL":"Wachtrij inkorten"},"Crossfade":{"de-DE":"Crossfade","es-VE":"Fundido cruzado","fi-FI":"Crossfade","fr-FR":"Crossfade","it-IT":"Dissolvenza incrociata","ko-KR":"크로스페이드","nl-NL":"Crossfade"},"Current partition":{"de-DE":"Momentane Partition","fr-FR":"Partition courante","it-IT":"Partizione corrente","ko-KR":"현재 파티션","nl-NL":"Huidige partitie"},"Current version":{},"DAC List":{},"DAC volume mode":{},"DB play time":{"de-DE":"Datenbank Wiedergabedauer","es-VE":"Tiempo de reproducción BD","fi-FI":"Tietokannan toistoaika","fr-FR":"Durée de lecture de la base de données","it-IT":"Durata esecuzione Database musicale","ko-KR":"DB 연주 시간","nl-NL":"DB speeltijd"},"DB updated":{"de-DE":"Datenbank zuletzt aktualisiert","es-VE":"BD actualizada","fi-FI":"Tietokanta päivitettty","fr-FR":"Base de données mise à jour","it-IT":"Database musicale aggiornato","ko-KR":"DB 업데이트됨","nl-NL":"DB geüpdatet"},"Dark":{"de-DE":"Dunkel","es-VE":"Oscuro","fi-FI":"Tumma","fr-FR":"Sombre","it-IT":"Scuro","ko-KR":"어둠","nl-NL":"Donker"},"Database":{"de-DE":"Datenbank","es-VE":"Base de datos","fi-FI":"Tietokanta","fr-FR":"Base de données","it-IT":"Database","ko-KR":"데이터 베이스","nl-NL":"Database"},"Database statistics":{"de-DE":"Datenbank Statistiken","es-VE":"Estadísticas de Base de datos","fi-FI":"Tietokanta tilastot","fr-FR":"Statistiques de la base de données","it-IT":"Statistiques de la base de données","ko-KR":"데이터베이스 통계","nl-NL":"Database statistieken"},"Database successfully updated":{"de-DE":"Datenbank erfolgreich aktualisiert","es-VE":"Base de datos actualizada exitosamente","fi-FI":"Tietokannan päivitys onnistui","fr-FR":"Base de données mise à jour","it-IT":"Database aggiornato con successo","ko-KR":"데이터베이스 업데이트됨","nl-NL":"Database geüpdatet"},"Database update finished":{"de-DE":"Datenbankaktualisierung beendet","es-VE":"Finalizó la actualización de la base de datos","fi-FI":"Tietokannan päivitys valmis","fr-FR":"Mise à jour de la base de données terminée","it-IT":"Aggiornamento database concluso","ko-KR":"데이터베이스 업데이트 마침","nl-NL":"Update database klaar"},"Database update started":{"de-DE":"Datenbankaktualisierung gestartet","es-VE":"Inició la actualización de la base de datos","fi-FI":"Tietokannan päivitys aloitettu","fr-FR":"Mise à jour de la base de données démarrée","it-IT":"Aggiornamento database avviato","ko-KR":"데이터베이스 업데이트 시작됨","nl-NL":"Updaten database gestart"},"Date":{"de-DE":"Datum","es-VE":"Año","fi-FI":"Päiväys","fr-FR":"Date","it-IT":"Data","ko-KR":"날짜","nl-NL":"Datum"},"Days":{"de-DE":"Tage","en-US":"Days","es-VE":"Dias","fi-FI":"Päivää","fr-FR":"Jours","it-IT":"Giorni","ko-KR":"일","nl-NL":"Dagen"},"Default":{"de-DE":"Standard","es-VE":"Por defecto","fi-FI":"Vakio","fr-FR":"Par défault","it-IT":"Predefinito","ko-KR":"기본","nl-NL":"Standaard"},"Definition":{"de-DE":"Definition","es-VE":"Definición","fi-FI":"Määritelmä","fr-FR":"Définition","it-IT":"Definizione","ko-KR":"결정","nl-NL":"Definitie"},"Delete":{"de-DE":"Löschen","es-VE":"Eliminar","fi-FI":"Poista","fr-FR":"Effacer","it-IT":"Elimina","ko-KR":"지우기","nl-NL":"Delete"},"Delete all playlists":{"de-DE":"Alle Wiedergabelisten löschen","es-VE":"Eliminar todas las listas de reproducción","fi-FI":"Poista kaikki soittolistat","fr-FR":"Supprimer toutes les listes de lecture","it-IT":"Elimina tutte le liste di riproduzione","ko-KR":"모든 연주목록 지움","nl-NL":"Delete alle afspeellijsten"},"Delete all smart playlists":{"de-DE":"Alle Intelligenten Wiedergabelisten löschen","es-VE":"Eliminar todas las listas de reproducción inteligentes","fi-FI":"Poista kaikki älykkäät soittolistat","fr-FR":"Supprimer toutes les listes de lecture intelligentes","it-IT":"Elimina tutte le liste di riproduzione smart","ko-KR":"모든 스마트 연주목록 지움","nl-NL":"Delete alle afspeellijsten"},"Delete empty playlists":{"de-DE":"Alle leere Wiedergabelisten löschen","es-VE":"Eliminar listas de reproducción vacias","fi-FI":"Poista tyhjät soittolistat","fr-FR":"Supprimer toutes les listes de lecture vides","it-IT":"Elimina tutte le liste di riproduzione vuote","ko-KR":"빈 연주목록 지움","nl-NL":"Delete lege afspeellijsten"},"Delete home icon":{"de-DE":"Löschen","it-IT":"Cancella l'icona della home","ko-KR":"홈 화면 지움"},"Delete playlist":{"de-DE":"Wiedergabeliste löschen","es-VE":"Eliminar lista de reproducción","fi-FI":"Poista soittolista","fr-FR":"Supprimer la liste de lecture intelligente","it-IT":"Cancella lista di riproduzione smart","ko-KR":"연주목록 지우기","nl-NL":"Delete afspeellijst"},"Delete playlists":{"de-DE":"Wiedergabelisten löschen","es-VE":"Eliminar listas de reproducción","fi-FI":"Poista soittolistat","fr-FR":"Supprimer les listes de lecture","it-IT":"Elimina liste di riproduzione","ko-KR":"연주목록 지움","nl-NL":"Delete afspeellijsten"},"Deleting bookmark failed":{"de-DE":"Lesezeichen konnte nicht gelöscht werden","es-VE":"Error al eliminar marcador","fi-FI":"Kirjanmerkin poisto epäonnistui","fr-FR":"Echec de la suppression du marque-page","it-IT":"Cancellazione segnalibro fallita","ko-KR":"즐겨찾기 지우기 안 됨","nl-NL":"Verwijderen bladwijzer mislukt"},"Deleting smart playlist failed":{"de-DE":"Intelligente Wiedergabeliste konnte nicht gelöscht werden","es-VE":"Error al eliminar lista de reproducción inteligente","fi-FI":"Älykkään soittolista poisto epäonnistui","fr-FR":"Echec de la suppression de la liste de lecture intelligente ","it-IT":"Impossibile eliminare lista di riproduzione smart","ko-KR":"스마트 연주목록 지우기 안 됨","nl-NL":"Verwijderen slimme afspeellijst mislukt"},"Dependent on the size of your music collection this can take a while":{"de-DE":"Der Aktualisierungsvorgang kann einige Zeit in Anspruch nehmen","es-VE":"Dependiendo del tamaño de su colección de música, esto puede llevar un tiempo","fi-FI":"Riippuen musiikkikokoelman koosta, tässä voi mennä hetki","fr-FR":"Cela peut durer longtemps en fonction de la taille de votre dossier musical","it-IT":"L'operazione può durare a lungo in funzione della dimensione della vostra raccolta musicale","ko-KR":"음원 크기에 따라 시간이 걸릴 수 있습니다","nl-NL":"Afhankelijk van de grootte van de muziekcollectie kan dit even duren"},"Descending":{"de-DE":"Absteigend","es-VE":"Descendiente","fi-FI":"Laskeva","fr-FR":"Descendant","it-IT":"Discendente","ko-KR":"내림차순","nl-NL":"Aflopend"},"Details":{"de-DE":"Details","fr-FR":"Détails","it-IT":"Dettagli","ko-KR":"상세","nl-NL":"Details"},"Dion Audio LOCO DAC-AMP":{},"Dion Audio LOCO DAC-AMP v2":{},"Disabled":{"de-DE":"Deaktiviert","es-VE":"Desactivado","fi-FI":"Poistettu käytöstä","fr-FR":"Désactivé","it-IT":"Disabilitato","ko-KR":"사용 안 함","nl-NL":"Uitgeschakeld"},"Disc":{"de-DE":"Disc","es-VE":"Disco","fi-FI":"Levy","fr-FR":"Disque","it-IT":"Disco","ko-KR":"디스크","nl-NL":"Disc"},"Disc 1":{"de-DE":"Disc 1","it-IT":"Disco 1","ko-KR":"디스크 1","nl-NL":"Disc 1"},"Dislike song":{"de-DE":"Schlechtes Lied","es-VE":"No me gusta esta canción","fi-FI":"Dissaa kappaletta","fr-FR":"Je n'aime pas cette chanson","it-IT":"Non mi piace più","ko-KR":"곡 좋아하지 않음","nl-NL":"Dislike nummer"},"Display tags":{"de-DE":"Tags zum Anzeigen","it-IT":"Mostra tag","ko-KR":"태그 표시"},"Download":{"de-DE":"Herunterladen","es-VE":"Descargar","fi-FI":"Lataa","fr-FR":"Télécharger","it-IT":"Scarica","ko-KR":"내려받기","nl-NL":"Download"},"Download booklet":{"de-DE":"Booklet herunterladen","it-IT":"Scarica libretto","ko-KR":"책자 내려받기","nl-NL":"Download boekje"},"Duplicate home icon":{"de-DE":"Kopieren","it-IT":"Duplica l'icona della home","ko-KR":"홈 화면 복사"},"Duration":{"de-DE":"Länge","es-VE":"Duración","fi-FI":"Kesto","fr-FR":"Durée","it-IT":"Durata","ko-KR":"길이","nl-NL":"Duur"},"Edit attributes":{"de-DE":"Eigenschaften editieren","fr-FR":"Editer les attributs","it-IT":"Modifica gli attributi","ko-KR":"속성 수정","nl-NL":"Pas parameters aan"},"Edit home icon":{"de-DE":"Bearbeiten","it-IT":"Modifica l'icona della home","ko-KR":"홈 화면 수정"},"Edit playlist":{"de-DE":"Wiegergabeliste bearbeiten","es-VE":"Editar lista de reproducción","fi-FI":"Muokkaa soittolistaa","fr-FR":"Modifier la liste de lecture","it-IT":"Modifica lista di riproduzione","ko-KR":"연주목록 편집","nl-NL":"Bewerk afspeellijst"},"Edit smart playlist":{"de-DE":"Intelligente Wiedergabeliste bearbeiten","es-VE":"Editar lista de reproducción inteligente","fi-FI":"Muokkaa älykästä soittolistaa","fr-FR":"Modifier la liste de lecture intelligente","it-IT":"Modifica lista di riproduzione smart","ko-KR":"스마트 연주목록 편집","nl-NL":"Bewerk slimme afspeellijst"},"Editing scripts is disabled":{"de-DE":"Das Editieren von Skripts ist deaktiviert","fr-FR":"Edition des scripts désactivé","it-IT":"Moidifica degli script disabilitata","ko-KR":"스크립트 편집 사용 안 함","nl-NL":"Bewerken scripts is uitgeschakeld"},"Either AlbumArtist or Artist tag must be enabled":{"de-DE":"Albumartist or Artist Tag muss aktiviert sein","ko-KR":"음반 연주자나 연주자 태그를 사용해야 함"},"Elements per page":{"de-DE":"Anzahl Listenelemente","ko-KR":"페이지당 요소"},"Empty list":{"de-DE":"Leere Liste","es-VE":"Lista vacía","fi-FI":"Tyhjä lista","fr-FR":"Liste vide","it-IT":"Lista vuota","ko-KR":"목록 비우기","nl-NL":"Lege lijst"},"Empty playlist":{"de-DE":"Leere Wiedergabeliste","es-VE":"Lista de reproducción vacía","fi-FI":"Tyhjä soittolista","fr-FR":"Liste de lecture vide","it-IT":"Lista di riproduzione vuota","ko-KR":"연주목록 비우기","nl-NL":"Lege afspeellijst"},"Empty queue":{"de-DE":"Leere Warteschlange","es-VE":"Cola de reproducción vavía","fi-FI":"Tyhjä jono","fr-FR":"Queue vide","it-IT":"Coda vuota","ko-KR":"순서 비우기","nl-NL":"Lege wachtrij"},"Enable DoP":{},"Enable FFmpeg":{},"Enable jukebox if playlist is database":{"de-DE":"Jukebox muss aktiviert sein, wenn als Wiedergabeliste die Datenbank ausgewählt ist.","es-VE":"Habilite Jukebox si la lista de reproducción es la base de datos","fi-FI":"Salli jukeboksi jos soittolista tietokanta","fr-FR":"Activer le mode jukebox si la playlist provient de la base de données","it-IT":"Abilita il jukebox se la lista di riproduzione è un database","ko-KR":"연주목록이 데이터베이스이면 뮤직박스 사용함","nl-NL":"Schakel jukebox in wanneer database als afspeellijst is geselecteerd"},"Enabled":{"de-DE":"Aktiv","es-VE":"Habilitado","fi-FI":"Päällä","fr-FR":"Activé","it-IT":"Abilitato","ko-KR":"사용함","nl-NL":"Ingeschakeld"},"Enforce uniqueness":{"de-DE":"Erzwinge Eindeutigkeit","es-VE":"Hacer cumplir la singularidad","fi-FI":"Pakota yksilöllisyys","fr-FR":"Eliminer les doublons","it-IT":"Elimina doppioni","ko-KR":"유일성 강제","nl-NL":"Gelijkenis op basis van"},"Error":{"de-DE":"Fehler","es-VE":"Error","fi-FI":"Virhe","fr-FR":"Erreur","it-IT":"Errore","ko-KR":"오류","nl-NL":"Fout"},"Error executing script %{script}":{"de-DE":"Fehler beim Ausführen des Skripts %{script}","fr-FR":"Erreur d'éxecution du sript %{script}","it-IT":"Errore esecuzione script %{script}","ko-KR":"스크립트 %{script} 실행 오류","nl-NL":"Fout bij uitvoeren script %{script}"},"Error executing script %{script}: Can not open or read script file":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Skript Datei kann nicht geöffnet oder gelesen werden","fr-FR":"Erreur d'éxecution du sript %{script}: Ouverture ou lecture du fichier de script impossible","it-IT":"Errore esecuzione script %{script}: impossibile aprire o leggere il file di script","ko-KR":"스크립트 %{script} 실행 오류: 스크립트 파일을 열거나 읽을 수 없음","nl-NL":"Fout bij uitvoeren script %{script}: Kan script niet openen of lezen"},"Error executing script %{script}: Error in garbage collector":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Fehler im Garbage Collector","fr-FR":"Erreur d'éxecution du sript %{script}: Erreur dans le ramasse-miettes","it-IT":"Errore esecuzione script %{script}: errore nel garbage collector","ko-KR":"스크립트 %{script} 실행 오류: 가비지 수집 오류","nl-NL":"Fout bij uitvoeren script %{script}: Fout in garbage collector"},"Error executing script %{script}: Error while running the message handler":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Fehler bei der Ausführung des Messagehandlers","fr-FR":"Erreur d'éxecution du sript %{script}: Erreur d'exécution du gestionnaire de message","it-IT":"Errore esecuzione script %{script}: errore esecuzione gestore messaggi","ko-KR":"스크립트 %{script} 실행 오류: 메시지 처리 실행 오류","nl-NL":"Fout bij uitvoeren script %{script}: Fout tijdens uitvoeren van message handler"},"Error executing script %{script}: Memory allocation error":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Speicherzuweisungsfehler","fr-FR":"Erreur d'éxecution du sript %{script}: Erreur d'allocation mémoire","it-IT":"Errore esecuzione script %{script}: errore allocazione memoria","ko-KR":"스크립트 %{script} 실행 오류: 메모리 할당 오류","nl-NL":"Fout bij uitvoeren script %{script}: Geheugentoewijzingsfout"},"Error executing script %{script}: Runtime error":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Laufzeitfehler","fr-FR":"Erreur d'éxecution du sript %{script}: Erreur de runtime","it-IT":"Errore esecuzione script %{script}: errore di runtime","ko-KR":"스크립트 %{script} 실행 오류: 런타임 오류","nl-NL":"Fout bij uitvoeren script %{script}: Runtime-fout"},"Error executing script %{script}: Syntax error during precompilation":{"de-DE":"Fehler beim Ausführen des Skripts %{script}: Syntax Fehler","fr-FR":"Erreur d'éxecution du sript %{script}: Erreur de précompilation","it-IT":"Errore esecuzione script %{script}: errore di compilazione","ko-KR":"스크립트 %{script} 실행 오류: 전처리 컴파일 문법 오류","nl-NL":"Fout bij uitvoeren script %{script}: syntaxisfout tijdens precompilatie"},"Error in response to command: %{command}":{"de-DE":"Fehler beim Ausführen von %{command}","es-VE":"Error en respuesta al comando: %{command}","fi-FI":"Virhe komennolla %{command}","fr-FR":"Erreur en réponse à la commande %{command}","it-IT":"Errore in risposta al comando %{command}","ko-KR":"명령어 오류: %{command}","nl-NL":"Uitvoerfout in: %{command}"},"Error loading stream":{"de-DE":"Fehler beim Laden des Streams","fr-FR":"Erreur de chargement de flux","it-IT":"Errore caricamento flusso","ko-KR":"스트리밍 읽기 오류","nl-NL":"Fout bij laden stream"},"Error reading metadata":{"de-DE":"Metadaten konnten nicht gelesen werden","it-IT":"Errore nella lettuda dei metadati","ko-KR":"메타데이터 읽기 오류"},"Event":{"de-DE":"Ereignis","fr-FR":"Evennement","it-IT":"Evento","ko-KR":"이벤트","nl-NL":"Gebeurtenis"},"Execute":{"de-DE":"Ausführen","fr-FR":"Exécuter","it-IT":"Esegui","ko-KR":"실행","nl-NL":"Uitvoeren"},"Execute Script":{"de-DE":"Skript ausführen","it-IT":"Esegui lo script","ko-KR":"스크립트 실행"},"Execute script":{"de-DE":"Skript ausführen","fr-FR":"Exécuter le script","it-IT":"Esegui lo script","ko-KR":"스크립트 실행","nl-NL":"Voer script uit"},"Failed to execute cmd %{cmd}":{"de-DE":"Fehler beim Ausführen des Systembefehls %{cmd}","es-VE":"Error al ejecutar el comando: %{cmd}","fi-FI":"Komennon %{cmd} suorittaminen epäonnistui","fr-FR":"Echec de l'exécution de la commande %{cmd}","it-IT":"Impossibile eseguire il comando %{cmd}","ko-KR":"%{cmd} 명령어 실행 안 됨","nl-NL":"Uitvoeren mislukt cmd %{cmd}"},"Failed to open bookmarks file":{"de-DE":"Lesezeichen Datei konnte nicht geöffnet werden","es-VE":"Error al abrir el archivo de marcadores","fi-FI":"Kirjanmerkki tiedoston avaaminen epäonnistui","fr-FR":"Echec de l'ouverture du fichier des marque-pages","it-IT":"Impossibile aprire il file dei segnalibri","ko-KR":"즐겨찾기 파일 열기 안 됨","nl-NL":"Openen bladwijzer mislukt"},"Failed to save playlist":{"de-DE":"Wiedergabeliste konnte nicht gespeichert werden","es-VE":"Error al guardar lista de reproducción","fi-FI":"Soittolistan tallennus epäonnistui","fr-FR":"Echec de l'enregistrement de la liste de lecture","it-IT":"Impossibile salvare la lista di riproduzione","ko-KR":"연주목록 저장 안 됨","nl-NL":"Saven afspeellijst mislukt"},"Failed to send love message to channel":{"de-DE":"Lieblingslied Nachricht konnte nicht gesendet werden","es-VE":"Error al enviar Me gusta al canal","fi-FI":"Rakkausviestin lähetys kanavalle epäonnistui","fr-FR":"Echec de l'envoi du statut adoré","it-IT":"Impossibile inviare il messaggio \"adorato\" sul canale","ko-KR":"채널에 애청곡 메시지 보내기 안 됨","nl-NL":"Versturen favoriet mislukt"},"Failed to set like, invalid like value":{"de-DE":"Wertung konnte nicht gesetzt werden, ungültiger Wert","es-VE":"Error al establecer me gusta, no válido","fi-FI":"Tykkäystä ei voitu asettaa, virheellinen tykkäys arvo","fr-FR":"Like non appliqué, valeur de like non valide","it-IT":"Impossibile applicare il like, valore de like non valido","ko-KR":"잘못된 값으로 좋아요 설정 안 됨","nl-NL":"Like mislukt, ongeldige waarde"},"Failed to set like, invalid song uri":{"de-DE":"Wertung konnte nicht gesetzt werden, ungültige Lied URL","es-VE":"Error al establecer me gusta, URI de canción inválido","fi-FI":"Tykkäystä ei voitu asettaa, virheellinen kappaleen URI","fr-FR":"Like non appliqué, URI de la chanson non valide","it-IT":"Impossibile applicare il like, URI della canzone non valido","ko-KR":"잘못된 곡 주소로 좋아요 설정 안 됨","nl-NL":"Like mislukt, ongeldige url"},"Failed to set like, unknown error":{"de-DE":"Like konnte nicht gesetzt werden - unbekannter Fehler","it-IT":"Impossibile impostare \"mi piace\", errore sconosciuto","ko-KR":"좋아요 설정 실패, 알 수 없는 오류"},"Failed to set song priority":{"de-DE":"Priorität des Liedes konnte nicht gesetzt werden","it-IT":"Impossibile impostare priorità brano fallita","ko-KR":"곡 우선 순위를 설정할 수 없음"},"Fe-Pi Audio Sound Card":{},"Fetch MPD settings":{"de-DE":"Lade MPD Einstellungen","es-VE":"Cargando configuraciones de myMPD","fi-FI":"Haetaan MPD asetukset","fr-FR":"Récupération des paramètres de MPD","it-IT":"Caricamento parametri di MPD","ko-KR":"MPD 설정 가져오기","nl-NL":"MPD-instellingen laden"},"Fetch myMPD settings":{"de-DE":"Lade myMPD Einstellungen","es-VE":"Cargando configuraciones de myMPD","fi-FI":"Noudetaan myMPD asetukset","fr-FR":"Récupération des paramètres de myMPD","it-IT":"Caricamento parametri di myMPD","ko-KR":"myMPD 설정 가져오기","nl-NL":"myMPD-instellingen laden"},"Fileformat":{"de-DE":"Dateiformat","es-VE":"Formato","fi-FI":"Tiedostomuoto","fr-FR":"Format de fichier","it-IT":"Formato file","ko-KR":"파일 포맷","nl-NL":"Bestandsformaat"},"Filename":{"de-DE":"Dateiname","es-VE":"Archivo","fi-FI":"Tiedostonimi","fr-FR":"Nom de fichier","it-IT":"Nome file","ko-KR":"파일 이름","nl-NL":"Bestandsnaam"},"Filesystem":{"de-DE":"Dateisystem","es-VE":"Sistema de archivos","fi-FI":"Tiedostojärjestelmä","fr-FR":"Système de fichiers","it-IT":"Filesystem","ko-KR":"파일 시스템","nl-NL":"Bestanden"},"Filetype":{"de-DE":"Dateityp","es-VE":"Tipo","fi-FI":"Tiedostotyyppi","fr-FR":"Type de fichier","it-IT":"Tipo file","ko-KR":"파일 형식","nl-NL":"Bestandstype"},"Filling jukebox queue failed, disabling jukebox":{"de-DE":"Jukebox Warteschlange konnte nicht aufgefüllt werden, Jukebox wurde deaktiviert","fr-FR":"Echec de remplissage de la queue du jukebox, désactivation du jukebox","it-IT":"Impossibile riempire la coda del jukebox, jukebox disabilitato","ko-KR":"뮤직박스 순서를 채울 수 없어 사용 안 함","nl-NL":"Vullen van de jukebox-wachtrij mislukt, jukebox wordt uitgeschakeld"},"Filter":{"de-DE":"Filter","it-IT":"Filtro","ko-KR":"필터"},"Fingerprint":{"de-DE":"Fingerabdruck","es-VE":"Huella","fi-FI":"Sormenjälki","fr-FR":"Empreinte","it-IT":"Impronta","ko-KR":"지문","nl-NL":"Fingerprint"},"Fingerprint command not supported":{"de-DE":"Fingerprint Befehl ist nicht unterstützt","es-VE":"Comando de huella no soportado","fi-FI":"Sormenjälki komento ei tuettu","fr-FR":"Commande d'empreinte non supportée","it-IT":"Comando impronta non supportato","ko-KR":"지문 명령어 지원 안 됨","nl-NL":"Fingerprint commando niet ondersteund"},"First page":{"de-DE":"Erste Seite","ko-KR":"첫 페이지"},"Focus search":{"de-DE":"Gehe zur Suche","es-VE":"Centrar en búsqueda","fi-FI":"Tarkenna haku","fr-FR":"Recherche avancée","it-IT":"Ricerca avanzata","ko-KR":"찾기로 가기","nl-NL":"Naar Zoeken"},"Focus table":{"de-DE":"In Tabelle navigieren","es-VE":"Centrar en tabla","fi-FI":"Tarkenna taulu","fr-FR":"Focus table (trad non trouvée)","it-IT":"Focus table","ko-KR":"목록에서 찾기","nl-NL":"In tabel navigeren"},"Force smart playlist update":{"de-DE":"Aktualisierung der intelligenten Wiedergabelisten erzwingen","fr-FR":"Forcer la mise à jour de la liste de lecture intelligente","it-IT":"Forza aggiornamento lista di riproduzione smart","ko-KR":"스마트 연주목록 강제 업데이트","nl-NL":"Forceer update smart playlist"},"Force update":{"de-DE":"Erzwinge Aktualisierung","fr-FR":"Forcer la mise à jour","it-IT":"Forza aggiornamento","ko-KR":"강제 업데이트","nl-NL":"Forceer update"},"Fri":{"de-DE":"Fr","es-VE":"Vie","fi-FI":"Pe","fr-FR":"Ven","it-IT":"Ven","ko-KR":"금","nl-NL":"Vr"},"From":{"de-DE":"Von","es-VE":"De","fi-FI":"Mistä","fr-FR":"De","it-IT":"Da","ko-KR":"원래","nl-NL":"Van"},"Fullscreen":{"de-DE":"Vollbild","fr-FR":"Plein écran","it-IT":"Schermo intero","ko-KR":"전체 화면","nl-NL":"Schermvullend"},"General":{"de-DE":"Allgemein","es-VE":"General","fi-FI":"Yleinen","fr-FR":"Général","it-IT":"Generale","ko-KR":"일반","nl-NL":"Algemeen"},"Generate smart playlist per":{"de-DE":"Erstelle intelligente Wiedergabelisten für","es-VE":"Generar lista de reproducción inteligente por","fi-FI":"Luo älykäs soittolista perustuen","fr-FR":"Générer une liste de lecture intelligente par","it-IT":"Genera lista di riproduzione smart per","ko-KR":"스마트 연주목록 생성","nl-NL":"Genereer slimme afspeellijst op basis van"},"Genre":{"de-DE":"Genre","es-VE":"Género","fi-FI":"Genre","fr-FR":"Genre","it-IT":"Genere","ko-KR":"장르","nl-NL":"Genre"},"Goto browse database":{"de-DE":"Gehe zu Datenbank durchsuchen","es-VE":"Ir a explorar base de datos","fi-FI":"Siirry tietokannan selaamiseen","fr-FR":"Aller à la base de données","it-IT":"Vai al database","ko-KR":"데이터베이스 열기로 가기","nl-NL":"Database openen"},"Goto browse filesystem":{"de-DE":"Gehe zu Dateisystem","es-VE":"Ir a explorar sistema de archivos","fi-FI":"Siirry tiedostojärjelmän selaukseen","fr-FR":"Aller au système de fichiers","it-IT":"Vai a filesystem","ko-KR":"파일 시스템 열기로 가기","nl-NL":"Bestandssysteem openen"},"Goto browse playlists":{"de-DE":"Gehe zu Wiedergabelisten","es-VE":"Ir a explorar listas de reproducción","fi-FI":"Siirry soittolistojen selaukseen","fr-FR":"Aller aux listes de lecture","it-IT":"Vai a sfoglia le liste di riproduzione","ko-KR":"연주목록 열기로 가기","nl-NL":"Afspeellijsten openen"},"Goto last played":{"de-DE":"Gehe zu Zuletzt gespielt","es-VE":"Ir a última reproducción","fi-FI":"Siirry viimeksi soitettuun","fr-FR":"Aller à la dernière chanson lue","it-IT":"Vai all'ultimo brano riprodotto","ko-KR":"앞선 연주로 가기","nl-NL":"Laatst afgespeeld openen"},"Goto playback":{"de-DE":"Gehe zu Wiedergabe","es-VE":"Ir a lista de reproducción","fi-FI":"Siirry toistoon","fr-FR":"Aller à la chanson en cours","it-IT":"Vai alla riproduzione corrente","ko-KR":"연주로 가기","nl-NL":"Afspelen openen"},"Goto playing song":{"de-DE":"Gehe zum aktuell gespielten Lied","it-IT":"Vai a riproduzione brano","ko-KR":"연주 곡으로 가기","nl-NL":"xxx"},"Goto queue":{"de-DE":"Gehe zu Warteschlange","es-VE":"Ir a cola de reproducción","fi-FI":"Siirry jonoon","fr-FR":"Aller à la queue","it-IT":"Vai alla coda","ko-KR":"순서로 가기","nl-NL":"Wachtrij openen"},"Goto search":{"de-DE":"Gehe zur Suche","es-VE":"Ir a buscar","fi-FI":"Siirry hakuun","fr-FR":"Aller à la recherche","it-IT":"Vai a ricerca","ko-KR":"찾기로 가기","nl-NL":"Zoeken openen"},"Goto view":{"de-DE":"Gehe zur Ansicht","it-IT":"Vai a Vista","ko-KR":"보기로 가기"},"Grouping":{"de-DE":"Grupierung","es-VE":"Agrupación","fi-FI":"Ryhmittely","fr-FR":"Groupement","it-IT":"Raggruppamento","ko-KR":"묶음","nl-NL":"Groepering"},"HIGH":{},"HI_RES":{},"HTTP Port":{"de-DE":"HTTP Port","fr-FR":"Port HTTP","it-IT":"Porta HTTP","ko-KR":"HTTP 포트","nl-NL":"HTTP-poort"},"HTTPS Port":{"de-DE":"HTTPS Port","fr-FR":"Port HTTPS","it-IT":"Porta HTTPS","ko-KR":"HTTPS 포트","nl-NL":"HTTPS-poort"},"Hardware":{},"HifiBerry DAC+ HD":{},"HifiBerry DAC+ADC":{},"HifiBerry DAC+ADC PRO":{},"HifiBerry DAC+DSP":{},"HifiBerry Digi and Digi+":{},"Hifiberry DAC":{},"Hifiberry DAC Plus":{},"Hifiberry Digi+ Pro":{},"Highlight color":{"de-DE":"Highlight Farbe","es-VE":"Color de realce","fi-FI":"Valintaväri","fr-FR":"Couleur de mise en valeur","it-IT":"Colore evidenziazioni","ko-KR":"강조색","nl-NL":"Accentkleur"},"Home":{"de-DE":"Startseite","it-IT":"Home","ko-KR":"홈"},"Homepage":{"de-DE":"Homepage","es-VE":"Página de Inicio","fi-FI":"Kotisivu","fr-FR":"Page web","it-IT":"Homepage","ko-KR":"홈페이지","nl-NL":"Website"},"Homescreen welcome":{"de-DE":"Du hast noch keine Homeicons hinzugefügt. Du kannst einzelne Ansichten, Wiedergabelisten und Skripte hinzufügen.","en-US":"You have not added any home icons yet. You can add views, playlists and scripts.","it-IT":"Benvenuto","ko-KR":"홈 아이콘을 아직 추가하지 않았습니다. 보기, 연주목록, 스크립트를 추가할 수 있습니다."},"Hours":{"de-DE":"Std","en-US":"Hrs","es-VE":"Horas","fi-FI":"Tuntia","fr-FR":"Heures","it-IT":"Ore","ko-KR":"시간","nl-NL":"h"},"IP-Address":{"de-DE":"IP-Adresse","es-VE":"Dirección IP","fi-FI":"IP-osoite","fr-FR":"Adresse IP","it-IT":"Indirizzo IP","ko-KR":"IP 주소","nl-NL":"IP-adres"},"IQAudIO Digi":{},"IQaudio Codec":{},"IQaudio DAC":{},"IQaudio DAC+":{},"Info":{"de-DE":"Hinweis","es-VE":"Info","fi-FI":"Tietoa","fr-FR":"Infos","it-IT":"Info","ko-KR":"정보","nl-NL":"Info"},"Initializing myMPD":{"de-DE":"Initialisiere myMPD","es-VE":"Inicializando myMPD","fi-FI":"Käynnistetään myMPD","fr-FR":"Initialisation de myMPD","it-IT":"Inizializzazione di myMPD in corso","ko-KR":"myMPD 초기화","nl-NL":"Voorbereiden myMPD"},"Install":{},"Invalid API request":{"de-DE":"Ungültiger API Befehl","es-VE":"Solicitud API incorrecta","fi-FI":"Virheellinen API pyyntö","fr-FR":"Requête API non valide","it-IT":"Richiesta API non valida","ko-KR":"잘못된 API 요구","nl-NL":"Ongeldig API-verzoek"},"Invalid CSS filter":{"de-DE":"Ungültiger CSS Filter","es-VE":"Filtro CSS inválido","fi-FI":"Virheellinen CSS suodatin","fr-FR":"Filtre CSS non valide","it-IT":"Filtro CSS non valido","ko-KR":"잘못된 CSS 필터","nl-NL":"Ongeldig CSS-filter"},"Invalid IP address":{},"Invalid MPD host":{"de-DE":"Ungültiger MPD Host","es-VE":"Servidor MPD inválido","fi-FI":"Virheellinen MPD isäntä","fr-FR":"Hôte MPD non valide","it-IT":"Hoste MPD non valido","ko-KR":"잘못된 MPD 호스트","nl-NL":"Ongeldige MPD host"},"Invalid MPD password":{"de-DE":"Ungültiges MPD Passwort","es-VE":"Contraseña MPD inválida","fi-FI":"Virheellinen MPD salasana","fr-FR":"Mot de passe MPD non valide","it-IT":"Password MPD non valida","ko-KR":"잘못된 MPD 비밀번호","nl-NL":"Ongeldig MPD wachtwoord"},"Invalid MPD port":{"de-DE":"Ungültiger MPD Port","es-VE":"Puerto MPD inválido","fi-FI":"Virheellinen MPD Portti","fr-FR":"Port MPD non valide","it-IT":"Porta MPD non valida","ko-KR":"잘못된 MPD 포트","nl-NL":"Ongeldige MPD poort"},"Invalid URI":{"de-DE":"Ungültige URL","es-VE":"URL Inválida","fi-FI":"Epäkelpo URI","fr-FR":"URL non valide","it-IT":"URI non valido","ko-KR":"잘못된 주소","nl-NL":"Ongeldige url"},"Invalid backend uri":{"de-DE":"Ungültige einzuhängende URL","es-VE":"URL de Back-End inválida","fi-FI":"Virheellinen järjestelmä uri","fr-FR":"URL du backend non valide","it-IT":"URI del backend non valido","ko-KR":"잘못된 백엔드 URL","nl-NL":"Ongeldige backend-url"},"Invalid channel name":{"de-DE":"Ungültiger Channel name","es-VE":"Nombre de canal inválido","fi-FI":"Virheellinen kanavanimi","fr-FR":"nom de canal non valide","it-IT":"Nome canale non valido","ko-KR":"잘못된 채널 이름","nl-NL":"ongeldige naam"},"Invalid color":{"de-DE":"Ungültige Farbe","es-VE":"Color inválido","fi-FI":"Virheellinen väri","fr-FR":"Couleur non valide","it-IT":"Colore non valido","ko-KR":"잘못된 색상","nl-NL":"Ongeldige kleur"},"Invalid column":{"de-DE":"Ungültiger Spaltenname","fi-FI":"Väärä sarake","fr-FR":"Colonne non valide","it-IT":"Colonna non valida","ko-KR":"잘못된 열","nl-NL":"Onjuiste kolom"},"Invalid filename":{"de-DE":"Ungültiger Dateiname","es-VE":"Nombre de archivo inválido","fi-FI":"Väärä tiedostonimi","fr-FR":"Nom de fichier non valide","it-IT":"Nome file non valido","ko-KR":"잘못된 파일 이름","nl-NL":"Ongeldige bestandsnaam"},"Invalid message":{"de-DE":"Ungültige Zeichen in Nachricht","es-VE":"Mensaje inválido","fi-FI":"Virheellinen viesti","fr-FR":"Message non valide","it-IT":"Messaggio non valido","ko-KR":"잘못된 메시지","nl-NL":"Ongeldig bericht"},"Invalid mount point":{"de-DE":"Ungültiger Einhängepunkt","es-VE":"Punto de montaje inválido","fi-FI":"Virheellinen liityntäköhta","fr-FR":"Point de montage non valide","it-IT":"Punto di montaggio non valido","ko-KR":"잘못된 마운트 위치","nl-NL":"Ongeldig aankoppelpunt"},"Invalid music directory":{"de-DE":"Ungültiges Musikverzeichnis","es-VE":"Directorio de música inválido","fi-FI":"Virheellinen musiikkikansio","fr-FR":"Dossier musical non valide","it-IT":"Cartella musica non valida","ko-KR":"잘못된 음원 디렉터리","nl-NL":"Ongeldige muziekmap"},"Invalid name":{"de-DE":"Ungültiger Name","es-VE":"Nombre inválido","fi-FI":"Virheellinen nimi","fr-FR":"Nom non valide","it-IT":"Nome non valido","ko-KR":"잘못된 이름","nl-NL":"Ongeldige naam"},"Invalid number":{"de-DE":"Ungültige Zahl","es-VE":"Número inválido","fi-FI":"Virheellinen numero","fr-FR":"Nombre non valide","it-IT":"Numero non valido","ko-KR":"잘못된 숫자","nl-NL":"Ongeldig getal"},"Invalid partition name":{"de-DE":"Ungültiger Partition Name","fr-FR":"Nom de partition non valide","it-IT":"Nome partizione non valido","ko-KR":"잘못된 파티션 이름","nl-NL":"Ongeldige partitienaam"},"Invalid prefix":{"de-DE":"Ungültiger Prefix","es-VE":"Prefijo inválido","fi-FI":"Virheellinen etuliite","fr-FR":"Préfixe non valide","it-IT":"Prefisso non valido","ko-KR":"잘못된 덧붙임","nl-NL":"Ongeldig voorvoegsel"},"Invalid scale ratio":{"de-DE":"Ungültiger Skalierungswert","fr-FR":"Ratio d'échelle non valide","it-IT":"Rapporto di scala non valido","ko-KR":"잘못된 크기 비율","nl-NL":"Ongeldige schaalverhouding"},"Invalid script API request":{"de-DE":"Ungültiger Script-API Aufruf","fr-FR":"Requête d'API des scripts non valide","it-IT":"Richiesta API dello script non valida","ko-KR":"잘못된 스크립트 API 요청","nl-NL":"Ongeldige script-API-verzoek"},"Invalid script argument":{"de-DE":"Ungültiger Skriptparameter","fr-FR":"Paramètre de script non valide","it-IT":"Parametro script non valido","ko-KR":"잘못된 스크립트 변수","nl-NL":"Ongeldig scriptargument"},"Invalid script name":{"de-DE":"Ungültiger Skriptname","fr-FR":"Nom du script non valide","it-IT":"Nome script non valido","ko-KR":"잘못된 스크립트 이름","nl-NL":"Ongeldige script naam"},"Invalid script order":{"de-DE":"Ungültige Skriptreihenfolge","fr-FR":"Ordre du script non valide","it-IT":"Ordine script non valido","ko-KR":"잘못된 스크립트 순서","nl-NL":"Ongeldige scriptvolgorde"},"Invalid server":{},"Invalid size":{"de-DE":"Ungültige Größe","es-VE":"Tamaño inválido","fi-FI":"Virheellinen koko","fr-FR":"Taille non valide","it-IT":"Dimensione non valida","ko-KR":"잘못된 크기","nl-NL":"Ongeldige grootte"},"Invalid trigger name":{"de-DE":"Ungültiger Trigger Name","fr-FR":"Nom du déclencheur non valide","it-IT":"Nome trigger non valido","ko-KR":"잘못된 트리거 이름","nl-NL":"Ongeldige triggernaam"},"Invalid type":{"de-DE":"Ungültiger Typ","es-VE":"Tipo inválido","fi-FI":"Väärä tyyppi","fr-FR":"Type de fichier non valide","it-IT":"Tipo file non valido","ko-KR":"잘못된 형식","nl-NL":"Ongeldig type"},"Invalid uri":{"de-DE":"Ungültige URI","it-IT":"URI non valido","ko-KR":"잘못된 URI"},"Invalid volume level":{"de-DE":"Ungültige Lautstärke","it-IT":"Livello volume non valido","ko-KR":"잘못된 음량 수준"},"JavaScript error":{"de-DE":"JavaScript Fehler","es-VE":"Error de JavaScript","fi-FI":"JavaScript virhe","fr-FR":"Erreur JavaScript","it-IT":"Errore JavaScript","ko-KR":"자바스크립트 오류","nl-NL":"JavaScript fout"},"JavaScript is disabled":{"de-DE":"JavaScript ist deaktiviert","es-VE":"JavaScript esta deshabilitado","fi-FI":"JavaScript poistettu käytöstä","fr-FR":"JavaScript est désactivé","it-IT":"JavaScript è disabilitato","ko-KR":"자바스크립트 사용 안 함","nl-NL":"JavaScript uitgeschakeld"},"Jukebox":{"de-DE":"Jukebox","es-VE":"Jukebox","fi-FI":"Jukebox","fr-FR":"Jukebox","it-IT":"Jukebox","ko-KR":"뮤직박스","nl-NL":"Jukebox"},"Jukebox mode":{"de-DE":"Jukebox Modus","es-VE":"Modo Jukebox","fi-FI":"Jukebox tila","fr-FR":"Mode Jukebox","it-IT":"Modo Jukebox","ko-KR":"뮤직박스 모드","nl-NL":"Jukebox-modus"},"JustBoom DAC Hat/Amp HAT/DAC Zero/Amp Zero":{},"JustBoom Digi & Digi Zero":{},"Justboom-dac and justboom-digi simultaneous usage":{},"Keep queue length":{"de-DE":"Warteschlangenlänge","es-VE":"Mantener longitud de cola de reproducción","fi-FI":"Pidä jonon pituus","fr-FR":"Garder la longueur de la queue","it-IT":"Mantieni la lunghezza della coda","ko-KR":"순서 길이 유지","nl-NL":"Aantal in wachtrij"},"LOSSLESS":{},"LOW":{},"Label":{"de-DE":"Herausgeber","es-VE":"Etiqueta","fi-FI":"Julkaisija","fr-FR":"Label","it-IT":"Etichetta","ko-KR":"음반사","nl-NL":"Label"},"Last modified":{"de-DE":"Zuletzt geändert","es-VE":"Últ. modificación","fi-FI":"Viimeksi muokattu","fr-FR":"Dernier modifié","it-IT":"Ultimo modificato","ko-KR":"앞서 수정함","nl-NL":"Laatst gewijzigd"},"Last page":{"de-DE":"Letzte Seite","ko-KR":"끝 페이지"},"Last played":{"de-DE":"Zuletzt gespielt","es-VE":"Última reproducción","fi-FI":"Viimeksi soitettu","fr-FR":"Dernier joué","it-IT":"Ultimo riprodotto","ko-KR":"앞서 연주함","nl-NL":"Laatst afgespeeld"},"Last played list count":{"de-DE":"Anzahl zuletzt gespielte Lieder","es-VE":"Conteo reproducción de última lista","fi-FI":"Viimeksi soitettujen listan koko","fr-FR":"Décompte des derniers lus","it-IT":"Conteggio ultima lista riprodotta","ko-KR":"앞선 연주 목록 개수","nl-NL":"Aantal laatst afgespeelde nummers"},"Last played older than (hours)":{"de-DE":"Zuletzte gespielt, vor mehr als (Stunden)","es-VE":"Última reproducción mas viejo que (horas)","fi-FI":"Viimeksi toistettu vanhempi kuin (Stunden)","fr-FR":"Dernier lu de plus de (heures)","it-IT":"Riprodotto per l'ultima volta prima di (heures)","ko-KR":"이전에 연주됨 (시간)","nl-NL":"Laatst afgespeeld, ouder dan (uur)"},"Last skipped":{"de-DE":"Zuletzt übersprungen","es-VE":"Última omisión","fi-FI":"Viimeksi ohitettu","fr-FR":"Dernier ignoré","it-IT":"Ultimo saltato","ko-KR":"앞서 건너뜀","nl-NL":"Laatst overgeslagen"},"LastModified":{"de-DE":"Zuletzt geändert","en-US":"Last modified","es-VE":"Últ. modif.","fi-FI":"ViimeksiMuokattu","fr-FR":"Dernière modification","it-IT":"Ultima modifica","ko-KR":"마지막 수정","nl-NL":"Laatst gewijzigd"},"LastPlayed":{"de-DE":"Zuletzt gespielt","es-VE":"Última reproducción","fi-FI":"ViimeksiSoitettu","fr-FR":"Dernier joué","it-IT":"Ultimo riprodotto","ko-KR":"앞서 연주함","nl-NL":"Laatst afgespeeld"},"Latest version":{},"Leaving playlist as it is":{"de-DE":"Wiedergabeliste wird nicht verändert","es-VE":"Dejando la lista de reproducción como está","fi-FI":"Soittolista jätetään entiselleen","fr-FR":"Laisser la liste de lecture inchangée","it-IT":"Lascia lista di riproduzione inalterata","ko-KR":"연주목록을 그대로 둠","nl-NL":"Afspeellijst niet gewijzigd"},"Libmpdclient version":{"de-DE":"Libmpdclient Version","es-VE":"Versión Libmpdclient","fi-FI":"Libmpdclient Versio","fr-FR":"Version de Libmpdclient","it-IT":"Versione di Libmpdclient","ko-KR":"Libmpdclient 버전","nl-NL":"Versie libmpdclient"},"Libmympdclient version":{"de-DE":"Libmympdclient Version","es-VE":"Versión Libmympdclient","fi-FI":"Libmympdclient Versio","fr-FR":"Version de Libmympdclient","it-IT":"Versione di Libmympdclient","ko-KR":"Libmympdclient 버전","nl-NL":"Versie libmympdclient"},"Ligature":{"de-DE":"Ligatur","it-IT":"Legatura","ko-KR":"연결"},"Ligature overview":{"de-DE":"Übersicht der Ligaturen","it-IT":"Panoramica legature","ko-KR":"연결 미리보기"},"Light":{"de-DE":"Hell","es-VE":"Claro","fi-FI":"Vaalea","fr-FR":"Clair","it-IT":"Chiaro","ko-KR":"밝음","nl-NL":"Licht"},"Like":{"de-DE":"Wertung","es-VE":"Me gusta","fi-FI":"Tykkää","fr-FR":"J'aime","it-IT":"Mi piace","ko-KR":"좋아요","nl-NL":"Like"},"Like song":{"de-DE":"Gutes Lied","es-VE":"Me gusta esta canción","fi-FI":"Tykkää kappaleesta","fr-FR":"J'aime cette chanson","it-IT":"Mi piace questa canzone","ko-KR":"곡 좋아요","nl-NL":"Like nummer"},"Local playback":{"de-DE":"Lokale Wiedergabe","es-VE":"Reproducción local","fi-FI":"Paikallinen toisto","fr-FR":"Lecture locale","it-IT":"Lecture locale","ko-KR":"로컬 연주","nl-NL":"Lokale weergave"},"Locale":{"de-DE":"Sprache","es-VE":"Idioma","fi-FI":"Kielivalinta","fr-FR":"Langue","it-IT":"Lingua","ko-KR":"언어","nl-NL":"Taal"},"Lookup at musicbrainz":{"de-DE":"Bei Musicbraonz nachschlagen","ko-KR":"뮤직브레인즈에서 찾기"},"Love song":{"de-DE":"Lieblingslied","es-VE":"Me encanta esta canción","fi-FI":"Rakkauslaulu","fr-FR":"J'adore cette chanson","it-IT":"\"Adoro\" questa canzone","ko-KR":"애청곡","nl-NL":"Favoriet"},"Lyrics":{"de-DE":"Liedtext","es-VE":"Letras","fi-FI":"Sanoitukset","fr-FR":"Paroles","it-IT":"Testi","ko-KR":"가사","nl-NL":"Songtekst"},"MPD channel":{"de-DE":"MPD Channel","es-VE":"Canal MPD","fi-FI":"MPD kanava","fr-FR":"Canal MPD","it-IT":"Canale MPD","ko-KR":"MPD 채널","nl-NL":"MPD-kanaal"},"MPD channel not found":{"de-DE":"MPD Channel nicht gefunden","es-VE":"Canal MPD no encontrado","fi-FI":"MPD kanavaa ei löytynyt","fr-FR":"Canal MPD non trouvé","it-IT":"Canale MPD non trovato","ko-KR":"MPD 채널 없음","nl-NL":"MPD-kanaal niet gevonden"},"MPD connection":{"de-DE":"MPD Verbindung","es-VE":"Conexión MPD","fi-FI":"MPD Yhteys","fr-FR":"Connection MPD","it-IT":"Connessione MPD","ko-KR":"MPD 연결","nl-NL":"MPD-verbinding"},"MPD connection error: %{error}":{"de-DE":"MPD Verbindungsfehler: %{error}","es-VE":"Error de conexión MPD: %{error}","fi-FI":"MPD yhteysvirhe: %{error}","fr-FR":"Erreur de connection MPD : %{error}","it-IT":"Errore connessione MPD : %{error}","ko-KR":"MPD 연결 오류: %{error}","nl-NL":"MPD verbindingsfout: %{error}"},"MPD disconnected":{"de-DE":"MPD nicht verbunden","es-VE":"MPD desconectado","fi-FI":"MPD yhteys katkaistu","fr-FR":"MPD déconnecté","it-IT":"MPD disconnesso","ko-KR":"MPD 연결 끊어짐","nl-NL":"MPD niet verbonden"},"MPD host":{"de-DE":"MPD Host","es-VE":"Servidor MPD","fi-FI":"MPD isäntä","fr-FR":"Hôte MPD","it-IT":"Host MPD","ko-KR":"MPD 호스트","nl-NL":"MPD host"},"MPD password":{"de-DE":"MPD Passwort","es-VE":"Contraseña MPD","fi-FI":"MPD Salasana","fr-FR":"Mot de passe MPD","it-IT":"Password MPD","ko-KR":"MPD 비밀번호","nl-NL":"MPD wachtwoord"},"MPD port":{"de-DE":"MPD Port","es-VE":"Puerto MPD","fi-FI":"MPD Portti","fr-FR":"Port MPD","it-IT":"Porta MPD","ko-KR":"MPD 포트","nl-NL":"MPD-poort"},"MPD stickers are disabled":{"de-DE":"MPD Sticker sind deaktiviert","es-VE":"Los Stickers MPD están deshabilitados","fi-FI":"MPD Stickerit pois käytöstä","fr-FR":"Les stickers MPD sont désactivés","it-IT":"Gli sticker MPD sono disabilitati","ko-KR":"MPD 스티커 사용 안 함","nl-NL":"MPD-stickers uitgeschakeld"},"MPD uptime":{"de-DE":"MPD Uptime","es-VE":"Tiempo de actividad MPD","fi-FI":"MPD Uptime","fr-FR":"MPD Uptime","it-IT":"MPD Uptime","ko-KR":"MPD 가동 시간","nl-NL":"MPD uptime"},"MUSICBRAINZ_ALBUMARTISTID":{"de-DE":"Musicbrainz AlbumArtist ID","es-VE":"Musicbrainz AlbumArtist ID","fi-FI":"Musicbrainz AlbumiArtisti ID","fr-FR":"MUSICBRAINZ_ALBUMARTISTID","it-IT":"MUSICBRAINZ_ALBUMARTISTID","ko-KR":"뮤직브레인즈 음반 연주자 ID","nl-NL":"Musicbrainz AlbumArtist ID"},"MUSICBRAINZ_ALBUMID":{"de-DE":"Musicbrainz Album ID","es-VE":"Musicbrainz Album ID","fi-FI":"Musicbrainz Albumi ID","fr-FR":"MUSICBRAINZ_ALBUMID","it-IT":"MUSICBRAINZ_ALBUMID","ko-KR":"뮤직브레인즈 음반 ID","nl-NL":"Musicbrainz Album ID"},"MUSICBRAINZ_ARTISTID":{"de-DE":"Musicbrainz Künstler ID","es-VE":"Musicbrainz Artist ID","fi-FI":"Musicbrainz artisti ID","fr-FR":"MUSICBRAINZ_ARTISTID","it-IT":"MUSICBRAINZ_ARTISTID","ko-KR":"뮤직브레인즈 연주자 ID","nl-NL":"Musicbrainz Ariest ID"},"MUSICBRAINZ_RELEASETRACKID":{"de-DE":"Musicbrainz Release Track ID","es-VE":"Musicbrainz Release Track ID","fi-FI":"Musicbrainz Release Track ID","fr-FR":"MUSICBRAINZ_RELEASETRACKID","it-IT":"MUSICBRAINZ_RELEASETRACKID","ko-KR":"뮤직브레인즈 발표 곡 ID","nl-NL":"Musicbrainz Release Track ID"},"MUSICBRAINZ_TRACKID":{"de-DE":"Musicbrainz Track ID","es-VE":"Musicbrainz Track ID","fi-FI":"Musicbrainz Track ID","fr-FR":"MUSICBRAINZ_TRACKID","it-IT":"MUSICBRAINZ_TRACKID","ko-KR":"뮤직브레인즈 곡 ID","nl-NL":"Musicbrainz Track ID"},"MUSICBRAINZ_WORKID":{"de-DE":"Musicbrainz Werk ID","es-VE":"Musicbrainz Work ID","fi-FI":"Musicbrainz Työ ID","fr-FR":"MUSICBRAINZ_TRACKID","it-IT":"MUSICBRAINZ_TRACKID","ko-KR":"뮤직브레인즈 작품 ID","nl-NL":"Musicbrainz Werk ID"},"MaintainEnableTagsText":{"de-DE":"Folgende Tags sollten gepflegt und aktiviert sein: Artist, AlbumArtist, Album, Track, Disc and Genre","en-US":"You should maintain and enable the tags Artist, AlbumArtist, Album, Track, Disc and Genre for best user experience.","it-IT":"MaintainEnableTagsText","ko-KR":"최고의 사용자 경험을 위해서는 연주자, 음반 연주자, 음반, 곡, 디스크, 장르 태그를 관리하고 사용해야 합니다."},"Mamboberry DACs":{},"Max. songs":{"de-DE":"Max. Lieder","es-VE":"Canciones max.","fi-FI":"Max. kappaleet","fr-FR":"Chansons max.","it-IT":"Max canzoni","ko-KR":"최대 곡","nl-NL":"Max. nummers"},"Maxim MAX98357A":{},"Media session support":{"de-DE":"Media Session Unterstützung","es-VE":"Soporte de sesión de medios","fi-FI":"Media Session tuki","fr-FR":"Session de médias supportée","it-IT":"Supporto media session","ko-KR":"미디어 세션 지원","nl-NL":"Mediasessie ondersteuning"},"Message":{"de-DE":"Nachricht","es-VE":"Mensaje","fi-FI":"Viesti","fr-FR":"Message","it-IT":"Messaggio","ko-KR":"메시지","nl-NL":"Bericht"},"Min. value":{"de-DE":"Min. Wert","es-VE":"Valor min.","fi-FI":"Min. arvo","fr-FR":"Valeur min.","it-IT":"Valore min.","ko-KR":"최소 값","nl-NL":"Min. waarde"},"Minimum one weekday must be selected":{"de-DE":"Es muss mindestens ein Wochentag ausgewählt sein.","es-VE":"Debe seleccionar al menos un dia de la semana","fi-FI":"Vähintään yksi päivä pitää valita","fr-FR":"Choisir wu moins un jour","it-IT":"Deve essere selezionato almeno un giorno della settimana","ko-KR":"최소 일주일 선택해야 함","nl-NL":"Selecteer minimaal 1 weekdag"},"Minutes":{"de-DE":"Min","en-US":"Min","es-VE":"Min","fi-FI":"Min","fr-FR":"Min","it-IT":"Minuti","ko-KR":"분","nl-NL":"min"},"Mixramp DB":{"de-DE":"Mixramp DB","es-VE":"Mixramp dB","fi-FI":"Mixramp DB","fr-FR":"Mixramp DB","it-IT":"Mixramp DB","ko-KR":"Mixramp DB","nl-NL":"Mixramp DB"},"Mixramp delay":{"de-DE":"Mixramp Verzögerung","es-VE":"Retraso Mixramp","fi-FI":"Mixramp viive","fr-FR":"Délai de Mixramp","it-IT":"Ritardo mixramp","ko-KR":"Mixramp 지연","nl-NL":"Mixramp-vertraging"},"Mon":{"de-DE":"Mo","es-VE":"Lun","fi-FI":"Ma","fr-FR":"Lun","it-IT":"Lun","ko-KR":"월","nl-NL":"Ma"},"Mongoose version":{"de-DE":"Mongoose Version","es-VE":"Versión Mongoose","fi-FI":"Mongoose Versio","fr-FR":"Version Mongoose","it-IT":"Versione Mongoose","ko-KR":"Mongoose 버전","nl-NL":"Versie Mongoose"},"Most played":{"de-DE":"Am Öftesten gespielt","es-VE":"Más reproducido","fi-FI":"Eniten soitettu","fr-FR":"Plus joués","it-IT":"Plus suonati","ko-KR":"자주 연주","nl-NL":"Meest afgespeeld"},"Mount point":{"de-DE":"Einhängepunkt","es-VE":"Punto de monaje","fi-FI":"Liityntäkohta","fr-FR":"Point de montage","it-IT":"Punto di montaggio","ko-KR":"마운트 위치","nl-NL":"Aankoppelpunt"},"Mounts":{"de-DE":"Einhängepunkte","es-VE":"Montar","fi-FI":"Liitokset","fr-FR":"Montages (dossier)","it-IT":"Montaggi (filesystem)","ko-KR":"마운트","nl-NL":"Aankoppelpunten"},"Move an output to this partition":{"de-DE":"Verschiebe ein Ausgabegerät zu dieser Partition","fr-FR":"Déplacer une sortie sur cette partition","it-IT":"Muovi un'uscita su questa partizione","ko-KR":"출력을 이 파티션으로 옮김","nl-NL":"Verplaats output naar deze partitie"},"Music directory":{"de-DE":"Musikverzeichnis","es-VE":"Directorio de música","fi-FI":"Musiikkikansio","fr-FR":"Dossier musical","it-IT":"Cartella musicale","ko-KR":"음원 디렉터리","nl-NL":"Muziekmap"},"Music directory not found":{"de-DE":"Musikverzeichnis nicht gefunden","es-VE":"Directorio de música no encontrado","fi-FI":"Musiikkikansiota ei löydy","fr-FR":"Dossier musical non trouvé","it-IT":"Cartella musica non travata","ko-KR":"음원 디렉터리 없음","nl-NL":"Muziekmap niet gevonden"},"Music folder path in NAS (e.g. /music)":{},"Must be a number":{"de-DE":"Muss eine Zahl sein","es-VE":"Debe ser un número","fi-FI":"Pitää olla numero","fr-FR":"Doit être un nombre","it-IT":"Deve essere un numero","ko-KR":"숫자여야 함","nl-NL":"Moet een getal zijn"},"Must be a number and equal or greater than zero":{"de-DE":"Muss eine Zahl größergleich 0 sein","es-VE":"Debe ser un número igual o mayor a cero","fi-FI":"Pitää olla numero joka on nolla tai suurempi","fr-FR":"Doit être un nombre supérieur ou égal à zéro","it-IT":"Deve essere un numero e maggiore o uguale a zero","ko-KR":"숫자이고 0과 같거나 커야 함","nl-NL":"Getal moet gelijk of groter zijn dan 0"},"Must be a number and greater than zero":{"de-DE":"Muss eine Zahl größer als 0 sein","es-VE":"Debe ser un número mayor a cero","fi-FI":"Tarvii olla numero joka on suurempi kuin 0","fr-FR":"Doit être un nombre supérieur à zéro","it-IT":"Dever essere un numero e maggiore di zero","ko-KR":"0보다 큰 숫자여야 함","nl-NL":"Moet een getal zijn en groter dan 0"},"NAS IP address":{},"NFS":{},"Name":{"de-DE":"Name","es-VE":"Nombre","fi-FI":"Nimi","fr-FR":"Nom","it-IT":"Nome","ko-KR":"이름","nl-NL":"Naam"},"Neighbors are disabled":{"de-DE":"Kein Neighbor Plugin aktiviert","fi-FI":"Naapurit lisäosa poissa käytöstä","fr-FR":"Les plugins voisins sont désactivés","it-IT":"I neighbors plugin sono disabilitati","ko-KR":"Neighbors 사용 안 함","nl-NL":"Neighbor-plugin uitgeschakeld"},"Network":{},"New mount":{"de-DE":"Neuer Einhängepunkt","es-VE":"Nuevo punto de montaje","fi-FI":"Uusi liitos","fr-FR":"Nouveau montage (dossier)","it-IT":"Nuovo montaggio (filesystem)","ko-KR":"새로운 마운트","nl-NL":"Nieuw aankoppelpunt"},"New partition":{"de-DE":"Neue Partition","fr-FR":"Nouvelle partition","it-IT":"Nuova partition","ko-KR":"새 파티션","nl-NL":"Nieuwe partitie"},"New playlist":{"de-DE":"Neue Wiedergabeliste","es-VE":"Nueva lista de reproducción","fi-FI":"Uusi soittolista","fr-FR":"Nouvelle liste de lecture","it-IT":"Nuova lista di riproduzione","ko-KR":"새 연주목록","nl-NL":"Nieuwe afspeellijst"},"New script":{"de-DE":"Neues Skript","fr-FR":"Nouveau script","it-IT":"Nuovo script","ko-KR":"새 스크립트","nl-NL":"Nieuw script"},"New timer":{"de-DE":"Neuer Timer","es-VE":"Nuevo Temporizador","fi-FI":"Uusi ajastin","fr-FR":"Nouvelle temporisation","it-IT":"Nuovo timer","ko-KR":"새로운 타이머","nl-NL":"Nieuwe Timer"},"New trigger":{"de-DE":"Neuer Trigger","fr-FR":"Nouveau déclencheur","it-IT":"Nuovo trigger","ko-KR":"새 트리거","nl-NL":"Nieuwe trigger"},"Newest songs":{"de-DE":"Neueste Lieder","es-VE":"Canciones mas recientes","fi-FI":"Uusimmat kappaleet","fr-FR":"Nouvelles chansons","it-IT":"Canzoni più nuove","ko-KR":"새 곡","nl-NL":"Nieuwste nummers"},"Next":{"de-DE":"Nächstes Lied","it-IT":"Successivo","ko-KR":"다음"},"Next in queue":{},"Next page":{"de-DE":"Nächste Seite","es-VE":"Página siguiente","fi-FI":"Seuraava sivu","fr-FR":"Page suivante","it-IT":"Pagina successiva","ko-KR":"다음 페이지","nl-NL":"Volgende pagina"},"Next song":{"de-DE":"Nächstes Lied","es-VE":"Canción siguiente","fi-FI":"Seuraava kappale","fr-FR":"Chanson suivante","it-IT":"Brano seguente","ko-KR":"다음 곡","nl-NL":"Volgende nummer"},"No action selected":{"de-DE":"Keine Aktion ausgewählt","fr-FR":"Pas d'action séléctionnée","it-IT":"Nessuna azione selezionata","ko-KR":"기능 선택 안 됨","nl-NL":"Geen actie geselecteerd"},"No albumart found by mpd":{"de-DE":"MPD konnte keine Cover finden","es-VE":"No se encontró carátula por MPD","fi-FI":"MPD ei löytäny albumi taidetta","fr-FR":"MPD n'a pas trouvé de jaquette","it-IT":"MPD non ha trovato la copertina","ko-KR":"MPD가 음반 표지를 찾을 수 없음","nl-NL":"Geen albumcover gevonden door MPD"},"No bookmarks found":{"de-DE":"Keine Lesezeichen gefunden","es-VE":"No se encontraron marcadores","fi-FI":"Kirjanmerkkejä ei löytynyt","fr-FR":"Marque-pages non trouvés","it-IT":"Nessun segnalibro trovato","ko-KR":"즐겨찾기를 찾을 수 없음","nl-NL":"Geen bladwijzers gevonden"},"No current song":{"de-DE":"Kein Lied ausgwählt","es-VE":"No hay canción actual","fi-FI":"Ei toistettavaa kappaletta","fr-FR":"Pas de chanson en cours","it-IT":"Nessun brano in riproduzione","ko-KR":"지금 곡 없음","nl-NL":"Geen nummer gekozen"},"No lyrics found":{"de-DE":"Kein Songtext gefunden","fi-FI":"Sanoituksia ei löydy","fr-FR":"Pas de paroles trouvées","it-IT":"Testo non trovato","ko-KR":"가사 없음","nl-NL":"Geen songteksten gevonden"},"No mixed content,  MPD stream must be served over https:":{"de-DE":"Mixed Content: MPD stream muss über https ausgeliefert werden:","fr-FR":"Mixed Content: le flux MPD doit être servi sur https : ","it-IT":"Nessun contenuto misto: il flusso MPD deve essere sertvito su https : ","ko-KR":"혼합된 컨텐트는 안되며, MPD 스트리밍은 https:를 통해야 합니다.","nl-NL":"Geen gemengde inhoud, MPD-stream moet via https worden weergegeven:"},"No mpd state for script execution submitted":{"de-DE":"Es wurde kein MPD Status für die Skriptausführung mitgeliefert","fr-FR":"Pas d'état de mpd fourni pour l'exécution du script","it-IT":"Manca lo stato mpd per l'esecuzione dello script","ko-KR":"스크립트 실행을 위한 MPD 상태 없음","nl-NL":"Geen MPD-status voor uitvoering script gegeven"},"No outputs":{"de-DE":"Keine Ausgabegeräte","fr-FR":"Pas de sortie","it-IT":"Nessuna uscita","ko-KR":"출력 없음","nl-NL":"Geen output"},"No playlists found":{"de-DE":"Keine Wiedergabelisten gefunden","es-VE":"No se encontraron Listas de reproducción","fi-FI":"Soittolistoja ei löydy","fr-FR":"Pas de liste de lecture trouvée","it-IT":"Nessuna lista di riproduzione trovata","ko-KR":"연주목록 찾을 수 없음","nl-NL":"Geen afspeellijsten gevonden"},"No response for method %{method}":{"de-DE":"Keine Rückmeldung für Aufruf %{method}","es-VE":"Sin respuesta para el método %{method}","fi-FI":"Ei vastausta metodiin %{method}","fr-FR":"Pas de retour pour la méthide %{method}","it-IT":"Nessuna risposta per il metodo %{method}","ko-KR":"%{method} 응답 없음","nl-NL":"Geen antwoord op methode %{method}"},"No results, please refine your search":{"de-DE":"Keine Ergebnisse, bitte passe die Suche an","es-VE":"Sin resultados, cambie los parámetros de búsqueda","fi-FI":"Ei tuloksia, tarkista hakuehdot","fr-FR":"Pas de résultats, veuillez préciser la rechercher","it-IT":"Nessun risultato, su prega di affinare la ricerca","ko-KR":"결과가 없으므로, 맞게 찾아야 함","nl-NL":"Geen hits, gebruik andere zoekterm"},"No search expression defined":{"de-DE":"Kein Suchausdruck angegeben","es-VE":"Ninguna expresión de búsqueda definida","fi-FI":"Hakutermiä ei määritetty","fr-FR":"Pas d'expression de recherche définie","it-IT":"Nessuna espressione di ricerca definita","ko-KR":"찾을 문구 없음","nl-NL":"Zoekopdracht niet gedefinieerd"},"No search tag defined and advanced search is disabled":{"de-DE":"Kein Such-Tag definiert und erweiterte Suche ist deaktiviert.","fr-FR":"Pas de tag de recherche défini et la recherche avancée est désactivée","it-IT":"Nessun tag di ricerca definito e la ricerca avanzata è disabilitata","ko-KR":"검색 태그가 없고 정의되지 않고 고급 검색을 사용 안 함","nl-NL":"Geen zoektag gedefinieerd en geavanceerd zoeken is uitgeschakeld"},"No such directory":{"de-DE":"Verzeichnis nicht gefunden","es-VE":"No se encontró ese directorio","fi-FI":"Kansiota ei ole","fr-FR":"Dossier introuvable","it-IT":"Cartella non trovata","ko-KR":"그런 디렉터리가 없음","nl-NL":"Map niet gevonden"},"None":{"de-DE":"Keines","es-VE":"Ninguno","fi-FI":"Ei mitään","fr-FR":"Rien","it-IT":"Nessuna","ko-KR":"없음","nl-NL":"Geen"},"None (not applicable)":{},"Notifications":{"de-DE":"Hinweise","es-VE":"Notificaciones","fi-FI":"Ilmoitukset","fr-FR":"Notifications","it-IT":"Notifiche","ko-KR":"알림","nl-NL":"Notificaties"},"Notifications are blocked":{"de-DE":"Benachrichtungen sind nicht erlaubt","es-VE":"Las Notificaciones están bloqueadas","fi-FI":"Ilmoitukset on estetty","fr-FR":"Les notifications sont bloquées","it-IT":"Le notifiche sono bloccate","ko-KR":"알림 차단됨","nl-NL":"Meldingen zijn geblokkeerd"},"Num entries":{"de-DE":"%{smart_count} Eintrag |||| %{smart_count} Einträge","en-US":"%{smart_count} Entry |||| %{smart_count} Entries","es-VE":"%{smart_count} Entrada |||| %{smart_count} Entradas","fi-FI":"%{smart_count} Kohde |||| %{smart_count} Kohdetta","fr-FR":"%{smart_count} Entrée |||| %{smart_count} Entrées","it-IT":"%{smart_count} Voce |||| %{smart_count} Voci","ko-KR":"%{smart_count} 항목 |||| %{smart_count} 항목","nl-NL":"%{smart_count} entry |||| %{smart_count} entries"},"Num playlists":{"de-DE":"%{smart_count} Wiedergabeliste |||| %{smart_count} Wiedergabelisten","en-US":"%{smart_count} Playlist |||| %{smart_count} Playlists","es-VE":"%{smart_count} Lista de reproducción |||| %{smart_count} Listas de reproducción","fi-FI":"%{smart_count} Soittolista |||| %{smart_count} Soittolistaa","fr-FR":"%{smart_count} Liste de lecture |||| %{smart_count} Listes de lecture","it-IT":"%{smart_count} Lista di riproduzione |||| %{smart_count} Liste di riproduzione","ko-KR":"%{smart_count} 연주목록 |||| %{smart_count} 연주목록","nl-NL":"%{smart_count} afspeellijst |||| %{smart_count} afspeellijsten"},"Num songs":{"de-DE":"%{smart_count} Lied |||| %{smart_count} Lieder","en-US":"%{smart_count} Song |||| %{smart_count} Songs","es-VE":"%{smart_count} Canción |||| %{smart_count} Canciones","fi-FI":"%{smart_count} Kappale |||| %{smart_count} Kappaletta","fr-FR":"%{smart_count} Chanson |||| %{smart_count} Chansons","it-IT":"%{smart_count} Canzone |||| %{smart_count} Canzoni","ko-KR":"%{smart_count} 곡 |||| %{smart_count} 곡","nl-NL":"%{smart_count} nummer |||| %{smart_count} nummers"},"Off":{"de-DE":"Deaktiviert","es-VE":"Apagado","fi-FI":"Pois","fr-FR":"Off","it-IT":"Off","ko-KR":"끄기","nl-NL":"Uit"},"Offset":{"de-DE":"Start","it-IT":"Differenza","ko-KR":"오프셋"},"On":{"de-DE":"Aktiv","es-VE":"On","fi-FI":"Päällä","fr-FR":"Actif","it-IT":"On","ko-KR":"켜기","nl-NL":"Aan"},"On page notifications":{"de-DE":"Integrierte Hinweise","es-VE":"Notificaciones en la Página","fi-FI":"Sivun ilmoitukset","fr-FR":"Notifications sur la page","it-IT":"Notifiche sulla pagina","ko-KR":"페이지에 알림","nl-NL":"Meldingen op pagina"},"Oneshot":{"de-DE":"Oneshot","es-VE":"Oneshot","fi-FI":"Oneshot","fr-FR":"Unique","it-IT":"Unico","ko-KR":"1회","nl-NL":"Oneshot"},"Open about":{"de-DE":"Öffne Über myMPD","es-VE":"Abrir acerca de ","fi-FI":"Avaa tiedot","fr-FR":"Ouvrir A propos","it-IT":"Apri le informazioni","ko-KR":"정보 열기","nl-NL":"Over myMPD openen"},"Open fullscreen":{"de-DE":"Öffnet den Vollbildmodus","fr-FR":"Ouvrir en pein écran","it-IT":"Apri a schermo intero","ko-KR":"전체 화면 열기","nl-NL":"Open schermvullend"},"Open local player":{"de-DE":"Lokale Wiedergabe","es-VE":"Abrir reproductor local","fi-FI":"Avaa paikallinen soitin","fr-FR":"Lancer le lecteur local","it-IT":"Avvia riproduttore locale","ko-KR":"로컬 연주기 열기","nl-NL":"Lokaal afspelen"},"Open main menu":{"de-DE":"Öffne Hauptmenü","es-VE":"Abrir menú principal","fi-FI":"Avaa päävalikko","fr-FR":"Ouvrir le menu principal","it-IT":"Apri il menù pricipale","ko-KR":"주 메뉴로 가기","nl-NL":"Hoofdmenu openen"},"Open settings":{"de-DE":"Einstellungen","es-VE":"Abrir configuraciones","fi-FI":"Avaa asetukset","fr-FR":"Ouvrir les paramètres","it-IT":"Apri parametri","ko-KR":"설정 열기","nl-NL":"Instellingen"},"Open song details":{"de-DE":"Lieddetails","es-VE":"Abrir detalles de canción","fi-FI":"Avaa kappaleen tiedot","fr-FR":"Afficher les détails de la chanson","it-IT":"Apri dettagli brano","ko-KR":"곡 정보 열기","nl-NL":"Nummerdetails"},"Open volume menu":{"de-DE":"Öffne Lautstärkemenü","es-VE":"Abrir menú de volumen","fi-FI":"Avaa äänenvoimakkuus valikko","fr-FR":"ouvrir le menu du volume","it-IT":"Apri il menù del volume","ko-KR":"음량 메뉴 열기","nl-NL":"Volumeregeing openen"},"Options":{"de-DE":"Optionen","it-IT":"Opzioni","ko-KR":"옵션"},"Order":{"de-DE":"Reihenfolge","es-VE":"Orden","fi-FI":"Järjestys","fr-FR":"Ordre","it-IT":"Ordine","ko-KR":"순서","nl-NL":"Volgorde"},"Other features":{"de-DE":"Weitere Features","es-VE":"Más funciones","fi-FI":"Muut ominaisuudet","fr-FR":"Autres fonctionnalités","it-IT":"Altre caratteristiche","ko-KR":"다른 기능","nl-NL":"Overige functies"},"Output":{"de-DE":"Ausgabegerät","fr-FR":"Sortie","it-IT":"Uscita","ko-KR":"출력","nl-NL":"Output"},"Output attributes":{"de-DE":"Ausgabeeigenschaften","fr-FR":"Attribus de sortie","it-IT":"Attributi dell'uscita","ko-KR":"출력 속성","nl-NL":"Outputparameters"},"Outputs":{"de-DE":"Ausgabegeräte","it-IT":"Uscite","ko-KR":"출력"},"Pagination":{"de-DE":"Seitenumbruch","es-VE":"Paginación","fi-FI":"Rivien määrä","fr-FR":"Pagination","it-IT":"Paginazione","ko-KR":"페이지 매기기","nl-NL":"Paginagrootte"},"Partition":{"de-DE":"Partition","fr-FR":"Partition","it-IT":"Partizione","ko-KR":"파티션","nl-NL":"Partitie"},"Partition name":{"de-DE":"Partition Name","fr-FR":"Nom de partition","it-IT":"Nome partizione","ko-KR":"파티션 이름","nl-NL":"Naam partitie"},"Partitions":{"de-DE":"Partitionen","fr-FR":"Partitions","it-IT":"Partizioni","ko-KR":"파티션","nl-NL":"Partities"},"Password":{},"Password cannot be blank":{},"Path":{},"Path must start with a leading slash":{},"Performer":{"de-DE":"Aufführender","es-VE":"Interprete","fi-FI":"Esittäjä","fr-FR":"Interprète","it-IT":"Esecutore","ko-KR":"연주자","nl-NL":"Uitvoerend artiest"},"Picture":{"de-DE":"Bild","it-IT":"Immagine","ko-KR":"그림"},"Pictures":{"de-DE":"Bilder","es-VE":"Imágenes","fi-FI":"Kuvat","fr-FR":"Images","it-IT":"Immagini","ko-KR":"그림","nl-NL":"Foto's "},"Play after current playing song":{"de-DE":"Nach aktuellem Lied abspielen","it-IT":"Riproduci dopo il brano corrente","ko-KR":"현재 연주 중인 곡 다음에 연주"},"Play count":{"de-DE":"Wie oft gespielt","es-VE":"Conteo reproducciones","fi-FI":"Soittokerrat","fr-FR":"Nombre de lecture","it-IT":"Numero esecuzioni","ko-KR":"연주 횟수","nl-NL":"Aantal x afgespeeld"},"Play time":{"de-DE":"Wiedergabedauer","es-VE":"Tiempo de reproducción","fi-FI":"Toisto aika","fr-FR":"Durée de lecture","it-IT":"Tempo di esecuzione","ko-KR":"연주 시간","nl-NL":"Gespeelde tijd"},"Playback":{"de-DE":"Wiedergabe","es-VE":"Reproducción","fi-FI":"Toisto","fr-FR":"Lecteur","it-IT":"Riproduzione","ko-KR":"연주","nl-NL":"Afspelen"},"Playback settings":{"de-DE":"Wiedergabeeinstellungen","it-IT":"Impostazioni di riproduzione","ko-KR":"연주 설정"},"Playback statistics":{"de-DE":"Wiedergabestatistiken","es-VE":"Estadísticas de reproducción","fi-FI":"Toistotilastot","fr-FR":"Statistiques de lecture","it-IT":"Statistiche di riproduzione","ko-KR":"연주 통계","nl-NL":"Afspeelgegevens"},"Playback statistics are disabled":{"de-DE":"Wiedergabestatistiken sind deaktiviert","es-VE":"Las estadísticas de reproducción están deshabilitadas","fi-FI":"Toistotilastot ovat pois päältä","fr-FR":"Les statistiques de lecture sont désactivées","it-IT":"Le statitisctiche di riproduzione sono disabilitate","ko-KR":"연주 통계 사용 안 함","nl-NL":"Afspeelstatistieken uitgeschakeld"},"Playlist":{"de-DE":"Wiedergabeliste","es-VE":"Lista de reproducción","fi-FI":"Soittolista","fr-FR":"Liste de lecture","it-IT":"Lista di riproduzione","ko-KR":"연주목록","nl-NL":"Afspeellijst"},"Playlist is too small to shuffle":{"de-DE":"Wiedergabeliste ist zu klein um sie zu mischen","es-VE":"La lista de reproducción es muy pequeña para mezclar aleatoriamente","fi-FI":"Soittolista on liian pieni sekoitettavaksi","fr-FR":"Liste de lecture trop petite pour être mélangée","it-IT":"Lista di riproduzione troppo corta per poter essere rimescolata","ko-KR":"연주목록이 너무 작아 뒤섞을 수 없음","nl-NL":"Afspeellijst te klein om te shufflen"},"Playlist is too small to sort":{"de-DE":"Wiedergabeliste ist zu klein um sie zu sortieren","es-VE":"Wiedergabeliste ist zu klein um sie zu sortieren","fi-FI":"Soittolista on liian pieni järjestettäväksi","fr-FR":"Liste de lecture trop petite pour être triée","it-IT":"Lista di riproduzione troppo corta per poter essere riordinata","ko-KR":"연주목록이 너무 작아 정렬할 수 없음","nl-NL":"Afspeellijst te klein om te sorteren"},"Playlist name":{"de-DE":"Wiedergabelistenname","es-VE":"Nombre de lista de reproducción","fi-FI":"Soittolistan nimi","fr-FR":"Nom de la liste de lecture","it-IT":"Nome lista di riproduzione","ko-KR":"연주목록 이름","nl-NL":"Naam afspeellijst"},"Playlist to small, disabling jukebox unique constraints temporarily":{"de-DE":"Die Wiedergabeliste ist zu klein, die Jukebox Regeln werden deaktiviert","fr-FR":"Liste de lecture trop petite, désactivation temporaire de la contrainte unique du jukebox","it-IT":"Lista di riproduzione troppo piccola, i vincoli del jukebox sono temporaneamnte disabilitati","ko-KR":"연주목록이 작아서, 임시로 뮤직박스의 하나 제한 사용 안 함","nl-NL":"Afspeellijst te klein, jukebox-voorwaarden worden tijdelijk uitgeschakeld"},"Playlists":{"de-DE":"Wiedergabelisten","es-VE":"Listas de reproducción","fi-FI":"Soittolistat","fr-FR":"Listes de lecture","it-IT":"Liste di riproduzione","ko-KR":"연주목록","nl-NL":"Afspeellijsten"},"Playlists are disabled":{"de-DE":"Wiedergabelisten sind deaktiviert","es-VE":"Listas de reproducción deshabilitadas","fi-FI":"Soittolistat ovat pois päältä","fr-FR":"Listes de lecture désactivées","it-IT":"Le liste di riproduzione sono disabilitate","ko-KR":"연주목록 사용 안 함","nl-NL":"Afspeellijsten uitgeschakeld"},"Playlists deleted":{"de-DE":"Wiedergabeliste wurde gelöscht","es-VE":"Listas de reproducción eliminadas","fi-FI":"Soittolistat poistettu","fr-FR":"Listes de lecture supprimées","it-IT":"Liste di riproduzione eliminate","ko-KR":"연주목록 지워짐","nl-NL":"Afspeellijsten gedeletet"},"Please choose playlist":{"de-DE":"Bitte Wiedergabeliste auswählen","es-VE":"Seleccione lista de reproducción","fi-FI":"Valitse soittolista","fr-FR":"Choisissez une liste de lecture","it-IT":"Scegliere una lista di riproduzione","ko-KR":"연주목록을 선택합니다","nl-NL":"Kies afspeellijst"},"Plugin":{"de-DE":"Plugin","fr-FR":"Plugin","it-IT":"Plugin","ko-KR":"플러그인","nl-NL":"Plug-in"},"Port":{"de-DE":"Port","es-VE":"Puerto","fi-FI":"Portti","fr-FR":"Port","it-IT":"Porta","ko-KR":"포트","nl-NL":"Poort"},"Pos":{"de-DE":"Pos","es-VE":"Pos","fi-FI":"Pos","fr-FR":"Pos","it-IT":"Pos","ko-KR":"위치","nl-NL":"Pos"},"Preview":{"de-DE":"Vorschau","es-VE":"Previsualizar","fi-FI":"Esikatselu","fr-FR":"Prévisualisation","it-IT":"Anteprima","ko-KR":"미리 보기","nl-NL":"Voorbeeld"},"Previous":{"de-DE":"Vorheriges Lied","it-IT":"Precedente","ko-KR":"이전"},"Previous page":{"de-DE":"Vorige Seite","es-VE":"Página anterior","fi-FI":"Edellinen sivu","fr-FR":"Page précédente","it-IT":"Pagina precedente","ko-KR":"이전 페이지","nl-NL":"Vorige pagina"},"Previous song":{"de-DE":"Voriges Lied","es-VE":"Canción anterior","fi-FI":"Edellinen kappale","fr-FR":"Chanson précédente","it-IT":"Brano precedente","ko-KR":"이전 곡","nl-NL":"Vorig nummer"},"Protocol version":{"de-DE":"Protokoll Version","es-VE":"Versión de protocolo","fi-FI":"Protokolla Versio","fr-FR":"Version de protocole","it-IT":"Versione del protocollo","ko-KR":"프로토콜 버전","nl-NL":"Versie protocol"},"Quantity":{"de-DE":"Anzahl","es-VE":"Cantidad","fi-FI":"Määrä","fr-FR":"Quantité","it-IT":"Quantità","ko-KR":"갯수","nl-NL":"Aantal"},"Queue":{"de-DE":"Warteschlange","es-VE":"Cola de reproducción","fi-FI":"Jono","fr-FR":"Queue","it-IT":"Coda","ko-KR":"순서","nl-NL":"Wachtrij"},"Queue replaced with %{name}":{"de-DE":"Warteschlange mit %{name} ersetzt","es-VE":"Cola de reproducción reemplazada con %{name}","fi-FI":"Jono korvattu %{name}:lla","fr-FR":"Queue remplacée par %{name}","it-IT":"Coda sostituita con %{name}","ko-KR":"%{name} 순서 바꿈","nl-NL":"Wachtrij vervangen door %{name}"},"RPi DAC":{},"RPi Proto":{},"Random":{"de-DE":"Zufall","es-VE":"Aleatorio","fi-FI":"Satunnainen","fr-FR":"Aléatoire","it-IT":"Casuale","ko-KR":"무작위","nl-NL":"Willekeurig"},"Red Rocks Audio DigiDAC1":{},"Reload":{"de-DE":"Neu laden","es-VE":"Recargar","fi-FI":"Lataa uudelleen","fr-FR":"Recharger","it-IT":"Ricarica","ko-KR":"다시 읽기","nl-NL":"Herladen"},"Remote scripting is disabled":{"de-DE":"Remotescripting ist deaktiviert","fr-FR":"Les scripts distants sont désactivés","it-IT":"Gli script remoti sono disabilitati","ko-KR":"원격 스크립트 사용 안 함","nl-NL":"Scripten op afstand uitgeschakeld"},"Remove":{"de-DE":"Entfernen","es-VE":"Remover","fi-FI":"Poista","fr-FR":"Supprimer","it-IT":"Elimina","ko-KR":"지우기","nl-NL":"Verwijder"},"Remove all downwards":{"de-DE":"Aller Lieder darunter entfernen","es-VE":"Remover todo hacia abajo","fi-FI":"Poista kaikki alempana","fr-FR":"Supprimer vers le bas","it-IT":"Elimina tutto in basso","ko-KR":"아래로 지우기","nl-NL":"Verwijder alle hieronder"},"Remove all upwards":{"de-DE":"Alle Lieder darüber entfernen","es-VE":"Remover todo hacia arriba","fi-FI":"Poista kaikki ylempänä","fr-FR":"Supprimer vers le haut","it-IT":"Elimina tutto in alto","ko-KR":"위로 지우기","nl-NL":"Verwijder alle hierboven"},"Remove item from queue":{"de-DE":"Ausgewähltes Element aus Warteschlange entfernen","es-VE":"Eliminar elemento de la cola de reproducción","fi-FI":"Poista jonosta","fr-FR":"Enlever l'élément de la queue","it-IT":"Rimuovi l'elemento dalla coda","ko-KR":"순서에서 항목 지우기","nl-NL":"Verwijder selectie uit wachtrij"},"Rename playlist":{"de-DE":"Wiedergabeliste umbenennen","es-VE":"Renombrar lista de reproducción","fi-FI":"Nimeä soittolista uudelleen","fr-FR":"Renommer la liste de lecture","it-IT":"Rinomina lista di riproduzione","ko-KR":"연주목록 이름 바꾸기","nl-NL":"Hernoem afspeellijst"},"Renaming playlist failed":{"de-DE":"Wiedergabeliste konnte nicht umbenannt werden","es-VE":"Error al renombrar lista de reproducción","fi-FI":"Soittolistan nimeäminen epäonnistui","fr-FR":"Echec du renommage de la liste de lecture","it-IT":"Impossibile rinominare la lista di riproduzione","ko-KR":"연주목록 이름 바꾸기 안 됨","nl-NL":"Hernoemen afspeellijst mislukt"},"Repeat":{"de-DE":"Wiederholen","es-VE":"Repetir","fi-FI":"Uudelleentoisto","fr-FR":"Répéter","it-IT":"Ripetizione","ko-KR":"다시","nl-NL":"Herhalen"},"Replace queue":{"de-DE":"Warteschlange ersetzen","es-VE":"Reemplazar cola de reproducción","fi-FI":"Korvaa jono","fr-FR":"Remplacer la queue","it-IT":"Sostituisci la coda","ko-KR":"순서 바꾸기","nl-NL":"Vervang wachtrij"},"Replace queue with item":{"de-DE":"Warteschlange mit ausgewähltem Element ersetzen","es-VE":"Reemplazar cola de reproducción con esto","fi-FI":"Korvaa jono kohteella","fr-FR":"Remplacer la queue par l'élément","it-IT":"Sostituisci la coda con l'elemento","ko-KR":"순서에 항목 대체","nl-NL":"Vervang wachtrij met selectie"},"Replaced queue":{"de-DE":"Warteschlange ersetzt","ko-KR":"순서 바꿈"},"Replaygain":{"de-DE":"Lautstärkeanpassung","es-VE":"Volver a reproducir","fi-FI":"Replaygain","fr-FR":"Replaygain","it-IT":"Guadagno in riproduzione","ko-KR":"리플레이게인","nl-NL":"Replaygain"},"Rescan database":{"de-DE":"Datenbank neu einlesen","es-VE":"Reescanear base de datos","fi-FI":"Lue tietokanta uudelleen","fr-FR":"Rescanner la base de données","it-IT":"Nuova scansione database","ko-KR":"데이터베이스 다시 검색","nl-NL":"Herscan database"},"Rescan directory":{"de-DE":"Verzeichnis neu einlesen","es-VE":"Reescanear directorio","fi-FI":"Lue kansio uudelleen","fr-FR":"Rescanner le dossier","it-IT":"Nuova scansione cartella","ko-KR":"디렉터리 다시 검색","nl-NL":"Herscan map"},"Reset":{"de-DE":"Zurücksetzen","es-VE":"Restablecer","fi-FI":"Nollaa","fr-FR":"Remise à zéro","it-IT":"Reimposta","ko-KR":"다시 설정","nl-NL":"Reset"},"Reset settings":{"de-DE":"Einstellungen zurücksetzen","es-VE":"Restablecer configuraciones","fi-FI":"Nollaa asetukset","fr-FR":"Remise à zéro des paramètres","it-IT":"Reimposta i parametri","ko-KR":"다시 설정 하기","nl-NL":"Reset instellingen"},"Reset to default":{"de-DE":"Zurücksetzen","it-IT":"Reimposta ai valori predefiniti","ko-KR":"기본값으로 설정"},"Roon":{},"Samba A (guest access)":{},"Samba B (access with credentials)":{},"Sat":{"de-DE":"Sa","es-VE":"Sáb","fi-FI":"La","fr-FR":"Sam","it-IT":"Sab","ko-KR":"토","nl-NL":"Za"},"Save":{"de-DE":"Speichern","es-VE":"Guardar","fi-FI":"Tallenna","fr-FR":"Enregistrer","it-IT":"Salva","ko-KR":"저장","nl-NL":"Saven"},"Save as smart playlist":{"de-DE":"Als intelligente Wiedergabeliste speichern","es-VE":"Guardar como lista de reproducción inteligente","fi-FI":"Tallenna älykkäänä soittolistana","fr-FR":"Enregistrer comme liste de lecture intelligente","it-IT":"Salva come lista di riproduzione smart","ko-KR":"스마트 연주목록 저장","nl-NL":"Save als slimme afspeellijst"},"Save bookmark":{"de-DE":"Lesezeichen speichern","es-VE":"Guardad marcador","fi-FI":"Tallenna kirjanmerkki","fr-FR":"Enregistrer le marque-page","it-IT":"Enregistrer le marque-page","ko-KR":"즐겨찾기 저장","nl-NL":"Save bladwijzer"},"Save queue":{"de-DE":"Warteschlange speichern","es-VE":"Guardar cola de reproducción","fi-FI":"Tallenna Jono","fr-FR":"Enregistrer la queue","it-IT":"Salva la coda","ko-KR":"순서 저장","nl-NL":"Save wachtrij"},"Save smart playlist":{"de-DE":"Intelligente Wiedergabeliste sichern","es-VE":"Guardar lista de reproducción inteligente","fi-FI":"Tallenna älykäs soittolista","fr-FR":"Enregistrer la liste de lecture intelligente","it-IT":"Salva la lista di riproduzione smart","ko-KR":"스마트 연주목록 저장","nl-NL":"Save slimme afspeellijst"},"Saved smart playlist %{name}":{"de-DE":"Intelligente Wiedergabeliste %{name} gespeichert","es-VE":"Lista de reproducción inteligente guardada: %{name}","fi-FI":"Älykäs soittolista %{name} tallennettu","fr-FR":"Liste de lecture %{name} enregistrée","it-IT":"Lista di riproduzione %{name} salvata","ko-KR":"%{name} 스마트 연주목록 저장함","nl-NL":"Slimme afspeellijst %{name} opgeslagen"},"Saving bookmark failed":{"de-DE":"Lesezeichen konnte nicht gespeichert werden","es-VE":"Error al guardar marcador","fi-FI":"Kirjanmerkin tallennus epäonnistui","fr-FR":"Echec d'enregistrement du marque-page","it-IT":"Salvataggio segnalibro fallito","ko-KR":"즐겨찾기 저장 안 됨","nl-NL":"Saven bladwijzer mislukt"},"Scale ratio":{"de-DE":"Skalierungswert","fr-FR":"Ratio d'échelle","it-IT":"Rapporto di scala","ko-KR":"크기 비율","nl-NL":"Schaalverhouding"},"Script":{"de-DE":"Skript","fr-FR":"Script","it-IT":"Script","ko-KR":"스크립트","nl-NL":"Script"},"Script %{script} executed successfully":{"de-DE":"Skript %{script} erfolgreich gestartet","fr-FR":"Script %{script} exécuté","it-IT":"Script %{script} eseguito","ko-KR":"스크립트 %{script} 실행 성공","nl-NL":"Script %{script} succesvol uitgevoerd"},"Script arguments":{"de-DE":"Skriptparameter","fr-FR":"Paramètres du script","it-IT":"Parametri dello script","ko-KR":"스크립트 변수","nl-NL":"Scriptargumenten"},"Script name":{"de-DE":"Skriptname","fr-FR":"Nom du script","it-IT":"Nome dello script","ko-KR":"스크립트 이름","nl-NL":"Script naam"},"Scripting is disabled":{"de-DE":"Skripte sind deaktiviert","fr-FR":"Les scripts sont désactivés","it-IT":"Gli script sono disabilitati","ko-KR":"스크립트 사용 안 함","nl-NL":"Scripten is uitgeschakeld"},"Scripts":{"de-DE":"Skripte","fr-FR":"Scripte","it-IT":"Script","ko-KR":"스크립트","nl-NL":"Scripts"},"Scrobbled love":{"de-DE":"Lieblingslied wurde gescrobbelt","es-VE":"Me gusta recomendado","fi-FI":"Scrobbled rakkaus","fr-FR":"Scrobbler les chansons adorées","it-IT":"Scrobbling delle canzoni \"adorate\" eseguito","ko-KR":"애청곡 추천","nl-NL":"Favoriet werd gescrobbeld"},"Scrobbler integration":{"de-DE":"Scrobbler Integration","es-VE":"Scrobbler Integration","fi-FI":"Scrobbler Integration","fr-FR":"Intégration de Scrobbler (recommandations musicales)","it-IT":"Integrazione degli Scrobbler (raccomandazioni musicali)","ko-KR":"추천 통합","nl-NL":"Scrobbler-integratie"},"Search":{"de-DE":"Suchen","es-VE":"Buscar","fi-FI":"Etsi","fr-FR":"Recherche","it-IT":"Ricerca","ko-KR":"찾기","nl-NL":"Zoeken"},"Search queue":{"de-DE":"Warteschlange durchsuchen","es-VE":"Buscar cola de reproducción","fi-FI":"Etsi jonosta","fr-FR":"Chercher dans la queue","it-IT":"Ricerca nella coda","ko-KR":"순서 찾기","nl-NL":"Zoek in wachtrij"},"Searching...":{"de-DE":"Suche...","es-VE":"Buscando...","fi-FI":"Etsitään...","fr-FR":"Recherche...","it-IT":"Ricerca...","ko-KR":"찾는 중...","nl-NL":"Zoek..."},"Seconds":{"de-DE":"Sek","en-US":"Sec","es-VE":"Seg","fi-FI":"Sekuntia","fr-FR":"Sec","it-IT":"Secondi","ko-KR":"초","nl-NL":"sec"},"Select samba version":{},"Select tag to search":{"de-DE":"Tag zum Suchen auswählen","es-VE":"Seleccionar etiqueta para buscar","fi-FI":"Valitse etsittävä tagi","fr-FR":"Choisir les tags pour la recherche","it-IT":"Scegliere i tag per la ricerca","ko-KR":"찾을 태그 선택","nl-NL":"Selecteer tag om te zoeken"},"Select type":{},"Select view":{"de-DE":"Anzeige auswählen","it-IT":"Seleziona vista","ko-KR":"보기 선택"},"Send love message":{"de-DE":"Sende Lieblingslied","es-VE":"Enviar mensaje de Me gusta","fi-FI":"Lähetä rakkausviesti","fr-FR":"Envoyer statut \"adoré\"","it-IT":"Invia messaggio \"adorato\"","ko-KR":"애청 메시지 보내기","nl-NL":"Stuur favoriet"},"Settings":{"de-DE":"Einstellungen","es-VE":"Ajustes","fi-FI":"Asetukset","fr-FR":"Paramètres","it-IT":"Parametri","ko-KR":"설정","nl-NL":"Instellingen"},"Shortcut":{"de-DE":"Tastenkürzel","es-VE":"Acceso directo","fi-FI":"Pikalinkki","fr-FR":"Raccourci","it-IT":"Scorciatoia","ko-KR":"단축키","nl-NL":"Sneltoets"},"Shortcuts":{"de-DE":"Tastenkombinationen","es-VE":"Accesos directos","fi-FI":"Pikalinkki","fr-FR":"Raccourcis","it-IT":"Scorciatoie","ko-KR":"단축키","nl-NL":"Sneltoetsen"},"Show album":{"de-DE":"Album anzeigen","ko-KR":"음반 보기"},"Show attributes":{"de-DE":"Eigenschaften anzeigen","fr-FR":"Montrer les attributs","it-IT":"Mostra attributi","ko-KR":"속성 보기","nl-NL":"Toon parameters"},"Show cover":{"de-DE":"Cover anzeigen","it-IT":"Mostra copertina","ko-KR":"커버 보기"},"Shuffle":{"de-DE":"Mischen","es-VE":"Aleatorio","fi-FI":"Sekoita","fr-FR":"Mélanger","it-IT":"Mescolato","ko-KR":"뒤섞기","nl-NL":"Shuffle"},"Shuffle playlist":{"de-DE":"Wiedergabeliste mischen","es-VE":"Mezclar aleatoriamente la lista de reproducción","fi-FI":"Sekoita soittolista","fr-FR":"Mélanger la liste de lecture","it-IT":"Rimescola la lista di riproduzione","ko-KR":"연주목록 뒤섞기","nl-NL":"Shuffle afspeellijst"},"Shuffle queue":{"de-DE":"Warteschlange mischen","es-VE":"Cola de reproducción aleatoria","fi-FI":"Sekoita Jono","fr-FR":"Mélanger la queue","it-IT":"Rimescola la coda","ko-KR":"순서 뒤섞기","nl-NL":"Wachtrij shufflen"},"Shuffled playlist succesfully":{"de-DE":"Wiedergabeliste erfolgreich gemischt","es-VE":"Lista de reproducción mezclada aleatoriamente","fi-FI":"Soittolista sekoitetttu onnistuneesti","fr-FR":"Liste de lecture mélangée","it-IT":"Lista di riproduzione rimescolata con successo","ko-KR":"연주목록을 뒤섞음","nl-NL":"Afspeellijst geshuffled"},"Single":{"de-DE":"Nur ein Lied","es-VE":"Individual","fi-FI":"Yksittäistoisto","fr-FR":"Single","it-IT":"Singolo","ko-KR":"한 곡만","nl-NL":"Single"},"Size in px":{"de-DE":"Größe in PX","es-VE":"Tamaño en px","fi-FI":"koko pikseleinä","fr-FR":"Taille en pixels","it-IT":"Dimensione in pixels","ko-KR":"픽셀 크기","nl-NL":"Grootte in px"},"Size normal":{"de-DE":"Normale Größe","es-VE":"Tamaño normal","fi-FI":"Normaali koko","fr-FR":"Taille normale","it-IT":"Dimensione normale","ko-KR":"일반 크기","nl-NL":"Standaard formaat"},"Size small":{"de-DE":"Kleine Größe","es-VE":"Tamaño pequeño","fi-FI":"Pieni koko","fr-FR":"Petite taille","it-IT":"Dimensione ridotta","ko-KR":"작은 크기","nl-NL":"Klein formaat"},"Skip count":{"de-DE":"Wie oft übersprungen","es-VE":"Conteo omisiones","fi-FI":"Ohitus laskuri","fr-FR":"Nombre de fois ignoré ","it-IT":"Numero ignorati","ko-KR":"건너뛴 횟수","nl-NL":"Aantal x geskipt"},"Smart playlist":{"de-DE":"Intelligente Wiedergabeliste","es-VE":"Lista de reproducción inteligente","fi-FI":"Älykäs soittolista","fr-FR":"Liste de lecture intelligente","it-IT":"Lista di riproduzione smart","ko-KR":"스마트 연주목록","nl-NL":"Slimmme afspeellijst"},"Smart playlist %{playlist} updated":{"de-DE":"Intelligente Wiedergabeliste %{playlist} aktualisiert","es-VE":"Lista de reproducción %{playlist} actualizada","fi-FI":"Älykäs soittolista %{playlist} päivitetty","fr-FR":"Liste de lecture intelligente %{playlist} mise à jour","it-IT":"Lista di riproduzione smart %{playlist} aggiornata","ko-KR":"%{playlist} 스마트 연주목록 업데이트함","nl-NL":"Slimmme afspeellijst %{playlist} geüpdatet"},"Smart playlists":{"de-DE":"Intelligente Wiedergabelisten","es-VE":"Listas de reproducción inteligentes","fi-FI":"Älykkäät soittolistat","fr-FR":"Listes de lecture intelligente","it-IT":"Lista di riproduzione smart","ko-KR":"스마트 연주목록","nl-NL":"Slimmme afspeellijsten"},"Smart playlists are disabled":{"de-DE":"Intelligente Wiedergabelisten sind deaktiviert","fr-FR":"Les listes de lecture intelligentes sont désactivées","it-IT":"Le liste di riproduzione smart sono disabilitate","ko-KR":"스마트 연주목록 사용 안 함","nl-NL":"Smart playlists uitgeschakeld"},"Smart playlists prefix":{"de-DE":"Prefix von Intelligenten Wiedergabelisten","es-VE":"Prefijo de listas de reproducción inteligente","fi-FI":"Älykkäiden soittolistojen etuliite","fr-FR":"Préfixe des listes de lecture intelligentes","it-IT":"Prefisso lista di riproduzione smart","ko-KR":"스마트 연주목록 덧붙임","nl-NL":"Voorvoegsel slimme afspeellijsten"},"Smart playlists update failed":{"de-DE":"Intelligente Wiedergabelisten konnten nicht aktualisiert werden","es-VE":"Error Actualizando listas de reproducción inteligentes","fi-FI":"Älykkäiden soittolistojen päivitys epäonnistui","fr-FR":"Echec de la mise à jour des listes de lecture intelligentes","it-IT":"Impossibile aggiornare liste di riproduzione smart","ko-KR":"스마트 연주목록 업데이트 안 됨","nl-NL":"Updaten slimmme afspeellijsten mislukt"},"Smart playlists update started":{"de-DE":"Aktualisierung der intelligenten Wiedergabelisten gestartet","fr-FR":"Mise à jours des listes de lecture intelligentes","it-IT":"Aggiornamento liste di riproduzione smart avviato","ko-KR":"스마트 연주목록 업데이트 시작","nl-NL":"Smart playlists wordt geupdatet"},"Smart playlists updated":{"de-DE":"Intelligente Wiedergabelisten wurden aktualisiert","es-VE":"Listas de reproducción inteligentes actualizadas","fi-FI":"Älykkäät soittolistat päivitetty","fr-FR":"Listes de lecture intelligentes mises à jour","it-IT":"Lista di riproduzione smart aggiornate","ko-KR":"스마트 연주목록 업데이트됨","nl-NL":"Slimmme afspeellijsten geüpdatet"},"Software":{},"Song":{"de-DE":"Lied","es-VE":"Canción","fi-FI":"Kappale","fr-FR":"Chanson","it-IT":"Brano","ko-KR":"곡","nl-NL":"Nummer"},"Song details":{"de-DE":"Lieddetails","es-VE":"Detalles de canción","fi-FI":"Kappaleen tiedot","fr-FR":"Détails de la chanson","it-IT":"Dettagli brano","ko-KR":"곡 정보","nl-NL":"Nummerdetails"},"Songs":{"de-DE":"Lieder","es-VE":"Canciones","fi-FI":"Kappaleet","fr-FR":"Chansons","it-IT":"Canzoni","ko-KR":"곡","nl-NL":"Nummers"},"Sorry, your MPD version is too old":{"de-DE":"Entschuldige, deine MPD version ist zu alt","es-VE":"Su versión de MPD es muy vieja","fi-FI":"Liian vanha MPD versio","fr-FR":"Désolé, votre version MPD est trop vieille","it-IT":"Peccato, la tua versione di MPD è troppo vecchia","ko-KR":"MPD 버전이 낮음","nl-NL":"Sorry, je MPD-versie is te oud"},"Sort":{"de-DE":"Sortieren","it-IT":"Ordina","ko-KR":"정렬"},"Sort by":{"de-DE":"Sortieren","es-VE":"Ordenar por","fi-FI":"Järjestä","fr-FR":"Trier par","it-IT":"Ordina per","ko-KR":"정렬","nl-NL":"Sorteer op"},"Sort by tag":{"de-DE":"Sortiere nach Tag","es-VE":"Ordenar por etiqueta","fi-FI":"Lahittele tagin mukaan","fr-FR":"Trier par tags","it-IT":"Ordinato per tag","ko-KR":"태그로 정렬","nl-NL":"Sorteer op tag"},"Sort order of the script, 0 disables listing in main menu":{"de-DE":"Sortierreihenfolge der Skripts, 0 deaktiviert die Anzeige im Hauptmenü","fr-FR":"Ordre de tri du script, 0 désactive le listing dans le menu principal","it-IT":"Ordinamento degli script, 0 disabilita l'elenco nel menù pricipale","ko-KR":"스크립트 분류 순서, 0은 주 메뉴에 안 보임","nl-NL":"Sorteervolgorde van het script, 0 schakelt lijst in hoofdmenu uit"},"Sort playlist":{"de-DE":"Wiedergabeliste sortieren","es-VE":"Ordenar lista de reproducción","fi-FI":"Järjestä soittolista","fr-FR":"Trier la liste de lecture","it-IT":"Ordina la lista di riproduzione","ko-KR":"연주목록 정렬","nl-NL":"Sorteer afspeellijst"},"Sorted playlist succesfully":{"de-DE":"Wiedergabeliste erfolgreich sortiert","es-VE":"Lista de reproducción ordenada","fi-FI":"Soittolista järjestetty onnistuneesti","fr-FR":"Liste de lecture triée","it-IT":"Lista di riproduzione ordinata con successo","ko-KR":"연주목록 정렬함","nl-NL":"Afspeellijst gesorteerd"},"Specify":{"de-DE":"Manuell","es-VE":"Especificar","fi-FI":"Määritä","fr-FR":"Préciser","it-IT":"Specificare","ko-KR":"지정","nl-NL":"Specifiek"},"Spotify":{},"Start":{"de-DE":"Start","es-VE":"Iniciar","fi-FI":"Aloita","fr-FR":"Lancer","it-IT":"Avvia","ko-KR":"시작","nl-NL":"Start"},"Start playback":{"de-DE":"Wiedergabe starten","es-VE":"Iniciar reproducción","fi-FI":"Aloita toisto","fr-FR":"Lancer la lecture","it-IT":"Avvia riproduzione","ko-KR":"연주 시작","nl-NL":"Start afspelen"},"State":{"de-DE":"Status","fr-FR":"Etat","it-IT":"Stato","ko-KR":"상태","nl-NL":"Status"},"Statistics":{"de-DE":"Statistiken","es-VE":"Estadísticas","fi-FI":"Tilastot","fr-FR":"Statistiques","it-IT":"Statistiche","ko-KR":"통계","nl-NL":"Gegevens"},"Sticker":{"de-DE":"Sticker","es-VE":"Sticker","fi-FI":"Sticker","fr-FR":"Sticker","it-IT":"Sticker","ko-KR":"스티커","nl-NL":"Sticker"},"Sticker cache is NULL":{"de-DE":"Sticker Cache ist leer","fr-FR":"Le cache des Stickers est NULL","it-IT":"La cache degli Sticker è NULL","ko-KR":"Sticker 캐시가 없음","nl-NL":"Sticker cache is leeg"},"Stickers are disabled":{"de-DE":"Sticker sind deaktiviert","es-VE":"Los Stickers están deshabilitados","fi-FI":"Stickerit on poistettu käytöstä","fr-FR":"Les Stickers sont désactivés","it-IT":"Gli Stickers sono disabilitati","ko-KR":"스티커 사용 안 함","nl-NL":"Stickers uitgeschakeld"},"Stop":{"de-DE":"Stop","it-IT":"Stop","ko-KR":"정지"},"Stop playback":{"de-DE":"Wiedergabe anhalten","es-VE":"Detener reproducción","fi-FI":"Pysäytä toisto","fr-FR":"Arrêter la lecture","it-IT":"Arresto riproduzione","ko-KR":"연주 정지","nl-NL":"Stop afspelen"},"Stop playing":{"de-DE":"Stop","es-VE":"Stop","fi-FI":"Stop","fr-FR":"Arrêt de la lecture","it-IT":"Arresta riproduzione","ko-KR":"정지","nl-NL":"Stop"},"Stream URI":{"de-DE":"Stream URL","es-VE":"URL Streaming","fi-FI":"Stream URI","fr-FR":"URL du flux","it-IT":"URL del flusso","ko-KR":"스트리밍 주소","nl-NL":"Streaming url"},"Streaming":{},"Streaming Services":{},"Successfully cleared covercache":{"de-DE":"Covercache erfolgreich geleert","es-VE":"Covercache limpiado exitosamente","fi-FI":"Covercache tyhjennetty onnistuneesti","fr-FR":"Le cache des jaquettes a été vidé","it-IT":"Cache copertine svuotata con successo","ko-KR":"표지 캐시 지우기 완료","nl-NL":"Covercache gewist"},"Successfully croped covercache":{"de-DE":"Covercache erfolgreich bereinigt","es-VE":"Covercache cortado exitosamente","fi-FI":"Covercache rajattu onnistuneesti","fr-FR":"Le cache des jaquettes a été coupé","it-IT":"Cache copertine troncata con successo","ko-KR":"표지 캐시 잘라내기 완료","nl-NL":"Covercache opgeschoond"},"Successfully execute cmd %{cmd}":{"de-DE":"Systembefehl %{cmd} erfolgreich ausgeführt","es-VE":"Ejecutado %{cmd} exitosamente","fi-FI":"Komennon  %{cmd} suorittaminen onnistui","fr-FR":"Commande %{cmd} réussie","it-IT":"Commando %{cmd} eseguito","ko-KR":"%{cmd} 명령어 실행함","nl-NL":"Systeemcommando %{cmd} uitgevoerd"},"Sucessfully added random songs to queue":{"de-DE":"Zufällige Lieder wurden zur Warteschlange hinzugefügt","es-VE":"Agregadas canciones aleatorias a la cola de reproducción exitosamente","fi-FI":"Satunnaisten kappaleiden lisääminen jonoon onnistui","fr-FR":"Chansons aléatoires ajoutées à la queue","it-IT":"Brani casuali aggiunti con successo alla coda","ko-KR":"무작위 곡을 순서에 추가함","nl-NL":"Willekeurig nummer aan wachtrij toegevoegd"},"Sucessfully renamed playlist":{"de-DE":"Wiedergabeliste erfolgreich umbenannt","es-VE":"Lista de reproducción renombrada exitosamente","fi-FI":"Soittolista nimeäminen onnistui","fr-FR":"Liste de lexture renommée","it-IT":"Lista di riproduzione rinominata con successo","ko-KR":"연주목록 이름 바꿈","nl-NL":"Afspeellijst is hernoemd"},"Sun":{"de-DE":"So","es-VE":"Dom","fi-FI":"Sun","fr-FR":"Dim","it-IT":"Dom","ko-KR":"일","nl-NL":"Zo"},"Switch to":{"de-DE":"Wechsle zu","fr-FR":"Passer à","it-IT":"Passa a","ko-KR":"바꿈","nl-NL":"Schakel over naar"},"System command":{"de-DE":"Systembefehl","es-VE":"Comando de sistema","fi-FI":"Järjestelmä komento","fr-FR":"Commande système","it-IT":"Comando di sistema","ko-KR":"시스템 명령어","nl-NL":"Systeemcommando"},"System command not defined":{"de-DE":"Systembefehl nicht definiert","es-VE":"Comando del sistema no definido","fi-FI":"Järjestelmäkomentoa ei ole määritetty","fr-FR":"Commande système non définie","it-IT":"Comando di sistema non definito","ko-KR":"시스템 명령어 정의 안됨","nl-NL":"Systeemcommando niet bekend"},"System commands":{"de-DE":"Systembefehle","es-VE":"Comandos de sistema","fi-FI":"Järjestelmäkomennot","fr-FR":"Commandes système","it-IT":"Comandi di sistema","ko-KR":"시스템 명령어","nl-NL":"Systemcommando"},"System commands are disabled":{"de-DE":"Systembefehle sind deaktiviert","es-VE":"Comandos del sistema deshabilitados","fi-FI":"Järjestelmäkomennot on poistettu käytöstä","fr-FR":"Les commandes système sont désactivées","it-IT":"I comandi di sistema sono disabilitati","ko-KR":"시스템 명령어 사용 안 함","nl-NL":"Systeemcommando's uitgeschakeld"},"Tab":{"de-DE":"Tab","it-IT":"Linguetta","ko-KR":"탭"},"Tag":{"de-DE":"Tag","es-VE":"Etiqueta","fi-FI":"Tag","fr-FR":"Tag","it-IT":"Tag","ko-KR":"태그","nl-NL":"Tag"},"Tags":{"de-DE":"Tags","es-VE":"Etiquetas","fi-FI":"Tagit","fr-FR":"Tags","it-IT":"Tags","ko-KR":"태그","nl-NL":"Tags"},"Tags to browse":{"de-DE":"Tags für die Datenbankanzeige","es-VE":"Etiquetas para explorar","fi-FI":"Selattavat tagit","fr-FR":"Tags à parcourir (librairie)","it-IT":"Tag da sfogliare","ko-KR":"열 태그","nl-NL":"Tags om te browsen"},"Tags to search":{"de-DE":"Tags für die Suche","es-VE":"Etiquetas para buscar","fi-FI":"Etsittävät tagit","fr-FR":"Tags pour la recherche","it-IT":"Tag per la ricerca","ko-KR":"찾을 태그","nl-NL":"Tags om te zoeken"},"Tags to use":{"de-DE":"Genutzte Tags","es-VE":"Etiquetas para usar","fi-FI":"Käytettävät tagit","fr-FR":"Tags à utiliser","it-IT":"Tag da usare","ko-KR":"쓸 태그","nl-NL":"Te gebruiken tags"},"Theme":{"de-DE":"Design","es-VE":"Tema","fi-FI":"Teema","fr-FR":"Thème  ","it-IT":"Tema","ko-KR":"테마","nl-NL":"Thema"},"Thu":{"de-DE":"Do","es-VE":"Jue","fi-FI":"To","fr-FR":"Jeu","it-IT":"Gio","ko-KR":"목","nl-NL":"Do"},"Tidal":{},"Timer":{"de-DE":"Timer","es-VE":"Temporizador","fi-FI":"Ajastin","fr-FR":"Temporisation","it-IT":"Timer","ko-KR":"타이머","nl-NL":"Timer"},"Timer with given id not found":{"de-DE":"Timer nicht gefunden","es-VE":"Temporizador no se encontró con ese ID","fi-FI":"Ajastinta annetulla tunnuksella ei löydy","fr-FR":"Temporisation avec l'id donnée non trouvée","it-IT":"Timer con l'ID indicato non trovato","ko-KR":"타이머를 찾을 수 없음","nl-NL":"Timer niet gevonden"},"Timerange (days)":{"de-DE":"Tage","es-VE":"Tiempo (días)","fi-FI":"Aikaväli (päiviä)","fr-FR":"Période (jours)","it-IT":"Periodo (giorni)","ko-KR":"시간 범위 (날짜)","nl-NL":"Dagen"},"Title":{"de-DE":"Titel","es-VE":"Título","fi-FI":"Nimi","fr-FR":"Titre","it-IT":"Titolo","ko-KR":"제목","nl-NL":"Titel"},"To":{"de-DE":"Zu","es-VE":"Para","fi-FI":"Mihin","fr-FR":"A","it-IT":"A","ko-KR":"바꿈","nl-NL":"Naar"},"To top":{"de-DE":"Nach oben","es-VE":"Arriba","fi-FI":"Huipulle","fr-FR":"Remonter","it-IT":"All'inizio","ko-KR":"위로","nl-NL":"Omhoog"},"Toggle play":{"de-DE":"Abspielen / Pausieren","it-IT":"Commuta riproduzione","ko-KR":"연주 토글"},"Toggle play / pause":{"de-DE":"Play / Pause","es-VE":"Play / Pausa","fi-FI":"Play / Pause","fr-FR":"Lecture / Pause","it-IT":"Commuta riproduzione / pausa","ko-KR":"연주 / 잠시 멈춤","nl-NL":"Play / Pause"},"Track":{"de-DE":"Liednummer","es-VE":"# Pista","fi-FI":"Kappalenumero","fr-FR":"Piste","it-IT":"Traccia","ko-KR":"트랙","nl-NL":"Track"},"Trigger":{"de-DE":"Trigger","fr-FR":"Déclencheur","it-IT":"Trigger","ko-KR":"트리거","nl-NL":"Trigger"},"Trigger name":{"de-DE":"Trigger Name","fr-FR":"Nom du déclencheur","it-IT":"Nome del trigger","ko-KR":"트리거 이름","nl-NL":"Naam trigger"},"Trigger not found":{"de-DE":"Trigger nicht gefunden","fr-FR":"Déclencheur non trouvé","it-IT":"Trigger non trovato","ko-KR":"트리거를 찾을 수 없음","nl-NL":"Trigger niet gevonden"},"Tue":{"de-DE":"Di","es-VE":"Mar","fi-FI":"Ti","fr-FR":"Mar","it-IT":"Mar","ko-KR":"화","nl-NL":"Di"},"Type":{"de-DE":"Typ","es-VE":"Tipo","fi-FI":"Tyyppi","fr-FR":"Type","it-IT":"Tipo","ko-KR":"형식","nl-NL":"Type"},"URI":{"de-DE":"URL","es-VE":"URL","fi-FI":"URL","fr-FR":"URL","it-IT":"URI","ko-KR":"주소","nl-NL":"Url"},"Unknown album":{"de-DE":"Unbekanntes Album","es-VE":"Álbum desconocido","fi-FI":"Tuntematon albumi","fr-FR":"Album inconnu","it-IT":"Album sconosciuto","ko-KR":"모르는 음반","nl-NL":"Onbekend album"},"Unknown artist":{"de-DE":"Unbekannter Künstler","es-VE":"Artista desconocido","fi-FI":"Tuntematon artisti","fr-FR":"Artist inconnu","it-IT":"Artista sconosciuto","ko-KR":"모르는 연주자","nl-NL":"Onbekende artiest"},"Unknown request":{"de-DE":"Unbekannter Befehl","es-VE":"Solicitud desconocida","fi-FI":"Tuntematon pyyntö","fr-FR":"Requête inconnue","it-IT":"Richiesta sconosciuta","ko-KR":"알 수 없는 요구","nl-NL":"Onbekend verzoek"},"Unknown smart playlist type":{"de-DE":"Unbekannter intelligenter Wiedergabenlisten Typ","es-VE":"Tipo de lista de reproducción inteligente desconocido","fi-FI":"Älykkään soittolistan tyyppi tuntematon","fr-FR":"Type de liste de lecture intelligente inconnu","it-IT":"Tipo lista di riproduzione smart sconosciuto","ko-KR":"스마트 연주목록 형식을 알 수 없음","nl-NL":"Onbekend type afspeellijst"},"Unknown table %{table}":{"de-DE":"Unbekannte Tabelle %{table}","es-VE":"Tabla desconocida: %{table}","fi-FI":"Tuntematon taulu %{table}","fr-FR":"Table %{table} inconnue","it-IT":"Tabella %{table} sconosciuta","ko-KR":"%{table} 테이블 알 수 없음","nl-NL":"Onbekende tabel %{table}"},"Unmount":{"de-DE":"Aushängen","es-VE":"Desmontar","fi-FI":"Poista liityntä","fr-FR":"Démonter","it-IT":"Smonta","ko-KR":"언마운트","nl-NL":"Ontkoppelen"},"Unsupported file type":{"de-DE":"Nicht unterstützter Dateityp","it-IT":"Tipo file non supportato","ko-KR":"지원되지 않는 파일 형식"},"Update":{"de-DE":"Aktualisieren","es-VE":"Actualizar","fi-FI":"Päivitä","fr-FR":"Mettre à jour","it-IT":"Aggiornamento","ko-KR":"업데이트","nl-NL":"Updaten"},"Update database":{"de-DE":"Datenbank aktualisieren","es-VE":"Actualizar base de datos","fi-FI":"Päivitä tietokanta","fr-FR":"Mettre à jour la base de données","it-IT":"Aggiorna database","ko-KR":"데이터베이스 업데이트","nl-NL":"Update database"},"Update directory":{"de-DE":"Verzeichnis aktualisieren","es-VE":"Actualizar directorio","fi-FI":"Päivitä kansio","fr-FR":"Mettre à jour le dossier","it-IT":"Aggiornamento cartella","ko-KR":"디렉터리 업데이트","nl-NL":"Update map"},"Update smart playlist":{"de-DE":"Intelligente Wiedergabeliste aktualisieren","es-VE":"Actualizar lista de reproducción inteligente","fi-FI":"Päivitä alykäs soittolista","fr-FR":"Mettre à jour la liste de lecture intelligente","it-IT":"Aggiorna lista di riproduzione smart","ko-KR":"스마트 연주목록 업데이트","nl-NL":"Update slimme afspeellijst"},"Update smart playlists":{"de-DE":"Intelligente Wiedergabelisten aktualisieren","es-VE":"Actualizar listas de reproducción inteligentes","fi-FI":"Päivitä älykkäät soittolistat","fr-FR":"Mettre à jour les playlists intelligentes","it-IT":"Aggiorna le liste di riproduzione smart","ko-KR":"스마트 연주목록 업데이트","nl-NL":"Update slimme afspeellijsten"},"Update smart playlists (hours)":{"de-DE":"Intelligente Wiedergabelisten aktualisieren (Stunden)","es-VE":"Actualizar listas de reproducción inteligentes (horas)","fi-FI":"Älykkäiden soittolistojen päivitys (tunteja)","fr-FR":"Mise à jour des listes de lecture intelligentes (heures)","it-IT":"Aggiorna lista di riproduzione smart (ore)","ko-KR":"스마트 연주목록 업데이트 (시간)","nl-NL":"Update slimme afspeellijsten (uren)"},"Updating MPD database":{"de-DE":"MPD Datenbank wird aktualisiert","es-VE":"Actualizando base de datos MPD","fi-FI":"Päivitetään MPD tietokantaa","fr-FR":"Mise à jour de la base de données MPD","it-IT":"Aggiornamento database di MPD","ko-KR":"MPD 데이터베이스 업데이트 중","nl-NL":"MPD-database wordt geüpdatet"},"Updating of smart playlist %{playlist} failed":{"de-DE":"Intelligente Wiedergabeliste %{playlist} konnte nicht aktualisiert werden","es-VE":"Error actualizando de lista de reproducción inteligente %{playlist} ","fi-FI":"Älykkään soittolistan %{playlist} päivitys epäonnistui","fr-FR":"Echec de la mise à jour de la liste de lecture intelligente %{playlist}","it-IT":"Impossibile aggiornare la lista di riproduzione smart %{playlist}","ko-KR":"%{playlist} 스마트 연주목록 업데이트 안 됨","nl-NL":"Updaten slimmme afspeellijst %{playlist} mislukt "},"Use ligature":{"de-DE":"Ligatur benutzen","it-IT":"Usa legatura","ko-KR":"연결 사용"},"Username":{},"Username cannot be blank":{},"Version":{"de-DE":"Version","es-VE":"Versión","fi-FI":"Versio","fr-FR":"Version","it-IT":"Versione","ko-KR":"버전","nl-NL":"Versie"},"View":{"de-DE":"Ansicht","it-IT":"Vista","ko-KR":"보기"},"View playlist":{"de-DE":"Wiedergabeliste anzeigen","es-VE":"Ver lista de reproducción","fi-FI":"Näytä soittolista","fr-FR":"Voir la liste de lecture","it-IT":"Visualizza lista di riproduzione","ko-KR":"연주목록 보기","nl-NL":"Bekijk afspeellijst"},"Volume":{"de-DE":"Lautstärke","es-VE":"Volumen","fi-FI":"Äänenvoimakkuus","fr-FR":"Volume","it-IT":"Volume","ko-KR":"음량","nl-NL":"Volume"},"Volume down":{"de-DE":"Leiser","es-VE":"Volumen -","fi-FI":"Pienemmälle","fr-FR":"Baisser le volume","it-IT":"Abbassa volume","ko-KR":"소리 작게","nl-NL":"Volume min"},"Volume up":{"de-DE":"Lauter","es-VE":"Volumen +","fi-FI":"Isommalle","fr-FR":"Monter le volulme","it-IT":"Alza volume","ko-KR":"소리 크게","nl-NL":"Volume plus"},"Volumecontrol disabled":{"de-DE":"Lautstärkeregelung deaktiviert","es-VE":"Control de volumen deshabilitado","fi-FI":"Äänenvoimakkuuden säätö pois käytöstä","fr-FR":"Contrôle du volulme désactivé","it-IT":"Controllo volume disabilitato","ko-KR":"음량 조절 안 함","nl-NL":"Volumeregeling uitgeschakeld"},"Web notifications":{"de-DE":"Systemhinweise","es-VE":"Notificaciones Web","fi-FI":"Web ilmoitukset","fr-FR":"Notifications web","it-IT":"Notifiche web","ko-KR":"웹 알림","nl-NL":"Webmeldingen"},"Webserver":{"de-DE":"Webserver","es-VE":"Servidor Web","fi-FI":"Webserver","fr-FR":"Serveur Web","it-IT":"Server Web","ko-KR":"웹서버","nl-NL":"Webserver"},"Websocket connection failed":{"de-DE":"Websocket Verbindung fehlgeschlagen","es-VE":"Error en la conexión con el Websocket","fi-FI":"Websocket yhteys epäonnistui","fr-FR":"Echec de connexion de la Websocket","it-IT":"Impossibile stabilire connessione Websocket","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Websocket Verbinding mislukt"},"Websocket connection failed, trying to reconnect":{"de-DE":"Websocket Verbindung fehlgeschlagen, versuche neue Verbindung","es-VE":"Error en la conexión Websocket, intentando reconectar","fi-FI":"Websocket yhteys epäonnistui, yritetään uudelleen","fr-FR":"Echec de connexion de la Websocket, tentative de reconnexion","it-IT":"COnnessione a Websocket fallita, tentativo di riconnessione","ko-KR":"웹소켓 연결이 안 되어, 다시 시도하는 중","nl-NL":"Websocket Verbinding mislukt, nieuwe poging"},"Websocket is disconnected":{"de-DE":"Websocket ist nicht verbunden","es-VE":"Websocket está desconectado","fi-FI":"Websocket yhteys on katkaistu","fr-FR":"La websocket est déconnectée","it-IT":"Websocket disconnesso","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Websocket niet verbonden"},"Wed":{"de-DE":"Mit","es-VE":"Mié","fi-FI":"Ke","fr-FR":"Mer","it-IT":"Mer","ko-KR":"수","nl-NL":"Wo"},"Weekdays":{"de-DE":"Wochentage","es-VE":"Días de semana","fi-FI":"Viikonpäivät","fr-FR":"Jours de la semaine","it-IT":"Giorni della settimana","ko-KR":"주일","nl-NL":"Weekdagen"},"Work":{"de-DE":"Werk","es-VE":"Trabajo","fi-FI":"Työ","fr-FR":"Travail","it-IT":"Opera","ko-KR":"작품","nl-NL":"Werk"},"Your NAS Settings":{},"Zoom":{"de-DE":"Zoom","it-IT":"Zoom","ko-KR":"확대","nl-NL":"Zoom"},"bits":{"de-DE":"Bits","es-VE":"Bits","fi-FI":"bittiä","fr-FR":"Bits","it-IT":"bit","ko-KR":"비트","nl-NL":"bits"},"contains":{"de-DE":"enthält","es-VE":"contiene","fi-FI":"sisältää","fr-FR":"contient","it-IT":"contiene","ko-KR":"내용","nl-NL":"bevat"},"current":{"de-DE":"aktive","fr-FR":"en cours","it-IT":"corrente","ko-KR":"현재","nl-NL":"huidige"},"disabled":{"de-DE":"deaktiviert","fr-FR":"désactivé","it-IT":"disabilitato","ko-KR":"사용 안 함","nl-NL":"uitgeschakeld"},"enabled":{"de-DE":"aktiviert","fr-FR":"activé","it-IT":"abilitato","ko-KR":"사용함","nl-NL":"ingeschakeld"},"folder.jpg":{"de-DE":"folder.jpg","es-VE":"carpeta.jpg","fi-FI":"folder.jpg","fr-FR":"folder.jpg","it-IT":"folder.jpg","ko-KR":"folder.jpg","nl-NL":"folder.jpg"},"http://uri.to/stream.mp3":{"de-DE":"http://url.zum/stream.mp3","es-VE":"http://url.to/stream.mp3","fi-FI":"http://url.to/stream.mp3","fr-FR":"http://uri.to/stream.mp3","it-IT":"http://uri.to/stream.mp3","ko-KR":"http://주소/stream.mp3","nl-NL":"http://url.naar/stream.mp3"},"kHz":{"de-DE":"kHz","es-VE":"kHz","fi-FI":"kHz","fr-FR":"kHz","it-IT":"kHz","ko-KR":"kHz","nl-NL":"kHz"},"myMPD CA":{"de-DE":"myMPD Stammzertifikat","es-VE":"myMPD CA","fi-FI":"myMPD Sertifikaatti","fr-FR":"Certificat myMPD","it-IT":"CA myMPD","ko-KR":"myMPD 인증서","nl-NL":"myMPD CA"},"myMPD installed as app":{"de-DE":"myMPD wurde als App installiert","es-VE":"myMPD instalado como aplicación","fi-FI":"myMPD asennettu sovelluksena","fr-FR":"Application myMPD installée","it-IT":"Applicazione myMPD installata","ko-KR":"myMPD가 앱으로 설치됨","nl-NL":"myMPD werd als app geïnstalleerd "},"myMPD is in readonly mode":{"de-DE":"myMPD ist im Readonly Modus","es-VE":"myMPD está en modo solo lectura","fi-FI":"myMPD on vain luku tilassa","fr-FR":"myMPD est en lecture seule","it-IT":"myMPD è in modalità sola lettura","ko-KR":"읽기 전용 모드임","nl-NL":"myMPD is in alleen lezen modus"},"myMPD menu":{"de-DE":"myMPD Menu","it-IT":"Menù myMPD","ko-KR":"myMPD 메뉴"},"myMPD uptime":{"de-DE":"myMPD Uptime","es-VE":"Tiempo de actividad myMPD","fi-FI":"myMPD Uptime","fr-FR":"myMPD Uptime","it-IT":"myMPD Uptime","ko-KR":"myMPD 가동 시간","nl-NL":"myMPD uptime"},"never":{"de-DE":"noch nie","es-VE":"nunca","fi-FI":"Ei koskaan","fr-FR":"jamais","it-IT":"mai","ko-KR":"안 함","nl-NL":"nooit"},"newest":{"de-DE":"Neueste Lieder","es-VE":"más reciente","fi-FI":"Uusin","fr-FR":"nouveaux","it-IT":"più nuovo","ko-KR":"최신","nl-NL":"Nieuwste nummers"},"on":{"de-DE":"an","es-VE":"on","fi-FI":"Päällä","fr-FR":"actif","it-IT":"on","ko-KR":"켜기","nl-NL":"aan"},"search":{"de-DE":"Suche","es-VE":"buscar","fi-FI":"haku","fr-FR":"Recherche","it-IT":"Ricerca","ko-KR":"찾기","nl-NL":"Zoek"},"sticker":{"de-DE":"Sticker","es-VE":"Sticker","fi-FI":"Sticker","fr-FR":"sticker","it-IT":"sticker","ko-KR":"스티커","nl-NL":"Sticker"}};
var keymap={ArrowLeft:{cmd:"clickPrev",options:[],desc:"Previous song",key:"keyboard_arrow_left"},ArrowRight:{cmd:"clickNext",options:[],desc:"Next song",key:"keyboard_arrow_right"}," ":{cmd:"clickPlay",options:[],desc:"Toggle play / pause",key:"space_bar"},s:{cmd:"clickStop",options:[],desc:"Stop playing"},"-":{cmd:"volumeStep",options:["down"],desc:"Volume down"},"+":{cmd:"volumeStep",options:["up"],desc:"Volume up"},c:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_CLEAR"}],desc:"Clear queue"},u:{cmd:"updateDB",
options:["",!0],desc:"Update database"},r:{cmd:"rescanDB",options:["",!0],desc:"Rescan database"},p:{cmd:"updateSmartPlaylists",options:[!1],desc:"Update smart playlists",req:"featSmartpls"},a:{cmd:"showAddToPlaylist",options:["stream",""],desc:"Add stream"},t:{cmd:"openModal",options:["modalSettings"],desc:"Open settings"},i:{cmd:"clickTitle",options:[],desc:"Open song details"},l:{cmd:"openDropdown",options:["dropdownLocalPlayer"],desc:"Open local player"},0:{cmd:"appGoto",options:["Playback"],
desc:"Goto playback"},1:{cmd:"appGoto",options:["Queue","Current"],desc:"Goto queue"},2:{cmd:"appGoto",options:["Queue","LastPlayed"],desc:"Goto last played"},3:{cmd:"appGoto",options:["Browse","Database"],desc:"Goto browse database",req:"featTags"},4:{cmd:"appGoto",options:["Browse","Playlists"],desc:"Goto browse playlists",req:"featPlaylists"},5:{cmd:"appGoto",options:["Browse","Filesystem"],desc:"Goto browse filesystem"},6:{cmd:"appGoto",options:["Search"],desc:"Goto search"},m:{cmd:"openDropdown",
options:["dropdownMainMenu"],desc:"Open main menu"},v:{cmd:"openDropdown",options:["dropdownVolumeMenu"],desc:"Open volume menu"},S:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_SHUFFLE"}],desc:"Shuffle queue"},C:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_CROP"}],desc:"Crop queue"},"?":{cmd:"openModal",options:["modalAbout"],desc:"Open about"},"/":{cmd:"focusSearch",options:[],desc:"Focus search"},n:{cmd:"focusTable",options:[],desc:"Focus table"},q:{cmd:"queueSelectedItem",options:[!0],desc:"Append item to queue"},
Q:{cmd:"queueSelectedItem",options:[!1],desc:"Replace queue with item"},d:{cmd:"dequeueSelectedItem",options:[],desc:"Remove item from queue"},x:{cmd:"addSelectedItemToPlaylist",options:[],desc:"Append item to playlist"},F:{cmd:"openFullscreen",options:[],desc:"Open fullscreen"}};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function sendAPI(method, params, callback, onerror) {
    let request = {"jsonrpc": "2.0", "id": 0, "method": method, "params": params};
    let ajaxRequest=new XMLHttpRequest();
    ajaxRequest.open('POST', subdir + '/api', true);
    ajaxRequest.setRequestHeader('Content-type', 'application/json');
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState === 4) {
            if (ajaxRequest.responseText !== '') {
                let obj = JSON.parse(ajaxRequest.responseText);
                if (obj.error) {
                    showNotification(t(obj.error.message, obj.error.data), '', '', 'danger');
                    logError(JSON.stringify(obj.error));
                }
                else if (obj.result && obj.result.message && obj.result.message !== 'ok') {
                    logDebug('Got API response: ' + JSON.stringify(obj.result));
                    showNotification(t(obj.result.message, obj.result.data), '', '', 'success');
                }
                else if (obj.result && obj.result.message && obj.result.message === 'ok') {
                    logDebug('Got API response: ' + JSON.stringify(obj.result));
                }
                else if (obj.result && obj.result.method) {
                    logDebug('Got API response of type: ' + obj.result.method);
                }
                else {
                    logError('Got invalid API response: ' + JSON.stringify(obj));
                    if (onerror !== true) {
                        return;
                    }
                }
                if (callback !== undefined && typeof(callback) === 'function') {
                    if (obj.result !== undefined || onerror === true) {
                        logDebug('Calling ' + callback.name);
                        callback(obj);
                    }
                    else {
                        logDebug('Undefined resultset, skip calling ' + callback.name);
                    }
                }
            }
            else {
                logError('Empty response for request: ' + JSON.stringify(request));
                if (onerror === true) {
                    if (callback !== undefined && typeof(callback) === 'function') {
                        logDebug('Got empty API response calling ' + callback.name);
                        callback('');
                    }
                }
            }
        }
    };
    ajaxRequest.send(JSON.stringify(request));
    logDebug('Send API request: ' + method);
}

function webSocketConnect() {
    if (socket !== null && socket.readyState === WebSocket.OPEN) {
        logInfo('Socket already connected');
        websocketConnected = true;
        socketRetry = 0;
        return;
    }
    else if (socket !== null && socket.readyState === WebSocket.CONNECTING) {
        logInfo('Socket connection in progress');
        websocketConnected = false;
        socketRetry++;
        if (socketRetry > 20) {
            logError('Socket connection timed out');
            webSocketClose();
            setTimeout(function() {
                webSocketConnect();
            }, 1000);
            socketRetry = 0;
        }
        return;
    }
    else {
        websocketConnected = false;
    }
    
    let wsUrl = getWsUrl();
    socket = new WebSocket(wsUrl);
    socketRetry = 0;
    logInfo('Connecting to ' + wsUrl);

    try {
        socket.onopen = function() {
            logInfo('Websocket is connected');
            websocketConnected = true;
            if (websocketTimer !== null) {
                clearTimeout(websocketTimer);
                websocketTimer = null;
            }
        }

        socket.onmessage = function got_packet(msg) {
            var obj;
            try {
                obj = JSON.parse(msg.data);
                logDebug('Websocket notification: ' + JSON.stringify(obj));
            }
            catch(error) {
                logError('Invalid JSON data received: ' + msg.data);
                return;
            }
            
            if (obj.error) {
                showNotification(t(obj.error.message, obj.error.data), '', '', 'danger');
                return;
            }
            else if (obj.result) {
                showNotification(t(obj.result.message, obj.result.data), '', '', 'success');
                return;
            }

            switch (obj.method) {
                case 'welcome':
                    websocketConnected = true;
                    showNotification(t('Connected to myMPD'), wsUrl, '', 'success');
                    appRoute();
                    sendAPI("MPD_API_PLAYER_STATE", {}, parseState, true);
                    break;
                case 'update_state':
                    obj.result = obj.params;
                    parseState(obj);
                    break;
                case 'mpd_disconnected':
                    if (progressTimer) {
                        clearTimeout(progressTimer);
                    }
                    getSettings(true);
                    break;
                case 'mpd_connected':
                    showNotification(t('Connected to MPD'), '', '', 'success');
                    sendAPI("MPD_API_PLAYER_STATE", {}, parseState);
                    getSettings(true);
                    break;
                case 'update_queue':
                    if (app.current.app === 'Queue') {
                        getQueue();
                    }
                    else if (app.current.app === 'Playback') {
                        getQueueMini(obj.params.songPos);
                    }
                    obj.result = obj.params;
                    parseUpdateQueue(obj);
                    break;
                case 'update_options':
                    getSettings();
                    break;
                case 'update_outputs':
                    sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {}, parseOutputs);
                    break;
                case 'update_started':
                    updateDBstarted(false);
                    break;
                case 'update_database':
                    //fall through
                case 'update_finished':
                    updateDBfinished(obj.method);
                    updateDBstats();
                    break;
                case 'update_volume':
                    obj.result = obj.params;
                    parseVolume(obj);
                    break;
                case 'update_stored_playlist':
                    if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
                        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": app.current.offset, "limit": app.current.limit, "searchstr": app.current.search}, parsePlaylists);
                    }
                    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
                        sendAPI("MPD_API_PLAYLIST_CONTENT_LIST", {"offset": app.current.offset, "limit": app.current.limit, "searchstr": app.current.search, "uri": app.current.filter, "cols": settings.colsBrowsePlaylistsDetail}, parsePlaylists);
                    }
                    break;
                case 'update_lastplayed':
                    if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
                        sendAPI("MPD_API_QUEUE_LAST_PLAYED", {"offset": app.current.offset, "limit": app.current.limit, "cols": settings.colsQueueLastPlayed}, parseLastPlayed);
                    }
                    break;
                case 'update_jukebox':
                    if (app.current.app === 'Queue' && app.current.tab === 'Jukebox') {
                        sendAPI("MPD_API_JUKEBOX_LIST", {"offset": app.current.offset, "limit": app.current.limit, "cols": settings.colsQueueJukebox}, parseJukeboxList);
                    }
                    break;
                case 'error':
                    if (document.getElementById('alertMpdState').classList.contains('hide')) {
                        showNotification(t(obj.params.message), '', '', 'danger');
                    }
                    break;
                case 'warn':
                    if (document.getElementById('alertMpdState').classList.contains('hide')) {
                        showNotification(t(obj.params.message), '', '', 'warning');
                    }
                    break;
                case 'info':
                    if (document.getElementById('alertMpdState').classList.contains('hide')) {
                        showNotification(t(obj.params.message), '', '', 'success');
                    }
                    break;
                default:
                    break;
            }
        }

        socket.onclose = function(){
            logError('Websocket is disconnected');
            websocketConnected = false;
            if (appInited === true) {
                toggleUI();
                if (progressTimer) {
                    clearTimeout(progressTimer);
                }
            }
            else {
                showAppInitAlert(t('Websocket connection failed'));
                logError('Websocket connection failed.');
            }
            if (websocketTimer !== null) {
                clearTimeout(websocketTimer);
                websocketTimer = null;
            }
            websocketTimer = setTimeout(function() {
                logInfo('Reconnecting websocket');
                toggleAlert('alertMympdState', true, t('Websocket connection failed, trying to reconnect') + '&nbsp;&nbsp;<div class="spinner-border spinner-border-sm"></div>');
                webSocketConnect();
            }, 3000);
            socket = null;
        }

    } catch(error) {
        logError(error);
    }
}

function webSocketClose() {
    if (websocketTimer !== null) {
        clearTimeout(websocketTimer);
        websocketTimer = null;
    }
    if (socket !== null) {
        socket.onclose = function () {}; // disable onclose handler first
        socket.close();
        socket = null;
    }
    websocketConnected = false;
}

function getWsUrl() {
    let hostname = window.location.hostname;
    let protocol = window.location.protocol;
    let port = window.location.port;
    
    if (protocol === 'https:') {
        protocol = 'wss://';
    }
    else {
        protocol = 'ws://';
    }

    let wsUrl = protocol + hostname + (port !== '' ? ':' + port : '') + subdir + '/ws/';
    return wsUrl;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function navBrowseHandler(event) {
    if (event.target.nodeName === 'BUTTON') {
        const tag = event.target.getAttribute('data-tag');
        if (tag === 'Playlists' || tag === 'Filesystem') {
            appGoto('Browse', tag, undefined);
            return;
        }
        
        if (app.current.app === 'Browse' && app.current.tab !== 'Database') {
            let view = app.apps.Browse.tabs.Database.active;
            appGoto('Browse', 'Database', view);
            return;
        }
        if (tag !== 'Album') {
            app.current.filter = tag;
            app.current.sort = tag;
        }
        app.current.search = '';
        document.getElementById('searchDatabaseMatch').value = 'contains';
        appGoto(app.current.app, app.current.tab, app.current.view, 
            '0', app.current.limit, app.current.filter, app.current.sort, tag, app.current.search);
    }
}

function gotoBrowse() {
    if (settings.featAdvsearch === false) {
        return;
    }
    let card = app.current.app === 'Playback' ? 'Playback' : 'Browse';
    const x = event.target;
    let tag = x.getAttribute('data-tag');
    let name = decodeURI(x.getAttribute('data-name'));
    if (tag === null) {
        tag = x.parentNode.getAttribute('data-tag');
        name = decodeURI(x.parentNode.getAttribute('data-name'));
    }
    if (tag !== '' && name !== '' && name !== '-' && settings.browsetags.includes(tag)) {
        if (tag === 'Album') {
            let artist = x.getAttribute('data-albumartist');
            if (artist === null) {
                artist = x.parentNode.getAttribute('data-albumartist');
            }
            if (artist !== null) {
                //Show album details
                appGoto(card, 'Database', 'Detail', '0', tag, tagAlbumArtist, name, decodeURI(artist));
            }
            else {
                //show filtered album list
                appGoto(card, 'Database', 'List', '0', tag, tagAlbumArtist, 'Album', '(' + tag + ' == \'' + name + '\')');
            }
        }
        else {
            //show filtered album list
            appGoto(card, 'Database', 'List', '0', tag, tagAlbumArtist, 'Album', '(' + tag + ' == \'' + name + '\')');
        }
    }
}

function parseFilesystem(obj) {
    let list = app.current.app + (app.current.tab === 'Filesystem' ? app.current.tab : '');
    let table = document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List');
    let tbody = table.getElementsByTagName('tbody')[0];
    let colspan = settings['cols' + list].length;

    if (obj.error) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t(obj.error.message) + '</td></tr>';
        document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List').classList.remove('opacity05');
        //document.getElementById('cardFooterBrowse').innerText = '';
        return;
    }
    
    if (app.current.app === 'Browse' && app.current.tab === 'Filesystem') {
        const imageList = document.getElementById('BrowseFilesystemImages');
        imageList.innerHTML = '';
        if ((obj.result.images.length === 0 && obj.result.bookletPath === '') || settings.publish === false) {
            imageList.classList.add('hide');
        }
        else {
            imageList.classList.remove('hide');
        }
        if (obj.result.bookletPath !== '' && settings.publish === true) {
            let img = document.createElement('div');
            img.style.backgroundImage = 'url("' + subdir + '/assets/coverimage-booklet.svg")';
            img.classList.add('booklet');
            img.setAttribute('data-href', subdir + '/browse/music/' + obj.result.bookletPath);
            img.title = t('Booklet');
            imageList.appendChild(img);
        }
        for (let i = 0; i < obj.result.images.length; i++) {
            let img = document.createElement('div');
            img.style.backgroundImage = 'url("' + subdir + '/browse/music/' + obj.result.images[i] + '"),url("assets/coverimage-loading.svg")';
            imageList.appendChild(img);
        }
    }
    let nrItems = obj.result.returnedEntities;
    let tr = tbody.getElementsByTagName('tr');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    for (let i = 0; i < nrItems; i++) {
        let uri = encodeURI(obj.result.data[i].uri);
        let row = document.createElement('tr');
        let tds = '';
        row.setAttribute('data-type', obj.result.data[i].Type);
        row.setAttribute('data-uri', uri);
        row.setAttribute('tabindex', 0);
        if (app.current.app === 'Search' && settings.featTags === true && settings.featAdvsearch === true) {
            //add artist and album information for album actions in search app
            if (obj.result.data[i].Album !== undefined) {
                row.setAttribute('data-album', encodeURI(obj.result.data[i].Album));
            }
            if (obj.result.data[i][tagAlbumArtist] !== undefined) {
                row.setAttribute('data-albumartist', encodeURI(obj.result.data[i][tagAlbumArtist]));
            }
        }
        if (obj.result.data[i].Type === 'song') {
            row.setAttribute('data-name', obj.result.data[i].Title);
        }
        else {
            row.setAttribute('data-name', obj.result.data[i].name);
        }
        
        switch(obj.result.data[i].Type) {
            case 'dir':
            case 'smartpls':
            case 'plist':
                for (let c = 0; c < settings['cols' + list].length; c++) {
                    tds += '<td data-col="' + settings['cols' + list][c] + '">';
                    if (settings['cols' + list][c] === 'Type') {
                        if (obj.result.data[i].Type === 'dir') {
                            tds += '<span class="material-icons">folder_open</span>';
                        }
                        else {
                            tds += '<span class="material-icons">' + (obj.result.data[i].Type === 'smartpls' ? 'queue_music' : 'list') + '</span>';
                        }
                    }
                    else if (settings['cols' + list][c] === 'Title') {
                        tds += e(obj.result.data[i].name);
                    }
                    tds += '</td>';
                }
                tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
                row.innerHTML = tds;
                break;
            case 'song':
                if (obj.result.data[i].Duration !== undefined) {
                    obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
                }
                if (obj.result.data[i].LastModified !== undefined) {
                    obj.result.data[i].LastModified = localeDate(obj.result.data[i].LastModified);
                }
                for (let c = 0; c < settings['cols' + list].length; c++) {
                    tds += '<td data-col="' + settings['cols' + list][c] + '">';
                    if (settings['cols' + list][c] === 'Type') {
                        tds += '<span class="material-icons">music_note</span>';
                    }
                    else {
                        tds += e(obj.result.data[i][settings['cols' + list][c]]);
                    }
                    tds += '</td>';
                }
                tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
                row.innerHTML = tds;
                break;
        }
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    if (navigate === true) {
        focusTable(0);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
                    
    if (nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    }
    document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List').classList.remove('opacity05');
    //document.getElementById('cardFooterBrowse').innerText = t('Num entries', obj.result.totalEntities);
}

//eslint-disable-next-line no-unused-vars
function addAllFromBrowseFilesystem(replace) {
    if (replace === true) {
        sendAPI("MPD_API_QUEUE_REPLACE_TRACK", {"uri": app.current.search});
        showNotification(t('Replaced queue'), '', '', 'success');
    }
    else {
        sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": app.current.search});
        showNotification(t('Added all songs'), '', '', 'success');
    }
}

function addAllFromBrowseDatabasePlist(plist) {
    if (app.current.search.length >= 2) {
        sendAPI("MPD_API_DATABASE_SEARCH", {"plist": plist, "filter": app.current.view, "searchstr": app.current.search, "offset": 0, "limit": 0, "cols": settings.colsSearch, "replace": false});
    }
}

function parseBookmarks(obj) {
    let list = '<table class="table table-sm table-dark table-borderless mb-0">';
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        list += '<tr data-id="' + obj.result.data[i].id + '" data-type="' + obj.result.data[i].type + '" ' +
                'data-uri="' + encodeURI(obj.result.data[i].uri) + '">' +
                '<td class="nowrap"><a class="text-light" href="#" data-href="goto">' + e(obj.result.data[i].name) + '</a></td>' +
                '<td><a class="text-light material-icons material-icons-small" href="#" data-href="edit">edit</a></td><td>' +
                '<a class="text-light material-icons material-icons-small" href="#" data-href="delete">delete</a></td></tr>';
    }
    if (obj.result.returnedEntities === 0) {
        list += '<tr><td class="text-light nowrap">' + t('No bookmarks found') + '</td></tr>';
    }
    list += '</table>';
    document.getElementById('BrowseFilesystemBookmarks').innerHTML = list;
}

function showBookmarkSave(id, name, uri, type) {
    document.getElementById('saveBookmarkName').classList.remove('is-invalid');
    document.getElementById('saveBookmarkId').value = id;
    document.getElementById('saveBookmarkName').value = name;
    document.getElementById('saveBookmarkUri').value = uri;
    document.getElementById('saveBookmarkType').value = type;
    modalSaveBookmark.show();
}

//eslint-disable-next-line no-unused-vars
function saveBookmark() {
    let id = parseInt(document.getElementById('saveBookmarkId').value);
    let name = document.getElementById('saveBookmarkName').value;
    let uri = document.getElementById('saveBookmarkUri').value;
    let type = document.getElementById('saveBookmarkType').value;
    if (name !== '') {
        sendAPI("MYMPD_API_BOOKMARK_SAVE", {"id": id, "name": name, "uri": uri, "type": type});
        modalSaveBookmark.hide();
    }
    else {
        document.getElementById('saveBookmarkName').classList.add('is-invalid');
    }
}

function parseDatabase(obj) {
    let nrItems = obj.result.returnedEntities;
    let cardContainer = document.getElementById('BrowseDatabaseCards');
    let cols = cardContainer.getElementsByClassName('col');
    const has_io = 'IntersectionObserver' in window ? true : false;

    if (cols.length === 0) {
        cardContainer.innerHTML = '';
    }
    for (let i = 0; i < nrItems; i++) {
        let col = document.createElement('div');
        col.classList.add('col', 'px-0', 'flex-grow-0');
        if (obj.result.data[i].AlbumArtist === '') {
            obj.result.data[i].AlbumArtist = t('Unknown artist');
        }
        if (obj.result.data[i].Album === '') {
            obj.result.data[i].Album = t('Unknown album');
        }
        let id;
        let html;
        let picture = '';
        if (obj.result.tag === 'Album') {
            id = genId('database' + obj.result.data[i].Album + obj.result.data[i].AlbumArtist);
            picture = subdir + '/albumart/' + encodeURI(obj.result.data[i].FirstSongUri);
            html = '<div class="card card-grid clickable" data-picture="' + picture  + '" ' + 
                       'data-uri="' + encodeURI(obj.result.data[i].FirstSongUri.replace(/\/[^/]+$/, '')) + '" ' +
                       'data-type="dir" data-name="' + encodeURI(obj.result.data[i].Album) + '" ' +
                       'data-album="' + encodeURI(obj.result.data[i].Album) + '" ' +
                       'data-albumartist="' + encodeURI(obj.result.data[i].AlbumArtist) + '" tabindex="0">' +
                   '<div class="card-body album-cover-loading album-cover-grid bg-white d-flex" id="' + id + '"></div>' +
                   '<div class="card-footer card-footer-grid p-2" title="' + e(obj.result.data[i].AlbumArtist) + ': ' + e(obj.result.data[i].Album) + '">' +
                   e(obj.result.data[i].Album) + '<br/><small>' + e(obj.result.data[i].AlbumArtist) + '</small>' +
                   '</div></div>';
        }
        else {
            id = genId('database' + obj.result.data[i].value);
            picture = subdir + '/tagpics/' + obj.result.tag + '/' + encodeURI(obj.result.data[i].value);
            html = '<div class="card card-grid clickable" data-picture="' + picture + '" data-tag="' + encodeURI(obj.result.data[i].value) + '" tabindex="0">' +
                   (obj.result.pics === true ? '<div class="card-body album-cover-loading album-cover-grid bg-white" id="' + id + '"></div>' : '') +
                   '<div class="card-footer card-footer-grid p-2" title="' + e(obj.result.data[i].value) + '">' +
                   e(obj.result.data[i].value) + '<br/>' +
                   '</div></div>';
        }
        col.innerHTML = html;
        let replaced = false;
        if (i < cols.length) {
            if (cols[i].firstChild.getAttribute('data-picture') !== col.firstChild.getAttribute('data-picture')) {
                cols[i].replaceWith(col);
                replaced = true;
            }
        }
        else {
            cardContainer.append(col);
            replaced = true;
        }
        if (replaced === true) {
            if (has_io === true) {
                let options = {
                    root: null,
                    rootMargin: '0px',
                };
                let observer = new IntersectionObserver(setGridImage, options);
                observer.observe(col);
            }
            else {
                col.firstChild.firstChild.style.backgroundImage = picture;
            }
            if (obj.result.tag === 'Album' && isMobile === true) {
                addPlayButton(document.getElementById(id));
            }
        }
    }
    let colsLen = cols.length - 1;
    for (let i = colsLen; i >= nrItems; i --) {
        cols[i].remove();
    }
    
    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
                    
    if (nrItems === 0) {
        cardContainer.innerHTML = '<div class="ml-3 mb-3"><span class="material-icons">error_outline</span>&nbsp;' + t('Empty list') + '</div>';
    }
    //document.getElementById('cardFooterBrowse').innerText = gtPage('Num entries', obj.result.returnedEntities, obj.result.totalEntities);

    if (app.current.tag === 'Album') {
        parseDatabaseAlbum(obj);
    }
    if (app.current.app === 'Playback') {
        calcBoxHeight();
    }
    scrollToPosY(app.current.scrollPos);
}

function setGridImage(changes, observer) {
    changes.forEach(change => {
        if (change.intersectionRatio > 0) {
            observer.unobserve(change.target);
            const uri = decodeURI(change.target.firstChild.getAttribute('data-picture'));
            const body = change.target.firstChild.getElementsByClassName('card-body')[0];
            if (body) {
                body.style.backgroundImage = 'url("' + uri + '"), url("' + subdir + '/assets/coverimage-loading.svg")';
            }
        }
    });
}

function addPlayButton(parentEl) {
    const div = document.createElement('div');
    div.classList.add('align-self-end', 'album-grid-mouseover', 'material-icons', 'rounded-circle', 'clickable');
    div.innerText = 'play_arrow';
    parentEl.appendChild(div);
    div.addEventListener('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        replaceQueue('dir', decodeURI(event.target.parentNode.parentNode.getAttribute('data-uri')), decodeURI(event.target.parentNode.parentNode.getAttribute('data-name')));
    }, false);
}

function parseAlbumDetails(obj) {
    const coverEl = document.getElementById('viewDetailDatabaseCover');
    coverEl.style.backgroundImage = 'url("' + subdir + '/albumart/' + obj.result.data[0].uri + '"), url("' + subdir + '/assets/coverimage-loading.svg")';
    coverEl.setAttribute('data-images', obj.result.images.join(';;'));
    coverEl.setAttribute('data-uri', obj.result.data[0].uri);
    const infoEl = document.getElementById('viewDetailDatabaseInfo');
    infoEl.innerHTML = '<h1>' + e(obj.result.Album) + '</h1>' +
        '<small> ' + t('AlbumArtist') + '</small><p>' + e(obj.result.AlbumArtist) + '</p>' +
        (obj.result.bookletPath === '' || settings.featBrowse === false ? '' : 
            '<span class="text-light material-icons">description</span>&nbsp;<a class="text-light" target="_blank" href="' + subdir + '/browse/music/' + 
            e(obj.result.bookletPath) + '">' + t('Download booklet') + '</a>') +
        '</p>';
    const table = document.getElementById('BrowseDatabaseDetailList');
    const tbody = table.getElementsByTagName('tbody')[0];
    const nrCols = settings.colsBrowseDatabaseDetail.length;
    let titleList = '';
    if (obj.result.Discs > 1) {
        titleList = '<tr class="not-clickable"><td><span class="material-icons">album</span></td><td colspan="' + nrCols +'">' + t('Disc 1') + '</td></tr>';
    }
    let nrItems = obj.result.returnedEntities;
    let lastDisc = parseInt(obj.result.data[0].Disc);
    for (let i = 0; i < nrItems; i++) {
        if (lastDisc < parseInt(obj.result.data[i].Disc)) {
            titleList += '<tr class="not-clickable"><td><span class="material-icons">album</span></td><td colspan="' + nrCols +'">' + 
                t('Disc') + ' ' + e(obj.result.data[i].Disc) + '</td></tr>';
        }
        if (obj.result.data[i].Duration) {
            obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        }
        titleList += '<tr tabindex="0" data-type="song" data-name="' + obj.result.data[i].Title + '" data-uri="' + encodeURI(obj.result.data[i].uri) + '">';
        for (let c = 0; c < settings.colsBrowseDatabaseDetail.length; c++) {
            titleList += '<td data-col="' + settings.colsBrowseDatabaseDetail[c] + '">' + e(obj.result.data[i][settings.colsBrowseDatabaseDetail[c]]) + '</td>';
        }
        titleList += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td></tr>';
        lastDisc = obj.result.data[i].Disc;
    }
    tbody.innerHTML = titleList;
    const tfoot = table.getElementsByTagName('tfoot')[0];
    let colspan = settings.colsBrowseDatabaseDetail.length;
    tfoot.innerHTML = '<tr><td colspan="' + (colspan + 1) + '"><small>' + t('Num songs', obj.result.totalEntities) + '&nbsp;&ndash;&nbsp;' + beautifyDuration(obj.result.totalTime) + '</small></td></tr>';
    document.getElementById('BrowseDatabaseDetailList').classList.remove('opacity05');
}

//eslint-disable-next-line no-unused-vars
function backToAlbumGrid() {
    appGoto('Browse', 'Database', 'List');
}  

//eslint-disable-next-line no-unused-vars
function addAlbum(action) {
    const album = decodeURI(app.current.tag);
    const albumArtist = decodeURI(app.current.search);
    _addAlbum(action, albumArtist, album);
}

function _addAlbum(action, albumArtist, album) {
    const expression = '((Album == \'' + escapeMPD(album) + '\') AND (' + tagAlbumArtist + ' == \'' + escapeMPD(albumArtist) + '\'))';
    if (action === 'appendQueue') {
        addAllFromSearchPlist('queue', expression, false);
    }
    else if (action === 'replaceQueue') {
        addAllFromSearchPlist('queue', expression, true);
    }
    else if (action === 'addPlaylist') {
        showAddToPlaylist('ALBUM', expression);
    }
}

function searchAlbumgrid(x) {
    let expression = '';
    let crumbs = document.getElementById('searchDatabaseCrumb').children;
    for (let i = 0; i < crumbs.length; i++) {
        if (i > 0) {
            expression += ' AND ';
        }
        expression += '(' + decodeURI(crumbs[i].getAttribute('data-filter-tag')) + ' ' + 
            decodeURI(crumbs[i].getAttribute('data-filter-op')) + ' \'' + 
            escapeMPD(decodeURI(crumbs[i].getAttribute('data-filter-value'))) + '\')';
    }
    if (x !== '') {
        if (expression !== '') {
            expression += ' AND ';
        }
        let match = document.getElementById('searchDatabaseMatch');
        expression += '(' + app.current.filter + ' ' + match.options[match.selectedIndex].value + ' \'' + escapeMPD(x) +'\')';
    }
    
    if (expression.length <= 2) {
        expression = '';
    }
    appGoto(app.current.app, app.current.tab, app.current.view, 
        '0', app.current.limit, app.current.filter, app.current.sort, app.current.tag, expression);
}

function checkForUpdates() {
    sendAPI("MYMPD_API_UPDATE_CHECK", {}, parseCheck);

    btnWaiting(document.getElementById('btnCheckForUpdates'), true);
}

function parseCheck(obj) {
    document.getElementById('currentVersion').innerText = obj.result.currentVersion;
    document.getElementById('latestVersion').innerText = obj.result.latestVersion;

    if (obj.result.latestVersion !== '') {
        if (obj.result.updatesAvailable === true) {
            document.getElementById('lblInstallUpdates').innerText = 'New version available';
            document.getElementById('btnInstallUpdates').classList.remove('hide');
        }
        else {
            document.getElementById('lblInstallUpdates').innerText = 'System is up to date';
            document.getElementById('btnInstallUpdates').classList.add('hide');
        }
        document.getElementById('updateMsg').innerText = '';
    }
    else {
        document.getElementById('lblInstallUpdates').innerText = '';
        document.getElementById('btnInstallUpdates').classList.add('hide');
        document.getElementById('updateMsg').innerText = 'Cannot get latest version, please try again later';
    }

    btnWaiting(document.getElementById('btnCheckForUpdates'), false);
}

function installUpdates() {
    sendAPI("MYMPD_API_UPDATE_INSTALL", {}, parseInstall);

    document.getElementById('updateMsg').innerText = 'System will automatically reboot after installation';

    btnWaiting(document.getElementById('btnInstallUpdates'), true);
}

function parseInstall(obj) {
    if (obj.result.pacman === false) {
        document.getElementById('updateMsg').innerText = 'Update error, please try again later';
    }
    else if (obj.result.reboot === false) {
        document.getElementById('updateMsg').innerText = 'Reboot error, please reboot manually';
    }
    else {
        document.getElementById('updateMsg').innerText = '';
    }

    btnWaiting(document.getElementById('btnInstallUpdates'), false);
}

function parseCollybiaSettings() {
    document.getElementById('selectDac').value = settings.dac;
    document.getElementById('selectMixerType').value = settings.mixerType;
    toggleBtnChk('btnDop', settings.dop);
    toggleBtnChk('btnFFmpeg', settings.ffmpeg);

    document.getElementById('selectNsType').value = settings.nsType;
    document.getElementById('inputNsServer').value = settings.nsServer;
    document.getElementById('inputNsShare').value = settings.nsShare;
    document.getElementById('selectSambaVersion').value = settings.sambaVersion;
    document.getElementById('inputNsUsername').value = settings.nsUsername;
    document.getElementById('inputNsPassword').value = settings.nsPassword;

    if (settings.nsType === 0) {
        document.getElementById('nsServerShare').classList.add('hide');
        document.getElementById('sambaVersion').classList.add('hide');
        document.getElementById('nsCredentials').classList.add('hide');
        /* document.getElementById('inputNsServer').setAttribute('disabled', 'disabled');
        document.getElementById('inputNsShare').setAttribute('disabled', 'disabled');
        document.getElementById('inputNsUsername').setAttribute('disabled', 'disabled');
        document.getElementById('inputNsPassword').setAttribute('disabled', 'disabled'); */
    }
    else if (settings.nsType === 2) {
        document.getElementById('nsServerShare').classList.remove('hide');
        document.getElementById('sambaVersion').classList.remove('hide');
        document.getElementById('nsCredentials').classList.remove('hide');
    }
    else { // 1 or 3
        document.getElementById('nsServerShare').classList.remove('hide');
        if (settings.nsType === 1) {
            document.getElementById('sambaVersion').classList.remove('hide');
        }
        else {
            document.getElementById('sambaVersion').classList.add('hide');
        }
        document.getElementById('nsCredentials').classList.add('hide');
    }

    toggleBtnChk('btnAPMode', settings.apmode);
    toggleBtnChk('btnAirplay', settings.airplay);
    toggleBtnChk('btnRoon', settings.roon);
    toggleBtnChk('btnSpotify', settings.spotify);
    toggleBtnChkCollapse('btnTidalEnabled', 'collapseTidal', settings.tidalEnabled);
    document.getElementById('inputTidalUsername').value = settings.tidalUsername;
    document.getElementById('inputTidalPassword').value = settings.tidalPassword;
    document.getElementById('selectTidalAudioquality').value = settings.tidalAudioquality;
}

function saveCollybiaSettings() {
    let formOK = true;

    let selectNsType = document.getElementById('selectNsType');
    let selectNsTypeValue = selectNsType.options[selectNsType.selectedIndex].value;
    let inputNsServer = document.getElementById('inputNsServer');
    let inputNsShare = document.getElementById('inputNsShare');
    let inputNsUsername = document.getElementById('inputNsUsername');
    let inputNsPassword = document.getElementById('inputNsPassword');

    if (selectNsTypeValue !== '0') {
        /* if (inputNsServer.value.indexOf('/') !== 0) {
            if (!validateHost(inputNsServer)) {
                formOK = false;
            }
        } */
        if (!validateIPAddress(inputNsServer)) {
            formOK = false;
        }
        if (!validatePath(inputNsShare)) {
            formOK = false;
        }
    }
    if (selectNsTypeValue === '2') {
        if (!validateNotBlank(inputNsUsername) || !validateNotBlank(inputNsPassword)) {
            formOK = false;
        }
    }

    let inputTidalUsername = document.getElementById('inputTidalUsername');
    let inputTidalPassword = document.getElementById('inputTidalPassword');
    if (document.getElementById('btnTidalEnabled').classList.contains('active')) {
        if (!validateNotBlank(inputTidalUsername) || !validateNotBlank(inputTidalPassword)) {
            formOK = false;
        }
    }

    if (formOK === true) {
        let selectDac = document.getElementById('selectDac');
        let selectMixerType = document.getElementById('selectMixerType');
        let selectSambaVersion = document.getElementById('selectSambaVersion');
        let selectTidalAudioquality = document.getElementById('selectTidalAudioquality');
        sendAPI("MYMPD_API_SETTINGS_SET", {
            "dac": selectDac.options[selectDac.selectedIndex].value,
            "mixerType": selectMixerType.options[selectMixerType.selectedIndex].value,
            "dop": (document.getElementById('btnDop').classList.contains('active') ? true : false),
            "ffmpeg": (document.getElementById('btnFFmpeg').classList.contains('active') ? true : false),
            "nsType": parseInt(selectNsTypeValue),
            "nsServer": inputNsServer.value,
            "nsShare": inputNsShare.value,
            "sambaVersion": selectSambaVersion.options[selectSambaVersion.selectedIndex].value,
            "nsUsername": inputNsUsername.value,
            "nsPassword": inputNsPassword.value,
            "apmode": (document.getElementById('btnAPMode').classList.contains('active') ? true : false),
            "airplay": (document.getElementById('btnAirplay').classList.contains('active') ? true : false),
            "roon": (document.getElementById('btnRoon').classList.contains('active') ? true : false),
            "spotify": (document.getElementById('btnSpotify').classList.contains('active') ? true : false),
            "tidalEnabled": (document.getElementById('btnTidalEnabled').classList.contains('active') ? true : false),
            "tidalUsername": inputTidalUsername.value,
            "tidalPassword": inputTidalPassword.value,
            "tidalAudioquality": selectTidalAudioquality.options[selectTidalAudioquality.selectedIndex].value
        }, getSettings);
        modalCollybia.hide();
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function navigateGrid(grid, keyCode) {
    let handled = false;
    if (keyCode === 'Enter') {
        if (app.current.app === 'Browse' && app.current.tab === 'Database' && app.current.view === 'List') {
            if (app.current.tag === 'Album') {
                appGoto('Browse', 'Database', 'Detail', '0', undefined, 'Album','AlbumArtist', 
                    decodeURI(grid.getAttribute('data-album')),
                    decodeURI(grid.getAttribute('data-albumartist')));
            }
            else {
                app.current.search = '';
                document.getElementById('searchDatabaseStr').value = '';
                appGoto(app.current.app, app.current.card, undefined, '0', undefined, 'Album', 'AlbumArtist', 'Album',
                    '(' + app.current.tag + ' == \'' + decodeURI(grid.getAttribute('data-tag')) + '\')');
            }
            handled = true;
        }
        else if (app.current.app === 'Home') {
            const href = event.target.getAttribute('data-href');
            if (href !== null) {
               parseCmd(event, href);
            }
        }
    }
    else if (keyCode === ' ') {
        if (app.current.app === 'Browse' && app.current.tab === 'Database' && app.current.view === 'List') {
            if (app.current.tag === 'Album') {
                showMenu(grid.getElementsByClassName('card-footer')[0], event);
            }
            handled = true;
        }
        else if (app.current.app === 'Home') {
            showMenu(grid.getElementsByClassName('card-footer')[0], event);
        }
    }
    else if (keyCode === 'ArrowDown' || keyCode === 'ArrowUp') {
        const cur = grid;
        const next = keyCode === 'ArrowDown' ? (grid.parentNode.nextElementSibling !== null ? grid.parentNode.nextElementSibling.firstChild : null)
                                             : (grid.parentNode.previousElementSibling !== null ? grid.parentNode.previousElementSibling.firstChild : null);
        if (next !== null) {
            next.focus();
            cur.classList.remove('selected');
            next.classList.add('selected');
            handled = true;
            scrollFocusIntoView();
        }
    }
    else if (keyCode === 'Escape') {
        const cur = grid;
        cur.blur();
        cur.classList.remove('selected');
        handled = true;
    }
    if (handled === true) {
        event.stopPropagation();
        event.preventDefault();
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parseHome(obj) {
    const nrItems = obj.result.returnedEntities;
    const cardContainer = document.getElementById('HomeCards');
    const cols = cardContainer.getElementsByClassName('col');
    if (cols.length === 0) {
        cardContainer.innerHTML = '';
    }
    for (let i = 0; i < nrItems; i++) {
        const col = document.createElement('div');
        col.classList.add('col', 'px-0', 'flex-grow-0');
        if (obj.result.data[i].AlbumArtist === '') {
            obj.result.data[i].AlbumArtist = t('Unknown artist');
        }
        if (obj.result.data[i].Album === '') {
            obj.result.data[i].Album = t('Unknown album');
        }
        //Workarround for 6.10 change (add limit parameter)
        if (obj.result.data[i].cmd === 'appGoto') {
            if (obj.result.data[i].options.length === 8) {
                obj.result.data[i].options.splice(4, 0, settings.maxElementsPerPage);
            }
        }
        
        const href = JSON.stringify({"cmd": obj.result.data[i].cmd, "options": obj.result.data[i].options});
        const html = '<div class="card home-icons clickable" draggable="true" tabindex="0" data-pos="' + i + '" data-href=\'' + 
                   e(href) + '\'  title="' + e(obj.result.data[i].name) + '">' +
                   '<div class="card-body material-icons">' + e(obj.result.data[i].ligature) + '</div>' +
                   '<div class="card-footer card-footer-grid p-2">' +
                   e(obj.result.data[i].name) + 
                   '</div></div>';
        col.innerHTML = html;
        if (i < cols.length) {
            cols[i].replaceWith(col);
        }
        else {
            cardContainer.append(col);
        }
        if (obj.result.data[i].image !== '') {
            col.getElementsByClassName('card-body')[0].style.backgroundImage = 'url("' + subdir + '/browse/pics/' + obj.result.data[i].image + '")';
        }
        if (obj.result.data[i].bgcolor !== '') {
            col.getElementsByClassName('card-body')[0].style.backgroundColor = obj.result.data[i].bgcolor;
        }
    }
    let colsLen = cols.length - 1;
    for (let i = colsLen; i >= nrItems; i --) {
        cols[i].remove();
    }
                    
    if (nrItems === 0) {
        cardContainer.innerHTML = '<div class="ml-3">' + t('Homescreen welcome') + '</div>';
    }
}

function dragAndDropHome() {
    const homeCards = document.getElementById('HomeCards');
    homeCards.addEventListener('dragstart', function(event) {
        if (event.target.classList.contains('home-icons')) {
            event.target.classList.add('opacity05');
            event.dataTransfer.setDragImage(event.target, 0, 0);
            event.dataTransfer.effectAllowed = 'move';
            dragSrc = event.target;
            dragEl = event.target.cloneNode(true);
        }
    }, false);
    homeCards.addEventListener('dragleave', function(event) {
        event.preventDefault();
        if (dragEl.classList.contains('home-icons') === false) {
            return;
        }
        if (event.target.nodeName === 'DIV' && event.target.classList.contains('home-icons')) {
            event.target.classList.remove('dragover-icon');
        }
    }, false);
    homeCards.addEventListener('dragover', function(event) {
        event.preventDefault();
        if (dragEl.classList.contains('home-icons') === false) {
            return;
        }
        let th = homeCards.getElementsByClassName('dragover-icon');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-icon');
        }
        if (event.target.nodeName === 'DIV' && event.target.classList.contains('home-icons')) {
            event.target.classList.add('dragover-icon');
        }
        else if (event.target.nodeName === 'DIV' && event.target.parentNode.classList.contains('home-icons')) {
            event.target.parentNode.classList.add('dragover-icon');
        }
        event.dataTransfer.dropEffect = 'move';
    }, false);
    homeCards.addEventListener('dragend', function(event) {
        event.preventDefault();
        if (dragEl.classList.contains('home-icons') === false) {
            return;
        }
        let th = homeCards.getElementsByClassName('dragover-icon');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-icon');
        }
        dragSrc.classList.remove('opacity05');
    }, false);
    homeCards.addEventListener('drop', function(event) {
        event.preventDefault();
        event.stopPropagation();
        if (dragEl.classList.contains('home-icons') === false) {
            return;
        }
        let dst = event.target;
        if (dst.nodeName === 'DIV') {
            if (dst.classList.contains('card-body')) {
                dst = dst.parentNode;
            }
            if (dst.classList.contains('home-icons')) {
                dragEl.classList.remove('opacity05');
                const to = parseInt(dst.getAttribute('data-pos'));
                const from = parseInt(dragSrc.getAttribute('data-pos'));
                if (isNaN(to) === false && isNaN(from) === false && from !== to) {
                    sendAPI("MYMPD_API_HOME_ICON_MOVE", {"from": from, "to": to}, function(obj) {
                        parseHome(obj);
                    });
                }
            }
        }
        let th = homeCards.getElementsByClassName('dragover-icon');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-icon');
        }

    }, false);
}

//eslint-disable-next-line no-unused-vars
function executeHomeIcon(pos) {
    const el = document.getElementById('HomeCards').children[pos].firstChild;
    parseCmd(null, el.getAttribute('data-href'));
}

//eslint-disable-next-line no-unused-vars
function addViewToHome() {
    _addHomeIcon('appGoto', '', 'preview', [app.current.app, app.current.tab, app.current.view, 
        app.current.offset, app.current.limit, app.current.filter, app.current.sort, app.current.tag, app.current.search]); 
}

//eslint-disable-next-line no-unused-vars
function addScriptToHome(name, script_def) {
    let script = JSON.parse(script_def);
    let options = [script.script, script.arguments.join(',')];
    _addHomeIcon('execScriptFromOptions', name, 'description', options);
}

//eslint-disable-next-line no-unused-vars
function addPlistToHome(uri, name) {
    _addHomeIcon('replaceQueue', name, 'list', ['plist', uri, name]);
}

function _addHomeIcon(cmd, name, ligature, options) {
    document.getElementById('modalEditHomeIconTitle').innerHTML = t('Add to homescreen');
    document.getElementById('inputHomeIconReplace').value = 'false';
    document.getElementById('inputHomeIconOldpos').value = '0';
    document.getElementById('inputHomeIconName').value = name;
    document.getElementById('inputHomeIconLigature').value = ligature;
    document.getElementById('inputHomeIconBgcolor').value = '#28a745';
    document.getElementById('selectHomeIconCmd').value = cmd;
    
    showHomeIconCmdOptions(options);
    getHomeIconPictureList('');
    
    document.getElementById('homeIconPreview').innerText = ligature;
    document.getElementById('homeIconPreview').style.backgroundColor = '#28a745';
    document.getElementById('homeIconPreview').style.backgroundImage = '';
    document.getElementById('divHomeIconLigature').classList.remove('hide');
    modalEditHomeIcon.show();
}

//eslint-disable-next-line no-unused-vars
function duplicateHomeIcon(pos) {
    _editHomeIcon(pos, false, "Duplicate home icon");
}

//eslint-disable-next-line no-unused-vars
function editHomeIcon(pos) {
    _editHomeIcon(pos, true, "Edit home icon");
}

function _editHomeIcon(pos, replace, title) {
    document.getElementById('modalEditHomeIconTitle').innerHTML = t(title);
    sendAPI("MYMPD_API_HOME_ICON_GET", {"pos": pos}, function(obj) {
        document.getElementById('inputHomeIconReplace').value = replace;
        document.getElementById('inputHomeIconOldpos').value = pos;
        document.getElementById('inputHomeIconName').value = obj.result.data.name;
        document.getElementById('inputHomeIconLigature').value = obj.result.data.ligature;
        document.getElementById('inputHomeIconBgcolor').value = obj.result.data.bgcolor;
        document.getElementById('selectHomeIconCmd').value = obj.result.data.cmd;

        //Workarround for 6.10 change (add limit parameter)
        if (obj.result.data.cmd === 'appGoto') {
            if (obj.result.data.options.length === 8) {
                obj.result.data.options.splice(4, 0, settings.maxElementsPerPage);
            }
        }

        showHomeIconCmdOptions(obj.result.data.options);
        getHomeIconPictureList(obj.result.data.image);

        document.getElementById('homeIconPreview').innerText = obj.result.data.ligature;
        document.getElementById('homeIconPreview').style.backgroundColor = obj.result.data.bgcolor;
        
        if (obj.result.data.image === '') {
            document.getElementById('divHomeIconLigature').classList.remove('hide');
            document.getElementById('homeIconPreview').style.backgroundImage = '';
        }
        else {
            document.getElementById('divHomeIconLigature').classList.add('hide');
            document.getElementById('homeIconPreview').style.backgroundImage = 'url(' + subdir + '"/browse/pics/' + obj.result.data.image + '")';
        }
        
        modalEditHomeIcon.show();
    });
}

//eslint-disable-next-line no-unused-vars
function saveHomeIcon() {
    let formOK = true;
    let nameEl = document.getElementById('inputHomeIconName');
    if (!validateNotBlank(nameEl)) {
        formOK = false;
    }
    if (formOK === true) {
        let options = [];
        let optionEls = document.getElementById('divHomeIconOptions').getElementsByTagName('input');
        for (let i = 0; i < optionEls.length; i++) {
            //workarround for parsing arrays with empty values in frozen
            let value = optionEls[i].value !== '' ? optionEls[i].value : '!undefined!';
            options.push(value);
        }
        const image = getSelectValue('selectHomeIconImage');
        sendAPI("MYMPD_API_HOME_ICON_SAVE", {
            "replace": (document.getElementById('inputHomeIconReplace').value === 'true' ? true : false),
            "oldpos": parseInt(document.getElementById('inputHomeIconOldpos').value),
            "name": nameEl.value,
            "ligature": (image === '' ? document.getElementById('inputHomeIconLigature').value : ''),
            "bgcolor": document.getElementById('inputHomeIconBgcolor').value,
            "image": image,
            "cmd": document.getElementById('selectHomeIconCmd').value,
            "options": options
            }, function() {
                modalEditHomeIcon.hide();
                sendAPI("MYMPD_API_HOME_LIST", {}, function(obj) {
                    parseHome(obj);
                });
            });
    }
}

//eslint-disable-next-line no-unused-vars
function deleteHomeIcon(pos) {
    sendAPI("MYMPD_API_HOME_ICON_DELETE", {"pos": pos}, function(obj) {
        parseHome(obj);
    });
}

function showHomeIconCmdOptions(values) {
    let list = '';
    const optionsText = getSelectedOptionAttribute('selectHomeIconCmd', 'data-options')
    if (optionsText !== undefined) {    
        const options = JSON.parse(optionsText);
        for (let i = 0; i < options.options.length; i++) {
            let value = values !== undefined ? values[i] !== undefined ? values[i] : '' : '';
            list += '<div class="form-group row">' +
                '<label class="col-sm-4 col-form-label">' + t(options.options[i]) + '</label>' +
                '<div class="col-sm-8"><input class="form-control border-secondary" value="' + e(value) + '"></div>' +
                '</div>';
        }
    }
    document.getElementById('divHomeIconOptions').innerHTML = list;
}

function getHomeIconPictureList(picture) {
    sendAPI("MYMPD_API_HOME_ICON_PICTURE_LIST", {}, function(obj) {
        let options = '<option value="">' + t('Use ligature') + '</option>';
        for (let i = 0; i < obj.result.returnedEntities; i++) {
            options += '<option value="' + e(obj.result.data[i]) + '">' + e(obj.result.data[i])  + '</option>';
        }
        let sel = document.getElementById('selectHomeIconImage');
        sel.innerHTML = options;
        sel.value = picture;
    });
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function delQueueJukeboxSong(pos) {
    sendAPI("MPD_API_JUKEBOX_RM", {"pos": pos}, function() {
        sendAPI("MPD_API_JUKEBOX_LIST", {"offset": app.current.offset, "cols": settings.colsQueueJukebox}, parseJukeboxList);
    });
}

function parseJukeboxList(obj) {
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('QueueJukeboxList');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].LastPlayed = localeDate(obj.result.data[i].LastPlayed);
        let row = document.createElement('tr');
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('data-name', obj.result.data[i].Title);
        row.setAttribute('data-type', 'song');
        row.setAttribute('data-pos', i);
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < settings.colsQueueJukebox.length; c++) {
            tds += '<td data-col="' + settings.colsQueueJukebox[c] + '">' + e(obj.result.data[i][settings.colsQueueJukebox[c]]) + '</td>';
        }
        tds += '<td data-col="Action">';
        if (obj.result.data[i].uri !== '') {
            tds += '<a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a>';
        }
        tds += '</td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }                    

    let colspan = settings['colsQueueJukebox'].length;
    
    if (nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    }

    if (navigate === true) {
        focusTable(activeRow);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    document.getElementById('QueueJukeboxList').classList.remove('opacity05');
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
var keymap = {
    "ArrowLeft": {"cmd": "clickPrev", "options": [], "desc": "Previous song", "key": "keyboard_arrow_left"},
    "ArrowRight": {"cmd": "clickNext", "options": [], "desc": "Next song", "key": "keyboard_arrow_right"},
    " ": {"cmd": "clickPlay", "options": [], "desc": "Toggle play / pause", "key": "space_bar"},
    "s": {"cmd": "clickStop", "options": [], "desc": "Stop playing"},
    "-": {"cmd": "volumeStep", "options": ["down"], "desc": "Volume down"},
    "+": {"cmd": "volumeStep", "options": ["up"], "desc": "Volume up"},
    "c": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CLEAR"}], "desc": "Clear queue"},
    "u": {"cmd": "updateDB", "options": ["", true], "desc": "Update database"},
    "r": {"cmd": "rescanDB", "options": ["", true], "desc": "Rescan database"},
    "p": {"cmd": "updateSmartPlaylists", "options": [false], "desc": "Update smart playlists", "req": "featSmartpls"},
    "a": {"cmd": "showAddToPlaylist", "options": ["stream", ""], "desc": "Add stream"},
    "t": {"cmd": "openModal", "options": ["modalSettings"], "desc": "Open settings"},
    "i": {"cmd": "clickTitle", "options": [], "desc": "Open song details"},
    "l": {"cmd": "openDropdown", "options": ["dropdownLocalPlayer"], "desc": "Open local player"},
    "0": {"cmd": "appGoto", "options": ["Playback"], "desc": "Goto playback"},
    "1": {"cmd": "appGoto", "options": ["Queue", "Current"], "desc": "Goto queue"},
    "2": {"cmd": "appGoto", "options": ["Queue", "LastPlayed"], "desc": "Goto last played"},
    "3": {"cmd": "appGoto", "options": ["Browse", "Database"], "desc": "Goto browse database", "req": "featTags"},
    "4": {"cmd": "appGoto", "options": ["Browse", "Playlists"], "desc": "Goto browse playlists", "req": "featPlaylists"},
    "5": {"cmd": "appGoto", "options": ["Browse", "Filesystem"], "desc": "Goto browse filesystem"},
    "6": {"cmd": "appGoto", "options": ["Search"], "desc": "Goto search"},
    "m": {"cmd": "openDropdown", "options": ["dropdownMainMenu"], "desc": "Open main menu"},
    "v": {"cmd": "openDropdown", "options": ["dropdownVolumeMenu"], "desc": "Open volume menu"},
    "S": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_SHUFFLE"}], "desc": "Shuffle queue"},
    "C": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CROP"}], "desc": "Crop queue"},
    "?": {"cmd": "openModal", "options": ["modalAbout"], "desc": "Open about"},
    "/": {"cmd": "focusSearch", "options": [], "desc": "Focus search"},
    "n": {"cmd": "focusTable", "options": [], "desc": "Focus table"},
    "q": {"cmd": "queueSelectedItem", "options": [true], "desc": "Append item to queue"},
    "Q": {"cmd": "queueSelectedItem", "options": [false], "desc": "Replace queue with item"},
    "d": {"cmd": "dequeueSelectedItem", "options": [], "desc": "Remove item from queue"},
    "x": {"cmd": "addSelectedItemToPlaylist", "options": [], "desc": "Append item to playlist"},
    "F": {"cmd": "openFullscreen", "options": [], "desc": "Open fullscreen"}
};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function e(x) {
    if (isNaN(x)) {
        return x.replace(/([<>"'])/g, function(m0, m1) {
            if (m1 === '<') return '&lt;';
            else if (m1 === '>') return '&gt;';
            else if (m1 === '"') return '&quot;';
            else if (m1 === '\'') return '&apos;';
        }).replace(/\\u(003C|003E|0022|0027)/gi, function(m0, m1) {
            if (m1 === '003C') return '&lt;';
            else if (m1 === '003E') return '&gt;';
            else if (m1 === '0022') return '&quot;';
            else if (m1 === '0027') return '&apos;';
        });
    }
    return x;
}

function t(phrase, number, data) {
    let result = undefined;
    if (isNaN(number)) {
        data = number;
    }

    if (phrases[phrase]) {
        result = phrases[phrase][locale];
        if (result === undefined) {
            if (locale !== 'en-US') {
                logWarn('Phrase "' + phrase + '" for locale ' + locale + ' not found');
            }
            result = phrases[phrase]['en-US'];
        }
    }
    if (result === undefined) {
        result = phrase;
    }

    if (isNaN(number) === false) {
        let p = result.split(' |||| ');
        if (p.length > 1) {
            result = p[smartCount(number)];
        }
        result = result.replace('%{smart_count}', number);
    }
    
    if (data !== null) {
        result = result.replace(/%\{(\w+)\}/g, function(m0, m1) {
            return data[m1];
        });
    }
    
    return e(result);
}

function smartCount(number) {
    if (number === 0) { return 1; }
    else if (number === 1) { return 0; }
    else { return 1; }
}

function localeDate(secs) {
    let d;
    if (secs === undefined) {
       d  = new Date();
    }
    else {
        d = new Date(secs * 1000);
    }
    return d.toLocaleString(locale);
}

function beautifyDuration(x) {
    let days = Math.floor(x / 86400);
    let hours = Math.floor(x / 3600) - days * 24;
    let minutes = Math.floor(x / 60) - hours * 60 - days * 1440;
    let seconds = x - days * 86400 - hours * 3600 - minutes * 60;

    return (days > 0 ? days + '\u2009'+ t('Days') + ' ' : '') +
        (hours > 0 ? hours + '\u2009' + t('Hours') + ' ' + 
        (minutes < 10 ? '0' : '') : '') + minutes + '\u2009' + t('Minutes') + ' ' + 
        (seconds < 10 ? '0' : '') + seconds + '\u2009' + t('Seconds');
}

function beautifySongDuration(x) {
    let hours = Math.floor(x / 3600);
    let minutes = Math.floor(x / 60) - hours * 60;
    let seconds = x - hours * 3600 - minutes * 60;

    return (hours > 0 ? hours + ':' + (minutes < 10 ? '0' : '') : '') + 
        minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
}

//eslint-disable-next-line no-unused-vars
function gtPage(phrase, returnedEntities, totalEntities) {
    if (totalEntities > -1) {
        return t(phrase, totalEntities);
    }
    else if (returnedEntities + app.current.offset < settings.maxElementsPerPage) {
        return t(phrase, returnedEntities);
    }
    else {
        return '> ' + t(phrase, settings.maxElementsPerPage);
    }
}

function i18nHtml(root) {
    let attributes = [['data-phrase', 'innerText'], 
        ['data-title-phrase', 'title'], 
        ['data-placeholder-phrase', 'placeholder']
    ];
    for (let i = 0; i < attributes.length; i++) {
        let els = root.querySelectorAll('[' + attributes[i][0] + ']');
        let elsLen = els.length;
        for (let j = 0; j < elsLen; j++) {
            els[j][attributes[i][1]] = t(els[j].getAttribute(attributes[i][0]));
        }
    }
}
function setLocalPlayerUrl() {
    if (window.location.protocol === 'https:') {
        document.getElementById('infoLocalplayer').classList.remove('hide');
        document.getElementById('selectStreamMode').options[0].setAttribute('data-phrase','HTTPS Port');
    }
    else {
        document.getElementById('infoLocalplayer').classList.add('hide');
        document.getElementById('selectStreamMode').options[0].setAttribute('data-phrase','HTTP Port');
    }
    if (settings.streamUrl === '') {
        settings.mpdstream = window.location.protocol + '//';
        if (settings.mpdHost.match(/^127\./) !== null || settings.mpdHost === 'localhost' || settings.mpdHost.match(/^\//) !== null) {
            settings.mpdstream += window.location.hostname;
        }
        else {
            settings.mpdstream += settings.mpdHost;
        }
        settings.mpdstream += ':' + settings.streamPort + '/';
    } 
    else {
        settings.mpdstream = settings.streamUrl;
    }
    const localPlayer = document.getElementById('localPlayer');
    if (localPlayer.src !== settings.mpdstream) {
        localPlayer.pause();
        localPlayer.src = settings.mpdstream;
        localPlayer.load();
        setTimeout(function() {
            checkLocalPlayerState();
        }, 500);
    }

}

function clickCheckLocalPlayerState(event) {
    const el = event.target;
    el.classList.add('disabled');
    const parent = document.getElementById('localPlayer').parentNode;
    document.getElementById('localPlayer').remove();
    let localPlayer = document.createElement('audio');
    localPlayer.setAttribute('preload', 'none');
    localPlayer.setAttribute('controls', '');
    localPlayer.setAttribute('id', 'localPlayer');
    localPlayer.classList.add('mx-4');
    parent.appendChild(localPlayer);
    setLocalPlayerUrl();
    setTimeout(function() {
        el.classList.remove('disabled');
        localPlayer.play();
    }, 500);
}

function checkLocalPlayerState() {
    const localPlayer = document.getElementById('localPlayer');
    document.getElementById('errorLocalPlayback').classList.add('hide');
    document.getElementById('alertLocalPlayback').classList.add('hide');
    if (localPlayer.networkState === 0) {
        logDebug('localPlayer networkState: ' + localPlayer.networkState);
        document.getElementById('alertLocalPlayback').classList.remove('hide');
    }
    else if (localPlayer.networkState >=1) {
        logDebug('localPlayer networkState: ' + localPlayer.networkState);
    }
    if (localPlayer.networkState === 3) {
        logError('localPlayer networkState: ' + localPlayer.networkState);
        document.getElementById('errorLocalPlayback').classList.remove('hide');
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function logError(line) {
    logLog(0, 'ERROR: ' + line);
}

//eslint-disable-next-line no-unused-vars
function logWarn(line) {
    logLog(1, 'WARN: ' + line);
}

//eslint-disable-next-line no-unused-vars
function logInfo(line) {
    logLog(2, 'INFO: ' + line);
}

//eslint-disable-next-line no-unused-vars
function logVerbose(line) {
    logLog(3, 'VERBOSE: ' + line);
}

//eslint-disable-next-line no-unused-vars
function logDebug(line) {
    logLog(4, 'DEBUG: ' + line);
}

function logLog(loglevel, line) {
    if (settings.loglevel >= loglevel) {
        if (loglevel === 0) {
            console.error(line);
        }
        else if (loglevel === 1) {
            console.warn(line);
        }
        else if (loglevel === 4) {
            console.debug(line);
        }
        else {
            console.log(line);
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function openFullscreen() {
    let elem = document.documentElement;
    if (elem.requestFullscreen) {
        elem.requestFullscreen();
    }
    else if (elem.mozRequestFullScreen) { /* Firefox */
        elem.mozRequestFullScreen();
    }
    else if (elem.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
        elem.webkitRequestFullscreen();
    }
    else if (elem.msRequestFullscreen) { /* IE/Edge */
        elem.msRequestFullscreen();
    }
}

function setViewport(store) {
    let viewport = document.querySelector("meta[name=viewport]");
    viewport.setAttribute('content', 'width=device-width, initial-scale=' + scale + ', maximum-scale=' + scale);
    if (store === true) {
        try {
            localStorage.setItem('scale-ratio', scale);
        }
        catch(err) {
            logError('Can not save scale-ratio in localStorage: ' + err.message);
        }
    }
}

//eslint-disable-next-line no-unused-vars
function addStream() {
    let streamUriEl = document.getElementById('streamUrl');
    if (validateStream(streamUriEl) === true) {
        sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": streamUriEl.value});
        modalAddToPlaylist.hide();
        showNotification(t('Added stream %{streamUri} to queue', {"streamUri": streamUriEl.value}), '', '', 'success');
    }
}

function seekRelativeForward() {
    seekRelative(5);
}

function seekRelativeBackward() {
    seekRelative(-5);
}

function seekRelative(offset) {
    sendAPI("MPD_API_SEEK_CURRENT", {"seek": offset, "relative": true});
}

//eslint-disable-next-line no-unused-vars
function clickPlay() {
    if (playstate !== 'play') {
        sendAPI("MPD_API_PLAYER_PLAY", {});
    }
    else if (settings.footerStop === 'stop') {
        sendAPI("MPD_API_PLAYER_STOP", {});
    }
    else {
        sendAPI("MPD_API_PLAYER_PAUSE", {});
    }
}

//eslint-disable-next-line no-unused-vars
function clickStop() {
    sendAPI("MPD_API_PLAYER_STOP", {});
}

//eslint-disable-next-line no-unused-vars
function clickPrev() {
    sendAPI("MPD_API_PLAYER_PREV", {});
}

//eslint-disable-next-line no-unused-vars
function clickNext() {
    sendAPI("MPD_API_PLAYER_NEXT", {});
}

//eslint-disable-next-line no-unused-vars
function execSyscmd(cmd) {
    sendAPI("MYMPD_API_SYSCMD", {"cmd": cmd});
}

//eslint-disable-next-line no-unused-vars
function clearCovercache() {
    sendAPI("MYMPD_API_COVERCACHE_CLEAR", {});
}

//eslint-disable-next-line no-unused-vars
function cropCovercache() {
    sendAPI("MYMPD_API_COVERCACHE_CROP", {});
}

//eslint-disable-next-line no-unused-vars
function updateDB(uri, showModal) {
    sendAPI("MPD_API_DATABASE_UPDATE", {"uri": uri});
    updateDBstarted(showModal);
}

//eslint-disable-next-line no-unused-vars
function rescanDB(uri, showModal) {
    sendAPI("MPD_API_DATABASE_RESCAN", {"uri": uri});
    updateDBstarted(showModal);
}

function updateDBstarted(showModal) {
    if (showModal === true) {
        document.getElementById('updateDBfinished').innerText = '';
        document.getElementById('updateDBfooter').classList.add('hide');
        let updateDBprogress = document.getElementById('updateDBprogress');
        updateDBprogress.style.width = '20px';
        updateDBprogress.style.marginLeft = '-20px';
        modalUpdateDB.show();
        updateDBprogress.classList.add('updateDBprogressAnimate');
    }

    showNotification(t('Database update started'), '', '', 'success');
}

function updateDBfinished(idleEvent) {
    if (document.getElementById('modalUpdateDB').classList.contains('show')) {
        _updateDBfinished(idleEvent);
    }
    else {
        //on small databases the modal opens after the finish event
        setTimeout(function() {
            _updateDBfinished(idleEvent);
        }, 100);
    }
}

function _updateDBfinished(idleEvent) {
    //spinner in mounts modal
    let el = document.getElementById('spinnerUpdateProgress');
    if (el) {
        let parent = el.parentNode;
        el.remove();
        for (let i = 0; i < parent.children.length; i++) {
            parent.children[i].classList.remove('hide');
        }
    }

    //update database modal
    if (document.getElementById('modalUpdateDB').classList.contains('show')) {
        if (idleEvent === 'update_database') {
            document.getElementById('updateDBfinished').innerText = t('Database successfully updated');
        }
        else if (idleEvent === 'update_finished') {
            document.getElementById('updateDBfinished').innerText = t('Database update finished');
        }
        let updateDBprogress = document.getElementById('updateDBprogress');
        updateDBprogress.classList.remove('updateDBprogressAnimate');
        updateDBprogress.style.width = '100%';
        updateDBprogress.style.marginLeft = '0px';
        document.getElementById('updateDBfooter').classList.remove('hide');
    }

    //general notification
    if (idleEvent === 'update_database') {
        showNotification(t('Database successfully updated'), '', '', 'success');
    }
    else if (idleEvent === 'update_finished') {
        showNotification(t('Database update finished'), '', '', 'success');
    }
}

function updateDBstats() {
    sendAPI("MPD_API_DATABASE_STATS", {}, parseDBstats);
}

//eslint-disable-next-line no-unused-vars
function zoomPicture(el) {
    if (el.classList.contains('booklet')) {
        window.open(el.getAttribute('data-href'));
        return;
    }
    
    if (el.classList.contains('carousel')) {
        let imgSrc = el.getAttribute('data-images');
        let images;
        if (imgSrc !== null) {
            images = el.getAttribute('data-images').split(';;');
        }
        else if (lastSongObj.images) {
            images = lastSongObj.images.slice();
        }
        else {
            return;
        }
        
        //add uri to image list to get embedded albumart
        let a_images = [];
        if (el.getAttribute('data-uri')) {
            a_images = [ subdir + '/albumart/' + el.getAttribute('data-uri') ];
        }
        //add all but coverfiles to image list
        if (settings.publish === true) {
            for (let i = 0; i < images.length; i++) {
                if (isCoverfile(images[i]) === false) {
                    a_images.push(subdir + '/browse/music/' + images[i]);
                }
            }
        }
        const imgEl = document.getElementById('modalPictureImg');
        imgEl.style.paddingTop = 0;
        createImgCarousel(imgEl, 'picsCarousel', a_images);
        document.getElementById('modalPictureZoom').classList.add('hide');
        modalPicture.show();
        return;
    }
    
    if (el.style.backgroundImage !== '') {
        const imgEl = document.getElementById('modalPictureImg');
        imgEl.innerHTML = '';
        imgEl.style.paddingTop = '100%';
        imgEl.style.backgroundImage = el.style.backgroundImage;
        document.getElementById('modalPictureZoom').classList.remove('hide');
        modalPicture.show();
    }
}

//eslint-disable-next-line no-unused-vars
function zoomZoomPicture() {
    window.open(document.getElementById('modalPictureImg').style.backgroundImage.match(/^url\(["']?([^"']*)["']?\)/)[1]);
}


function createImgCarousel(imgEl, name, images) {
    let carousel = '<div id="' + name + '" class="carousel slide" data-ride="carousel">' +
        '<ol class="carousel-indicators">';
    for (let i = 0; i < images.length; i++) {
        carousel += '<li data-target="#' + name + '" data-slide-to="' + i + '"' +
            (i === 0 ? ' class="active"' : '') + '></li>';
    }
    carousel += '</ol>' +
        '<div class="carousel-inner" role="listbox">';
    for (let i = 0; i < images.length; i++) {
        carousel += '<div class="carousel-item' + (i === 0 ? ' active' : '') + '"><div></div></div>';
    }
    carousel += '</div>' +
        '<a class="carousel-control-prev" href="#' + name + '" data-slide="prev">' +
            '<span class="carousel-control-prev-icon"></span>' +
        '</a>' +
        '<a class="carousel-control-next" href="#' + name + '" data-slide="next">' +
            '<span class="carousel-control-next-icon"></span>' +
        '</a>' +
        '</div>';
    imgEl.innerHTML = carousel;
    let carouselItems = imgEl.getElementsByClassName('carousel-item');
    for (let i = 0; i < carouselItems.length; i++) {
        carouselItems[i].children[0].style.backgroundImage = 'url("' + encodeURI(images[i]) + '")';
    }
    let myCarousel = document.getElementById(name);
    //eslint-disable-next-line no-undef, no-unused-vars
    let myCarouselInit = new BSN.Carousel(myCarousel, {
        interval: false,
        pause: false
    });
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function unmountMount(mountPoint) {
    sendAPI("MPD_API_MOUNT_UNMOUNT", {"mountPoint": mountPoint}, showListMounts);
}

//eslint-disable-next-line no-unused-vars
function mountMount() {
    let formOK = true;
    document.getElementById('errorMount').classList.add('hide');
    
    if (formOK === true) {
        sendAPI("MPD_API_MOUNT_MOUNT", {
            "mountUrl": getSelectValue('selectMountUrlhandler') + document.getElementById('inputMountUrl').value,
            "mountPoint": document.getElementById('inputMountPoint').value,
            }, showListMounts, true);
    }
}

//eslint-disable-next-line no-unused-vars
function updateMount(el, uri) {
    let parent = el.parentNode;
    for (let i = 0; i < parent.children.length; i++) {
        parent.children[i].classList.add('hide');
    }
    let spinner = document.createElement('div');
    spinner.setAttribute('id', 'spinnerUpdateProgress');
    spinner.classList.add('spinner-border', 'spinner-border-sm');
    el.parentNode.insertBefore(spinner, el);
    updateDB(uri, false);    
}

//eslint-disable-next-line no-unused-vars
function showEditMount(uri, storage) {
    document.getElementById('listMounts').classList.remove('active');
    document.getElementById('editMount').classList.add('active');
    document.getElementById('listMountsFooter').classList.add('hide');
    document.getElementById('editMountFooter').classList.remove('hide');
    document.getElementById('errorMount').classList.add('hide');

    let c = uri.match(/^(\w+:\/\/)(.+)$/);
    if (c !== null && c.length > 2) {
        document.getElementById('selectMountUrlhandler').value = c[1];
        document.getElementById('inputMountUrl').value = c[2];
        document.getElementById('inputMountPoint').value = storage;
    }
    else {
        document.getElementById('inputMountUrl').value = '';
        document.getElementById('inputMountPoint').value = '';
    }
    document.getElementById('inputMountUrl').focus();
    document.getElementById('inputMountUrl').classList.remove('is-invalid');
    document.getElementById('inputMountPoint').classList.remove('is-invalid');
}

function showListMounts(obj) {
    if (obj && obj.error && obj.error.message) {
        let emEl = document.getElementById('errorMount');
        emEl.innerText = obj.error.message;
        emEl.classList.remove('hide');
        return;
    }
    document.getElementById('listMounts').classList.add('active');
    document.getElementById('editMount').classList.remove('active');
    document.getElementById('listMountsFooter').classList.remove('hide');
    document.getElementById('editMountFooter').classList.add('hide');
    sendAPI("MPD_API_MOUNT_LIST", {}, parseListMounts);
}

function parseListMounts(obj) {
    let tbody = document.getElementById('listMounts').getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    
    let activeRow = 0;
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        let row = document.createElement('tr');
        row.setAttribute('data-url', encodeURI(obj.result.data[i].mountUrl));
        row.setAttribute('data-point', encodeURI(obj.result.data[i].mountPoint));
        if (obj.result.data[i].mountPoint === '') {
            row.classList.add('not-clickable');
        }
        let tds = '<td>' + (obj.result.data[i].mountPoint === '' ? '<span class="material-icons">home</span>' : e(obj.result.data[i].mountPoint)) + '</td>' +
                  '<td>' + e(obj.result.data[i].mountUrl) + '</td>';
        if (obj.result.data[i].mountPoint !== '') {
            tds += '<td data-col="Action">' + 
                   '<a href="#" title="' + t('Unmount') + '" data-action="unmount" class="material-icons color-darkgrey">delete</a>' +
                   '<a href="#" title="' + t('Update') + '" data-action="update"class="material-icons color-darkgrey">refresh</a>' +
                   '</td>';
        }
        else {
            tds += '<td>&nbsp;</td>';
        }
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= obj.result.returnedEntities; i --) {
        tr[i].remove();
    }

    if (obj.result.returnedEntities === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="4">' + t('Empty list') + '</td></tr>';
    }     
}

function parseNeighbors(obj) {
    let list = '';
    if (obj.error) {
        list = '<div class="list-group-item"><span class="material-icons">error_outline</span> ' + t(obj.error.message) + '</div>';
    }
    else {
        for (let i = 0; i < obj.result.returnedEntities; i++) {
            list += '<a href="#" class="list-group-item list-group-item-action" data-value="' + obj.result.data[i].uri + '">' + 
                    obj.result.data[i].uri + '<br/><small>' + obj.result.data[i].displayName + '</small></a>';
        }    
        if (obj.result.returnedEntities === 0) {
            list = '<div class="list-group-item"><span class="material-icons">error_outline</span>&nbsp;' + t('Empty list') + '</div>';
        }
    }
    document.getElementById('dropdownNeighbors').children[0].innerHTML = list;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

/* Disable eslint warnings */
/* global BSN, phrases, locales */

var socket = null;
var websocketConnected = false;
var websocketTimer = null;
var socketRetry = 0;

var lastSong = '';
var lastSongObj = {};
var lastState;
var currentSong = {};
var playstate = '';
var settingsLock = false;
var settingsParsed = false;
var settingsNew = {};
var settings = {};
settings.loglevel = 2;
var alertTimeout = null;
var progressTimer = null;
var deferredA2HSprompt;
var dragSrc;
var dragEl;
var showSyncedLyrics = false;

var appInited = false;
var subdir = '';
var uiEnabled = true;
var locale = navigator.language || navigator.userLanguage;
var scale = '1.0';
var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
var ligatureMore = 'menu';
var progressBarTransition = 'width 1s linear';
var tagAlbumArtist = 'AlbumArtist';

var app = {};
app.apps = { 
    "Home": { 
        "offset": 0,
        "limit": 100,
        "filter": "-",
        "sort": "-",
        "tag": "-",
        "search": "",
        "scrollPos": 0
    },
    "Playback": {
        "active": "Database",
        "tabs": {
            "Database": {
                "active": "List",
                "views": {
                    "List": {
                        "page": 0,
                        "offset": 0,
                        "limit": 100,
                        "filter": "AlbumArtist",
                        "sort": "AlbumArtist",
                        "tag": "Album",
                        "search": "",
                        "scrollPos": 0
                    },
                    "Detail": {
                        "page": 0,
                        "offset": 0,
                        "limit": 100,
                        "filter": "-",
                        "sort": "-",
                        "tag": "-",
                        "search": "",
                        "scrollPos": 0
                    }
                }
            }
        }
    },
    "Queue": {
        "active": "Current",
        "tabs": { 
            "Current": { 
                "page": 0,
                "offset": 0,
                "limit": 100,
                "filter": "any",
                "sort": "-",
                "tag": "-",
                "search": "",
                "scrollPos": 0
            },
            "LastPlayed": {
                "page": 0,
                "offset": 0,
                "limit": 100,
                "filter": "any",
                "sort": "-",
                "tag": "-",
                "search": "",
                "scrollPos": 0 
            },
            "Jukebox": {
                "page": 0,
                "offset": 0,
                "limit": 100,
                "filter": "any",
                "sort": "-",
                "tag": "-",
                "search": "",
                "scrollPos": 0 
            }
        }
    },
    "Browse": { 
        "active": "Database", 
        "tabs":  { 
            "Filesystem": {
                "page": 0, 
                "offset": 0,
                "limit": 100,
                "filter": "-",
                "sort": "-",
                "tag": "-",
                "search": "",
                "scrollPos": 0 
            },
            "Playlists": { 
                "active": "All",
                "views": { 
                    "All": {
                        "page": 0,
                        "offset": 0,
                        "limit": 100,
                        "filter": "-",
                        "sort": "-",
                        "tag": "-",
                        "search": "", 
                        "scrollPos": 0 
                    },
                    "Detail": {
                        "page": 0,
                        "offset": 0,
                        "limit": 100,
                        "filter": "-",
                        "sort": "-",
                        "tag": "-",
                        "search": "",
                        "scrollPos": 0
                    }
                }
            },
            "Database": { 
                "active": "List",
                "views": { 
                    "List": { 
                        "page": 0,
                        "offset": 0,
                        "limit": 100,
                        "filter": "AlbumArtist",
                        "sort": "AlbumArtist",
                        "tag": "Album",
                        "search": "",
                        "scrollPos": 0
                    },
                    "Detail": { 
                        "page": 0,
                        "offset": 0,
                        "limit": 100,
                        "filter": "-",
                        "sort": "-",
                        "tag": "-",
                        "search": "",
                        "scrollPos": 0
                    }
                }
            }
        }
    },
    "Search": { 
        "page": 0,
        "offset": 0,
        "limit": 100,
        "filter": "any",
        "sort": "-",
        "tag": "-",
        "search": "",
        "scrollPos": 0
    }
};

app.current = { "app": "Home", "tab": undefined, "view": undefined, "offset": 0, "limit": 100, "filter": "", "search": "", "sort": "", "tag": "", "scrollPos": 0 };
app.last = { "app": undefined, "tab": undefined, "view": undefined, "offset": 0, "limit": 100, "filter": "", "search": "", "sort": "", "tag": "", "scrollPos": 0 };

var domCache = {};
domCache.counter = document.getElementById('counter');
domCache.volumePrct = document.getElementById('volumePrct');
domCache.volumeControl = document.getElementById('volumeControl');
domCache.volumeMenu = document.getElementById('volumeMenu');
domCache.btnsPlay = document.getElementsByClassName('btnPlay');
domCache.btnsPlayLen = domCache.btnsPlay.length;
domCache.btnPrev = document.getElementById('btnPrev');
domCache.btnNext = document.getElementById('btnNext');
domCache.progress = document.getElementById('footerProgress');
domCache.progressBar = document.getElementById('footerProgressBar');
domCache.progressPos = document.getElementById('footerProgressPos')
domCache.volumeBar = document.getElementById('volumeBar');
domCache.outputs = document.getElementById('outputs');
domCache.btnA2HS = document.getElementById('nav-add2homescreen');
domCache.currentCover = document.getElementById('currentCover');
domCache.currentTitle = document.getElementById('currentTitle');
domCache.footerTitle = document.getElementById('footerTitle');
domCache.footerArtist = document.getElementById('footerArtist');
domCache.footerAlbum = document.getElementById('footerAlbum');
domCache.footerCover = document.getElementById('footerCover');
domCache.btnVoteUp = document.getElementById('btnVoteUp');
domCache.btnVoteDown = document.getElementById('btnVoteDown');
domCache.badgeQueueItems = null;
domCache.searchstr = document.getElementById('searchstr');
domCache.searchCrumb = document.getElementById('searchCrumb');
domCache.body = document.getElementsByTagName('body')[0];
domCache.footer = document.getElementsByTagName('footer')[0];
domCache.header = document.getElementById('header');
domCache.mainMenu = document.getElementById('mainMenu');

/* eslint-disable no-unused-vars */
var modalConnection = new BSN.Modal(document.getElementById('modalConnection'));
var modalSettings = new BSN.Modal(document.getElementById('modalSettings'));
var modalAbout = new BSN.Modal(document.getElementById('modalAbout')); 
var modalSaveQueue = new BSN.Modal(document.getElementById('modalSaveQueue'));
var modalAddToQueue = new BSN.Modal(document.getElementById('modalAddToQueue'));
var modalSongDetails = new BSN.Modal(document.getElementById('modalSongDetails'));
var modalAddToPlaylist = new BSN.Modal(document.getElementById('modalAddToPlaylist'));
var modalRenamePlaylist = new BSN.Modal(document.getElementById('modalRenamePlaylist'));
var modalUpdateDB = new BSN.Modal(document.getElementById('modalUpdateDB'));
var modalSaveSmartPlaylist = new BSN.Modal(document.getElementById('modalSaveSmartPlaylist'));
var modalDeletePlaylist = new BSN.Modal(document.getElementById('modalDeletePlaylist'));
var modalSaveBookmark = new BSN.Modal(document.getElementById('modalSaveBookmark'));
var modalTimer = new BSN.Modal(document.getElementById('modalTimer'));
var modalMounts = new BSN.Modal(document.getElementById('modalMounts'));
var modalExecScript = new BSN.Modal(document.getElementById('modalExecScript'));
var modalScripts = new BSN.Modal(document.getElementById('modalScripts'));
var modalPartitions = new BSN.Modal(document.getElementById('modalPartitions'));
var modalPartitionOutputs = new BSN.Modal(document.getElementById('modalPartitionOutputs'));
var modalTrigger = new BSN.Modal(document.getElementById('modalTrigger'));
var modalOutputAttributes = new BSN.Modal(document.getElementById('modalOutputAttributes'));
var modalPicture = new BSN.Modal(document.getElementById('modalPicture'));
var modalEditHomeIcon = new BSN.Modal(document.getElementById('modalEditHomeIcon'));
var modalCollybia = new BSN.Modal(document.getElementById('modalCollybia'));

var dropdownMainMenu = new BSN.Dropdown(document.getElementById('mainMenu'));
var dropdownVolumeMenu = new BSN.Dropdown(document.getElementById('volumeMenu'));
var dropdownBookmarks = new BSN.Dropdown(document.getElementById('BrowseFilesystemBookmark'));
var dropdownLocalPlayer = new BSN.Dropdown(document.getElementById('localPlaybackMenu'));
var dropdownPlay = new BSN.Dropdown(document.getElementById('btnPlayDropdown'));
var dropdownDatabaseSort = new BSN.Dropdown(document.getElementById('btnDatabaseSortDropdown'));
var dropdownNeighbors = new BSN.Dropdown(document.getElementById('btnDropdownNeighbors'));

var collapseDBupdate = new BSN.Collapse(document.getElementById('navDBupdate'));
var collapseSettings = new BSN.Collapse(document.getElementById('navSettings'));
var collapseSyscmds = new BSN.Collapse(document.getElementById('navSyscmds'));
var collapseScripting = new BSN.Collapse(document.getElementById('navScripting'));
var collapseJukeboxMode = new BSN.Collapse(document.getElementById('labelJukeboxMode'));
/* eslint-enable no-unused-vars */

function appPrepare(scrollPos) {
    if (app.current.app !== app.last.app || app.current.tab !== app.last.tab || app.current.view !== app.last.view) {
        //Hide all cards + nav
        for (let i = 0; i < domCache.navbarBtnsLen; i++) {
            domCache.navbarBtns[i].classList.remove('active');
        }
        document.getElementById('cardHome').classList.add('hide');
        document.getElementById('cardPlayback').classList.add('hide');
        document.getElementById('cardQueue').classList.add('hide');
        document.getElementById('cardBrowse').classList.add('hide');
        document.getElementById('cardSearch').classList.add('hide');
        document.getElementById('cardQueueCurrent').classList.add('hide');
        document.getElementById('cardQueueLastPlayed').classList.add('hide');
        document.getElementById('cardQueueJukebox').classList.add('hide');
        document.getElementById('cardBrowsePlaylists').classList.add('hide');
        document.getElementById('cardBrowseFilesystem').classList.add('hide');
        document.getElementById('cardBrowseDatabase').classList.add('hide');
        //show active card
        setGridPlayback();
        document.getElementById('card' + app.current.app).classList.remove('hide');
        if (app.current.tab !== undefined) {
            if (app.current.app === 'Playback') {
                document.getElementById('cardBrowseDatabase').classList.remove('hide');
            }
            else {
                document.getElementById('card' + app.current.app + app.current.tab).classList.remove('hide');
            }
        }
        //show active navbar icon
        let nav = document.getElementById('nav' + app.current.app + app.current.tab);
        if (nav) {
            nav.classList.add('active');
        }
        else {
            nav = document.getElementById('nav' + app.current.app);
            if (nav) {
                document.getElementById('nav' + app.current.app).classList.add('active');
            }
        }
    }
    scrollToPosY(scrollPos);
    const list = document.getElementById(app.current.app + 
        (app.current.tab === undefined ? '' : app.current.tab) + 
        (app.current.view === undefined ? '' : app.current.view) + 'List');
    if (list) {
        list.classList.add('opacity05');
    }
    else if (app.current.app === 'Playback') {
        document.getElementById('QueueMiniList').classList.add('opacity05');
        if (app.current.view === 'Detail') {
            document.getElementById('BrowseDatabaseDetailList').classList.add('opacity05');
        }
    }
}

function appGoto(card, tab, view, offset, limit, filter, sort, tag, search, newScrollPos) {
    //save scrollPos of current view
    let scrollPos = 0;
    if (document.body.scrollTop) {
        scrollPos = document.body.scrollTop
    }
    else {
        scrollPos = document.documentElement.scrollTop;
    }
        
    if (app.apps[app.current.app].scrollPos !== undefined) {
        app.apps[app.current.app].scrollPos = scrollPos
    }
    else if (app.apps[app.current.app].tabs[app.current.tab].scrollPos !== undefined) {
        app.apps[app.current.app].tabs[app.current.tab].scrollPos = scrollPos
    }
    else if (app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos !== undefined) {
        app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos = scrollPos;
    }

    //set null options to undefined
    if (offset === null) {
        offset = undefined;
    }
    if (limit === null) {
        limit = undefined;
    }
    if (filter === null) {
        filter = undefined;
    }
    if (sort === null) {
        sort = undefined;
    }
    if (tag === null) {
        tag = undefined;
    }
    if (search === null) {
        search = undefined;
    }

    //build new hash
    let hash = '';
    if (app.apps[card].tabs) {
        if (tab === undefined) {
            tab = app.apps[card].active;
        }
        if (app.apps[card].tabs[tab].views) {
            if (view === undefined) {
                view = app.apps[card].tabs[tab].active;
            }
            hash = '/' + encodeURIComponent(card) + '/' + encodeURIComponent(tab) + '/' + encodeURIComponent(view) + '!' + 
                encodeURIComponent(offset === undefined ? app.apps[card].tabs[tab].views[view].offset : offset) + '/' +
                encodeURIComponent(limit === undefined ? app.apps[card].tabs[tab].views[view].limit : limit) + '/' +
                encodeURIComponent(filter === undefined ? app.apps[card].tabs[tab].views[view].filter : filter) + '/' +
                encodeURIComponent(sort === undefined ? app.apps[card].tabs[tab].views[view].sort : sort) + '/' +
                encodeURIComponent(tag === undefined ? app.apps[card].tabs[tab].views[view].tag : tag) + '/' +
                encodeURIComponent(search === undefined ? app.apps[card].tabs[tab].views[view].search : search);
            if (newScrollPos !== undefined) {
                app.apps[card].tabs[tab].views[view].scrollPos = newScrollPos;
            }
        }
        else {
            hash = '/' + encodeURIComponent(card) + '/' + encodeURIComponent(tab) + '!' + 
                encodeURIComponent(offset === undefined ? app.apps[card].tabs[tab].offset : offset) + '/' +
                encodeURIComponent(limit === undefined ? app.apps[card].tabs[tab].limit : limit) + '/' +
                encodeURIComponent(filter === undefined ? app.apps[card].tabs[tab].filter : filter) + '/' +
                encodeURIComponent(sort === undefined ? app.apps[card].tabs[tab].sort : sort) + '/' +
                encodeURIComponent(tag === undefined ? app.apps[card].tabs[tab].tag : tag) + '/' +
                encodeURIComponent(search === undefined ? app.apps[card].tabs[tab].search : search);
            if (newScrollPos !== undefined) {
                app.apps[card].tabs[tab].scrollPos = newScrollPos;
            }
        }
    }
    else {
        hash = '/' + encodeURIComponent(card) + '!' + 
            encodeURIComponent(offset === undefined ? app.apps[card].offset : offset) + '/' +
            encodeURIComponent(limit === undefined ? app.apps[card].limit : limit) + '/' +
            encodeURIComponent(filter === undefined ? app.apps[card].filter : filter) + '/' +
            encodeURIComponent(sort === undefined ? app.apps[card].sort : sort) + '/' +
            encodeURIComponent(tag === undefined ? app.apps[card].tag : tag) + '/' +
            encodeURIComponent(search === undefined ? app.apps[card].search : search);
        if (newScrollPos !== undefined) {
            app.apps[card].scrollPos = newScrollPos;
        }
    }
    location.hash = hash;
}

function appRoute() {
    //called on hash change
    if (settingsParsed === false) {
        appInitStart();
        return;
    }
    let hash = location.hash;
    let params = hash.match(/^#\/(\w+)\/?(\w+)?\/?(\w+)?!(\d+)\/(\d+)\/([^/]+)\/([^/]+)\/([^/]+)\/(.*)$/);
    if (params) {
        app.current.app = decodeURIComponent(params[1]);
        app.current.tab = params[2] !== undefined ? decodeURIComponent(params[2]) : undefined;
        app.current.view = params[3] !== undefined ? decodeURIComponent(params[3]) : undefined;
        app.current.offset = parseInt(decodeURIComponent(params[4]));
        app.current.limit = parseInt(decodeURIComponent(params[5]));
        app.current.filter = decodeURIComponent(params[6]);
        app.current.sort = decodeURIComponent(params[7]);
        app.current.tag = decodeURIComponent(params[8]);
        app.current.search = decodeURIComponent(params[9]);
        
        if (app.apps[app.current.app].offset !== undefined) {
            app.apps[app.current.app].offset = app.current.offset;
            app.apps[app.current.app].limit = app.current.limit;
            app.apps[app.current.app].filter = app.current.filter;
            app.apps[app.current.app].sort = app.current.sort;
            app.apps[app.current.app].tag = app.current.tag;
            app.apps[app.current.app].search = app.current.search;
            app.current.scrollPos = app.apps[app.current.app].scrollPos;
        }
        else if (app.apps[app.current.app].tabs[app.current.tab].offset !== undefined) {
            app.apps[app.current.app].tabs[app.current.tab].offset = app.current.offset;
            app.apps[app.current.app].tabs[app.current.tab].limit = app.current.limit;
            app.apps[app.current.app].tabs[app.current.tab].filter = app.current.filter;
            app.apps[app.current.app].tabs[app.current.tab].sort = app.current.sort;
            app.apps[app.current.app].tabs[app.current.tab].tag = app.current.tag;
            app.apps[app.current.app].tabs[app.current.tab].search = app.current.search;
            app.apps[app.current.app].active = app.current.tab;
            app.current.scrollPos = app.apps[app.current.app].tabs[app.current.tab].scrollPos;
        }
        else if (app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].offset !== undefined) {
            app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].offset = app.current.offset;
            app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].limit = app.current.limit;
            app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].filter = app.current.filter;
            app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].sort = app.current.sort;
            app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].tag = app.current.tag;
            app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].search = app.current.search;
            app.apps[app.current.app].active = app.current.tab;
            app.apps[app.current.app].tabs[app.current.tab].active = app.current.view;
            app.current.scrollPos = app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos;
        }
    }
    else {
        appPrepare(0);
        if (settings.featHome === true) {
            appGoto('Home');
        }
        else {
            appGoto('Playback');
        }
        return;
    }
    appPrepare(app.current.scrollPos);

    if (app.current.app === 'Home') {
        sendAPI("MYMPD_API_HOME_LIST", {}, parseHome);
    }
	
    // else if (app.current.app === 'Playback') {
    //     sendAPI("MPD_API_PLAYER_CURRENT_SONG", {}, songChange);
    // }
    else if (app.current.app === 'Queue' && app.current.tab === 'Current' ) {
        selectTag('searchqueuetags', 'searchqueuetagsdesc', app.current.filter);
        getQueue();
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        sendAPI("MPD_API_QUEUE_LAST_PLAYED", {"offset": app.current.offset, "limit": app.current.limit, "cols": settings.colsQueueLastPlayed}, parseLastPlayed);
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'Jukebox') {
        sendAPI("MPD_API_JUKEBOX_LIST", {"offset": app.current.offset, "limit": app.current.limit, "cols": settings.colsQueueJukebox}, parseJukeboxList);
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": app.current.offset, "limit": app.current.limit, "searchstr": app.current.search}, parsePlaylists);
        const searchPlaylistsStrEl = document.getElementById('searchPlaylistsStr');
        if (searchPlaylistsStrEl.value === '' && app.current.search !== '') {
            searchPlaylistsStrEl.value = app.current.search;
        }
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        sendAPI("MPD_API_PLAYLIST_CONTENT_LIST", {"offset": app.current.offset, "limit": app.current.limit, "searchstr": app.current.search, "uri": app.current.filter, "cols": settings.colsBrowsePlaylistsDetail}, parsePlaylists);
        const searchPlaylistsStrEl = document.getElementById('searchPlaylistsStr');
        if (searchPlaylistsStrEl.value === '' && app.current.search !== '') {
            searchPlaylistsStrEl.value = app.current.search;
        }
    }    
    else if (app.current.app === 'Browse' && app.current.tab === 'Filesystem') {
        sendAPI("MPD_API_DATABASE_FILESYSTEM_LIST", {"offset": app.current.offset, "limit": app.current.limit, "path": (app.current.search ? app.current.search : "/"), 
            "searchstr": (app.current.filter !== '-' ? app.current.filter : ''), "cols": settings.colsBrowseFilesystem}, parseFilesystem, true);
        // Don't add all songs from root
        if (app.current.search) {
            document.getElementById('BrowseFilesystemAddAllSongs').removeAttribute('disabled');
            document.getElementById('BrowseFilesystemAddAllSongsBtn').removeAttribute('disabled');
        }
        else {
            document.getElementById('BrowseFilesystemAddAllSongs').setAttribute('disabled', 'disabled');
            document.getElementById('BrowseFilesystemAddAllSongsBtn').setAttribute('disabled', 'disabled');
        }
        // Create breadcrumb
        let breadcrumbs='<li class="breadcrumb-item"><a data-uri="" class="text-body material-icons">home</a></li>';
        let pathArray = app.current.search.split('/');
        let pathArrayLen = pathArray.length;
        let fullPath = '';
        for (let i = 0; i < pathArrayLen; i++) {
            if (pathArrayLen - 1 === i) {
                breadcrumbs += '<li class="breadcrumb-item active">' + e(pathArray[i]) + '</li>';
                break;
            }
            fullPath += pathArray[i];
            breadcrumbs += '<li class="breadcrumb-item"><a class="text-body" href="#" data-uri="' + encodeURI(fullPath) + '">' + e(pathArray[i]) + '</a></li>';
            fullPath += '/';
        }
        document.getElementById('BrowseBreadcrumb').innerHTML = breadcrumbs;
        const searchFilesystemStrEl = document.getElementById('searchFilesystemStr');
        if (searchFilesystemStrEl.value === '' && app.current.filter !== '-') {
            searchFilesystemStrEl.value = app.current.filter;
        }
        searchFilesystemStrEl.value = app.current.filter === '-' ? '' :  app.current.filter;
    }
    else if ((app.current.app === 'Browse' || app.current.app === 'Playback') && app.current.tab === 'Database' && app.current.view === 'List') {
        if (app.current.app === 'Playback') {
            sendAPI("MPD_API_PLAYER_CURRENT_SONG", {}, songChange);
        }
        document.getElementById('viewListDatabase').classList.remove('hide');
        document.getElementById('viewDetailDatabase').classList.add('hide');
        selectTag('searchDatabaseTags', 'searchDatabaseTagsDesc', app.current.filter);
        selectTag('BrowseDatabaseByTagDropdown', 'btnBrowseDatabaseByTagDesc', app.current.tag);
        let sort = app.current.sort;
        let sortdesc = false;
        if (app.current.sort.charAt(0) === '-') {
            sortdesc = true;
            sort = app.current.sort.substr(1);
            toggleBtnChk('databaseSortDesc', true);
        }
        else {
            toggleBtnChk('databaseSortDesc', false);
        }
        selectTag('databaseSortTags', undefined, sort);
        if (app.current.tag === 'Album') {
            const crumbEl = document.getElementById('searchDatabaseCrumb');
            const searchEl = document.getElementById('searchDatabaseStr');
            
            let crumbs = '';
            let elements = app.current.search.split(' AND ');
            for (let i = 0; i < elements.length - 1 ; i++) {
                let expression = elements[i].substring(1, elements[i].length - 1);
                let fields = expression.match(/^(\w+)\s+(\S+)\s+'(.*)'$/);
                crumbs += '<button data-filter-tag="' + encodeURI(fields[1]) + '" ' +
                    'data-filter-op="' + encodeURI(fields[2]) + '" ' +
                    'data-filter-value="' + encodeURI(unescapeMPD(fields[3])) + '" class="btn btn-light mr-2">' + e(expression) + '<span class="badge badge-secondary">&times</span></button>';
            }
            crumbEl.innerHTML = crumbs;
            if (searchEl.value === '' && elements.length >= 1) {
                let lastEl = elements[elements.length - 1].substring(1, elements[elements.length - 1].length - 1);
                let lastElValue = lastEl.substring(lastEl.indexOf('\'') + 1, lastEl.length - 1);
                if (searchEl.value !== lastElValue) {
                    let fields = lastEl.match(/^(\w+)\s+(\S+)\s+'(.*)'$/);
                    crumbEl.innerHTML += '<button data-filter-tag="' + encodeURI(fields[1]) + '" ' +
                        'data-filter-op="' + encodeURI(fields[2]) + '" ' +
                        'data-filter-value="' + encodeURI(unescapeMPD(fields[3])) + '" class="btn btn-light mr-2">' + e(lastEl) + '<span class="badge badge-secondary">&times</span></button>';
                }
                document.getElementById('searchDatabaseMatch').value = 'contains';
            }
            crumbEl.classList.remove('hide');
            document.getElementById('searchDatabaseMatch').classList.remove('hide');
            document.getElementById('btnDatabaseSortDropdown').removeAttribute('disabled');
            document.getElementById('btnDatabaseSearchDropdown').removeAttribute('disabled');
            sendAPI("MPD_API_DATABASE_GET_ALBUMS", {"offset": app.current.offset, "limit": app.current.limit, "searchstr": app.current.search, 
                "filter": app.current.filter, "sort": sort, "sortdesc": sortdesc}, parseDatabase);
        }
        else {
            document.getElementById('searchDatabaseCrumb').classList.add('hide');
            document.getElementById('searchDatabaseMatch').classList.add('hide');
            document.getElementById('btnDatabaseSortDropdown').setAttribute('disabled', 'disabled');
            document.getElementById('btnDatabaseSearchDropdown').setAttribute('disabled', 'disabled');
            document.getElementById('searchDatabaseStr').value = app.current.search;
            sendAPI("MPD_API_DATABASE_TAG_LIST", {"offset": app.current.offset, "limit": app.current.limit, "searchstr": app.current.search, 
                "filter": app.current.filter, "sort": sort, "sortdesc": sortdesc, "tag": app.current.tag}, parseDatabase);
        }
    }
    else if ((app.current.app === 'Browse' || app.current.app === 'Playback') && app.current.tab === 'Database' && app.current.view === 'Detail') {
        if (app.current.app === 'Playback') {
            sendAPI("MPD_API_PLAYER_CURRENT_SONG", {}, songChange);
        }
        document.getElementById('viewListDatabase').classList.add('hide');
        document.getElementById('viewDetailDatabase').classList.remove('hide');
        if (app.current.filter === 'Album') {
            let cols = settings.colsBrowseDatabaseDetail.slice();
            if (cols.includes('Disc') === false) {
                cols.push('Disc');
            }
            sendAPI("MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", {"album": app.current.tag,
                "searchstr": app.current.search,
                "tag": app.current.sort, "cols": cols}, parseAlbumDetails);
        }    
    }
    else if (app.current.app === 'Search') {
        domCache.searchstr.focus();
        if (settings.featAdvsearch) {
            let crumbs = '';
            let elements = app.current.search.substring(1, app.current.search.length - 1).split(' AND ');
            for (let i = 0; i < elements.length - 1 ; i++) {
                let expression = elements[i].substring(1, elements[i].length - 1);
                let fields = expression.match(/^(\w+)\s+(\S+)\s+'(.*)'$/);
                crumbs += '<button data-filter-tag="' + encodeURI(fields[1]) + '" ' +
                    'data-filter-op="' + encodeURI(fields[2]) + '" ' +
                    'data-filter-value="' + encodeURI(unescapeMPD(fields[3])) + '" class="btn btn-light mr-2">' + e(expression) + '<span class="badge badge-secondary">&times</span></button>';
            }
            domCache.searchCrumb.innerHTML = crumbs;
            if (domCache.searchstr.value === '' && elements.length >= 1) {
                let lastEl = elements[elements.length - 1].substring(1,  elements[elements.length - 1].length - 1);
                let lastElValue = lastEl.substring(lastEl.indexOf('\'') + 1, lastEl.length - 1);
                if (domCache.searchstr.value !== lastElValue) {
                    let fields = lastEl.match(/^(\w+)\s+(\S+)\s+'(.*)'$/);
                    domCache.searchCrumb.innerHTML += '<button data-filter-tag="' + encodeURI(fields[1]) + '" ' +
                        'data-filter-op="' + encodeURI(fields[2]) + '" ' +
                        'data-filter-value="' + encodeURI(unescapeMPD(fields[3])) + '" class="btn btn-light mr-2">' + e(lastEl) + '<span class="badge badge-secondary">&times</span></button>';
                }
                let match = lastEl.substring(lastEl.indexOf(' ') + 1);
                match = match.substring(0, match.indexOf(' '));
                if (match === '') {
                    match = 'contains';
                }
                document.getElementById('searchMatch').value = match;
            }
        }
        else {
            if (domCache.searchstr.value === '' && app.current.search !== '') {
                domCache.searchstr.value = app.current.search;
            }
        }
        if (app.last.app !== app.current.app) {
            if (app.current.search !== '') {
                let colspan = settings['cols' + app.current.app].length;
                document.getElementById('SearchList').getElementsByTagName('tbody')[0].innerHTML=
                    '<tr><td><span class="material-icons">search</span></td>' +
                    '<td colspan="' + colspan + '">' + t('Searching...') + '</td></tr>';
            }
        }

        if (domCache.searchstr.value.length >= 2 || domCache.searchCrumb.children.length > 0) {
            if (settings.featAdvsearch) {
                let sort = app.current.sort;
                let sortdesc = false;
                if (sort === '-') {
                    if (settings.tags.includes('Title')) {
                        sort = 'Title';
                    }
                    else {
                        sort = '-';
                    }
                    document.getElementById('SearchList').setAttribute('data-sort', sort);
                }
                else {
                    if (sort.indexOf('-') === 0) {
                        sortdesc = true;
                        sort = sort.substring(1);
                    }
                }
                sendAPI("MPD_API_DATABASE_SEARCH_ADV", {"plist": "", "offset": app.current.offset, "limit": app.current.limit, "sort": sort, "sortdesc": sortdesc, "expression": app.current.search, "cols": settings.colsSearch, "replace": false}, parseSearch);
            }
            else {
                sendAPI("MPD_API_DATABASE_SEARCH", {"plist": "", "offset": app.current.offset, "limit": app.current.limit, "filter": app.current.filter, "searchstr": app.current.search, "cols": settings.colsSearch, "replace": false}, parseSearch);
            }
        }
        else {
            document.getElementById('SearchList').getElementsByTagName('tbody')[0].innerHTML = '';
            document.getElementById('searchAddAllSongs').setAttribute('disabled', 'disabled');
            document.getElementById('searchAddAllSongsBtn').setAttribute('disabled', 'disabled');
            document.getElementById('SearchList').classList.remove('opacity05');
            setPagination(0, 0);
        }
        selectTag('searchtags', 'searchtagsdesc', app.current.filter);
    }
    else {
        appGoto("Home");
    }

    app.last.app = app.current.app;
    app.last.tab = app.current.tab;
    app.last.view = app.current.view;
}

function showAppInitAlert(text) {
    document.getElementById('splashScreenAlert').innerHTML = '<p class="text-danger">' + t(text) + '</p>' +
        '<p><a id="appReloadBtn" class="btn btn-danger text-light clickable">' + t('Reload') + '</a></p>';
    document.getElementById('appReloadBtn').addEventListener('click', function() {
        clearAndReload();
    }, false);
}


function clearAndReload() {
    if ('serviceWorker' in navigator) {
        caches.keys().then(function(cacheNames) {
            cacheNames.forEach(function(cacheName) {
                caches.delete(cacheName);
            });
        });
    }
    location.reload();
}

function a2hsInit() {
    window.addEventListener('beforeinstallprompt', function(event) {
        logDebug('Event: beforeinstallprompt');
        // Prevent Chrome 67 and earlier from automatically showing the prompt
        event.preventDefault();
        // Stash the event so it can be triggered later
        deferredA2HSprompt = event;
        // Update UI notify the user they can add to home screen
        domCache.btnA2HS.classList.remove('hide');
    });

    domCache.btnA2HS.addEventListener('click', function() {
        // Hide our user interface that shows our A2HS button
        domCache.btnA2HS.classList.add('hide');
        // Show the prompt
        deferredA2HSprompt.prompt();
        // Wait for the user to respond to the prompt
        deferredA2HSprompt.userChoice.then((choiceResult) => {
            choiceResult.outcome === 'accepted' ? logDebug('User accepted the A2HS prompt') : logDebug('User dismissed the A2HS prompt');
            deferredA2HSprompt = null;
        });
    });
    
    window.addEventListener('appinstalled', function() {
        logInfo('myMPD installed as app');
        showNotification(t('myMPD installed as app'), '', '', 'success');
    });
}

function appInitStart() {
    //add app routing event handler
    window.addEventListener('hashchange', appRoute, false);

    //set initial scale
    if (isMobile === true) {
        scale = localStorage.getItem('scale-ratio');
        if (scale === null) {
            scale = '1.0';
        }
        setViewport(false);
    }
    else {
        let m = document.getElementsByClassName('featMobile');
        for (let i = 0; i < m.length; i++) {
            m[i].classList.add('hide');
        }        
    }

    subdir = window.location.pathname.replace('/index.html', '').replace(/\/$/, '');
    let localeList = '<option value="default" data-phrase="Browser default"></option>';
    for (let i = 0; i < locales.length; i++) {
        localeList += '<option value="' + e(locales[i].code) + '">' + e(locales[i].desc) + ' (' + e(locales[i].code) + ')</option>';
    }
    document.getElementById('selectLocale').innerHTML = localeList;
    
    i18nHtml(document.getElementById('splashScreenAlert'));
    
    //set loglevel
    let script = document.getElementsByTagName("script")[0].src.replace(/^.*[/]/, '');
    if (script !== 'combined.js') {
        settings.loglevel = 4;
    }
    //register serviceworker
    if ('serviceWorker' in navigator && window.location.protocol === 'https:' 
        && window.location.hostname !== 'localhost' && script === 'combined.js')
    {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('/sw.js', {scope: '/'}).then(function(registration) {
                // Registration was successful
                logInfo('ServiceWorker registration successful.');
                registration.update();
            }, function(err) {
                // Registration failed
                logError('ServiceWorker registration failed: ' + err);
            });
        });
    }

    appInited = false;
    document.getElementById('splashScreen').classList.remove('hide');
    document.getElementsByTagName('body')[0].classList.add('overflow-hidden');
    document.getElementById('splashScreenAlert').innerText = t('Fetch myMPD settings');

    a2hsInit();

    getSettings(true);
    appInitWait();
}

function appInitWait() {
    setTimeout(function() {
        if (settingsParsed === 'true' && websocketConnected === true) {
            //app initialized
            document.getElementById('splashScreenAlert').innerText = t('Applying settings');
            document.getElementById('splashScreen').classList.add('hide-fade');
            setTimeout(function() {
                document.getElementById('splashScreen').classList.add('hide');
                document.getElementById('splashScreen').classList.remove('hide-fade');
                document.getElementsByTagName('body')[0].classList.remove('overflow-hidden');
            }, 500);
            appInit();
            appInited = true;
            return;
        }
        
        if (settingsParsed === 'true') {
            //parsed settings, now its save to connect to websocket
            document.getElementById('splashScreenAlert').innerText = t('Connect to websocket');
            webSocketConnect();
        }
        else if (settingsParsed === 'error') {
            return;
        }
        appInitWait();
    }, 500);
}

function appInit() {
    document.getElementById('mainMenu').addEventListener('click', function(event) {
        event.preventDefault();
    }, false);

    document.getElementById('btnChVolumeDown').addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);
    document.getElementById('btnChVolumeUp').addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);

    domCache.volumeBar.addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);
    domCache.volumeBar.addEventListener('change', function() {
        sendAPI("MPD_API_PLAYER_VOLUME_SET", {"volume": domCache.volumeBar.value});
    }, false);

    domCache.progress.addEventListener('click', function(event) {
        if (currentSong && currentSong.currentSongId >= 0 && currentSong.totalTime > 0) {
            domCache.progressBar.style.transition = 'none';
            domCache.progressBar.style.width = event.clientX + 'px';
            setTimeout(function() {
                domCache.progressBar.style.transition = progressBarTransition;
            }, 10)
            const seekVal = Math.ceil((currentSong.totalTime * event.clientX) / event.target.offsetWidth);
            sendAPI("MPD_API_PLAYER_SEEK", {"songid": currentSong.currentSongId, "seek": seekVal});
        }
    }, false);
    domCache.progress.addEventListener('mousemove', function(event) {
        if ((playstate === 'pause' || playstate === 'play') && currentSong.totalTime > 0) {
            domCache.progressPos.innerText = beautifySongDuration(Math.ceil((currentSong.totalTime / event.target.offsetWidth) * event.clientX));
            domCache.progressPos.style.display = 'block';
            const w = domCache.progressPos.offsetWidth / 2;
            const posX = event.clientX < w ? event.clientX : (event.clientX < window.innerWidth - w ? event.clientX - w : event.clientX - (w * 2));
            domCache.progressPos.style.left = posX + 'px';
        }
    }, false);
    domCache.progress.addEventListener('mouseout', function() {
        domCache.progressPos.style.display = 'none';
    }, false);

    let collapseArrows = document.querySelectorAll('.subMenu');
    let collapseArrowsLen = collapseArrows.length;
    for (let i = 0; i < collapseArrowsLen; i++) {
        collapseArrows[i].addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            let icon = this.getElementsByTagName('span')[0];
            icon.innerText = icon.innerText === 'keyboard_arrow_right' ? 'keyboard_arrow_down' : 'keyboard_arrow_right';
        }, false);
    }    

    document.getElementById('navbar-main').addEventListener('click', function(event) {
        event.preventDefault();
        let href = event.target.getAttribute('data-href');
        if (href === null) {
            href = event.target.parentNode.getAttribute('data-href');
        }
        if (href !== null) {
            parseCmd(event, href);
        }
    }, false);
    
    document.getElementById('volumeMenu').parentNode.addEventListener('show.bs.dropdown', function () {
        sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {}, parseOutputs);
    });
    
    document.getElementById('btnDropdownNeighbors').parentNode.addEventListener('show.bs.dropdown', function () {
        if (settings.featNeighbors === true) {
            sendAPI("MPD_API_MOUNT_NEIGHBOR_LIST", {}, parseNeighbors, true);
        }
        else {
            document.getElementById('dropdownNeighbors').children[0].innerHTML = 
                '<div class="list-group-item"><span class="material-icons">warning</span> ' + t('Neighbors are disabled') + '</div>';
        }
    });
    
    document.getElementById('dropdownNeighbors').children[0].addEventListener('click', function (event) {
        event.preventDefault();
        if (event.target.nodeName === 'A') {
            let c = event.target.getAttribute('data-value').match(/^(\w+:\/\/)(.+)$/);
            document.getElementById('selectMountUrlhandler').value = c[1];
            document.getElementById('inputMountUrl').value = c[2];
        }
    });
    
    document.getElementById('BrowseFilesystemBookmark').parentNode.addEventListener('show.bs.dropdown', function () {
        sendAPI("MYMPD_API_BOOKMARK_LIST", {"offset": 0, "limit": 0}, parseBookmarks);
    });
    
    document.getElementById('playDropdown').parentNode.addEventListener('show.bs.dropdown', function () {
        showPlayDropdown();
    });

    document.getElementById('playDropdown').addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
    });
    
    let dropdowns = document.querySelectorAll('.dropdown-toggle');
    for (let i = 0; i < dropdowns.length; i++) {
        dropdowns[i].parentNode.addEventListener('show.bs.dropdown', function () {
            alignDropdown(this);
        });
    }
    
    document.getElementById('modalTimer').addEventListener('shown.bs.modal', function () {
        showListTimer();
    });

    document.getElementById('modalMounts').addEventListener('shown.bs.modal', function () {
        showListMounts();
    });
    
    document.getElementById('modalScripts').addEventListener('shown.bs.modal', function () {
        showListScripts();
    });
    
    document.getElementById('modalTrigger').addEventListener('shown.bs.modal', function () {
        showListTrigger();
    });
    
    document.getElementById('modalPartitions').addEventListener('shown.bs.modal', function () {
        showListPartitions();
    });
    
    document.getElementById('modalPartitionOutputs').addEventListener('shown.bs.modal', function () {
        sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {"partition": "default"}, parsePartitionOutputsList, false);
    });
    
    document.getElementById('modalAbout').addEventListener('shown.bs.modal', function () {
        sendAPI("MPD_API_DATABASE_STATS", {}, parseStats);
        getServerinfo();
        let trs = '';
        for (let key in keymap) {
            if (keymap[key].req === undefined || settings[keymap[key].req] === true) {
                trs += '<tr><td><div class="key' + (keymap[key].key && keymap[key].key.length > 1 ? ' material-icons material-icons-small' : '') + 
                       '">' + (keymap[key].key !== undefined ? keymap[key].key : key ) + '</div></td><td>' + t(keymap[key].desc) + '</td></tr>';
            }
        }
        document.getElementById('tbodyShortcuts').innerHTML = trs;
    });
    
    document.getElementById('modalAddToPlaylist').addEventListener('shown.bs.modal', function () {
        if (!document.getElementById('addStreamFrm').classList.contains('hide')) {
            document.getElementById('streamUrl').focus();
            document.getElementById('streamUrl').value = '';
        }
        else {
            document.getElementById('addToPlaylistPlaylist').focus();
        }
    });
    
    document.getElementById('inputTimerVolume').addEventListener('change', function() {
        document.getElementById('textTimerVolume').innerHTML = this.value + '&nbsp;%';
    }, false);
    
    document.getElementById('selectTimerAction').addEventListener('change', function() {
        selectTimerActionChange();
    }, false);
    
    document.getElementById('selectTriggerScript').addEventListener('change', function() {
        selectTriggerActionChange();
    }, false);
    
    let selectTimerHour = ''; 
    for (let i = 0; i < 24; i++) {
        selectTimerHour += '<option value="' + i + '">' + zeroPad(i, 2) + '</option>';
    }
    document.getElementById('selectTimerHour').innerHTML = selectTimerHour;
    
    let selectTimerMinute = ''; 
    for (let i = 0; i < 60; i = i + 5) {
        selectTimerMinute += '<option value="' + i + '">' + zeroPad(i, 2) + '</option>';
    }
    document.getElementById('selectTimerMinute').innerHTML = selectTimerMinute;
    
    document.getElementById('selectTheme').addEventListener('change', function() {
        const value = getSelectValue(this);
        if (value === 'theme-default') { 
            document.getElementById('inputBgColor').value = '#ccc';
        }
        else if (value === 'theme-light') {
            document.getElementById('inputBgColor').value = '#fff';
        }
        else if (value === 'theme-dark') {
            document.getElementById('inputBgColor').value = '#000';
        }
        document.getElementById('bgColorPreview').style.backgroundColor = document.getElementById('inputBgColor').value;
    }, false);
    
    document.getElementById('modalAddToQueue').addEventListener('shown.bs.modal', function () {
        document.getElementById('inputAddToQueueQuantity').classList.remove('is-invalid');
        document.getElementById('warnJukeboxPlaylist2').classList.add('hide');
        if (settings.featPlaylists === true) {
            sendAPI("MPD_API_PLAYLIST_LIST", {"searchstr": "", "offset": 0, "limit": 0}, function(obj) { 
                getAllPlaylists(obj, 'selectAddToQueuePlaylist');
            });
        }
    });

    document.getElementById('modalUpdateDB').addEventListener('hidden.bs.modal', function () {
        document.getElementById('updateDBprogress').classList.remove('updateDBprogressAnimate');
    });
    
    document.getElementById('modalSaveQueue').addEventListener('shown.bs.modal', function () {
        let plName = document.getElementById('saveQueueName');
        plName.focus();
        plName.value = '';
        plName.classList.remove('is-invalid');
    });
        
    document.getElementById('modalSettings').addEventListener('shown.bs.modal', function () {
        getSettings();
        document.getElementById('inputCrossfade').classList.remove('is-invalid');
        document.getElementById('inputMixrampdb').classList.remove('is-invalid');
        document.getElementById('inputMixrampdelay').classList.remove('is-invalid');
        document.getElementById('inputScaleRatio').classList.remove('is-invalid');
    });

    document.getElementById('modalCollybia').addEventListener('shown.bs.modal', function () {
        this.focus();
        getSettings();
        document.getElementById('inputNsServer').classList.remove('is-invalid');
        document.getElementById('inputNsShare').classList.remove('is-invalid');
        document.getElementById('inputNsUsername').classList.remove('is-invalid');
        document.getElementById('inputNsPassword').classList.remove('is-invalid');
    });

    document.getElementById('modalCollybia').addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
            saveIdeonSettings();
            event.stopPropagation();
            event.preventDefault();
        }
    });

    document.getElementById('selectNsType').addEventListener('change', function () {
        let value = this.options[this.selectedIndex].value;
        if (value === '0') {
            document.getElementById('nsServerShare').classList.add('hide');
            document.getElementById('sambaVersion').classList.add('hide');
            document.getElementById('nsCredentials').classList.add('hide');
            document.getElementById('inputNsServer').value = '';
            document.getElementById('inputNsShare').value = '';
            document.getElementById('inputNsUsername').value = '';
            document.getElementById('inputNsPassword').value = '';
        }
        else if (value === '2') {
            document.getElementById('nsServerShare').classList.remove('hide');
            document.getElementById('sambaVersion').classList.remove('hide');
            document.getElementById('nsCredentials').classList.remove('hide');
        }
        else {
            document.getElementById('nsServerShare').classList.remove('hide');
            if (value === '1') {
                document.getElementById('sambaVersion').classList.remove('hide');
            }
            else {
                document.getElementById('sambaVersion').classList.add('hide');
            }
            document.getElementById('nsCredentials').classList.add('hide');
            document.getElementById('inputNsUsername').value = '';
            document.getElementById('inputNsPassword').value = '';
        }
    });

    document.getElementById('modalConnection').addEventListener('shown.bs.modal', function () {
        getSettings();
        document.getElementById('inputMpdHost').classList.remove('is-invalid');
        document.getElementById('inputMpdPort').classList.remove('is-invalid');
        document.getElementById('inputMpdPass').classList.remove('is-invalid');
    });

    document.getElementById('btnJukeboxModeGroup').addEventListener('mouseup', function () {
        setTimeout(function() {
            let value = document.getElementById('btnJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');
            if (value === '0') {
                document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
            }
            else if (value === '2') {
                document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').value = 'Database';
            }
            else if (value === '1') {
                document.getElementById('inputJukeboxQueueLength').removeAttribute('disabled');
                document.getElementById('selectJukeboxPlaylist').removeAttribute('disabled');
            }
            if (value !== '0') {
                toggleBtnChk('btnConsume', true);            
            }
            checkConsume();
        }, 100);
    });
    
    document.getElementById('btnConsume').addEventListener('mouseup', function() {
        setTimeout(function() { 
            checkConsume(); 
        }, 100);
    });
    
    document.getElementById('btnStickers').addEventListener('mouseup', function() {
        setTimeout(function() {
            if (document.getElementById('btnStickers').classList.contains('active')) {
                document.getElementById('warnPlaybackStatistics').classList.add('hide');
                document.getElementById('inputJukeboxLastPlayed').removeAttribute('disabled');
            }
            else {
                document.getElementById('warnPlaybackStatistics').classList.remove('hide');
                document.getElementById('inputJukeboxLastPlayed').setAttribute('disabled', 'disabled');
            }
        }, 100);
    });
    
    document.getElementById('selectAddToQueueMode').addEventListener('change', function () {
        let value = this.options[this.selectedIndex].value;
        if (value === '2') {
            document.getElementById('inputAddToQueueQuantity').setAttribute('disabled', 'disabled');
            document.getElementById('inputAddToQueueQuantity').value = '1';
            document.getElementById('selectAddToQueuePlaylist').setAttribute('disabled', 'disabled');
            document.getElementById('selectAddToQueuePlaylist').value = 'Database';
        }
        else if (value === '1') {
            document.getElementById('inputAddToQueueQuantity').removeAttribute('disabled');
            document.getElementById('selectAddToQueuePlaylist').removeAttribute('disabled');
        }
    });

    document.getElementById('addToPlaylistPlaylist').addEventListener('change', function () {
        if (this.options[this.selectedIndex].value === 'new') {
            document.getElementById('addToPlaylistNewPlaylistDiv').classList.remove('hide');
            document.getElementById('addToPlaylistNewPlaylist').focus();
        }
        else {
            document.getElementById('addToPlaylistNewPlaylistDiv').classList.add('hide');
        }
    }, false);
    
    document.getElementById('selectMusicDirectory').addEventListener('change', function () {
        if (this.options[this.selectedIndex].value === 'auto') {
            document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue;
            document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
        }
        else if (this.options[this.selectedIndex].value === 'none') {
            document.getElementById('inputMusicDirectory').value = '';
            document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
        }
        else {
            document.getElementById('inputMusicDirectory').value = '';
            document.getElementById('inputMusicDirectory').removeAttribute('readonly');
        }
    }, false);
    
    document.getElementById('syscmds').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            parseCmd(event, event.target.getAttribute('data-href'));
        }
    }, false);
    
    document.getElementById('scripts').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            execScript(event.target.getAttribute('data-href'));
        }
    }, false);

    let hrefs = document.querySelectorAll('[data-href]');
    let hrefsLen = hrefs.length;
    for (let i = 0; i < hrefsLen; i++) {
        if (hrefs[i].classList.contains('notclickable') === false) {
            hrefs[i].classList.add('clickable');
        }
        let parentInit = hrefs[i].parentNode.classList.contains('noInitChilds') ? true : false;
        if (parentInit === false) {
            parentInit = hrefs[i].parentNode.parentNode.classList.contains('noInitChilds') ? true : false;
        }
        if (parentInit === true) {
            //handler on parentnode
            continue;
        }
        hrefs[i].addEventListener('click', function(event) {
            parseCmd(event, this.getAttribute('data-href'));
        }, false);
    }
    
    document.getElementById('HomeCards').addEventListener('click', function(event) {
        if (event.target.classList.contains('card-body')) {
            const href = event.target.parentNode.getAttribute('data-href');
            if (href !== null) {
               parseCmd(event, href);
            }
        }
        else if (event.target.classList.contains('card-footer')){
            let sels = document.getElementById('HomeCards').getElementsByClassName('selected');
            for (let i = 0; i < sels.length; i++) {
                sels[i].classList.remove('selected');
            }
            event.target.parentNode.classList.add('selected');
            showMenu(event.target, event);
            event.stopPropagation();
        }
    }, false);
    
    document.getElementById('HomeCards').addEventListener('keydown', function(event) {
        navigateGrid(event.target, event.key);
    }, false);
    
    dragAndDropHome();
    
    document.getElementById('selectHomeIconCmd').addEventListener('change', function() {
        showHomeIconCmdOptions();
    }, false);

    document.getElementById('inputHomeIconLigature').addEventListener('change', function(event) {
        document.getElementById('homeIconPreview').innerText = event.target.value;
        if (event.target.value !== '') {
            document.getElementById('selectHomeIconImage').value = '';
            document.getElementById('homeIconPreview').style.backgroundImage = '';
        }
    }, false);
    
    document.getElementById('inputHomeIconBgcolor').addEventListener('change', function(event) {
        document.getElementById('homeIconPreview').style.backgroundColor = event.target.value;
    }, false);
    
    document.getElementById('selectHomeIconImage').addEventListener('change', function(event) {
        const value = getSelectValue(event.target);
        document.getElementById('homeIconPreview').style.backgroundImage = 'url("' + subdir + '/browse/pics/' + value  + '")';
        if (value !== '') {
            document.getElementById('divHomeIconLigature').classList.add('hide');
            document.getElementById('homeIconPreview').innerHTML = '';
        }
        else {
            document.getElementById('divHomeIconLigature').classList.remove('hide');
            document.getElementById('homeIconPreview').innerText = document.getElementById('inputHomeIconLigature').value;
        }
    }, false);

    document.getElementById('HomeCards').addEventListener('click', function(event) {
        if (event.target.classList.contains('card-body')) {
            const href = event.target.parentNode.getAttribute('data-href');
            if (href !== null) {
               parseCmd(event, href);
            }
        }
        else if (event.target.classList.contains('card-footer')){
            let sels = document.getElementById('HomeCards').getElementsByClassName('selected');
            for (let i = 0; i < sels.length; i++) {
                sels[i].classList.remove('selected');
            }
            event.target.parentNode.classList.add('selected');
            showMenu(event.target, event);
            event.stopPropagation();
        }
    }, false);
    
    document.getElementById('HomeCards').addEventListener('keydown', function(event) {
        navigateGrid(event.target, event.key);
    }, false);
    
    dragAndDropHome();
    
    document.getElementById('selectHomeIconCmd').addEventListener('change', function() {
        showHomeIconCmdOptions();
    }, false);

    document.getElementById('inputHomeIconLigature').addEventListener('change', function(event) {
        document.getElementById('homeIconPreview').innerText = event.target.value;
        if (event.target.value !== '') {
            document.getElementById('selectHomeIconImage').value = '';
            document.getElementById('homeIconPreview').style.backgroundImage = '';
        }
    }, false);
    
    document.getElementById('inputHomeIconBgcolor').addEventListener('change', function(event) {
        document.getElementById('homeIconPreview').style.backgroundColor = event.target.value;
    }, false);
    
    document.getElementById('selectHomeIconImage').addEventListener('change', function(event) {
        const value = getSelectValue(event.target);
        document.getElementById('homeIconPreview').style.backgroundImage = 'url("' + subdir + '/browse/pics/' + value  + '")';
        if (value !== '') {
            document.getElementById('divHomeIconLigature').classList.add('hide');
            document.getElementById('homeIconPreview').innerHTML = '';
        }
        else {
            document.getElementById('divHomeIconLigature').classList.remove('hide');
            document.getElementById('homeIconPreview').innerText = document.getElementById('inputHomeIconLigature').value;
        }
    }, false);

    let pd = document.getElementsByClassName('pages');
    let pdLen = pd.length;
    for (let i = 0; i < pdLen; i++) {
        pd[i].addEventListener('click', function (event) {
            if (event.target.nodeName === 'BUTTON') {
                gotoPage(event.target.getAttribute('data-page'));
            }
        }, false);
    }

    document.getElementById('cardPlaybackTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'P') {
            gotoBrowse();
        }
    }, false);

    document.getElementById('BrowseBreadcrumb').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            event.preventDefault();
            appGoto('Browse', 'Filesystem', undefined, '0', app.current.limit, app.current.filter, app.current.sort, '-', decodeURI(event.target.getAttribute('data-uri')));
        }
    }, false);
    
    document.getElementById('tbodySongDetails').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            if (event.target.id === 'calcFingerprint') {
                sendAPI("MPD_API_DATABASE_FINGERPRINT", {"uri": decodeURI(event.target.getAttribute('data-uri'))}, parseFingerprint);
                event.preventDefault();
                let parent = event.target.parentNode;
                let spinner = document.createElement('div');
                spinner.classList.add('spinner-border', 'spinner-border-sm');
                event.target.classList.add('hide');
                parent.appendChild(spinner);
            }
            else if (event.target.classList.contains('external')) {
                //do nothing, link opens in new browser window
            }
            else if (event.target.parentNode.getAttribute('data-tag') !== null) {
                modalSongDetails.hide();
                event.preventDefault();
                gotoBrowse();
            } 
        }
        else if (event.target.nodeName === 'BUTTON') { 
            if (event.target.getAttribute('data-href')) {
                parseCmd(event, event.target.getAttribute('data-href'));
            }
        }
    }, false);

    document.getElementById('outputs').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.stopPropagation();
            event.preventDefault();
            sendAPI("MPD_API_PLAYER_TOGGLE_OUTPUT", {"output": event.target.getAttribute('data-output-id'), "state": (event.target.classList.contains('active') ? 0 : 1)});
            toggleBtn(event.target.id);
        }
        else if (event.target.nodeName === 'A') {
            event.preventDefault();
            showListOutputAttributes(decodeURI(event.target.parentNode.getAttribute('data-output-name')));
        }
    }, false);
    
    document.getElementById('listTimerList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            if (!event.target.parentNode.classList.contains('not-clickable')) {
                showEditTimer(event.target.parentNode.getAttribute('data-id'));
            }
        }
        else if (event.target.nodeName === 'A') {
            deleteTimer(event.target.parentNode.parentNode.getAttribute('data-id'));
        }
        else if (event.target.nodeName === 'BUTTON') {
            toggleTimer(event.target, event.target.parentNode.parentNode.getAttribute('data-id'));
        }
    }, false);

    document.getElementById('listMountsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            if (event.target.parentNode.getAttribute('data-point') === '') {
                return false;
            }
            showEditMount(decodeURI(event.target.parentNode.getAttribute('data-url')),decodeURI(event.target.parentNode.getAttribute('data-point')));
        }
        else if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let mountPoint = decodeURI(event.target.parentNode.parentNode.getAttribute('data-point'));
            if (action === 'unmount') {
                unmountMount(mountPoint);
            }
            else if (action === 'update') {
                updateMount(event.target, mountPoint);
            }
        }
    }, false);
    
    document.getElementById('listScriptsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            if (settings.featScripteditor === false || event.target.parentNode.getAttribute('data-script') === '') {
                return false;
            }
            showEditScript(decodeURI(event.target.parentNode.getAttribute('data-script')));
        }
        else if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let script = decodeURI(event.target.parentNode.parentNode.getAttribute('data-script'));
            if (action === 'delete') {
                deleteScript(script);
            }
            else if (action === 'execute') {
                execScript(event.target.getAttribute('data-href'));
            }
            else if (action === 'add2home') {
                addScriptToHome(script, event.target.getAttribute('data-href'))
            }
        }
    }, false);
    
    document.getElementById('listTriggerList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            let id = decodeURI(event.target.parentNode.getAttribute('data-trigger-id'));
            showEditTrigger(id);
        }
        else if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let id = decodeURI(event.target.parentNode.parentNode.getAttribute('data-trigger-id'));
            if (action === 'delete') {
                deleteTrigger(id);
            }
        }
    }, false);
    
    document.getElementById('listPartitionsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let partition = decodeURI(event.target.parentNode.parentNode.getAttribute('data-partition'));
            if (action === 'delete') {
                deletePartition(partition);
            }
            else if (action === 'switch') {
                switchPartition(partition);
            }
        }
    }, false);
    
    document.getElementById('partitionOutputsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            let outputName = decodeURI(event.target.parentNode.getAttribute('data-output'));
            moveOutput(outputName);
            modalPartitionOutputs.hide();
        }
    }, false);
    
    document.getElementById('QueueCurrentList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            sendAPI("MPD_API_PLAYER_PLAY_TRACK", {"track": event.target.parentNode.getAttribute('data-trackid')});
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);
    
    document.getElementById('QueueLastPlayedList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('QueueJukeboxList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);
	
    document.getElementById('QueueMiniList').addEventListener('click', function (event) {
        if (event.target.nodeName === 'TD') {
            sendAPI("MPD_API_PLAYER_PLAY_TRACK", { "track": event.target.parentNode.getAttribute('data-trackid') });
        }
        //wip add menu for a
    }, false);

    document.getElementById('BrowseFilesystemList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            switch(event.target.parentNode.getAttribute('data-type')) {
                case 'parentDir':
                case 'dir':
                    app.current.filter = '-';
                    appGoto('Browse', 'Filesystem', undefined, '0', app.current.limit, app.current.filter, app.current.sort, '-', decodeURI(event.target.parentNode.getAttribute("data-uri")));
                    break;
                case 'song':
                    appendQueue('song', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
                    break;
                case 'plist':
                    appendQueue('plist', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
                    break;
            }
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseFilesystemBookmarks').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            let id = event.target.parentNode.parentNode.getAttribute('data-id');
            let type = event.target.parentNode.parentNode.getAttribute('data-type');
            let uri = decodeURI(event.target.parentNode.parentNode.getAttribute('data-uri'));
            let name = event.target.parentNode.parentNode.firstChild.innerText;
            let href = event.target.getAttribute('data-href');
            
            if (href === 'delete') {
                sendAPI("MYMPD_API_BOOKMARK_RM", {"id": id}, function() {
                    sendAPI("MYMPD_API_BOOKMARK_LIST", {"offset": 0, "limit": 0}, parseBookmarks);
                });
                event.preventDefault();
                event.stopPropagation();
            }
            else if (href === 'edit') {
                showBookmarkSave(id, name, uri, type);
            }
            else if (href === 'goto') {
                appGoto('Browse', 'Filesystem', undefined, '0', undefined, '-','-','-', uri);
            }
        }
    }, false);

    document.getElementById('BrowsePlaylistsAllList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('plist', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowsePlaylistsDetailList').addEventListener('click', function(event) {
        if (event.target.parentNode.parentNode.nodeName === 'TFOOT') {
            return;
        }
        if (event.target.nodeName === 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);    
    
    document.getElementById('SearchList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseDatabaseCards').addEventListener('click', function(event) {
        if (app.current.tag === 'Album') {
            if (event.target.classList.contains('card-body')) {
                appGoto('Browse', 'Database', 'Detail', 0, undefined, 'Album', 'AlbumArtist', 
                    decodeURI(event.target.parentNode.getAttribute('data-album')), 
                    decodeURI(event.target.parentNode.getAttribute('data-albumartist')));
            }
            else if (event.target.classList.contains('card-footer')){
                showMenu(event.target, event);
                const selCards = document.getElementById('BrowseDatabaseCards').getElementsByClassName('selected');
                for (let i = 0; i < selCards.length; i++) {
                    selCards[i].classList.remove('selected');
                }
                event.target.parentNode.classList.add('selected');
            }
        }
        else {
            app.current.search = '';
            document.getElementById('searchDatabaseStr').value = '';
            appGoto(app.current.app, app.current.card, undefined, 0, undefined, 'Album', 'AlbumArtist', 'Album', 
                '(' + app.current.tag + ' == \'' + decodeURI(event.target.parentNode.getAttribute('data-tag')) + '\')');
        }
    }, false);
    
    document.getElementById('BrowseDatabaseCards').addEventListener('keydown', function(event) {
        navigateGrid(event.target, event.key);
    }, false);
    
    if (isMobile === false) {
        document.getElementById('BrowseDatabaseCards').addEventListener('mouseover', function(event) {
            if (event.target.classList.contains('card-body') && event.target.childNodes.length === 0) {
                const oldEls = document.getElementById('BrowseDatabaseCards').getElementsByClassName('album-grid-mouseover');
                if (oldEls.length > 1) {
                    for (let i = 0; i < oldEls.length; i++) {
                        oldEls[i].remove();
                    }
                }
                addPlayButton(event.target);
            }
        }, false);

        document.getElementById('BrowseDatabaseCards').addEventListener('mouseout', function(event) {
            if (event.target.classList.contains('card-body') && (event.relatedTarget === null || ! event.relatedTarget.classList.contains('album-grid-mouseover'))) {
                event.target.innerHTML = '';
            }
        }, false);
    }
    
    document.getElementById('BrowseDatabaseDetailList').addEventListener('click', function(event) {
        if (event.target.parentNode.parentNode.nodeName === 'TFOOT') {
            return;
        }
        if (event.target.nodeName === 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute('data-uri')), event.target.parentNode.getAttribute('data-name'));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseFilesystemAddAllSongsDropdown').addEventListener('click', function (event) {
        if (event.target.nodeName === 'BUTTON') {
            if (event.target.getAttribute('data-phrase') === 'Add all to queue') {
                addAllFromBrowseFilesystem();
            }
            else if (event.target.getAttribute('data-phrase') === 'Add all to playlist') {
                showAddToPlaylist(app.current.search, '');
            }
        }
    }, false);

    document.getElementById('searchAddAllSongsDropdown').addEventListener('click', function (event) {
        if (event.target.nodeName === 'BUTTON') {
            if (event.target.getAttribute('data-phrase') === 'Add all to queue') {
                addAllFromSearchPlist('queue', null, false);
            }
            else if (event.target.getAttribute('data-phrase') === 'Add all to playlist') {
                showAddToPlaylist('SEARCH', '');
            }
            else if (event.target.getAttribute('data-phrase') === 'Save as smart playlist') {
                saveSearchAsSmartPlaylist();
            }
        }
    }, false);

    document.getElementById('searchtags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            app.current.filter = event.target.getAttribute('data-tag');
            doSearch(domCache.searchstr.value);
        }
    }, false);
    
    document.getElementById('searchDatabaseTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            app.current.filter = event.target.getAttribute('data-tag');
            appGoto(app.current.app, app.current.tab, app.current.view, '0', app.current.limit, app.current.filter, app.current.sort, app.current.tag, app.current.search);
        }
    }, false);
    
    document.getElementById('databaseSortDesc').addEventListener('click', function(event) {
        toggleBtnChk(this);
        event.stopPropagation();
        event.preventDefault();
        if (app.current.sort.charAt(0) === '-') {
            app.current.sort = app.current.sort.substr(1);
        }
        else {
            app.current.sort = '-' + app.current.sort;
        }
        appGoto(app.current.app, app.current.tab, app.current.view, '0', app.current.limit, app.current.filter, app.current.sort, app.current.tag, app.current.search);
    }, false);

    document.getElementById('databaseSortTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.preventDefault();
            event.stopPropagation();
            app.current.sort = event.target.getAttribute('data-tag');
            appGoto(app.current.app, app.current.tab, app.current.view, '0', app.current.limit, app.current.filter, app.current.sort, app.current.tag, app.current.search);
        }
    }, false);

    document.getElementById('BrowseDatabaseByTagDropdown').addEventListener('click', function(event) {
        navBrowseHandler(event);
    }, false);
    document.getElementById('BrowseNavPlaylistsDropdown').addEventListener('click', function(event) {
        navBrowseHandler(event);
    }, false);
    document.getElementById('BrowseNavFilesystemDropdown').addEventListener('click', function(event) {
        navBrowseHandler(event);
    }, false);

    document.getElementById('dropdownSortPlaylistTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.preventDefault();
            playlistSort(event.target.getAttribute('data-tag'));
        }
    }, false);

    document.getElementById('searchqueuestr').addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else {
            appGoto(app.current.app, app.current.tab, app.current.view, '0', app.current.limit, app.current.filter , app.current.sort, '-', this.value);
        }
    }, false);

    document.getElementById('searchqueuetags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            appGoto(app.current.app, app.current.tab, app.current.view, 
                app.current.offset, app.current.limit, event.target.getAttribute('data-tag'), app.current.sort, '-', app.current.search);
        }
    }, false);
    
    document.getElementById('searchFilesystemStr').addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else {
            appGoto(app.current.app, app.current.tab, app.current.view, 
                '0', app.current.limit, (this.value !== '' ? this.value : '-'), app.current.sort, '-', app.current.search);
        }
    }, false);
    
    document.getElementById('searchPlaylistsStr').addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else {
            appGoto(app.current.app, app.current.tab, app.current.view, 
                '0', app.current.limit, app.current.filter, app.current.sort, '-', this.value);
        }
    }, false);

    let colDropdowns = ['PlaybackColsDropdown'];
    for (let i = 0; i < colDropdowns.length; i++) {
        document.getElementById(colDropdowns[i]).addEventListener('click', function(event) {
            if (event.target.nodeName === 'BUTTON' && event.target.classList.contains('material-icons')) {
                event.stopPropagation();
                event.preventDefault();
                toggleBtnChk(event.target);
            }
        }, false);
    }


    const noFormSubmit = ['search', 'searchqueue', 'searchdatabase'];
    for (let i = 0; i < noFormSubmit.length; i++) {
        document.getElementById(noFormSubmit[i]).addEventListener('submit', function(event) {
            event.preventDefault();
        }, false);
    }

    document.getElementById('searchDatabaseStr').addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else if (event.key === 'Enter' && app.current.tag === 'Album') {
            if (this.value !== '') {
                let match = document.getElementById('searchDatabaseMatch');
                let li = document.createElement('button');
                li.classList.add('btn', 'btn-light', 'mr-2');
                li.setAttribute('data-filter-tag', encodeURI(app.current.filter));
                li.setAttribute('data-filter-op', encodeURI(match.options[match.selectedIndex].value));
                li.setAttribute('data-filter-value', encodeURI(this.value));
                li.innerHTML = e(app.current.filter) + ' ' + e(match.options[match.selectedIndex].value) + ' \'' + e(this.value) + '\'<span class="ml-2 badge badge-secondary">&times;</span>';
                this.value = '';
                document.getElementById('searchDatabaseCrumb').appendChild(li);
            }
            else {
                searchAlbumgrid(this.value);
            }
        }
        else if (app.current.tag === 'Album') {
            searchAlbumgrid(this.value);
        }
        else {
            appGoto(app.current.app, app.current.tab, app.current.view, 
                '0', app.current.limit, app.current.filter, app.current.sort, app.current.tag, this.value);        
        }
    }, false);

    document.getElementById('searchDatabaseCrumb').addEventListener('click', function(event) {
        if (event.target.nodeName === 'SPAN') {
            event.preventDefault();
            event.stopPropagation();
            event.target.parentNode.remove();
            searchAlbumgrid('');
        }
        else if (event.target.nodeName === 'BUTTON') {
            event.preventDefault();
            event.stopPropagation();
            selectTag('searchDatabaseTags', 'searchDatabaseTagsDesc', decodeURI(event.target.getAttribute('data-filter-tag')));
            document.getElementById('searchDatabaseStr').value = unescapeMPD(decodeURI(event.target.getAttribute('data-filter-value')));
            document.getElementById('searchDatabaseMatch').value = decodeURI(event.target.getAttribute('data-filter-op'));
            event.target.remove();
            searchAlbumgrid(document.getElementById('searchDatabaseStr').value);
        }
    }, false);

    domCache.searchstr.addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else if (event.key === 'Enter' && settings.featAdvsearch) {
            if (this.value !== '') {
                let match = document.getElementById('searchMatch');
                let li = document.createElement('button');
                li.classList.add('btn', 'btn-light', 'mr-2');
                li.setAttribute('data-filter-tag', encodeURI(app.current.filter));
                li.setAttribute('data-filter-op', encodeURI(match.options[match.selectedIndex].value));
                li.setAttribute('data-filter-value', encodeURI(this.value));
                li.innerHTML = e(app.current.filter) + ' ' + e(match.options[match.selectedIndex].value) + ' \'' + e(this.value) + '\'<span class="ml-2 badge badge-secondary">&times;</span>';
                this.value = '';
                domCache.searchCrumb.appendChild(li);
            }
            else {
                doSearch(this.value);
            }
        }
        else {
            doSearch(this.value);
        }
    }, false);

    domCache.searchCrumb.addEventListener('click', function(event) {
        if (event.target.nodeName === 'SPAN') {
            event.preventDefault();
            event.stopPropagation();
            event.target.parentNode.remove();
            doSearch('');
        }
        else if (event.target.nodeName === 'BUTTON') {
            event.preventDefault();
            event.stopPropagation();
            domCache.searchstr.value = unescapeMPD(decodeURI(event.target.getAttribute('data-filter-value')));
            selectTag('searchtags', 'searchtagsdesc', decodeURI(event.target.getAttribute('data-filter-tag')));
            document.getElementById('searchMatch').value = decodeURI(event.target.getAttribute('data-filter-op'));
            event.target.remove();
            doSearch(domCache.searchstr.value);
        }
    }, false);

    document.getElementById('searchMatch').addEventListener('change', function() {
        doSearch(domCache.searchstr.value);
    }, false);
    
    document.getElementById('SearchList').getElementsByTagName('tr')[0].addEventListener('click', function(event) {
        if (settings.featAdvsearch) {
            if (event.target.nodeName === 'TH') {
                if (event.target.innerHTML === '') {
                    return;
                }
                let col = event.target.getAttribute('data-col');
                if (col === 'Duration') {
                    return;
                }
                let sortcol = app.current.sort;
                let sortdesc = true;
                
                if (sortcol === col || sortcol === '-' + col) {
                    if (sortcol.indexOf('-') === 0) {
                        sortdesc = true;
                        col = sortcol.substring(1);
                    }
                    else {
                        sortdesc = false;
                    }
                }
                if (sortdesc === false) {
                    sortcol = '-' + col;
                    sortdesc = true;
                }
                else {
                    sortdesc = false;
                    sortcol = col;
                }
                
                let s = document.getElementById('SearchList').getElementsByClassName('sort-dir');
                for (let i = 0; i < s.length; i++) {
                    s[i].remove();
                }
                app.current.sort = sortcol;
                event.target.innerHTML = t(col) + '<span class="sort-dir material-icons pull-right">' + 
                    (sortdesc === true ? 'arrow_drop_up' : 'arrow_drop_down') + '</span>';
                appGoto(app.current.app, app.current.tab, app.current.view,
                    app.current.offset, app.current.limit, app.current.filter,  app.current.sort, '-', app.current.search);
            }
        }
    }, false);

    document.getElementById('inputScriptArgument').addEventListener('keyup', function(event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            event.stopPropagation();
            addScriptArgument();
        }
    }, false);
    
    document.getElementById('selectScriptArguments').addEventListener('click', function(event) {
        if (event.target.nodeName === 'OPTION') {
            removeScriptArgument(event);
        }
    }, false);

    document.getElementsByTagName('body')[0].addEventListener('click', function() {
        hideMenu();
    }, false);

    dragAndDropTable('QueueCurrentList');
    dragAndDropTable('BrowsePlaylistsDetailList');
    dragAndDropTableHeader('QueueCurrent');
    dragAndDropTableHeader('QueueLastPlayed');
    dragAndDropTableHeader('QueueJukebox');
    dragAndDropTableHeader('Search');
    dragAndDropTableHeader('BrowseFilesystem');
    dragAndDropTableHeader('BrowsePlaylistsDetail');
    dragAndDropTableHeader('BrowseDatabaseDetail');

    window.addEventListener('focus', function() {
        sendAPI("MPD_API_PLAYER_STATE", {}, parseState);
    }, false);


    document.addEventListener('keydown', function(event) {
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'SELECT' ||
            event.target.tagName === 'TEXTAREA' || event.ctrlKey || event.altKey) {
            return;
        }
        let cmd = keymap[event.key];
        if (cmd && typeof window[cmd.cmd] === 'function') {
            if (keymap[event.key].req === undefined || settings[keymap[event.key].req] === true)
                parseCmd(event, cmd);
        }        
        
    }, false);
    

    let tables = document.getElementsByTagName('table');
    for (let i = 0; i < tables.length; i++) {
        tables[i].setAttribute('tabindex', 0);
        tables[i].addEventListener('keydown', function(event) {
            navigateTable(this, event.key);
        }, false);
    }

    let selectThemeHtml = '';
    Object.keys(themes).forEach(function(key) {
        selectThemeHtml += '<option value="' + e(key) + '">' + t(themes[key]) + '</option>';
    });
    document.getElementById('selectTheme').innerHTML = selectThemeHtml;

    window.addEventListener('beforeunload', function() {
        webSocketClose();
    });
    
    document.getElementById('alertLocalPlayback').getElementsByTagName('a')[0].addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        clickCheckLocalPlayerState(event);
    }, false);
    
    document.getElementById('errorLocalPlayback').getElementsByTagName('a')[0].addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        clickCheckLocalPlayerState(event);
    }, false);

    document.getElementById('localPlayer').addEventListener('click', function(event) {
        event.stopPropagation();
    });
    
    document.getElementById('localPlayer').addEventListener('canplay', function() {
        logDebug('localPlayer event: canplay');
        document.getElementById('alertLocalPlayback').classList.add('hide');
        document.getElementById('errorLocalPlayback').classList.add('hide');
    });
    document.getElementById('localPlayer').addEventListener('error', function() {
        logError('localPlayer event: error');
        document.getElementById('errorLocalPlayback').classList.remove('hide');
    });
}

//Init app
window.onerror = function(msg, url, line) {
    logError('JavaScript error: ' + msg + ' (' + url + ': ' + line + ')');
    if (settings.loglevel >= 4) {
        if (appInited === true) {
            showNotification(t('JavaScript error'), msg + ' (' + url + ': ' + line + ')', '', 'danger');
        }
        else {
            showAppInitAlert(t('JavaScript error') + ': ' + msg + ' (' + url + ': ' + line + ')');
        }
    }
    return true;
};

window.onresize = function () {
    if (app.current.app === 'Playback') {    
        calcBoxHeight();
    }
};

appInitStart();
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function setStateIcon() {
    if (websocketConnected === false || settings.mpdConnected === false) {
//        domCache.mainMenu.classList.add('text-light');
//        domCache.mainMenu.classList.remove('connected');
        document.getElementById('logoBg').setAttribute('fill', '#6c757d');
    }
    else {
//        domCache.mainMenu.classList.add('connected');
//        domCache.mainMenu.classList.remove('text-light');
        document.getElementById('logoBg').setAttribute('fill', settings.highlightColor);
    }
}

function toggleAlert(alertBox, state, msg) {
    const alertBoxEl = document.getElementById(alertBox);
    if (state === false) {
        alertBoxEl.innerHTML = '';
        alertBoxEl.classList.add('hide');
    }
    else {
        alertBoxEl.innerHTML = msg;
        alertBoxEl.classList.remove('hide');
    }
}

function showNotification(notificationTitle, notificationText, notificationHtml, notificationType) {
    if (notificationTitle === 'No current song' ||
        notificationTitle === 'No lyrics found'
    ) {
        return;
    }

    if (settings.notificationWeb === true) {
        let notification = new Notification(notificationTitle, {icon: 'assets/favicon.ico', body: notificationText});
        setTimeout(notification.close.bind(notification), 3000);
    } 
    if (settings.notificationPage === true || notificationType === 'danger' || notificationType === 'warning') {
        let alertBox;
        if (alertTimeout) {
            clearTimeout(alertTimeout);
        }
        if (!document.getElementById('alertBox')) {
            alertBox = document.createElement('div');
            alertBox.setAttribute('id', 'alertBox');
            alertBox.classList.add('toast');
        }
        else {
            alertBox = document.getElementById('alertBox');
        }
        
        let toast = '<div class="toast-header">';
        if (notificationType === 'success' ) {
            toast += '<span class="material-icons text-success mr-2">info</span>';
        }
        else if (notificationType === 'warning' ) {
            toast += '<span class="material-icons text-warning mr-2">warning</span>';
        }
        else {
            toast += '<span class="material-icons text-danger mr-2">error</span>';
        }
        toast += '<strong class="mr-auto">' + e(notificationTitle) + '</strong>' +
            '<button type="button" class="ml-2 mb-1 close">&times;</button></div>';
        if (notificationHtml !== '' || notificationText !== '') {
            toast += '<div class="toast-body">' + (notificationHtml === '' ? e(notificationText) : notificationHtml) + '</div>';
        }
        toast += '</div>';
        alertBox.innerHTML = toast;
        
        if (!document.getElementById('alertBox')) {
            document.getElementsByTagName('main')[0].append(alertBox);
            requestAnimationFrame(function() {
                let ab = document.getElementById('alertBox');
                if (ab) {
                    ab.classList.add('alertBoxActive');
                }
            });
        }
        alertBox.getElementsByTagName('button')[0].addEventListener('click', function() {
            hideNotification();
        }, false);

        alertTimeout = setTimeout(function() {
            hideNotification();
        }, 3000);
    }
    setStateIcon();
    logMessage(notificationTitle, notificationText, notificationHtml, notificationType);
}

function logMessage(notificationTitle, notificationText, notificationHtml, notificationType) {
    if (notificationType === 'success') { notificationType = 'Info'; }
    else if (notificationType === 'warning') { notificationType = 'Warning'; }
    else if (notificationType === 'danger') { notificationType = 'Error'; }
    
    let overview = document.getElementById('logOverview');

    let append = true;
    let lastEntry = overview.firstElementChild;
    if (lastEntry) {
        if (lastEntry.getAttribute('data-title') === notificationTitle) {
            append = false;        
        }
    }

    let entry = document.createElement('div');
    entry.classList.add('text-light');
    entry.setAttribute('data-title', notificationTitle);
    let occurence = 1;
    if (append === false) {
        occurence += parseInt(lastEntry.getAttribute('data-occurence'));
    }
    entry.setAttribute('data-occurence', occurence);
    entry.innerHTML = '<small>' + localeDate() + '&nbsp;&ndash;&nbsp;' + t(notificationType) +
        (occurence > 1 ? '&nbsp;(' + occurence + ')' : '') + '</small>' +
        '<p>' + e(notificationTitle) +
        (notificationHtml === '' && notificationText === '' ? '' :
        '<br/>' + (notificationHtml === '' ? e(notificationText) : notificationHtml)) +
        '</p>';

    if (append === true) {
        overview.insertBefore(entry, overview.firstElementChild);
    }
    else {
        overview.replaceChild(entry, lastEntry);
    }
   
    let overviewEls = overview.getElementsByTagName('div');
    if (overviewEls.length > 10) {
        overviewEls[10].remove();
    }
}

//eslint-disable-next-line no-unused-vars
function clearLogOverview() {
    let overviewEls = document.getElementById('logOverview').getElementsByTagName('div');
    for (let i = overviewEls.length - 1; i >= 0; i--) {
        overviewEls[i].remove();
    }
    setStateIcon();
}

function hideNotification() {
    if (alertTimeout) {
        clearTimeout(alertTimeout);
    }

    if (document.getElementById('alertBox')) {
        document.getElementById('alertBox').classList.remove('alertBoxActive');
        setTimeout(function() {
            let alertBox = document.getElementById('alertBox');
            if (alertBox) {
                alertBox.remove();
            }
        }, 750);
    }
}

function notificationsSupported() {
    return "Notification" in window;
}

function setElsState(tag, state, type) {
    let els = type === 'tag' ? document.getElementsByTagName(tag) : document.getElementsByClassName(tag);
    let elsLen = els.length;
    for (let i = 0; i < elsLen; i++) {
        if (els[i].classList.contains('close')) {
            continue;
        }
        if (state === 'disabled') {
            if (els[i].classList.contains('alwaysEnabled') === false) {
                if (els[i].getAttribute('disabled') === null) {
                    els[i].setAttribute('disabled', 'disabled');
                    els[i].classList.add('disabled');
                }
            }
        }
        else {
            if (els[i].classList.contains('disabled')) {
                els[i].removeAttribute('disabled');
                els[i].classList.remove('disabled');
            }
        }
    }
}

function toggleUI() {
    let state = 'disabled';
    const topAlert = document.getElementById('top-alerts');
    if (websocketConnected === true && settings.mpdConnected === true) {
        topAlert.classList.add('hide');
        state = 'enabled';
    }
    else {
        let topPadding = 0;
        if (window.innerWidth < window.innerHeight) {
            topPadding = domCache.header.offsetHeight;
        }
        topAlert.style.paddingTop = topPadding + 'px';
        topAlert.classList.remove('hide');
    }
    let enabled = state === 'disabled' ? false : true;
    if (enabled !== uiEnabled) {
        logDebug('Setting ui state to ' + state);
        setElsState('a', state, 'tag');
        setElsState('input', state, 'tag');
        setElsState('button', state, 'tag');
        setElsState('clickable', state, 'class');
        uiEnabled = enabled;
    }

    if (settings.mpdConnected === true) {
        toggleAlert('alertMpdState', false, '');
    }
    else {
        toggleAlert('alertMpdState', true, t('MPD disconnected'));
        logMessage(t('MPD disconnected'), '', '', 'danger');
    }

    if (websocketConnected === true) {
        toggleAlert('alertMympdState', false, '');
    }
    else if (appInited === true) {
        toggleAlert('alertMympdState', true, t('Websocket is disconnected'));
        logMessage(t('Websocket is disconnected'), '', '', 'danger');
    }
 
    setStateIcon();
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function moveOutput(output) {
    sendAPI("MPD_API_PARTITION_OUTPUT_MOVE", {"name": output});
}

function parsePartitionOutputsList(obj) {
    let outputs = document.getElementById('outputs').getElementsByTagName('button');
    let outputIds = [];
    for (let i = 0; i < outputs.length; i++) {
        outputIds.push(parseInt(outputs[i].getAttribute('data-output-id')));
    }

    let outputList = '';
    let nr = 0;
    for (let i = 0; i < obj.result.data.length; i++) {
        if (outputIds.includes(obj.result.data[i].id) === false) {
            outputList += '<tr data-output="' + encodeURI(obj.result.data[i].name) + '"><td>' +
                e(obj.result.data[i].name) + '</td></tr>';
            nr++;
        }
    }
    if (nr === 0) {
        outputList = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span>&nbsp;' +
            t('Empty list') + '</td></tr>';
    }
    document.getElementById('partitionOutputsList').innerHTML = outputList;
}

//eslint-disable-next-line no-unused-vars
function savePartition() {
    let formOK = true;
    
    let nameEl = document.getElementById('inputPartitionName');
    if (!validatePlnameEl(nameEl)) {
        formOK = false;
    }
    
    if (formOK === true) {
        sendAPI("MPD_API_PARTITION_NEW", {
            "name": nameEl.value
            }, showListPartitions, false);
    }
}

//eslint-disable-next-line no-unused-vars
function showNewPartition() {
    document.getElementById('listPartitions').classList.remove('active');
    document.getElementById('newPartition').classList.add('active');
    document.getElementById('listPartitionsFooter').classList.add('hide');
    document.getElementById('newPartitionFooter').classList.remove('hide');
    
    const nameEl = document.getElementById('inputPartitionName');
    nameEl.classList.remove('is-invalid');
    nameEl.value = '';
    nameEl.focus();
}

function showListPartitions() {
    document.getElementById('listPartitions').classList.add('active');
    document.getElementById('newPartition').classList.remove('active');
    document.getElementById('listPartitionsFooter').classList.remove('hide');
    document.getElementById('newPartitionFooter').classList.add('hide');
    document.getElementById('errorPartition').classList.add('hide');
    sendAPI("MPD_API_PARTITION_LIST", {}, parsePartitionList, false);
}

function deletePartition(partition) {
    sendAPI("MPD_API_PARTITION_RM", {"name": partition}, function(obj) {
        if (obj.error) {
            let el = document.getElementById('errorPartition');
            el.innerText = t(obj.error.message);
            el.classList.remove('hide');
        }
        sendAPI("MPD_API_PARTITION_LIST", {}, parsePartitionList, false);
    }, true);
}

function switchPartition(partition) {
    sendAPI("MPD_API_PARTITION_SWITCH", {"name": partition}, function(obj) {
        if (obj.error) {
            let el = document.getElementById('errorPartition');
            el.innerText = t(obj.error.message);
            el.classList.remove('hide');
        }
        sendAPI("MPD_API_PARTITION_LIST", {}, parsePartitionList, false);
        sendAPI("MPD_API_PLAYER_STATE", {}, parseState);
    }, true);
}

function parsePartitionList(obj) {
    if (obj.result.data.length > 0) {
        let partitionList = '';
        for (let i = 0; i < obj.result.data.length; i++) {
            partitionList += '<tr data-partition="' + encodeURI(obj.result.data[i].name) + '"><td class="' +
                (obj.result.data[i].name === settings.partition ? 'font-weight-bold' : '') +
                '">' + e(obj.result.data[i].name) + 
                (obj.result.data[i].name === settings.partition ? '&nbsp;(' + t('current') + ')' : '') +
                '</td>' +
                '<td data-col="Action">' +
                (obj.result.data[i].name === 'default' || obj.result.data[i].name === settings.partition  ? '' : 
                    '<a href="#" title="' + t('Delete') + '" data-action="delete" class="material-icons color-darkgrey">delete</a>') +
                (obj.result.data[i].name !== settings.partition ? '<a href="#" title="' + t('Switch to') + '" data-action="switch" class="material-icons color-darkgrey">check_circle</a>' : '') +
                '</td></tr>';
        }
        document.getElementById('listPartitionsList').innerHTML = partitionList;
    }
    else {
        document.getElementById('listPartitionsList').innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="2">' + t('Empty list') + '</td></tr>';
    }
}

function setGridPlayback() {
    let list = ['col-md-6', 'd-none', 'd-md-block'];
    // let bts = document.getElementsByClassName('btnText');
    if (app.current.app === 'Playback') {
        document.getElementById('row1').classList.add('row');
        document.getElementById('col1').classList.add('col-md-6');
        document.getElementById('col2').classList.add(...list);
        document.getElementById('cardQueueMini').classList.remove('hide');
        document.getElementById('cardBrowse').classList.remove('hide');
        document.getElementById('cardBrowseDatabase').classList.remove('hide');
        // for (let i = 0; i < bts.length; i++) {
        //     bts[i].classList.add('hide');
        // }
    }
    else {
        document.getElementById('row1').classList.remove('row');
        document.getElementById('col1').classList.remove('col-md-6');
        document.getElementById('col2').classList.remove(...list);
        document.getElementById('cardQueueMini').classList.add('hide');
        // for (let i = 0; i < bts.length; i++) {
        //     bts[i].classList.remove('hide');
        // }
        document.getElementById('viewListDatabaseBox').style.height = '';
        document.getElementById('viewDetailDatabaseBox').style.height = '';
    }
}

function setAppState(page, filter, sort, tag, search) {
    let card = app.current.app === 'Browse' ? 'Playback' : 'Browse';
    let state = { "page": page, "filter": filter, "sort": sort, "tag": tag, "search": search };
    state.scrollPos = app.apps[card].tabs.Database.views[app.current.view].scrollPos;
    app.apps[card].tabs.Database.active = app.current.view;
    app.apps[card].tabs.Database.views[app.current.view] = state;
}

function getQueueMini(pos) {
    let colsQueueMini = ["Pos", "Title", "Artist", "Album", "Duration"];
    // list
    if (pos !== undefined && pos !== -1) {
        sendAPI("MPD_API_QUEUE_MINI", { "pos": pos, "limit": 0, "cols": colsQueueMini }, parseQueueMini);
    }
    else if (pos === undefined) {
        let table = document.getElementById('QueueMiniList');
        let tbody = table.getElementsByTagName('tbody')[0];
        for (let i = tbody.rows.length - 1; i >= 0; i--) {
            tbody.deleteRow(i);
        }
        table.classList.add('opacity05');
    }
    // footer
    sendAPI("MPD_API_QUEUE_LIST", { "offset": 0, "limit": 0, "cols": [] }, parseQueueList);
}

function parseQueueMini(obj) {
    let colsQueueMini = ["Pos", "Title", "Artist", "Album", "Duration"];
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('QueueMiniList');
    let activeRow = 0;
    table.setAttribute('data-version', obj.result.queueVersion);
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].Pos++;
        let row = document.createElement('tr');
        row.setAttribute('data-trackid', obj.result.data[i].id);
        row.setAttribute('id', 'queueMiniTrackId' + obj.result.data[i].id);
        row.setAttribute('data-songpos', obj.result.data[i].Pos);
        row.setAttribute('data-duration', obj.result.data[i].Duration);
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < colsQueueMini.length; c++) {
            tds += '<td data-col="' + colsQueueMini[c] + '">' + e(obj.result.data[i][colsQueueMini[c]]) + '</td>';
        }
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i--) {
        tr[i].remove();
    }
    document.getElementById('QueueMiniList').classList.remove('opacity05');
}

function parseQueueList(obj) {
    if (obj.result.totalTime && obj.result.totalTime > 0 && obj.result.totalEntities <= settings.maxElementsPerPage) {
        document.getElementById('cardFooterQueueMini').innerText = t('Num songs', obj.result.totalEntities) + ' – ' + beautifyDuration(obj.result.totalTime);
    }
    else if (obj.result.totalEntities > 0) {
        document.getElementById('cardFooterQueueMini').innerText = t('Num songs', obj.result.totalEntities);
    }
    else {
        document.getElementById('cardFooterQueueMini').innerText = '';
    }
}

function parseDatabaseAlbum(obj) {
    let colspan = 3;
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('BrowseDatabaseAlbumList');
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    let activeRow = 0;
    for (let i = 0; i < nrItems; i++) {
        let row = document.createElement('tr');
        let tds = '';
        row.setAttribute('data-type', 'dir');
        let uri = dirname(obj.result.data[i].FirstSongUri);
        row.setAttribute('data-uri', encodeURI(uri));
        row.setAttribute('tabindex', 0);
        row.setAttribute('data-album', obj.result.data[i].Album);
        row.setAttribute('data-albumartist', obj.result.data[i].AlbumArtist);
        row.setAttribute('data-name', obj.result.data[i].Album);
        tds += '<td data-col="Type"><span class="material-icons">album</span></td>';
        tds += '<td data-col="Album">' + e(obj.result.data[i].Album) + '</td>';
        tds += '<td data-col="AlbumArtist">' + e(obj.result.data[i].AlbumArtist) + '</td>';
        tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i--) {
        tr[i].remove();
    }

    if (nrItems === 0)
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    document.getElementById('BrowseDatabaseAlbumList').classList.remove('opacity05');
}

function calcBoxHeight() {
    if (app.current.app === 'Playback') {
        let oh1 = document.getElementById('cardPlayback').offsetHeight;
        let oh2 = document.getElementById('cardQueueMini').offsetHeight;
        let oh3 = document.getElementById('BrowseDatabaseButtons').offsetHeight;
        let oh4 = document.getElementById('searchDatabaseCrumb').offsetHeight;
        let oh5 = document.getElementById('PlaybackButtonsTop').offsetHeight;
        document.getElementById('viewListDatabaseBox').style.height = oh1 + oh2 - oh3 - oh4 - 17 + 'px';
        document.getElementById('viewDetailDatabaseBox').style.height = oh1 + oh2 - oh5 - 1 + 'px';
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parsePlaylists(obj) {
    if (app.current.view === 'All') {
        document.getElementById('BrowsePlaylistsAllList').classList.remove('hide');
        document.getElementById('BrowsePlaylistsDetailList').classList.add('hide');
        document.getElementById('btnBrowsePlaylistsAll').parentNode.classList.add('hide');
        document.getElementById('playlistContentBtns').classList.add('hide');
        document.getElementById('smartPlaylistContentBtns').classList.add('hide');
        document.getElementById('btnAddSmartpls').parentNode.classList.remove('hide');
        document.getElementById('BrowseNavPlaylists').parentNode.classList.remove('hide');
    }
    else {
        if (obj.result.uri.indexOf('.') > -1 || obj.result.smartpls === true) {
            document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-ro', 'true')
            document.getElementById('playlistContentBtns').classList.add('hide');
            document.getElementById('smartPlaylistContentBtns').classList.remove('hide');
        }
        else {
            document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-ro', 'false');
            document.getElementById('playlistContentBtns').classList.remove('hide');
            document.getElementById('smartPlaylistContentBtns').classList.add('hide');
        }
        document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-uri', obj.result.uri);
        document.getElementById('BrowsePlaylistsDetailList').getElementsByTagName('caption')[0].innerHTML = 
            (obj.result.smartpls === true ? t('Smart playlist') : t('Playlist'))  + ': ' + obj.result.uri;
        document.getElementById('BrowsePlaylistsDetailList').classList.remove('hide');
        document.getElementById('BrowsePlaylistsAllList').classList.add('hide');
        document.getElementById('btnBrowsePlaylistsAll').parentNode.classList.remove('hide');
        document.getElementById('btnAddSmartpls').parentNode.classList.add('hide');
        document.getElementById('BrowseNavPlaylists').parentNode.classList.add('hide');
    }
            
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById(app.current.app + app.current.tab + app.current.view + 'List');
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    if (app.current.view === 'All') {
        for (let i = 0; i < nrItems; i++) {
            let uri = encodeURI(obj.result.data[i].uri);
            let row = document.createElement('tr');
            row.setAttribute('data-uri', uri);
            row.setAttribute('data-type', obj.result.data[i].Type);
            row.setAttribute('data-name', obj.result.data[i].name);
            row.setAttribute('tabindex', 0);
            row.innerHTML = '<td data-col="Type"><span class="material-icons">' + (obj.result.data[i].Type === 'smartpls' ? 'queue_music' : 'list') + '</span></td>' +
                            '<td>' + e(obj.result.data[i].name) + '</td>' +
                            '<td>'+ localeDate(obj.result.data[i].last_modified) + '</td>' +
                            '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
            if (i < tr.length) {
                activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
            }
            else {
                tbody.append(row);
            }
        }
        //document.getElementById('cardFooterBrowse').innerText = gtPage('Num playlists', obj.result.returnedEntities, obj.result.totalEntities);
    }
    else if (app.current.view === 'Detail') {
        for (let i = 0; i < nrItems; i++) {
            let uri = encodeURI(obj.result.data[i].uri);
            let row = document.createElement('tr');
            if (obj.result.smartpls === false) {
                row.setAttribute('draggable','true');
            }
            row.setAttribute('id','playlistTrackId' + obj.result.data[i].Pos);
            row.setAttribute('data-type', obj.result.data[i].Type);
            row.setAttribute('data-uri', uri);
            row.setAttribute('data-name', obj.result.data[i].Title);
            row.setAttribute('data-songpos', obj.result.data[i].Pos);
            row.setAttribute('tabindex', 0);
            obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
            let tds = '';
            for (let c = 0; c < settings.colsBrowsePlaylistsDetail.length; c++) {
                tds += '<td data-col="' + settings.colsBrowsePlaylistsDetail[c] + '">' + e(obj.result.data[i][settings.colsBrowsePlaylistsDetail[c]]) + '</td>';
            }
            tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
            row.innerHTML = tds;

            if (i < tr.length) {
                activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
            }
            else {
                tbody.append(row);
            }
        }
        let tfoot = table.getElementsByTagName('tfoot')[0];
        let colspan = settings.colsBrowsePlaylistsDetail.length;
        colspan++;
        tfoot.innerHTML = '<tr><td colspan="' + (colspan + 1) + '"><small>' + t('Num songs', obj.result.totalEntities) + '&nbsp;&ndash;&nbsp;' + beautifyDuration(obj.result.totalTime) + '</small></td></tr>';
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    if (navigate === true) {
        focusTable(0);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    
    if (nrItems === 0) {
        if (app.current.view === 'All') {
            tbody.innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
                              '<td colspan="3">' + t('No playlists found') + '</td></tr>';
        }
        else {
            tbody.innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
                              '<td colspan="' + settings.colsBrowsePlaylistsDetail.length + '">' + t('Empty playlist') + '</td></tr>';
        }
    }
            
    document.getElementById(app.current.app + app.current.tab + app.current.view + 'List').classList.remove('opacity05');
}

//eslint-disable-next-line no-unused-vars
function playlistDetails(uri) {
    document.getElementById('BrowsePlaylistsAllList').classList.add('opacity05');
    appGoto('Browse', 'Playlists', 'Detail', '0', undefined, uri, '-', '-', '');
}

//eslint-disable-next-line no-unused-vars
function playlistClear() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_CLEAR", {"uri": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function playlistShuffle() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_SHUFFLE", {"uri": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function playlistSort(tag) {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_SORT", {"uri": uri, "tag": tag});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

function getAllPlaylists(obj, playlistSelect, playlistValue) {
    let nrItems = obj.result.returnedEntities;
    let playlists = '';
    if (playlistSelect === 'addToPlaylistPlaylist') {
        playlists = '<option value=""></option><option value="new">' + t('New playlist') + '</option>';
    }
    else if (playlistSelect === 'selectJukeboxPlaylist' || 
             playlistSelect === 'selectAddToQueuePlaylist' ||
             playlistSelect === 'selectTimerPlaylist') 
    {
        playlists = '<option value="Database">' + t('Database') + '</option>';
    }

    for (let i = 0; i < nrItems; i++) {
        if (playlistSelect === 'addToPlaylistPlaylist' && obj.result.data[i].Type === 'smartpls') {
            continue;
        }
        playlists += '<option value="' + e(obj.result.data[i].uri) + '"';
        if (playlistValue !== null && obj.result.data[i].uri === playlistValue) {
            playlists += ' selected';
        }
        playlists += '>' + e(obj.result.data[i].uri) + '</option>';
    }
    
    document.getElementById(playlistSelect).innerHTML = playlists;
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylists(force) {
    sendAPI("MPDWORKER_API_SMARTPLS_UPDATE_ALL", {"force":force});
}

//eslint-disable-next-line no-unused-vars
function removeFromPlaylist(uri, pos) {
    pos--;
    sendAPI("MPD_API_PLAYLIST_RM_TRACK", {"uri": uri, "track": pos});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function toggleAddToPlaylistFrm() {
    let btn = document.getElementById('toggleAddToPlaylistBtn');
    toggleBtn('toggleAddToPlaylistBtn');
    if (btn.classList.contains('active')) {
        document.getElementById('addToPlaylistFrm').classList.remove('hide');
        document.getElementById('addStreamFooter').classList.add('hide');
        document.getElementById('addToPlaylistFooter').classList.remove('hide');
    }    
    else {
        document.getElementById('addToPlaylistFrm').classList.add('hide');
        document.getElementById('addStreamFooter').classList.remove('hide');
        document.getElementById('addToPlaylistFooter').classList.add('hide');
    }
}

function parseSmartPlaylist(obj) {
    let nameEl = document.getElementById('saveSmartPlaylistName');
    nameEl.value = obj.result.playlist;
    nameEl.classList.remove('is-invalid');
    document.getElementById('saveSmartPlaylistType').value = t(obj.result.type);
    document.getElementById('saveSmartPlaylistType').setAttribute('data-value', obj.result.type);
    document.getElementById('saveSmartPlaylistSearch').classList.add('hide');
    document.getElementById('saveSmartPlaylistSticker').classList.add('hide');
    document.getElementById('saveSmartPlaylistNewest').classList.add('hide');
    let tagList;
    if (settings.featTags) {
        tagList = '<option value="any">' + t('Any Tag') + '</option>';
    }
    tagList += '<option value="filename">' + t('Filename') + '</option>';
    for (let i = 0; i < settings.searchtags.length; i++) {
        tagList += '<option value="' + settings.searchtags[i] + '">' + t(settings.searchtags[i]) + '</option>';
    }
    let elSelectSaveSmartPlaylistTag = document.getElementById('selectSaveSmartPlaylistTag');
    elSelectSaveSmartPlaylistTag.innerHTML = tagList;
    if (obj.result.type === 'search') {
        document.getElementById('saveSmartPlaylistSearch').classList.remove('hide');
        document.getElementById('selectSaveSmartPlaylistTag').value = obj.result.tag;
        document.getElementById('inputSaveSmartPlaylistSearchstr').value = obj.result.searchstr;
        if (settings.featAdvsearch === true && obj.result.tag === 'expression') {
            elSelectSaveSmartPlaylistTag.parentNode.parentNode.classList.add('hide');
            elSelectSaveSmartPlaylistTag.innerHTML = '<option value="expression">expression</option>';
            elSelectSaveSmartPlaylistTag.value = 'expression';
        }
        else {
            document.getElementById('selectSaveSmartPlaylistTag').parentNode.parentNode.classList.remove('hide');
        }
    }
    else if (obj.result.type === 'sticker') {
        document.getElementById('saveSmartPlaylistSticker').classList.remove('hide');
        document.getElementById('selectSaveSmartPlaylistSticker').value = obj.result.sticker;
        document.getElementById('inputSaveSmartPlaylistStickerMaxentries').value = obj.result.maxentries;
        document.getElementById('inputSaveSmartPlaylistStickerMinvalue').value = obj.result.minvalue;
    }
    else if (obj.result.type === 'newest') {
        document.getElementById('saveSmartPlaylistNewest').classList.remove('hide');
        let timerange = obj.result.timerange / 24 / 60 / 60;
        document.getElementById('inputSaveSmartPlaylistNewestTimerange').value = timerange;
    }
    modalSaveSmartPlaylist.show();
    nameEl.focus();
}

//eslint-disable-next-line no-unused-vars
function saveSmartPlaylist() {
    let name = document.getElementById('saveSmartPlaylistName').value;
    let type = document.getElementById('saveSmartPlaylistType').getAttribute('data-value');
    let sortEl = document.getElementById('saveSmartPlaylistSort');
    let sort = sortEl.options[sortEl.selectedIndex].value;
    if (validatePlname(name) === true) {
        if (type === 'search') {
            let tagEl = document.getElementById('selectSaveSmartPlaylistTag');
            let tag = tagEl.options[tagEl.selectedIndex].value;
            let searchstr = document.getElementById('inputSaveSmartPlaylistSearchstr').value;
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "tag": tag, "searchstr": searchstr, "sort": sort});
        }
        else if (type === 'sticker') {
            let stickerEl = document.getElementById('selectSaveSmartPlaylistSticker');
            let sticker = stickerEl.options[stickerEl.selectedIndex].value;
            let maxentriesEl = document.getElementById('inputSaveSmartPlaylistStickerMaxentries');
            if (!validateInt(maxentriesEl)) {
                return;
            }
            let minvalueEl = document.getElementById('inputSaveSmartPlaylistStickerMinvalue');
            if (!validateInt(minvalueEl)) {
                return;
            }
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "sticker": sticker, "maxentries": parseInt(maxentriesEl.value), 
                "minvalue": parseInt(minvalueEl.value), "sort": sort});
        }
        else if (type === 'newest') {
            let timerangeEl = document.getElementById('inputSaveSmartPlaylistNewestTimerange');
            if (!validateInt(timerangeEl)) {
                return;
            }
            let timerange = parseInt(timerangeEl.value) * 60 * 60 * 24;
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "timerange": timerange, "sort": sort});
        }
        else {
            document.getElementById('saveSmartPlaylistType').classList.add('is-invalid');
            return;
        }
        modalSaveSmartPlaylist.hide();
        showNotification(t('Saved smart playlist %{name}', {"name": name}), '', '', 'success');
    }
    else {
        document.getElementById('saveSmartPlaylistName').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function addSmartpls(type) {
    let obj = {"jsonrpc":"2.0", "id":0, "result": {"method":"MPD_API_SMARTPLS_GET"}};
    if (type === 'mostPlayed') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'mostPlayed';
        obj.result.type = 'sticker';
        obj.result.sticker = 'playCount';
        obj.result.maxentries = 200;
        obj.result.minvalue = 10;
    }
    else if (type === 'newest') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'newestSongs';
        obj.result.type = 'newest';
        obj.result.timerange = 14 * 24 * 60 * 60;
    }
    else if (type === 'bestRated') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'bestRated';
        obj.result.type = 'sticker';
        obj.result.sticker = 'like';
        obj.result.maxentries = 200;
        obj.result.minvalue = 2;
    }
    parseSmartPlaylist(obj);
}

//eslint-disable-next-line no-unused-vars
function deletePlaylists() {
    let selectDeletePlaylists = document.getElementById('selectDeletePlaylists');
    let btnDeletePlaylists = document.getElementById('btnDeletePlaylists');
    btnWaiting(btnDeletePlaylists, true);
    sendAPI("MPD_API_PLAYLIST_RM_ALL", {"type": selectDeletePlaylists.options[selectDeletePlaylists.selectedIndex].value}, function() {
        btnWaiting(btnDeletePlaylists, false);
    });
}

//eslint-disable-next-line no-unused-vars
function showAddToPlaylistCurrentSong() {
    let uri = document.getElementById('currentTitle').getAttribute('data-uri');
    if (uri !== '') {
        showAddToPlaylist(uri, '');
    }
}

//eslint-disable-next-line no-unused-vars
function showAddToPlaylistCurrentSearch() {
    showAddToPlaylist(app.current.search, '');
}

function showAddToPlaylist(uri, searchstr) {
    document.getElementById('addToPlaylistUri').value = uri;
    document.getElementById('addToPlaylistSearch').value = searchstr;
    document.getElementById('addToPlaylistPlaylist').innerHTML = '';
    document.getElementById('addToPlaylistNewPlaylist').value = '';
    document.getElementById('addToPlaylistNewPlaylistDiv').classList.add('hide');
    document.getElementById('addToPlaylistNewPlaylist').classList.remove('is-invalid');
    toggleBtn('toggleAddToPlaylistBtn',0);
    let streamUrl = document.getElementById('streamUrl')
    streamUrl.focus();
    streamUrl.value = '';
    streamUrl.classList.remove('is-invalid');
    if (uri !== 'stream') {
        document.getElementById('addStreamFooter').classList.add('hide');
        document.getElementById('addStreamFrm').classList.add('hide');
        document.getElementById('addToPlaylistFooter').classList.remove('hide');
        document.getElementById('addToPlaylistFrm').classList.remove('hide');
        document.getElementById('addToPlaylistCaption').innerText = t('Add to playlist');
    }
    else {
        document.getElementById('addStreamFooter').classList.remove('hide');
        document.getElementById('addStreamFrm').classList.remove('hide');
        document.getElementById('addToPlaylistFooter').classList.add('hide');
        document.getElementById('addToPlaylistFrm').classList.add('hide');
        document.getElementById('addToPlaylistCaption').innerText = t('Add stream');
    }
    modalAddToPlaylist.show();
    if (settings.featPlaylists) {
        sendAPI("MPD_API_PLAYLIST_LIST", {"searchstr": "", "offset": 0, "limit": 0}, function(obj) {
            getAllPlaylists(obj, 'addToPlaylistPlaylist');
        });
    }
}

//eslint-disable-next-line no-unused-vars
function addToPlaylist() {
    let uri = decodeURI(document.getElementById('addToPlaylistUri').value);
    if (uri === 'stream') {
        uri = document.getElementById('streamUrl').value;
        if (uri === '' || uri.indexOf('http') === -1) {
            document.getElementById('streamUrl').classList.add('is-invalid');
            return;
        }
    }
    let plistEl = document.getElementById('addToPlaylistPlaylist');
    let plist = plistEl.options[plistEl.selectedIndex].value;
    if (plist === 'new') {
        let newPl = document.getElementById('addToPlaylistNewPlaylist').value;
        if (validatePlname(newPl) === true) {
            plist = newPl;
        }
        else {
            document.getElementById('addToPlaylistNewPlaylist').classList.add('is-invalid');
            return;
        }
    }
    if (plist !== '') {
        if (uri === 'SEARCH') {
            addAllFromSearchPlist(plist, null, false);
        }
        else if (uri === 'ALBUM') {
            let expression = document.getElementById('addToPlaylistSearch').value;
            addAllFromSearchPlist(plist, expression, false);
        }
        else if (uri === 'DATABASE') {
            addAllFromBrowseDatabasePlist(plist);
        }
        else {
            sendAPI("MPD_API_PLAYLIST_ADD_TRACK", {"uri": uri, "plist": plist});
        }
        modalAddToPlaylist.hide();
    }
    else {
        document.getElementById('addToPlaylistPlaylist').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function showRenamePlaylist(from) {
    document.getElementById('renamePlaylistTo').classList.remove('is-invalid');
    modalRenamePlaylist.show();
    document.getElementById('renamePlaylistFrom').value = from;
    document.getElementById('renamePlaylistTo').value = '';
}

//eslint-disable-next-line no-unused-vars
function renamePlaylist() {
    let from = document.getElementById('renamePlaylistFrom').value;
    let to = document.getElementById('renamePlaylistTo').value;
    if (to !== from && validatePlname(to) === true) {
        sendAPI("MPD_API_PLAYLIST_RENAME", {"from": from, "to": to});
        modalRenamePlaylist.hide();
    }
    else {
        document.getElementById('renamePlaylistTo').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function showSmartPlaylist(playlist) {
    sendAPI("MPD_API_SMARTPLS_GET", {"playlist": playlist}, parseSmartPlaylist);
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylist(playlist) {
    sendAPI("MPDWORKER_API_SMARTPLS_UPDATE", {"playlist": playlist});
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylistClick() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPDWORKER_API_SMARTPLS_UPDATE", {"playlist": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function showDelPlaylist(uri) {
    document.getElementById('deletePlaylist').value = uri;
    modalDeletePlaylist.show();
}

//eslint-disable-next-line no-unused-vars
function delPlaylist() {
    let uri = document.getElementById('deletePlaylist').value;
    sendAPI("MPD_API_PLAYLIST_RM", {"uri": uri});
    modalDeletePlaylist.hide();
}

function playlistMoveTrack(from, to) {
    sendAPI("MPD_API_PLAYLIST_MOVE_TRACK", {"plist": app.current.search, "from": from, "to": to});
}

//eslint-disable-next-line no-unused-vars
function addSelectedItemToPlaylist() {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id === 'BrowsePlaylistsAllList') {
            return;
        }
        showAddToPlaylist(item.getAttribute('data-uri'), '');
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function b64EncodeUnicode(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
            return String.fromCharCode('0x' + p1);
    }));
}

function b64DecodeUnicode(str) {
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

function addMenuItem(href, text) {
    return '<a class="dropdown-item" href="#" data-href=\'' + b64EncodeUnicode(JSON.stringify(href)) + '\'>' + text +'</a>';
}

function hideMenu() {
    let menuEl = document.querySelector('[data-popover]');
    if (menuEl) {
        let m = new BSN.Popover(menuEl, {});
        m.hide();
        menuEl.removeAttribute('data-popover');
        if (menuEl.parentNode.parentNode.classList.contains('selected')) {
            focusTable(undefined, menuEl.parentNode.parentNode.parentNode.parentNode);
        }
        else if ((app.current.app === 'Browse' || app.current.app === 'Playback') && app.current.tab === 'Database') {
            focusTable(undefined, menuEl.parentNode.parentNode.parentNode.parentNode);
        }
        else if (app.current.app === 'Home') {
            focusTable(undefined, menuEl.parentNode.parentNode.parentNode.parentNode);
        }
        else if (app.current.app === 'Home') {
            focusTable(undefined, menuEl.parentNode.parentNode.parentNode.parentNode);
        }
    }
}

function showMenu(el, event) {
    event.preventDefault();
    event.stopPropagation();
    hideMenu();
    //if (el.getAttribute('data-init')) {
    //    return;
    //}
    if (el.parentNode.nodeName === 'TH') {
        showMenuTh(el);
    }
    else {
        showMenuTd(el);
    }
}

function showMenuTh(el) {
    let table = (app.current.app === 'Playback' ? 'Browse' : app.current.app) + (app.current.tab !== undefined ? app.current.tab : '') + (app.current.view !== undefined ? app.current.view : '');
    let menu = '<form class="p-2" id="colChecklist' + table + '">';
    menu += setColsChecklist(table);
    menu += '<button class="btn btn-success btn-block btn-sm mt-2">' + t('Apply') + '</button>';
    menu += '</form>';
    new BSN.Popover(el, { trigger: 'click', delay: 0, dismissible: true, template: '<div class="popover" role="tooltip">' +
        '<div class="arrow"></div>' +
        '<div class="popover-content" id="' + table + 'ColsDropdown' + '">' + menu + '</div>' +
        '</div>', content: ' '});
    let popoverInit = el.Popover;
    if (el.getAttribute('data-init') === null) {
        el.setAttribute('data-init', 'true');
        el.addEventListener('shown.bs.popover', function(event) {
            event.target.setAttribute('data-popover', 'true');
            document.getElementById('colChecklist' + table).addEventListener('click', function(eventClick) {
                if (eventClick.target.nodeName === 'BUTTON' && eventClick.target.classList.contains('material-icons')) {
                    toggleBtnChk(eventClick.target);
                    eventClick.preventDefault();
                    eventClick.stopPropagation();
                }
                else if (eventClick.target.nodeName === 'BUTTON') {
                    eventClick.preventDefault();
                    saveCols(table);
                }
            }, false);
        }, false);
    }
    popoverInit.show();
}

function showMenuTd(el) {
    let type = el.getAttribute('data-type');
    let uri = decodeURI(el.getAttribute('data-uri'));
    let name = decodeURI(el.getAttribute('data-name'));
    let nextsongpos = 0;
    if (type === null || uri === '') {
        type = el.parentNode.getAttribute('data-type');
        uri = decodeURI(el.parentNode.getAttribute('data-uri'));
        name = el.parentNode.getAttribute('data-name');
    }
    if (type === null || uri === '') {
        type = el.parentNode.parentNode.getAttribute('data-type');
        uri = decodeURI(el.parentNode.parentNode.getAttribute('data-uri'));
        name = el.parentNode.parentNode.getAttribute('data-name');
    }
    
    if (lastState) {
        nextsongpos = lastState.nextSongPos;
    }

    let menu = '';
    if ((app.current.app === 'Browse' && app.current.tab === 'Filesystem') || app.current.app === 'Search' ||
        ((app.current.app === 'Browse' || app.current.app === 'Playback') && app.current.tab === 'Database' && app.current.view === 'Detail')) {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            (type === 'song' ? addMenuItem({"cmd": "appendAfterQueue", "options": [type, uri, nextsongpos, name]}, t('Add after current playing song')) : '') +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (type !== 'plist' && type !== 'smartpls' && settings.featPlaylists === true ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (type === 'song' ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '') +
            (type === 'plist' || type === 'smartpls' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('View playlist')) : '') +
            ((type === 'plist' || type === 'smartpls') && settings.featHome === true ? addMenuItem({"cmd": "addPlistToHome", "options": [uri, name]}, t('Add to homescreen')) : '');
            
        if (app.current.tab === 'Filesystem') {
            menu += (type === 'dir' && settings.featBookmarks ? addMenuItem({"cmd": "showBookmarkSave", "options": [-1, name, uri, type]}, t('Add bookmark')) : '') +
                (type === 'dir' ? addMenuItem({"cmd": "updateDB", "options": [dirname(uri), true]}, t('Update directory')) : '') +
                (type === 'dir' ? addMenuItem({"cmd": "rescanDB", "options": [dirname(uri), true]}, t('Rescan directory')) : '');
        }
        if (app.current.app === 'Search') {
            const curTr = el.parentNode.parentNode;
            if (curTr.hasAttribute('data-album') && curTr.hasAttribute('data-albumartist')) {
                const vAlbum = decodeURI(curTr.getAttribute('data-album'));
                const vAlbumArtist = decodeURI(curTr.getAttribute('data-albumartist'));
                menu += '<div class="dropdown-divider"></div>' +
                    '<a class="dropdown-item" id="advancedMenuLink" data-toggle="collapse" href="#advancedMenu"><span class="material-icons material-icons-left">keyboard_arrow_right</span>Album actions</a>' +
                    '<div class="collapse" id="advancedMenu">' +
                        addMenuItem({"cmd": "_addAlbum", "options": ["appendQueue", vAlbumArtist, vAlbum]}, t('Append to queue')) +
                        addMenuItem({"cmd": "_addAlbum", "options": ["replaceQueue", vAlbumArtist, vAlbum]}, t('Replace queue')) +
                        (settings.featPlaylists === true ? addMenuItem({"cmd": "_addAlbum", "options": ["addPlaylist", vAlbumArtist, vAlbum]}, t('Add to playlist')) : '') +
                    '</div>';
            }
            else {
                //songs must be arragend in one album per folder
                const baseuri = dirname(uri);
                menu += '<div class="dropdown-divider"></div>' +
                    '<a class="dropdown-item" id="advancedMenuLink" data-toggle="collapse" href="#advancedMenu"><span class="material-icons material-icons-left">keyboard_arrow_right</span>Folder actions</a>' +
                    '<div class="collapse" id="advancedMenu">' +
                        addMenuItem({"cmd": "appendQueue", "options": [type, baseuri, name]}, t('Append to queue')) +
                        addMenuItem({"cmd": "appendAfterQueue", "options": [type, baseuri, nextsongpos, name]}, t('Add after current playing song')) +
                        addMenuItem({"cmd": "replaceQueue", "options": [type, baseuri, name]}, t('Replace queue')) +
                        (settings.featPlaylists === true ? addMenuItem({"cmd": "showAddToPlaylist", "options": [baseuri, ""]}, t('Add to playlist')) : '') +
                    '</div>';
            }
        }
    }
    else if ((app.current.app === 'Browse' || app.current.app === 'Playback') && app.current.tab === 'Database' && app.current.view === 'List') {
        const albumArtist = decodeURI(el.parentNode.getAttribute('data-albumartist'));
        const album = decodeURI(el.parentNode.getAttribute('data-album'));
        menu += addMenuItem({"cmd": "appGoto", "options": ["Browse", "Database", "Detail", 0, undefined, "Album", tagAlbumArtist, album, albumArtist]}, t('Show album')) +
            addMenuItem({"cmd": "_addAlbum", "options": ["appendQueue", albumArtist, album]}, t('Append to queue')) +
            addMenuItem({"cmd": "_addAlbum", "options": ["replaceQueue", albumArtist, album]}, t('Replace queue')) +
            (settings.featPlaylists === true ? addMenuItem({"cmd": "_addAlbum", "options": ["addPlaylist", albumArtist, album]}, t('Add to playlist')) : '');
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('View playlist')) : addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('Edit playlist')))+
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "showSmartPlaylist", "options": [uri]}, t('Edit smart playlist')) : '') +
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "updateSmartPlaylist", "options": [uri]}, t('Update smart playlist')) : '') +
            addMenuItem({"cmd": "showRenamePlaylist", "options": [uri]}, t('Rename playlist')) + 
            addMenuItem({"cmd": "showDelPlaylist", "options": [uri]}, t('Delete playlist')) +
            (settings.featHome === true ?addMenuItem({"cmd": "addPlistToHome", "options": [uri, name]}, t('Add to homescreen')) : '');
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        let x = document.getElementById('BrowsePlaylistsDetailList');
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (x.getAttribute('data-ro') === 'false' ? addMenuItem({"cmd": "removeFromPlaylist", "options": [x.getAttribute('data-uri'), 
                    el.parentNode.parentNode.getAttribute('data-songpos')]}, t('Remove')) : '') +
            (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'Current') {
        const trackid = parseInt(el.parentNode.parentNode.getAttribute('data-trackid'));
        menu += ( trackid !== lastState.currentSongId ? addMenuItem({"cmd": "playAfterCurrent", "options": [trackid, el.parentNode.parentNode.getAttribute('data-songpos')]}, t('Play after current playing song')) : '') +
            addMenuItem({"cmd": "delQueueSong", "options": ["single", trackid]}, t('Remove')) +
            addMenuItem({"cmd": "delQueueSong", "options": ["range", 0, el.parentNode.parentNode.getAttribute('data-songpos')]}, t('Remove all upwards')) +
            addMenuItem({"cmd": "delQueueSong", "options": ["range", (parseInt(el.parentNode.parentNode.getAttribute('data-songpos'))-1), -1]}, t('Remove all downwards')) +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'Jukebox') {
        menu += addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) +
            addMenuItem({"cmd": "delQueueJukeboxSong", "options": [el.parentNode.parentNode.getAttribute('data-pos')]}, t('Remove'));
    }
    else if (app.current.app === 'Home') {
        const pos = parseInt(el.parentNode.getAttribute('data-pos'));
        const href = JSON.parse(el.parentNode.getAttribute('data-href'));
        let actionDesc = '';
        if (href.cmd === 'replaceQueue' && href.options[0] === 'plist') {
            type = 'plist';
            uri = href.options[1];
            actionDesc = t('Add and play playlist');
            name = t('Playlist');
        }
        else if (href.cmd === 'appGoto') {
            type = 'view';
            actionDesc = t('Goto view');
            name = t('View');
        }
        else if (href.cmd === 'execScriptFromOptions') {
            type = 'script';
            actionDesc = t('Execute script');
            name = t('Script');
        }
        menu += '<h6 class="dropdown-header">' + name + '</h6>' +
                addMenuItem({"cmd": "executeHomeIcon", "options": [pos]}, actionDesc) +
                (type === 'plist' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('View playlist')) : '') +
                addMenuItem({"cmd": "editHomeIcon", "options": [pos]}, t('Edit home icon')) +
                addMenuItem({"cmd": "duplicateHomeIcon", "options": [pos]}, t('Duplicate home icon')) +
                addMenuItem({"cmd": "deleteHomeIcon", "options": [pos]}, t('Delete home icon'));
    }

    new BSN.Popover(el, { trigger: 'click', delay: 0, dismissible: true, template: '<div class="popover" role="tooltip">' +
        '<div class="arrow"></div>' +
        '<div class="popover-content">' + menu + '</div>' +
        '</div>', content: ' '});
    let popoverInit = el.Popover;
    if (el.getAttribute('data-init') === null) {
        el.setAttribute('data-init', 'true');
        el.addEventListener('shown.bs.popover', function(event) {
            event.target.setAttribute('data-popover', 'true');
            document.getElementsByClassName('popover-content')[0].addEventListener('click', function(eventClick) {
                eventClick.preventDefault();
                eventClick.stopPropagation();
                if (eventClick.target.nodeName === 'A') {
                    let dh = eventClick.target.getAttribute('data-href');
                    if (dh) {
                        let cmd = JSON.parse(b64DecodeUnicode(dh));
                        parseCmd(event, cmd);
                        hideMenu();
                    }
                }
            }, false);
            document.getElementsByClassName('popover-content')[0].addEventListener('keydown', function(eventKey) {
                eventKey.preventDefault();
                eventKey.stopPropagation();
                if (eventKey.key === 'ArrowDown' || eventKey.key === 'ArrowUp') {
                    let menuItemsHtml = this.getElementsByTagName('a');
                    let menuItems = Array.prototype.slice.call(menuItemsHtml);
                    let idx = menuItems.indexOf(document.activeElement);
                    do {
                        idx = eventKey.key === 'ArrowUp' ? (idx > 1 ? idx - 1 : 0)
                                                 : eventKey.key === 'ArrowDown' ? ( idx < menuItems.length - 1 ? idx + 1 : idx)
                                                                            : idx;
                        if ( idx === 0 || idx === menuItems.length -1 ) {
                            break;
                        }
                    } while ( !menuItems[idx].offsetHeight )
                    menuItems[idx] && menuItems[idx].focus();
                }
                else if (eventKey.key === 'Enter') {
                    eventKey.target.click();
                }
                else if (eventKey.key === 'Escape') {
                    hideMenu();
                }
            }, false);
            let collapseLink = document.getElementById('advancedMenuLink');
            if (collapseLink) {
                collapseLink.addEventListener('click', function() {
                    let icon = this.getElementsByTagName('span')[0];
                    if (icon.innerText === 'keyboard_arrow_right') {
                        icon.innerText = 'keyboard_arrow_down';
                    }
                    else {
                        icon.innerText = 'keyboard_arrow_right';
                    }
                }, false);
                new BSN.Collapse(collapseLink);
            }
            document.getElementsByClassName('popover-content')[0].firstChild.focus();
        }, false);
    }
    popoverInit.show();
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parseUpdateQueue(obj) {
    //Set playstate
    if (obj.result.state === 1) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].innerText = 'play_arrow';
        }
        playstate = 'stop';
        domCache.progressBar.style.transition = 'none';
        domCache.progressBar.style.width = '0px';
        setTimeout(function() {
            domCache.progressBar.style.transition = progressBarTransition;
        }, 10);
    }
    else if (obj.result.state === 2) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            if (settings.footerStop === 'stop') {
                domCache.btnsPlay[i].innerText = 'stop';
            }
            else {
                domCache.btnsPlay[i].innerText = 'pause';
            }
        }
        playstate = 'play';
    }
    else {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].innerText = 'play_arrow';
        }
        playstate = 'pause';
    }

    if (obj.result.queueLength === 0) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].setAttribute('disabled', 'disabled');
        }
    }
    else {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].removeAttribute('disabled');
        }
    }

    mediaSessionSetState();
    mediaSessionSetPositionState(obj.result.totalTime, obj.result.elapsedTime);

    domCache.badgeQueueItems.innerText = obj.result.queueLength;
    
    if (obj.result.nextSongPos === -1 && settings.jukeboxMode === false) {
        domCache.btnNext.setAttribute('disabled', 'disabled');
    }
    else {
        domCache.btnNext.removeAttribute('disabled');
    }
    
    if (obj.result.songPos < 0) {
        domCache.btnPrev.setAttribute('disabled', 'disabled');
    }
    else {
        domCache.btnPrev.removeAttribute('disabled');
    }
}

function getQueue() {
    if (app.current.search.length >= 2) {
        sendAPI("MPD_API_QUEUE_SEARCH", {"filter": app.current.filter, "offset": app.current.offset, "limit": app.current.limit, "searchstr": app.current.search, "cols": settings.colsQueueCurrent}, parseQueue, false);
    }
    else {
        sendAPI("MPD_API_QUEUE_LIST", {"offset": app.current.offset, "limit": app.current.limit, "cols": settings.colsQueueCurrent}, parseQueue, false);
    }
}

function parseQueue(obj) {
    if (obj.result.offset < app.current.offset) {
        gotoPage(obj.result.offset);
        return;
    }

    if (obj.result.totalEntities > settings.maxElementsPerPage) {
        document.getElementById('btnQueueGotoPlayingSong').parentNode.classList.remove('hide');
    }
    else {
        document.getElementById('btnQueueGotoPlayingSong').parentNode.classList.add('hide');
    }

    let table = document.getElementById('QueueCurrentList');
    let tfoot = table.getElementsByTagName('tfoot')[0];

    let colspan = settings['colsQueueCurrent'].length;

    if (obj.result.totalTime && obj.result.totalTime > 0 && obj.result.totalEntities <= app.current.limit ) {
        tfoot.innerHTML = '<tr><td colspan="' + (colspan + 1) + '"><small>' + t('Num songs', obj.result.totalEntities) + '&nbsp;&ndash;&nbsp;' + beautifyDuration(obj.result.totalTime) + '</small></td></tr>';
    }
    else if (obj.result.totalEntities > 0) {
        tfoot.innerHTML = '<tr><td colspan="' + (colspan + 1) + '"><small>' + t('Num songs', obj.result.totalEntities) + '</small></td></tr>';
    }
    else {
        tfoot.innerHTML = '';
    }

    if (obj.result.totalEntities > settings.maxElementsPerPage) {
        document.getElementById('btnQueueGotoPlayingSong').parentNode.classList.remove('hide');
    }
    else {
        document.getElementById('btnQueueGotoPlayingSong').parentNode.classList.add('hide');
    }

    let nrItems = obj.result.returnedEntities;
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    table.setAttribute('data-version', obj.result.queueVersion);
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].Pos++;
        let row = document.createElement('tr');
        row.setAttribute('draggable', 'true');
        row.setAttribute('data-trackid', obj.result.data[i].id);
        row.setAttribute('id','queueTrackId' + obj.result.data[i].id);
        row.setAttribute('data-songpos', obj.result.data[i].Pos);
        row.setAttribute('data-duration', obj.result.data[i].Duration);
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < settings.colsQueueCurrent.length; c++) {
            tds += '<td data-col="' + settings.colsQueueCurrent[c] + '">' + e(obj.result.data[i][settings.colsQueueCurrent[c]]) + '</td>';
        }
        tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
        if ('IntersectionObserver' in window) {
            let options = {
                root: null,
                rootMargin: '0px',
            };
            let observer = new IntersectionObserver(setRowImage, options);
            observer.observe(row);
        }
        else {
            row.firstChild.firstChild.src = subdir + '/albumart/' + obj.result.data[i].uri;
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    if (obj.result.method === 'MPD_API_QUEUE_SEARCH' && nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('No results, please refine your search') + '</td></tr>';
    }
    else if (obj.result.method === 'MPD_API_QUEUE_LIST' && nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('Empty queue') + '</td></tr>';
    }

    if (navigate === true) {
        focusTable(activeRow);
    }
    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    document.getElementById('QueueCurrentList').classList.remove('opacity05');

    scrollToPosY(app.current.scrollPos);
}

function setRowImage(changes, observer) {
    changes.forEach(change => {
        if (change.intersectionRatio > 0) {
            observer.unobserve(change.target);
            const uri = change.target.getAttribute('data-uri');
            change.target.firstChild.firstChild.src = subdir + '/albumart/' + uri;
        }
    });
}

function parseLastPlayed(obj) {
    //document.getElementById('cardFooterQueue').innerText = t('Num songs', obj.result.totalEntities);
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('QueueLastPlayedList');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].LastPlayed = localeDate(obj.result.data[i].LastPlayed);
        let row = document.createElement('tr');
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('data-name', obj.result.data[i].Title);
        row.setAttribute('data-type', 'song');
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < settings.colsQueueLastPlayed.length; c++) {
            tds += '<td data-col="' + settings.colsQueueLastPlayed[c] + '">' + e(obj.result.data[i][settings.colsQueueLastPlayed[c]]) + '</td>';
        }
        tds += '<td data-col="Action">';
        if (obj.result.data[i].uri !== '') {
            tds += '<a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a>';
        }
        tds += '</td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }                    

    let colspan = settings['colsQueueLastPlayed'].length;
    
    if (nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    }

    if (navigate === true) {
        focusTable(activeRow);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    document.getElementById('QueueLastPlayedList').classList.remove('opacity05');
}

//eslint-disable-next-line no-unused-vars
function queueSelectedItem(append) {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id === 'QueueCurrentList') {
            return;
        }
        if (append === true) {
            appendQueue(item.getAttribute('data-type'), item.getAttribute('data-uri'), item.getAttribute('data-name'));
        }
        else {
            replaceQueue(item.getAttribute('data-type'), item.getAttribute('data-uri'), item.getAttribute('data-name'));
        }
    }
}

//eslint-disable-next-line no-unused-vars
function dequeueSelectedItem() {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id !== 'QueueCurrentList') {
            return;
        }
        delQueueSong('single', item.getAttribute('data-trackid'));
    }
}

function appendQueue(type, uri, name) {
    switch(type) {
        case 'song':
        case 'dir':
            sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": uri});
            showNotification(t('%{name} added to queue', {"name": name}), '', '', 'success');
            break;
        case 'plist':
            sendAPI("MPD_API_QUEUE_ADD_PLAYLIST", {"plist": uri});
            showNotification(t('%{name} added to queue', {"name": name}), '', '', 'success');
            break;
    }
}

//eslint-disable-next-line no-unused-vars
function appendAfterQueue(type, uri, to, name) {
    switch(type) {
        case 'song':
            sendAPI("MPD_API_QUEUE_ADD_TRACK_AFTER", {"uri": uri, "to": to});
            to++;
            showNotification(t('%{name} added to queue position %{to}', {"name": name, "to": to}), '', '', 'success');
            break;
    }
}

function replaceQueue(type, uri, name) {
    switch(type) {
        case 'song':
        case 'dir':
            sendAPI("MPD_API_QUEUE_REPLACE_TRACK", {"uri": uri});
            showNotification(t('Queue replaced with %{name}', {"name": name}), '', '', 'success');
            break;
        case 'plist':
            sendAPI("MPD_API_QUEUE_REPLACE_PLAYLIST", {"plist": uri});
            showNotification(t('Queue replaced with %{name}', {"name": name}), '', '', 'success');
            break;
    }
}

//eslint-disable-next-line no-unused-vars
function addToQueue() {
    let formOK = true;
    let inputAddToQueueQuantityEl = document.getElementById('inputAddToQueueQuantity');
    if (!validateInt(inputAddToQueueQuantityEl)) {
        formOK = false;
    }
    
    let selectAddToQueueMode = document.getElementById('selectAddToQueueMode');
    let jukeboxMode = selectAddToQueueMode.options[selectAddToQueueMode.selectedIndex].value

    let selectAddToQueuePlaylist = document.getElementById('selectAddToQueuePlaylist');
    let jukeboxPlaylist = selectAddToQueuePlaylist.options[selectAddToQueuePlaylist.selectedIndex].value;
    
    if (jukeboxMode === '1' && settings.featSearchwindow === false && jukeboxPlaylist === 'Database') {
        document.getElementById('warnJukeboxPlaylist2').classList.remove('hide');
        formOK = false;
    }
    
    if (formOK === true) {
        sendAPI("MPD_API_QUEUE_ADD_RANDOM", {
            "mode": jukeboxMode,
            "playlist": jukeboxPlaylist,
            "quantity": document.getElementById('inputAddToQueueQuantity').value
        });
        modalAddToQueue.hide();
    }
}

//eslint-disable-next-line no-unused-vars
function saveQueue() {
    let plName = document.getElementById('saveQueueName').value;
    if (validatePlname(plName) === true) {
        sendAPI("MPD_API_QUEUE_SAVE", {"plist": plName});
        modalSaveQueue.hide();
    }
    else {
        document.getElementById('saveQueueName').classList.add('is-invalid');
    }
}

function delQueueSong(mode, start, end) {
    if (mode === 'range') {
        sendAPI("MPD_API_QUEUE_RM_RANGE", {"start": start, "end": end});
    }
    else if (mode === 'single') {
        sendAPI("MPD_API_QUEUE_RM_TRACK", { "track": start});
    }
}

//eslint-disable-next-line no-unused-vars
function gotoPlayingSong() {
    let offset = lastState.songPos < settings.maxElementsPerPage ? 0 : Math.floor(lastState.songPos / settings.maxElementsPerPage) * settings.maxElementsPerPage;
    gotoPage(offset);
}

//eslint-disable-next-line no-unused-vars
function playAfterCurrent(trackid, songpos) {
    if (settings.random === 0) {
        //not in random mode - move song after current playling song
        let newSongPos = lastState.songPos !== undefined ? lastState.songPos + 2 : 0;
        sendAPI("MPD_API_QUEUE_MOVE_TRACK", {"from": songpos, "to": newSongPos});
    }
    else {
        //in random mode - set song priority
        sendAPI("MPD_API_QUEUE_PRIO_SET_HIGHEST", {"trackid": trackid});
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function saveScript() {
    let formOK = true;
    
    let nameEl = document.getElementById('inputScriptName');
    if (!validatePlnameEl(nameEl)) {
        formOK = false;
    }
    
    let orderEl = document.getElementById('inputScriptOrder');
    if (!validateInt(orderEl)) {
        formOK = false;
    }
    
    if (formOK === true) {
        let args = [];
        let argSel = document.getElementById('selectScriptArguments');
        for (let i = 0; i < argSel.options.length; i++) {
            args.push(argSel.options[i].text);
        }
        sendAPI("MYMPD_API_SCRIPT_SAVE", {
            "oldscript": document.getElementById('inputOldScriptName').value,
            "script": nameEl.value,
            "order": parseInt(orderEl.value),
            "content": document.getElementById('textareaScriptContent').value,
            "arguments": args
            }, showListScripts, false);
    }
}

function addScriptArgument() {
    let el = document.getElementById('inputScriptArgument');
    if (validatePlnameEl(el)) {
        let o = document.createElement('option');
        o.text = el.value;
        document.getElementById('selectScriptArguments').appendChild(o);
        el.value = '';
    }
}

function removeScriptArgument(ev) {
    let el = document.getElementById('inputScriptArgument');
    el.value = ev.target.text;
    ev.target.remove();
    el.focus();  
}

//eslint-disable-next-line no-unused-vars
function showEditScript(script) {
    document.getElementById('listScripts').classList.remove('active');
    document.getElementById('editScript').classList.add('active');
    document.getElementById('listScriptsFooter').classList.add('hide');
    document.getElementById('editScriptFooter').classList.remove('hide');
    
    document.getElementById('inputScriptName').classList.remove('is-invalid');
    document.getElementById('inputScriptOrder').classList.remove('is-invalid');
    document.getElementById('inputScriptArgument').classList.remove('is-invalid');
    
    if (script !== '') {
        sendAPI("MYMPD_API_SCRIPT_GET", {"script": script}, parseEditScript, false);
    }
    else {
        document.getElementById('inputOldScriptName').value = '';
        document.getElementById('inputScriptName').value = '';
        document.getElementById('inputScriptOrder').value = '1';
        document.getElementById('inputScriptArgument').value = '';
        document.getElementById('selectScriptArguments').innerText = '';
        document.getElementById('textareaScriptContent').value = '';
    }
}

function parseEditScript(obj) {
    document.getElementById('inputOldScriptName').value = obj.result.script;
    document.getElementById('inputScriptName').value = obj.result.script;
    document.getElementById('inputScriptOrder').value = obj.result.metadata.order;
    document.getElementById('inputScriptArgument').value = '';
    let selSA = document.getElementById('selectScriptArguments');
    selSA.innerText = '';
    for (let i = 0; i < obj.result.metadata.arguments.length; i++) {
        let o = document.createElement('option');
        o.innerText = obj.result.metadata.arguments[i];
        selSA.appendChild(o);
    }
    document.getElementById('textareaScriptContent').value = obj.result.content;
}

function showListScripts() {
    document.getElementById('listScripts').classList.add('active');
    document.getElementById('editScript').classList.remove('active');
    document.getElementById('listScriptsFooter').classList.remove('hide');
    document.getElementById('editScriptFooter').classList.add('hide');
    sendAPI("MYMPD_API_SCRIPT_LIST", {"all": true}, parseScriptList);
}

function deleteScript(script) {
    sendAPI("MYMPD_API_SCRIPT_DELETE", {"script": script}, function() {
        getScriptList(true);
    }, false);
}

function getScriptList(all) {
    sendAPI("MYMPD_API_SCRIPT_LIST", {"all": all}, parseScriptList, false);
}

function parseScriptList(obj) {
    let timerActions = document.createElement('optgroup');
    timerActions.setAttribute('data-value', 'script');
    timerActions.setAttribute('label', t('Script'));
    let scriptMaxListLen = 4;
    let scriptListMain = ''; //list in main menu
    let scriptList = ''; //list in scripts dialog
    let scriptListLen = obj.result.data.length;
    let showScriptListLen = 0;
    if (scriptListLen > 0) {
        obj.result.data.sort(function(a, b) {
            return a.metadata.order - b.metadata.order;
        });
        for (let i = 0; i < scriptListLen; i++) {
            let arglist = '';
            if (obj.result.data[i].metadata.arguments.length > 0) {
                for (let j = 0; j < obj.result.data[i].metadata.arguments.length; j++) {
                    obj.result.data[i].metadata.arguments[j] = e(obj.result.data[i].metadata.arguments[j]);
                }
                arglist = '"' + obj.result.data[i].metadata.arguments.join('","') + '"';
            }
            if (obj.result.data[i].metadata.order > 0) {
                showScriptListLen++;
                scriptListMain += '<a class="dropdown-item text-light alwaysEnabled" href="#" data-href=\'{"script": "' + 
                    e(obj.result.data[i].name) + '", "arguments": [' + arglist + ']}\'>' + e(obj.result.data[i].name) + '</a>';
                
            }
            scriptList += '<tr data-script="' + encodeURI(obj.result.data[i].name) + '"><td>' + e(obj.result.data[i].name) + '</td>' +
                '<td data-col="Action">' +
                    (settings.featScripteditor === true ? 
                        '<a href="#" title="' + t('Delete') + '" data-action="delete" class="material-icons color-darkgrey">delete</a>' : '') +
                        '<a href="#" title="' + t('Execute') + '" data-action="execute" class="material-icons color-darkgrey" ' +
                            ' data-href=\'{"script": "' + e(obj.result.data[i].name) + '", "arguments": [' + arglist + ']}\'>play_arrow</a>' +
                        '<a href="#" title="' + t('Add to homescreen') + '" data-action="add2home" class="material-icons color-darkgrey" ' +
                            ' data-href=\'{"script": "' + e(obj.result.data[i].name) + '", "arguments": [' + arglist + ']}\'>add_to_home_screen</a>' +
                '</td></tr>';
            timerActions.innerHTML += '<option data-arguments=\'{"arguments":[' + arglist + ']}\' value="' + 
                e(obj.result.data[i].name) + '">' + e(obj.result.data[i].name) + '</option>';
        }
        document.getElementById('listScriptsList').innerHTML = scriptList;
    }
    else {
        document.getElementById('listScriptsList').innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="2">' + t('Empty list') + '</td></tr>';
    }
    document.getElementById('scripts').innerHTML = (showScriptListLen > scriptMaxListLen || showScriptListLen === 0 ? '' : '<div class="dropdown-divider"></div>') + scriptListMain;
        
    if (showScriptListLen > scriptMaxListLen) {
        document.getElementById('navScripting').classList.remove('hide');
        document.getElementById('scripts').classList.add('collapse', 'menu-indent');
    }
    else {
        document.getElementById('navScripting').classList.add('hide');
        document.getElementById('scripts').classList.remove('collapse', 'menu-indent');
    }

    document.getElementById('selectTriggerScript').innerHTML = timerActions.innerHTML;
    
    let old = document.getElementById('selectTimerAction').querySelector('optgroup[data-value="script"]');
    if (old) {
        old.replaceWith(timerActions);
    }
    else {
        document.getElementById('selectTimerAction').appendChild(timerActions);
    }
}

//eslint-disable-next-line no-unused-vars
function execScriptFromOptions(cmd, options) {
    let args = options !== undefined && options !== '' ? options.split(',') : [];
    let script = {"script": cmd, "arguments": args};
    execScript(JSON.stringify(script));
}

function execScript(href) {
    let cmd = JSON.parse(href);
    if (cmd.arguments.length === 0) {
        sendAPI("MYMPD_API_SCRIPT_EXECUTE", {"script": cmd.script, "arguments": {}});
    }
    else {
        let arglist ='';
        for (let i = 0; i < cmd.arguments.length; i++) {
            arglist += '<div class="form-group row">' +
                  '<label class="col-sm-4 col-form-label" for="inputScriptArg' + i + '">' + e(cmd.arguments[i]) +'</label>' +
                  '<div class="col-sm-8">' +
                     '<input name="' + e(cmd.arguments[i]) + '" id="inputScriptArg' + i + '" type="text" class="form-control border-secondary" value="">' +
                  '</div>' +
                '</div>';

        }
        document.getElementById('execScriptArguments').innerHTML = arglist;
        document.getElementById('modalExecScriptScriptname').value = cmd.script;
        modalExecScript.show();
    }
}

//eslint-disable-next-line no-unused-vars
function execScriptArgs() {
    let script = document.getElementById('modalExecScriptScriptname').value;
    let args = {};
    let inputs = document.getElementById('execScriptArguments').getElementsByTagName('input');
    for (let i = 0; i < inputs.length; i++) {
        args[inputs[i].name] = inputs[i].value;
    }
    sendAPI("MYMPD_API_SCRIPT_EXECUTE", {"script": script, "arguments": args});
    modalExecScript.hide();
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function doSearch(x) {
    if (settings.featAdvsearch) {
        let expression = '(';
        let crumbs = domCache.searchCrumb.children;
        for (let i = 0; i < crumbs.length; i++) {
            expression += '(' + decodeURI(crumbs[i].getAttribute('data-filter-tag')) + ' ' + 
                decodeURI(crumbs[i].getAttribute('data-filter-op')) + ' \'' + 
                escapeMPD(decodeURI(crumbs[i].getAttribute('data-filter-value'))) + '\')';
            if (x !== '') {
                expression += ' AND ';
            }
        }
        if (x !== '') {
            let match = document.getElementById('searchMatch');
            expression += '(' + app.current.filter + ' ' + match.options[match.selectedIndex].value + ' \'' + escapeMPD(x) +'\'))';
        }
        else {
            expression += ')';
        }
        if (expression.length <= 2) {
            expression = '';
        }
        appGoto('Search', undefined, undefined, '0', app.current.limit, app.current.filter, app.current.sort, '-', expression);
    }
    else {
        appGoto('Search', undefined, undefined, '0', app.current.limit, app.current.filter, app.current.sort, '-', x);
    }
}

function parseSearch(obj) {
    //document.getElementById('panel-heading-search').innerText = gtPage('Num songs', obj.result.returnedEntities, obj.result.totalEntities);
    //document.getElementById('cardFooterSearch').innerText = gtPage('Num songs', obj.result.returnedEntities, obj.result.totalEntities);
    
    if (obj.result.returnedEntities > 0) {
        document.getElementById('searchAddAllSongs').removeAttribute('disabled');
        document.getElementById('searchAddAllSongsBtn').removeAttribute('disabled');
    } 
    else {
        document.getElementById('searchAddAllSongs').setAttribute('disabled', 'disabled');
        document.getElementById('searchAddAllSongsBtn').setAttribute('disabled', 'disabled');
    }
    parseFilesystem(obj);
}

//eslint-disable-next-line no-unused-vars
function saveSearchAsSmartPlaylist() {
    parseSmartPlaylist({"jsonrpc":"2.0","id":0,"result":{"method":"MPD_API_SMARTPLS_GET", 
        "playlist":"",
        "type":"search",
        "tag": settings.featAdvsearch === true ? 'expression' : app.current.filter,
        "searchstr": app.current.search}});
}

function addAllFromSearchPlist(plist, searchstr, replace) {
    if (searchstr === null) {
        searchstr = app.current.search;    
    }
    if (settings.featAdvsearch) {
        sendAPI("MPD_API_DATABASE_SEARCH_ADV", {"plist": plist, 
            "sort": "", 
            "sortdesc": false, 
            "expression": searchstr,
            "offset": 0,
            "limit": 0,
            "cols": settings.colsSearch, 
            "replace": replace});
    }
    else {
        sendAPI("MPD_API_DATABASE_SEARCH", {"plist": plist, 
            "filter": app.current.filter, 
            "searchstr": searchstr,
            "offset": 0,
            "limit": 0, 
            "cols": settings.colsSearch, 
            "replace": replace});
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function saveConnection() {
    let formOK = true;
    let mpdHostEl = document.getElementById('inputMpdHost');
    let mpdPortEl = document.getElementById('inputMpdPort');
    let mpdPassEl = document.getElementById('inputMpdPass');
    let musicDirectoryEl  = document.getElementById('selectMusicDirectory');
    let musicDirectory = musicDirectoryEl.options[musicDirectoryEl.selectedIndex].value;
    
    if (musicDirectory === 'custom') {
        let musicDirectoryValueEl  = document.getElementById('inputMusicDirectory');
        if (!validatePath(musicDirectoryValueEl)) {
            formOK = false;        
        }
        musicDirectory = musicDirectoryValueEl.value;
    }    
    
    if (mpdPortEl.value === '') {
        mpdPortEl.value = '6600';
    }
    if (mpdHostEl.value.indexOf('/') !== 0) {
        if (!validateInt(mpdPortEl)) {
            formOK = false;        
        }
        if (!validateHost(mpdHostEl)) {
            formOK = false;        
        }
    }
    if (formOK === true) {
        sendAPI("MYMPD_API_CONNECTION_SAVE", {
            "mpdHost": mpdHostEl.value,
            "mpdPort": mpdPortEl.value,
            "mpdPass": mpdPassEl.value,
            "musicDirectory": musicDirectory
        }, getSettings);
        modalConnection.hide();    
    }
}

function getSettings(onerror) {
    if (settingsLock === false) {
        settingsLock = true;
        sendAPI("MYMPD_API_SETTINGS_GET", {}, getMpdSettings, onerror);
    }
}

function getMpdSettings(obj) {
    if (obj !== '' && obj.result) {
        settingsNew = obj.result;
        document.getElementById('splashScreenAlert').innerText = t('Fetch MPD settings');
        sendAPI("MPD_API_SETTINGS_GET", {}, joinSettings, true);
    }
    else {
        settingsParsed = 'error';
        if (appInited === false) {
            showAppInitAlert(obj === '' ? t('Can not parse settings') : t(obj.error.message));
        }
        return false;
    }
}

function joinSettings(obj) {
    if (obj !== '' && obj.result) {
        for (let key in obj.result) {
            settingsNew[key] = obj.result[key];
        }
    }
    else {
        settingsParsed = 'error';
        if (appInited === false) {
            showAppInitAlert(obj === '' ? t('Can not parse settings') : t(obj.error.message));
        }
        settingsNew.mpdConnected = false;
    }
    settings = Object.assign({}, settingsNew);
    settingsLock = false;
    parseSettings();
    toggleUI();
    if (settings.mpdConnected === true) {
        sendAPI("MPD_API_URLHANDLERS", {}, parseUrlhandlers,false);
    }
    btnWaiting(document.getElementById('btnApplySettings'), false);
}

function parseUrlhandlers(obj) {
    let storagePlugins = '';
    for (let i = 0; i < obj.result.data.length; i++) {
        switch(obj.result.data[i]) {
            case 'http://':
            case 'https://':
            case 'nfs://':
            case 'smb://':
                storagePlugins += '<option value="' + obj.result.data[i] + '">' + obj.result.data[i] + '</option>';
                break;
        }
    }
    document.getElementById('selectMountUrlhandler').innerHTML = storagePlugins;
}

function checkConsume() {
    let stateConsume = document.getElementById('btnConsume').classList.contains('active') ? true : false;
    let stateJukeboxMode = getBtnGroupValue('btnJukeboxModeGroup');
    if (stateJukeboxMode > 0 && stateConsume === false) {
        document.getElementById('warnConsume').classList.remove('hide');
    }
    else {
        document.getElementById('warnConsume').classList.add('hide');
    }
}

function parseSettings() {
    if (settings.locale === 'default') {
        locale = navigator.language || navigator.userLanguage;
    }
    else {
        locale = settings.locale;
    }
    
    if (isMobile === true) {    
        document.getElementById('inputScaleRatio').value = scale;
    }

    let setTheme = settings.theme;
    if (settings.theme === 'theme-autodetect') {
        setTheme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'theme-dark' : 'theme-default';
    }    

    Object.keys(themes).forEach(function(key) {
        if (key === setTheme) {
            domCache.body.classList.add(key);
        }
        else {
            domCache.body.classList.remove(key);
        }
    });

    setNavbarIcons();

    if (settings.footerStop === 'both') {
        document.getElementById('btnStop').classList.remove('hide');
    }
    else {
        document.getElementById('btnStop').classList.add('hide');
    }
    
    document.getElementById('selectTheme').value = settings.theme;
    
    if (settings.mpdConnected === true) {
        parseMPDSettings();
    }
    
    if (settings.mpdHost.indexOf('/') !== 0) {
        document.getElementById('mpdInfo_host').innerText = settings.mpdHost + ':' + settings.mpdPort;
    }
    else {
        document.getElementById('mpdInfo_host').innerText = settings.mpdHost;
    }
    
    document.getElementById('inputMpdHost').value = settings.mpdHost;
    document.getElementById('inputMpdPort').value = settings.mpdPort;
    document.getElementById('inputMpdPass').value = settings.mpdPass;

    let btnNotifyWeb = document.getElementById('btnNotifyWeb');
    document.getElementById('warnNotifyWeb').classList.add('hide');
    if (notificationsSupported()) {
        if (Notification.permission !== 'granted') {
            if (settings.notificationWeb === true) {
                document.getElementById('warnNotifyWeb').classList.remove('hide');
            }
            settings.notificationWeb = false;
        }
        if (Notification.permission === 'denied') {
            document.getElementById('warnNotifyWeb').classList.remove('hide');
        }
        toggleBtnChk('btnNotifyWeb', settings.notificationWeb);
        btnNotifyWeb.removeAttribute('disabled');
    }
    else {
        btnNotifyWeb.setAttribute('disabled', 'disabled');
        toggleBtnChk('btnNotifyWeb', false);
    }
    
    toggleBtnChk('btnNotifyPage', settings.notificationPage);
    toggleBtnChk('btnMediaSession', settings.mediaSession);
    toggleBtnChkCollapse('btnFeatLocalplayer', 'collapseLocalplayer', settings.featLocalplayer);
    toggleBtnChk('btnFeatTimer', settings.featTimer);
    toggleBtnChk('btnBookmarks', settings.featBookmarks);
    toggleBtnChk('btnFeatLyrics', settings.featLyrics);

    if (settings.streamUrl === '') {
        document.getElementById('selectStreamMode').value = 'port';
        document.getElementById('inputStreamUrl').value = settings.streamPort;
    }
    else {
        document.getElementById('selectStreamMode').value = 'url';
        document.getElementById('inputStreamUrl').value = settings.streamUrl;
    }
    toggleBtnChkCollapse('btnCoverimage', 'collapseAlbumart', settings.coverimage);

    document.getElementById('inputBookletName').value = settings.bookletName;
    
    document.getElementById('selectLocale').value = settings.locale;
    document.getElementById('inputCoverimageName').value = settings.coverimageName;

    document.getElementById('inputCoverimageSize').value = settings.coverimageSize;
    document.getElementById('inputCoverimageSizeSmall').value = settings.coverimageSizeSmall;

    document.documentElement.style.setProperty('--mympd-coverimagesize', settings.coverimageSize + "px");
    document.documentElement.style.setProperty('--mympd-coverimagesizesmall', settings.coverimageSizeSmall + "px");
    document.documentElement.style.setProperty('--mympd-highlightcolor', settings.highlightColor);
    
    document.getElementById('inputHighlightColor').value = settings.highlightColor;
    document.getElementById('inputBgColor').value = settings.bgColor;
    document.getElementsByTagName('body')[0].style.backgroundColor = settings.bgColor;
    
    toggleBtnChkCollapse('btnBgCover', 'collapseBackground', settings.bgCover);
    document.getElementById('inputBgCssFilter').value = settings.bgCssFilter;    

    let albumartbg = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < albumartbg.length; i++) {
        albumartbg[i].style.filter = settings.bgCssFilter;
    }

    toggleBtnChkCollapse('btnLoveEnable', 'collapseLove', settings.love);
    document.getElementById('inputLoveChannel').value = settings.loveChannel;
    document.getElementById('inputLoveMessage').value = settings.loveMessage;
    
    document.getElementById('selectMaxElementsPerPage').value = settings.maxElementsPerPage;
    app.apps.Home.limit = settings.maxElementsPerPage;
    app.apps.Playback.limit = settings.maxElementsPerPage;
    app.apps.Queue.tabs.Current.limit = settings.maxElementsPerPage;
    app.apps.Queue.tabs.LastPlayed.limit = settings.maxElementsPerPage;
    app.apps.Queue.tabs.Jukebox.limit = settings.maxElementsPerPage;
    app.apps.Browse.tabs.Filesystem.limit = settings.maxElementsPerPage;
    app.apps.Browse.tabs.Playlists.views.All.limit = settings.maxElementsPerPage;
    app.apps.Browse.tabs.Playlists.views.Detail.limit = settings.maxElementsPerPage;
    app.apps.Browse.tabs.Database.views.List.limit = settings.maxElementsPerPage;
    app.apps.Browse.tabs.Database.views.Detail.limit = settings.maxElementsPerPage;
    app.apps.Search.limit = settings.maxElementsPerPage;
    
    toggleBtnChk('btnStickers', settings.stickers);
    document.getElementById('inputLastPlayedCount').value = settings.lastPlayedCount;
    
    toggleBtnChkCollapse('btnSmartpls', 'collapseSmartpls', settings.smartpls);
    
    let features = ["featLocalplayer", "featSyscmds", "featMixramp", "featCacert", "featBookmarks", 
        "featRegex", "featTimer", "featLyrics", "featScripting", "featScripteditor", "featHome"];
    for (let j = 0; j < features.length; j++) {
        let Els = document.getElementsByClassName(features[j]);
        let ElsLen = Els.length;
        let displayEl = settings[features[j]] === true ? '' : 'none';
        for (let i = 0; i < ElsLen; i++) {
            Els[i].style.display = displayEl;
        }
    }
    
    let readonlyEls = document.getElementsByClassName('warnReadonly');
    for (let i = 0; i < readonlyEls.length; i++) {
        if (settings.readonly === false) {
            readonlyEls[i].classList.add('hide');
        }
        else {
            readonlyEls[i].classList.remove('hide');
        }
    }
    if (settings.readonly === true) {
        document.getElementById('btnBookmarks').setAttribute('disabled', 'disabled');
        document.getElementsByClassName('groupClearCovercache')[0].classList.add('hide');
    }
    else {
        document.getElementById('btnBookmarks').removeAttribute('disabled');
        document.getElementsByClassName('groupClearCovercache')[0].classList.remove('hide');
    }
    
    let timerActions = '<optgroup data-value="player" label="' + t('Playback') + '">' +
        '<option value="startplay">' + t('Start playback') + '</option>' +
        '<option value="stopplay">' + t('Stop playback') + '</option>' +
        '</optgroup>';

    if (settings.featSyscmds === true) {
        let syscmdsMaxListLen = 4;
        let syscmdsList = '';
        let syscmdsListLen = settings.syscmdList.length;
        if (syscmdsListLen > 0) {
            timerActions += '<optgroup data-value="syscmd" label="' + t('System command') + '">';
            syscmdsList = syscmdsListLen > syscmdsMaxListLen ? '' : '<div class="dropdown-divider"></div>';
            for (let i = 0; i < syscmdsListLen; i++) {
                if (settings.syscmdList[i] === 'HR') {
                    syscmdsList += '<div class="dropdown-divider"></div>';
                }
                else {
                    syscmdsList += '<a class="dropdown-item text-light alwaysEnabled" href="#" data-href=\'{"cmd": "execSyscmd", "options": ["' + 
                        e(settings.syscmdList[i]) + '"]}\'>' + e(settings.syscmdList[i]) + '</a>';
                    timerActions += '<option value="' + e(settings.syscmdList[i]) + '">' + e(settings.syscmdList[i]) + '</option>';
                }
            }
        }
        document.getElementById('syscmds').innerHTML = syscmdsList;
        timerActions += '</optgroup>';
        
        if (syscmdsListLen > syscmdsMaxListLen) {
            document.getElementById('navSyscmds').classList.remove('hide');
            document.getElementById('syscmds').classList.add('collapse', 'menu-indent');
        }
        else {
            document.getElementById('navSyscmds').classList.add('hide');
            document.getElementById('syscmds').classList.remove('collapse', 'menu-indent');
        }
    }
    else {
        document.getElementById('syscmds').innerHTML = '';
    }

    if (settings.featScripting === true) {
        getScriptList(true);
    }
    else {
        document.getElementById('scripts').innerHTML = '';
    }

    document.getElementById('selectTimerAction').innerHTML = timerActions;
    
    toggleBtnGroupValueCollapse(document.getElementById('btnJukeboxModeGroup'), 'collapseJukeboxMode', settings.jukeboxMode);
    document.getElementById('selectJukeboxUniqueTag').value = settings.jukeboxUniqueTag;
    document.getElementById('inputJukeboxQueueLength').value = settings.jukeboxQueueLength;
    document.getElementById('inputJukeboxLastPlayed').value = settings.jukeboxLastPlayed;
    
    if (settings.jukeboxMode === 0) {
        document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
    }
    else if (settings.jukeboxMode === 2) {
        document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').value = 'Database';
    }
    else if (settings.jukeboxMode === 1) {
        document.getElementById('inputJukeboxQueueLength').removeAttribute('disabled');
        document.getElementById('selectJukeboxPlaylist').removeAttribute('disabled');
    }

    document.getElementById('inputSmartplsPrefix').value = settings.smartplsPrefix;
    document.getElementById('inputSmartplsInterval').value = settings.smartplsInterval / 60 / 60;
    document.getElementById('selectSmartplsSort').value = settings.smartplsSort;

    domCache.volumeBar.setAttribute('min', settings.volumeMin);
    domCache.volumeBar.setAttribute('max', settings.volumeMax);

    if (settings.featLocalplayer === true) {
        setLocalPlayerUrl();
    }
    
    if (settings.musicDirectory === 'auto') {
        document.getElementById('selectMusicDirectory').value = settings.musicDirectory;
        document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue !== undefined ? settings.musicDirectoryValue : '';
        document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
    }
    else if (settings.musicDirectory === 'none') {
        document.getElementById('selectMusicDirectory').value = settings.musicDirectory;
        document.getElementById('inputMusicDirectory').value = '';
        document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
    }
    else {
        document.getElementById('selectMusicDirectory').value = 'custom';
        document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue;
        document.getElementById('inputMusicDirectory').removeAttribute('readonly');
    }

    //update columns
    if (app.current.app === 'Queue' && app.current.tab === 'Current') {
        getQueue();
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        appRoute();
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'Jukebox') {
        appRoute();
    }
    else if (app.current.app === 'Search') {
        appRoute();
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Filesystem') {
        appRoute();
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        appRoute();
    }
    else if ((app.current.app === 'Browse' || app.current.app === 'Playback') && app.current.tab === 'Database' && app.current.search !== '') {
        calcBoxHeight();
        appRoute();
    }

    i18nHtml(document.getElementsByTagName('body')[0]);

    checkConsume();

    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        navigator.mediaSession.setActionHandler('play', clickPlay);
        navigator.mediaSession.setActionHandler('pause', clickPlay);
        navigator.mediaSession.setActionHandler('stop', clickStop);
        navigator.mediaSession.setActionHandler('seekbackward', seekRelativeBackward);
        navigator.mediaSession.setActionHandler('seekforward', seekRelativeForward);
        navigator.mediaSession.setActionHandler('previoustrack', clickPrev);
        navigator.mediaSession.setActionHandler('nexttrack', clickNext);
        
        if (!navigator.mediaSession.setPositionState) {
            logDebug('mediaSession.setPositionState not supported by browser');
        }
    }
    else {
        logDebug('mediaSession not supported by browser');
    }

    parseCollybiaSettings();
    settingsParsed = 'true';
}

function parseMPDSettings() {
    toggleBtnChk('btnRandom', settings.random);
    toggleBtnChk('btnConsume', settings.consume);
    toggleBtnChk('btnRepeat', settings.repeat);
    toggleBtnChk('btnAutoPlay', settings.autoPlay);

    toggleBtnGroupValue(document.getElementById('btnSingleGroup'), settings.single);
    toggleBtnGroupValue(document.getElementById('btnReplaygainGroup'), settings.replaygain);

    document.getElementById('partitionName').innerText = settings.partition;
    
    document.getElementById('inputCrossfade').value = settings.crossfade;
    document.getElementById('inputMixrampdb').value = settings.mixrampdb;
    document.getElementById('inputMixrampdelay').value = settings.mixrampdelay;
    
    if (settings.featLibrary === true && settings.publish === true) {
        settings['featBrowse'] = true;    
    }
    else {
        settings['featBrowse'] = false;
    }

    let features = ['featStickers', 'featSmartpls', 'featPlaylists', 'featTags', 'featCoverimage', 'featAdvsearch',
        'featLove', 'featSingleOneshot', 'featBrowse', 'featMounts', 'featNeighbors',
        'featPartitions'];
    for (let j = 0; j < features.length; j++) {
        let Els = document.getElementsByClassName(features[j]);
        let ElsLen = Els.length;
        let displayEl = settings[features[j]] === true ? '' : 'none';
        if (features[j] === 'featCoverimage' && settings.coverimage === false) {
            displayEl = 'none';
        }
        for (let i = 0; i < ElsLen; i++) {
            Els[i].style.display = displayEl;
        }
    }
    
    if (settings.featPlaylists === false && settings.smartpls === true) {
        document.getElementById('warnSmartpls').classList.remove('hide');
    }
    else {
        document.getElementById('warnSmartpls').classList.add('hide');
    }
    
    if (settings.featPlaylists === true && settings.readonly === false) {
        document.getElementById('btnSmartpls').removeAttribute('disabled');
    }
    else {
        document.getElementById('btnSmartpls').setAttribute('disabled', 'disabled');
    }

    if (settings.featStickers === false && settings.stickers === true) {
        document.getElementById('warnStickers').classList.remove('hide');
    }
    else {
        document.getElementById('warnStickers').classList.add('hide');
    }
    
    if (settings.featStickers === false || settings.stickers === false || settings.featStickerCache === false) {
        document.getElementById('warnPlaybackStatistics').classList.remove('hide');
        document.getElementById('inputJukeboxLastPlayed').setAttribute('disabled', 'disabled');
    }
    else {
        document.getElementById('warnPlaybackStatistics').classList.add('hide');
        document.getElementById('inputJukeboxLastPlayed').removeAttribute('disabled');
    }
    
    if (settings.featLove === false && settings.love === true) {
        document.getElementById('warnScrobbler').classList.remove('hide');
    }
    else {
        document.getElementById('warnScrobbler').classList.add('hide');
    }
    
    if (settings.featLibrary === false && settings.coverimage === true) {
        document.getElementById('warnAlbumart').classList.remove('hide');
    }
    else {
        document.getElementById('warnAlbumart').classList.add('hide');
    }
    if (settings.musicDirectoryValue === '' && settings.musicDirectory !== 'none') {
        document.getElementById('warnMusicDirectory').classList.remove('hide');
    }
    else {
        document.getElementById('warnMusicDirectory').classList.add('hide');
    }

    document.getElementById('warnJukeboxPlaylist').classList.add('hide');

    if (settings.bgCover === true && settings.featCoverimage === true && settings.coverimage === true) {
        setBackgroundImage(lastSongObj.uri);
    }
    else {
        clearBackgroundImage();
    }

    let triggerEventList = '';
    Object.keys(settings.triggers).forEach(function(key) {
        triggerEventList += '<option value="' + e(settings.triggers[key]) + '">' + t(key) + '</option>';
    });
    document.getElementById('selectTriggerEvent').innerHTML = triggerEventList;
    
    settings.tags.sort();
    settings.searchtags.sort();
    settings.browsetags.sort();
    filterCols('colsSearch');
    filterCols('colsQueueCurrent');
    filterCols('colsQueueLastPlayed');
    filterCols('colsQueueJukebox');
    filterCols('colsBrowsePlaylistsDetail');
    filterCols('colsBrowseFilesystem');
    filterCols('colsBrowseDatabaseDetail');
    filterCols('colsPlayback');
    
    if (settings.featTags === false) {
        app.apps.Browse.active = 'Filesystem';
        app.apps.Search.sort = 'filename';
        app.apps.Search.filter = 'filename';
        app.apps.Queue.tabs.Current.filter = 'filename';
        settings.colsQueueCurrent = ["Pos", "Title", "Duration"];
        settings.colsQueueLastPlayed = ["Pos", "Title", "LastPlayed"];
        settings.colsQueueJukebox = ["Pos", "Title"];
        settings.colsSearch = ["Title", "Duration"];
        settings.colsBrowseFilesystem = ["Type", "Title", "Duration"];
        settings.colsBrowseDatabase = ["Track", "Title", "Duration"];
        settings.colsPlayback = [];
    }
    else {
        let pbtl = '';
        for (let i = 0; i < settings.colsPlayback.length; i++) {
            pbtl += '<div id="current' + settings.colsPlayback[i]  + '" data-tag="' + settings.colsPlayback[i] + '" ' +
                    (settings.colsPlayback[i] === 'Lyrics' ? '' : 'data-name="' + (lastSongObj[settings.colsPlayback[i]] ? encodeURI(lastSongObj[settings.colsPlayback[i]]) : '') + '"');

            if (settings.colsPlayback[i] === 'Album' && lastSongObj[tagAlbumArtist] !== null) {
                pbtl += 'data-albumartist="' + encodeURI(lastSongObj[tagAlbumArtist]) + '"';
            }

            pbtl += '>' +
                    '<small>' + t(settings.colsPlayback[i]) + '</small>' +
                    '<p';
            if (settings.browsetags.includes(settings.colsPlayback[i])) {
                pbtl += ' class="clickable"';
            }
            pbtl += '>';
            if (settings.colsPlayback[i] === 'Duration') {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? beautifySongDuration(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            else if (settings.colsPlayback[i] === 'LastModified') {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? localeDate(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            else if (settings.colsPlayback[i] === 'Fileformat') {
                pbtl += (lastState ? fileformat(lastState.audioFormat) : '');
            }
            else if (settings.colsPlayback[i].indexOf('MUSICBRAINZ') === 0) {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? getMBtagLink(settings.colsPlayback[i], lastSongObj[settings.colsPlayback[i]]) : '');
            }

            else {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? e(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            pbtl += '</p></div>';
        }
        document.getElementById('cardPlaybackTags').innerHTML = pbtl;
        //click on lyrics header to expand lyrics text container
        let cl = document.getElementById('currentLyrics');
        if (cl && lastSongObj.uri) {
            let el = cl.getElementsByTagName('small')[0];
            el.classList.add('clickable');
            el.addEventListener('click', function(event) {
                event.target.parentNode.children[1].classList.toggle('expanded');
            }, false);
            getLyrics(lastSongObj.uri, cl.getElementsByTagName('p')[0]);
        }
    }

    if (settings.tags.includes('Title')) {
        app.apps.Search.sort = 'Title';
    }
    
    if (settings.tags.includes('AlbumArtist')) {
        tagAlbumArtist = 'AlbumArtist';        
    }
    else if (settings.tags.includes('Artist')) {
        tagAlbumArtist = 'Artist';        
    }
    
    if (!settings.tags.includes('AlbumArtist') && app.apps.Browse.tabs.Database.views.List.filter === 'AlbumArtist') {
        app.apps.Browse.tabs.Database.views.List.filter = 'Artist';
        app.apps.Browse.tabs.Database.views.List.sort = 'Artist';
    }

    if (settings.featAdvsearch === false && app.apps.Browse.active === 'Database') {
        app.apps.Browse.active = 'Filesystem';
    }

    if (settings.featAdvsearch === false) {
        const tagEls = document.getElementById('cardPlaybackTags').getElementsByTagName('p');
        for (let i = 0; i < tagEls.length; i++) {
            tagEls[i].classList.remove('clickable');
        }
    }
    else {
        const tagEls = document.getElementById('cardPlaybackTags').getElementsByTagName('p');
        for (let i = 0; i < tagEls.length; i++) {
            tagEls[i].classList.add('clickable');
        }
    }
    
    if (settings.featPlaylists === true) {
        sendAPI("MPD_API_PLAYLIST_LIST", {"searchstr": "", "offset": 0, "limit": 0}, function(obj) {
            getAllPlaylists(obj, 'selectJukeboxPlaylist', settings.jukeboxPlaylist);
        });
    }
    else {
        document.getElementById('selectJukeboxPlaylist').innerHTML = '<option value="Database">' + t('Database') + '</option>';
    }

    setCols('QueueCurrent');
    setCols('Search');
    setCols('QueueLastPlayed');
    setCols('QueueJukebox');
    setCols('BrowseFilesystem');
    setCols('BrowsePlaylistsDetail');
    setCols('BrowseDatabaseDetail');
    setCols('Playback');

    addTagList('BrowseDatabaseByTagDropdown', 'browsetags');
    addTagList('BrowseNavPlaylistsDropdown', 'browsetags');
    addTagList('BrowseNavFilesystemDropdown', 'browsetags');
    
    addTagList('searchqueuetags', 'searchtags');
    addTagList('searchtags', 'searchtags');
    addTagList('searchDatabaseTags', 'browsetags');
    addTagList('databaseSortTagsList', 'browsetags');
    addTagList('dropdownSortPlaylistTags', 'tags');
    addTagList('saveSmartPlaylistSort', 'tags');
    
    addTagListSelect('selectSmartplsSort', 'tags');
    addTagListSelect('saveSmartPlaylistSort', 'tags');
    addTagListSelect('selectJukeboxUniqueTag', 'browsetags');
    
    initTagMultiSelect('inputEnabledTags', 'listEnabledTags', settings.allmpdtags, settings.tags);
    initTagMultiSelect('inputSearchTags', 'listSearchTags', settings.tags, settings.searchtags);
    initTagMultiSelect('inputBrowseTags', 'listBrowseTags', settings.tags, settings.browsetags);
    initTagMultiSelect('inputGeneratePlsTags', 'listGeneratePlsTags', settings.browsetags, settings.generatePlsTags);
}

//eslint-disable-next-line no-unused-vars
function resetSettings() {
    sendAPI("MYMPD_API_SETTINGS_RESET", {}, getSettings);
    modalSettings.hide();
}

//eslint-disable-next-line no-unused-vars
function saveSettings(closeModal) {
    let formOK = true;

    let inputCrossfade = document.getElementById('inputCrossfade');
    if (!inputCrossfade.getAttribute('disabled')) {
        if (!validateInt(inputCrossfade)) {
            formOK = false;
        }
    }

    let inputJukeboxQueueLength = document.getElementById('inputJukeboxQueueLength');
    if (!validateInt(inputJukeboxQueueLength)) {
        formOK = false;
    }

    let inputJukeboxLastPlayed = document.getElementById('inputJukeboxLastPlayed');
    if (!validateInt(inputJukeboxLastPlayed)) {
        formOK = false;
    }
    
    let selectStreamModeEl = document.getElementById('selectStreamMode');
    let streamUrl = '';
    let streamPort = '';
    let inputStreamUrl = document.getElementById('inputStreamUrl');
    if (selectStreamModeEl.options[selectStreamModeEl.selectedIndex].value === 'port') {
        streamPort = inputStreamUrl.value;
        if (!validateInt(inputStreamUrl)) {
            formOK = false;
        }
    }
    else {
        streamUrl = inputStreamUrl.value;
        if (!validateStream(inputStreamUrl)) {
            formOK = false;
        }
    }

    let inputCoverimageSizeSmall = document.getElementById('inputCoverimageSizeSmall');
    if (!validateInt(inputCoverimageSizeSmall)) {
        formOK = false;
    }

    let inputCoverimageSize = document.getElementById('inputCoverimageSize');
    if (!validateInt(inputCoverimageSize)) {
        formOK = false;
    }
    
    let inputCoverimageName = document.getElementById('inputCoverimageName');
    if (!validateFilenameList(inputCoverimageName)) {
        formOK = false;
    }
    
    let inputBookletName = document.getElementById('inputBookletName');
    if (!validateFilename(inputBookletName)) {
        formOK = false;
    }
    
    if (isMobile === true) {
        let inputScaleRatio = document.getElementById('inputScaleRatio');
        if (!validateFloat(inputScaleRatio)) {
            formOK = false;
        }
        else {
            scale = parseFloat(inputScaleRatio.value);
            setViewport(true);
        }
    }

    let inputLastPlayedCount = document.getElementById('inputLastPlayedCount');
    if (!validateInt(inputLastPlayedCount)) {
        formOK = false;
    }
    
    if (document.getElementById('btnLoveEnable').classList.contains('active')) {
        let inputLoveChannel = document.getElementById('inputLoveChannel');
        let inputLoveMessage = document.getElementById('inputLoveMessage');
        if (!validateNotBlank(inputLoveChannel) || !validateNotBlank(inputLoveMessage)) {
            formOK = false;
        }
    }

    if (settings.featMixramp === true) {
        let inputMixrampdb = document.getElementById('inputMixrampdb');
        if (!inputMixrampdb.getAttribute('disabled')) {
            if (!validateFloat(inputMixrampdb)) {
                formOK = false;
            } 
        }
        let inputMixrampdelay = document.getElementById('inputMixrampdelay');
        if (!inputMixrampdelay.getAttribute('disabled')) {
            if (inputMixrampdelay.value === 'nan') {
                inputMixrampdelay.value = '-1';
            }
            if (!validateFloat(inputMixrampdelay)) {
                formOK = false;
            }
        }
    }
    
    let inputSmartplsInterval = document.getElementById('inputSmartplsInterval');
    if (!validateInt(inputSmartplsInterval)) {
        formOK = false;
    }
    let smartplsInterval = document.getElementById('inputSmartplsInterval').value * 60 * 60;

    let singleState = getBtnGroupValue('btnSingleGroup');
    let jukeboxMode = getBtnGroupValue('btnJukeboxModeGroup');
    let replaygain = getBtnGroupValue('btnReplaygainGroup');
    let jukeboxUniqueTag = document.getElementById('selectJukeboxUniqueTag');
    let jukeboxUniqueTagValue = jukeboxUniqueTag.options[jukeboxUniqueTag.selectedIndex].value;

    let selectJukeboxPlaylist = document.getElementById('selectJukeboxPlaylist');
    let jukeboxPlaylist = selectJukeboxPlaylist.options[selectJukeboxPlaylist.selectedIndex].value;
    
    if (jukeboxMode === '2') {
        jukeboxUniqueTagValue = 'Album';
    }
    
    if (jukeboxMode === '1' && settings.featSearchwindow === false && jukeboxPlaylist === 'Database') {
        formOK = false;
        document.getElementById('warnJukeboxPlaylist').classList.remove('hide');
    }
    
    if (formOK === true) {
        let selectLocale = document.getElementById('selectLocale');
        let selectTheme = document.getElementById('selectTheme');
        sendAPI("MYMPD_API_SETTINGS_SET", {
            "consume": (document.getElementById('btnConsume').classList.contains('active') ? 1 : 0),
            "random": (document.getElementById('btnRandom').classList.contains('active') ? 1 : 0),
            "single": parseInt(singleState),
            "repeat": (document.getElementById('btnRepeat').classList.contains('active') ? 1 : 0),
            "replaygain": replaygain,
            "crossfade": document.getElementById('inputCrossfade').value,
            "mixrampdb": (settings.featMixramp === true ? document.getElementById('inputMixrampdb').value : settings.mixrampdb),
            "mixrampdelay": (settings.featMixramp === true ? document.getElementById('inputMixrampdelay').value : settings.mixrampdelay),
            "notificationWeb": (document.getElementById('btnNotifyWeb').classList.contains('active') ? true : false),
            "notificationPage": (document.getElementById('btnNotifyPage').classList.contains('active') ? true : false),
            "mediaSession": (document.getElementById('btnMediaSession').classList.contains('active') ? true : false),
            "jukeboxMode": parseInt(jukeboxMode),
            "jukeboxPlaylist": jukeboxPlaylist,
            "jukeboxQueueLength": parseInt(document.getElementById('inputJukeboxQueueLength').value),
            "jukeboxLastPlayed": parseInt(document.getElementById('inputJukeboxLastPlayed').value),
            "jukeboxUniqueTag": jukeboxUniqueTagValue,
            "autoPlay": (document.getElementById('btnAutoPlay').classList.contains('active') ? true : false),
            "bgCover": (document.getElementById('btnBgCover').classList.contains('active') ? true : false),
            "bgColor": document.getElementById('inputBgColor').value,
            "bgCssFilter": document.getElementById('inputBgCssFilter').value,
            "featLocalplayer": (document.getElementById('btnFeatLocalplayer').classList.contains('active') ? true : false),
            "streamUrl": streamUrl,
            "streamPort": parseInt(streamPort),
            "coverimage": (document.getElementById('btnCoverimage').classList.contains('active') ? true : false),
            "coverimageName": document.getElementById('inputCoverimageName').value,
            "coverimageSize": document.getElementById('inputCoverimageSize').value,
            "coverimageSizeSmall": document.getElementById('inputCoverimageSizeSmall').value,
            "locale": selectLocale.options[selectLocale.selectedIndex].value,
            "love": (document.getElementById('btnLoveEnable').classList.contains('active') ? true : false),
            "loveChannel": document.getElementById('inputLoveChannel').value,
            "loveMessage": document.getElementById('inputLoveMessage').value,
            "bookmarks": (document.getElementById('btnBookmarks').classList.contains('active') ? true : false),
            "maxElementsPerPage": parseInt(getSelectValue('selectMaxElementsPerPage')),
            "stickers": (document.getElementById('btnStickers').classList.contains('active') ? true : false),
            "lastPlayedCount": document.getElementById('inputLastPlayedCount').value,
            "smartpls": (document.getElementById('btnSmartpls').classList.contains('active') ? true : false),
            "smartplsPrefix": document.getElementById('inputSmartplsPrefix').value,
            "smartplsInterval": smartplsInterval,
            "smartplsSort": document.getElementById('selectSmartplsSort').value,
            "taglist": getTagMultiSelectValues(document.getElementById('listEnabledTags'), false),
            "searchtaglist": getTagMultiSelectValues(document.getElementById('listSearchTags'), false),
            "browsetaglist": getTagMultiSelectValues(document.getElementById('listBrowseTags'), false),
            "generatePlsTags": getTagMultiSelectValues(document.getElementById('listGeneratePlsTags'), false),
            "theme": selectTheme.options[selectTheme.selectedIndex].value,
            "highlightColor": document.getElementById('inputHighlightColor').value,
            "timer": (document.getElementById('btnFeatTimer').classList.contains('active') ? true : false),
            "bookletName": document.getElementById('inputBookletName').value,
            "lyrics": (document.getElementById('btnFeatLyrics').classList.contains('active') ? true : false)
        }, getSettings);
        if (closeModal === true) {
            modalSettings.hide();
        }
        else {
            btnWaiting(document.getElementById('btnApplySettings'), true);
        }
    }
}

function getTagMultiSelectValues(taglist, translated) {
    let values = [];
    let chkBoxes = taglist.getElementsByTagName('button');
    for (let i = 0; i < chkBoxes.length; i++) {
        if (chkBoxes[i].classList.contains('active')) {
            if (translated === true) {
                values.push(t(chkBoxes[i].name));
            }
            else {
                values.push(chkBoxes[i].name);
            }
        }
    }
    if (translated === true) {
        return values.join(', ');
    }
    return values.join(',');
}

function initTagMultiSelect(inputId, listId, allTags, enabledTags) {
    let values = [];
    let list = '';
    for (let i = 0; i < allTags.length; i++) {
        if (enabledTags.includes(allTags[i])) {
            values.push(t(allTags[i]));
        }
        list += '<div class="form-check">' +
            '<button class="btn btn-secondary btn-xs clickable material-icons material-icons-small' + 
            (enabledTags.includes(allTags[i]) ? ' active' : '') + '" name="' + allTags[i] + '">' +
            (enabledTags.includes(allTags[i]) ? 'check' : 'radio_button_unchecked') + '</button>' +
            '<label class="form-check-label" for="' + allTags[i] + '">&nbsp;&nbsp;' + t(allTags[i]) + '</label>' +
            '</div>';
    }
    document.getElementById(listId).innerHTML = list;

    let inputEl = document.getElementById(inputId);
    inputEl.value = values.join(', ');
    if (inputEl.getAttribute('data-init') === 'true') {
        return;
    }
    inputEl.setAttribute('data-init', 'true');
    document.getElementById(listId).addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'BUTTON') {
            toggleBtnChk(event.target);
            event.target.parentNode.parentNode.parentNode.previousElementSibling.value = getTagMultiSelectValues(event.target.parentNode.parentNode, true);
        }
    });
}

function filterCols(x) {
    let tags = settings.tags.slice();
    if (settings.featTags === false) {
        tags.push('Title');
    }
    tags.push('Duration');
    if (x === 'colsQueueCurrent' || x === 'colsBrowsePlaylistsDetail' || x === 'colsQueueLastPlayed' || x === 'colsQueueJukebox') {
        tags.push('Pos');
    }
    else if (x === 'colsBrowseFilesystem') {
        tags.push('Type');
    }
    if (x === 'colsQueueLastPlayed') {
        tags.push('LastPlayed');
    }
    if (x === 'colsSearch') {
        tags.push('LastModified');
    }
    if (x === 'colsPlayback') {
        tags.push('Filetype');
        tags.push('Fileformat');
        tags.push('LastModified');
        if (settings.featLyrics === true) {
            tags.push('Lyrics');
        }
    }
    let cols = [];
    for (let i = 0; i < settings[x].length; i++) {
        if (tags.includes(settings[x][i])) {
            cols.push(settings[x][i]);
        }
    }
    if (x === 'colsSearch') {
        //enforce albumartist and album for albumactions
        if (cols.includes('Album') === false && tags.includes('Album')) {
            cols.push('Album');
        }
        if (cols.includes(tagAlbumArtist) === false && tags.includes(tagAlbumArtist)) {
            cols.push(tagAlbumArtist);
        }
    }
    settings[x] = cols;
    logDebug('Columns for ' + x + ': ' + cols);
}

//eslint-disable-next-line no-unused-vars
function toggleBtnNotifyWeb() {
    let btnNotifyWeb = document.getElementById('btnNotifyWeb');
    let notifyWebState = btnNotifyWeb.classList.contains('active') ? true : false;
    if (notificationsSupported()) {
        if (notifyWebState === false) {
            Notification.requestPermission(function (permission) {
                if (!('permission' in Notification)) {
                    Notification.permission = permission;
                }
                if (permission === 'granted') {
                    toggleBtnChk('btnNotifyWeb', true);
                    settings.notificationWeb = true;
                    document.getElementById('warnNotifyWeb').classList.add('hide');
                } 
                else {
                    toggleBtnChk('btnNotifyWeb', false);
                    settings.notificationWeb = false;
                    document.getElementById('warnNotifyWeb').classList.remove('hide');
                }
            });
        }
        else {
            toggleBtnChk('btnNotifyWeb', false);
            settings.notificationWeb = false;
            document.getElementById('warnNotifyWeb').classList.add('hide');
        }
    }
    else {
        toggleBtnChk('btnNotifyWeb', false);
        settings.notificationWeb = false;
    }
}

//eslint-disable-next-line no-unused-vars
function setPlaySettings(el) {
    if (el.parentNode.classList.contains('btn-group')) {
        toggleBtnGroup(el);
    }
    else {
        toggleBtnChk(el);
    }
    if (el.parentNode.id === 'playDropdownBtnJukeboxModeGroup') {
        if (el.parentNode.getElementsByClassName('active')[0].getAttribute('data-value') !== '0') {
            toggleBtnChk('playDropdownBtnConsume', true);            
        }
    }
    else if (el.id === 'playDropdownBtnConsume') {
        if (el.classList.contains('active') === false) {
            toggleBtnGroupValue(document.getElementById('playDropdownBtnJukeboxModeGroup'), 0);
        }
    }

    savePlaySettings();
}

function showPlayDropdown() {
    toggleBtnChk(document.getElementById('playDropdownBtnRandom'), settings.random);
    toggleBtnChk(document.getElementById('playDropdownBtnConsume'), settings.consume);
    toggleBtnChk(document.getElementById('playDropdownBtnRepeat'), settings.repeat);
    toggleBtnChk(document.getElementById('playDropdownBtnRandom'), settings.random);
    toggleBtnGroupValue(document.getElementById('playDropdownBtnSingleGroup'), settings.single);
    toggleBtnGroupValue(document.getElementById('playDropdownBtnJukeboxModeGroup'), settings.jukeboxMode);
}

function savePlaySettings() {
    let singleState = document.getElementById('playDropdownBtnSingleGroup').getElementsByClassName('active')[0].getAttribute('data-value');
    let jukeboxMode = document.getElementById('playDropdownBtnJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');
    sendAPI("MYMPD_API_SETTINGS_SET", {
        "consume": (document.getElementById('playDropdownBtnConsume').classList.contains('active') ? 1 : 0),
        "random": (document.getElementById('playDropdownBtnRandom').classList.contains('active') ? 1 : 0),
        "single": parseInt(singleState),
        "repeat": (document.getElementById('playDropdownBtnRepeat').classList.contains('active') ? 1 : 0),
        "jukeboxMode": parseInt(jukeboxMode)
        }, getSettings);
}

function setNavbarIcons() {
    let oldBadgeQueueItems = document.getElementById('badgeQueueItems');
    let oldQueueLength = 0;
    if (oldBadgeQueueItems) {
        oldQueueLength = oldBadgeQueueItems.innerText;
    }
    
    let btns = '';
    for (let i = 0; i < settings.navbarIcons.length; i++) {
        let hide = '';
        if (settings.featHome === false && settings.navbarIcons[i].title === 'Home') {
            hide = 'hide';
        }
        btns += '<div id="nav' + settings.navbarIcons[i].options.join('') + '" class="nav-item flex-fill text-center ' + hide + '">' +
          '<a data-title-phrase="' + t(settings.navbarIcons[i].title) + '" data-href="" class="nav-link text-light" href="#">' +
            '<span class="material-icons">' + settings.navbarIcons[i].ligature + '</span>' + 
            '<span class="navText" data-phrase="' + t(settings.navbarIcons[i].title) + '"></span>' +
            (settings.navbarIcons[i].badge !== '' ? settings.navbarIcons[i].badge : '') +
          '</a>' +
        '</div>';
    }
    let container = document.getElementById('navbar-main');
    container.innerHTML = btns;

    domCache.navbarBtns = container.getElementsByTagName('div');
    domCache.navbarBtnsLen = domCache.navbarBtns.length;
    domCache.badgeQueueItems = document.getElementById('badgeQueueItems');
    domCache.badgeQueueItems.innerText = oldQueueLength;

    if (document.getElementById('nav' + app.current.app)) {
        document.getElementById('nav' + app.current.app).classList.add('active');
    }

    for (let i = 0; i < domCache.navbarBtnsLen; i++) {
        domCache.navbarBtns[i].firstChild.setAttribute('data-href', JSON.stringify({"cmd": "appGoto", "options": settings.navbarIcons[i].options}));
    }
}

//eslint-disable-next-line no-unused-vars
function resetValue(elId) {
    const el = document.getElementById(elId);
    el.value = el.getAttribute('data-default') !== null ? el.getAttribute('data-default') : 
        (el.getAttribute('placeholder') !== null ? el.getAttribute('placeholder') : '');
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function songDetails(uri) {
    sendAPI("MPD_API_DATABASE_SONGDETAILS", {"uri": uri}, parseSongDetails);
    modalSongDetails.show();
}

function parseFingerprint(obj) {
    let textarea = document.createElement('textarea');
    textarea.value = obj.result.fingerprint;
    textarea.classList.add('form-control', 'text-monospace', 'small');
    let fpTd = document.getElementById('fingerprint');
    fpTd.innerHTML = '';
    fpTd.appendChild(textarea);
}

function getMBtagLink(tag, value) {
    let MBentity = '';
    switch (tag) {
        case 'MUSICBRAINZ_ALBUMARTISTID':
        case 'MUSICBRAINZ_ARTISTID':
            MBentity = 'artist';
            break;
        case 'MUSICBRAINZ_ALBUMID':
            MBentity = 'release';
            break;
        case 'MUSICBRAINZ_RELEASETRACKID':
            MBentity = 'track';
            break;
        case 'MUSICBRAINZ_TRACKID':
            MBentity = 'recording';
            break;
    }
    if (MBentity === '') {
        return e(value);
    }
    else {
        return '<a title="' + t('Lookup at musicbrainz') + '" class="text-success external" target="_musicbrainz" href="https://musicbrainz.org/' + MBentity + '/' + encodeURI(value) + '">' +
            '<span class="material-icons">open_in_browser</span>&nbsp;' + value + '</a>';
    }
}

function parseSongDetails(obj) {
    let modal = document.getElementById('modalSongDetails');
    modal.getElementsByClassName('album-cover')[0].style.backgroundImage = 'url("' + subdir + '/albumart/' + obj.result.uri + '"), url("' + subdir + '/assets/coverimage-loading.svg")';
    
    let elH1s = modal.getElementsByTagName('h1');
    for (let i = 0; i < elH1s.length; i++) {
        elH1s[i].innerText = obj.result.Title;
    }
    
    let songDetailsHTML = '';
    for (let i = 0; i < settings.tags.length; i++) {
        if (settings.tags[i] === 'Title' || obj.result[settings.tags[i]] === '-') {
            continue;
        }
        songDetailsHTML += '<tr><th>' + t(settings.tags[i]) + '</th><td data-tag="' + settings.tags[i] + '" data-name="' + encodeURI(obj.result[settings.tags[i]]) + '"';
        if (settings.tags[i] === 'Album' && obj.result[tagAlbumArtist] !== null) {
            songDetailsHTML += ' data-albumartist="' + encodeURI(obj.result[tagAlbumArtist]) + '"';
        }
        songDetailsHTML += '>';
        if (settings.browsetags.includes(settings.tags[i]) && obj.result[settings.tags[i]] !== '-') {
            songDetailsHTML += '<a class="text-success" href="#">' + e(obj.result[settings.tags[i]]) + '</a>';
        }
        else if (settings.tags[i].indexOf('MUSICBRAINZ') === 0) {
            songDetailsHTML += getMBtagLink(settings.tags[i], obj.result[settings.tags[i]]);
        }
        else {
            songDetailsHTML += obj.result[settings.tags[i]];
        }
        songDetailsHTML += '</td></tr>';
    }
    songDetailsHTML += '<tr><th>' + t('Duration') + '</th><td>' + beautifyDuration(obj.result.Duration) + '</td></tr>';
    if (settings.featLibrary === true && settings.publish === true) {
        songDetailsHTML += '<tr><th>' + t('Filename') + '</th><td><a class="breakAll text-success" href="/browse/music/' + 
            encodeURI(obj.result.uri) + '" target="_blank" title="' + e(obj.result.uri) + '">' + 
            e(basename(obj.result.uri, true)) + '</a></td></tr>';
    }
    else {
        songDetailsHTML += '<tr><th>' + t('Filename') + '</th><td class="breakAll"><span title="' + e(obj.result.uri) + '">' + 
            e(basename(obj.result.uri, true)) + '</span></td></tr>';
    }
    songDetailsHTML += '<tr><th>' + t('Filetype') + '</th><td>' + filetype(obj.result.uri) + '</td></tr>';
    songDetailsHTML += '<tr><th>' + t('LastModified') + '</th><td>' + localeDate(obj.result.LastModified) + '</td></tr>';
    if (settings.featFingerprint === true) {
        songDetailsHTML += '<tr><th>' + t('Fingerprint') + '</th><td class="breakAll" id="fingerprint"><a class="text-success" data-uri="' + 
            encodeURI(obj.result.uri) + '" id="calcFingerprint" href="#">' + t('Calculate') + '</a></td></tr>';
    }
    if (obj.result.bookletPath !== '' && settings.publish === true) {
        songDetailsHTML += '<tr><th>' + t('Booklet') + '</th><td><a class="text-success" href="' + subdir + '/browse/music/' + dirname(obj.result.uri) + '/' + settings.bookletName + '" target="_blank">' + t('Download') + '</a></td></tr>';
    }
    if (settings.featStickers === true) {
        songDetailsHTML += '<tr><th colspan="2" class="pt-3"><h5>' + t('Statistics') + '</h5></th></tr>' +
            '<tr><th>' + t('Play count') + '</th><td>' + obj.result.playCount + '</td></tr>' +
            '<tr><th>' + t('Skip count') + '</th><td>' + obj.result.skipCount + '</td></tr>' +
            '<tr><th>' + t('Last played') + '</th><td>' + (obj.result.lastPlayed === 0 ? t('never') : localeDate(obj.result.lastPlayed)) + '</td></tr>' +
            '<tr><th>' + t('Last skipped') + '</th><td>' + (obj.result.lastSkipped === 0 ? t('never') : localeDate(obj.result.lastSkipped)) + '</td></tr>' +
            '<tr><th>' + t('Like') + '</th><td>' +
              '<div class="btn-group btn-group-sm">' +
                '<button title="' + t('Dislike song') + '" id="btnVoteDown2" data-href=\'{"cmd": "voteSong", "options": [0]}\' class="btn btn-sm btn-light material-icons">thumb_down</button>' +
                '<button title="' + t('Like song') + '" id="btnVoteUp2" data-href=\'{"cmd": "voteSong", "options": [2]}\' class="btn btn-sm btn-light material-icons">thumb_up</button>' +
              '</div>' +
            '</td></tr>';
    }
    
    document.getElementById('tbodySongDetails').innerHTML = songDetailsHTML;
    setVoteSongBtns(obj.result.like, obj.result.uri);
    
    if (settings.featLyrics === true) {
        getLyrics(obj.result.uri, document.getElementById('lyricsText'));
    }

    let showPictures = false;
    if (obj.result.images.length > 0 && settings.featLibrary === true && settings.publish === true) {
        showPictures = true;
    }
    else if (settings.coverimage === true) {
        showPictures = true;
    }
    
    let pictureEls = document.getElementsByClassName('featPictures');
    for (let i = 0; i < pictureEls.length; i++) {
        if (showPictures === true) {
            pictureEls[i].classList.remove('hide');
        }
        else {
            pictureEls[i].classList.add('hide');
        }
    }
    
    if (showPictures === true) {
        //add uri to image list to get embedded albumart
        let images = [ subdir + '/albumart/' + obj.result.uri ];
        //add all but coverfiles to image list
        if (settings.publish === true) {
            for (let i = 0; i < obj.result.images.length; i++) {
                if (isCoverfile(obj.result.images[i]) === false) {
                    images.push(subdir + '/browse/music/' + obj.result.images[i]);
                }
            }
        }
        const imgEl = document.getElementById('tabSongPics');
        createImgCarousel(imgEl, 'songPicsCarousel', images);
    }
    else {
        document.getElementById('tabSongPics').innerText = '';
    }
}

function isCoverfile(uri) {
    let filename = basename(uri).toLowerCase();
    let fileparts = filename.split('.');
    
    let extensions = ['png', 'jpg', 'jpeg', 'svg', 'webp', 'tiff', 'bmp'];
    let coverimageNames = settings.coverimageName.split(',');
    for (let i = 0; i < coverimageNames.length; i++) {
        let name = coverimageNames[i].trim();
        if (filename === name) {
            return true;
        }
        if (fileparts[1]) {
            if (name === fileparts[0] && extensions.includes(fileparts[1])) {
                return true;
            }
        }
    }
    return false;
}

function getLyrics(uri, el) {
    if (uri === undefined) {
        el.innerHTML = t('No lyrics found');
        return;
    }
    el.classList.add('opacity05');
    sendAPI("MPD_API_LYRICS_GET", {"uri": uri}, function(obj) {
        if (obj.error) {
            el.innerText = t(obj.error.message);
        }
        else if (obj.result.message) {
            el.innerText = t(obj.result.message);
        }
        else {
            let lyricsHeader = '<span class="lyricsHeader" class="btn-group-toggle" data-toggle="buttons">';
            let lyrics = '<div class="lyricsTextContainer">';
            for (let i = 0; i < obj.result.returnedEntities; i++) {
                let ht = obj.result.data[i].desc;
                if (ht !== '' && obj.result.data[i].lang !== '') {
                    ht += ' (' + obj.result.data[i].lang + ')';
                }
                else if (obj.result.data[i].lang !== '') {
                    ht = obj.result.data[i].lang;
                }
                else {
                    ht = i;
                }
                lyricsHeader += '<label data-num="' + i + '" class="btn btn-sm btn-outline-secondary mr-2' + (i === 0 ? ' active' : '') + '">' + ht + '</label>';
                lyrics += '<div class="lyricsText' + (i > 0 ? ' hide' : '') + '">' +
                    (obj.result.synced === true ? parseSyncedLyrics(obj.result.data[i].text) : e(obj.result.data[i].text).replace(/\n/g, "<br/>")) + 
                    '</div>';
            }
            lyricsHeader += '</span>';
            lyrics += '</div>';
            showSyncedLyrics = obj.result.synced;
            if (obj.result.returnedEntities > 1) {
                el.innerHTML = lyricsHeader + lyrics;
                el.getElementsByClassName('lyricsHeader')[0].addEventListener('click', function(event) {
                    if (event.target.nodeName === 'LABEL') {
                        event.target.parentNode.getElementsByClassName('active')[0].classList.remove('active');
                        event.target.classList.add('active');
                        const nr = parseInt(event.target.getAttribute('data-num'));
                        const tEls = el.getElementsByClassName('lyricsText');
                        for (let i = 0; i < tEls.length; i++) {
                            if (i === nr) {
                                tEls[i].classList.remove('hide');
                            }
                            else {
                                tEls[i].classList.add('hide');
                            }
                        }
                    }
                }, false);
            }
            else {
                el.innerHTML = lyrics;
            }
        }
        el.classList.remove('opacity05');
    }, true);
}

function parseSyncedLyrics(text) {
    let html = '';
    const lines = text.split('\r\n');
    for (let i = 0; i < lines.length; i++) {
        //line must start with timestamp
        let line = lines[i].match(/^\[(\d+):(\d+)\.(\d+)\](.*)$/);
        if (line) {
            let sec = parseInt(line[1]) * 60 + parseInt(line[2]);
            //line[3] are hundreths of a seconde - ignore it for the moment
            html += '<p><span data-sec="' + sec + '">';
            //support of extended lrc format - timestamps for words
            html += line[4].replace(/<(\d+):(\d+)\.\d+>/g, function(m0, m1, m2) {
                //hundreths of a secondes are ignored
                let wsec = parseInt(m1) * 60 + parseInt(m2);
                return '</span><span data-sec="' + wsec + '">';
            });
            html += '</span></p>';
        }
    }
    html += '';
    return html;
}

//eslint-disable-next-line no-unused-vars
function loveSong() {
    sendAPI("MPD_API_LOVE", {});
}

//eslint-disable-next-line no-unused-vars
function voteSong(vote) {
    let uri = decodeURI(domCache.currentTitle.getAttribute('data-uri'));
    if (uri === '') {
        return;
    }
        
    if (vote === 2 && domCache.btnVoteUp.classList.contains('highlight')) {
        vote = 1;
    }
    else if (vote === 0 && domCache.btnVoteDown.classList.contains('highlight')) {
        vote = 1;
    }
    sendAPI("MPD_API_LIKE", {"uri": uri, "like": vote});
    setVoteSongBtns(vote, uri);
}

function setVoteSongBtns(vote, uri) {
    if (uri === undefined) {
        uri = '';
    }
    domCache.btnVoteUp2 = document.getElementById('btnVoteUp2');
    domCache.btnVoteDown2 = document.getElementById('btnVoteDown2');

    if (uri === '' || uri.indexOf('://') > -1) {
        domCache.btnVoteUp.setAttribute('disabled', 'disabled');
        domCache.btnVoteDown.setAttribute('disabled', 'disabled');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.setAttribute('disabled', 'disabled');
            domCache.btnVoteDown2.setAttribute('disabled', 'disabled');
        }
        domCache.btnVoteUp.classList.remove('highlight');
        domCache.btnVoteDown.classList.remove('highlight');
    }
    else {
        domCache.btnVoteUp.removeAttribute('disabled');
        domCache.btnVoteDown.removeAttribute('disabled');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.removeAttribute('disabled');
            domCache.btnVoteDown2.removeAttribute('disabled');
        }
    }
    
    if (vote === 0) {
        domCache.btnVoteUp.classList.remove('highlight');
        domCache.btnVoteDown.classList.add('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.remove('highlight');
            domCache.btnVoteDown2.classList.add('highlight');
        }
    }
    else if (vote === 1) {
        domCache.btnVoteUp.classList.remove('highlight');
        domCache.btnVoteDown.classList.remove('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.remove('highlight');
            domCache.btnVoteDown2.classList.remove('highlight');
        }
    }
    else if (vote === 2) {
        domCache.btnVoteUp.classList.add('highlight');
        domCache.btnVoteDown.classList.remove('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.add('highlight');
            domCache.btnVoteDown2.classList.remove('highlight');
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parseStats(obj) {
    document.getElementById('mpdstats_artists').innerText =  obj.result.artists;
    document.getElementById('mpdstats_albums').innerText = obj.result.albums;
    document.getElementById('mpdstats_songs').innerText = obj.result.songs;
    document.getElementById('mpdstats_dbPlaytime').innerText = beautifyDuration(obj.result.dbPlaytime);
    document.getElementById('mpdstats_playtime').innerText = beautifyDuration(obj.result.playtime);
    document.getElementById('mpdstats_uptime').innerText = beautifyDuration(obj.result.uptime);
    document.getElementById('mpdstats_mympd_uptime').innerText = beautifyDuration(obj.result.myMPDuptime);
    document.getElementById('mpdstats_dbUpdated').innerText = localeDate(obj.result.dbUpdated);
    document.getElementById('mympdVersion').innerText = obj.result.mympdVersion;
    document.getElementById('mpdInfo_version').innerText = obj.result.mpdVersion;
    document.getElementById('mpdInfo_libmpdclientVersion').innerText = obj.result.libmpdclientVersion;
    document.getElementById('mpdInfo_libmympdclientVersion').innerText = obj.result.libmympdclientVersion;
}

function getServerinfo() {
    let ajaxRequest=new XMLHttpRequest();
    ajaxRequest.open('GET', subdir + '/api/serverinfo', true);
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState === 4) {
            let obj = JSON.parse(ajaxRequest.responseText);
            document.getElementById('wsIP').innerText = obj.result.ip;
            document.getElementById('wsMongooseVersion').innerText = obj.result.version;
        }
    };
    ajaxRequest.send();
}

function parseOutputs(obj) {
    let btns = '';
    let nr = 0;
    for (let i = 0; i < obj.result.numOutputs; i++) {
        if (obj.result.data[i].plugin !== 'dummy') {
            nr++;
            btns += '<button id="btnOutput' + obj.result.data[i].id +'" data-output-name="' + encodeURI(obj.result.data[i].name) + '" data-output-id="' + obj.result.data[i].id + '" class="btn btn-secondary btn-block';
            if (obj.result.data[i].state === 1) {
                btns += ' active';
            }
            btns += '"><span class="material-icons float-left">volume_up</span> ' + e(obj.result.data[i].name);
            if (Object.keys(obj.result.data[i].attributes).length > 0) {
                btns += '<a class="material-icons float-right text-white" title="' + t('Edit attributes') + '">settings</a>';
            }
            else {
                btns += '<a class="material-icons float-right text-white" title="' + t('Show attributes') + '">settings</a>';
            }
            btns += '</button>';
        }
    }
    if (nr === 0) {
        btns = '<span class="material-icons">error_outline</span> ' + t('No outputs');
    }
    domCache.outputs.innerHTML = btns;
}

function showListOutputAttributes(outputName) {
    sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {}, function(obj) {
        modalOutputAttributes.show();
        let output;
        for (let i = 0; i < obj.result.data.length; i++) {
            if (obj.result.data[i].name === outputName) {
                output = obj.result.data[i];
                break;
            }
        }
        document.getElementById('modalOutputAttributesId').value = e(output.id);        
        let list = '<tr><td>' + t('Name') + '</td><td>' + e(output.name) + '</td></tr>' +
            '<tr><td>' + t('State') + '</td><td>' + (output.state === 1 ? t('enabled') : t('disabled')) + '</td></tr>' +
            '<tr><td>' + t('Plugin') + '</td><td>' + e(output.plugin) + '</td></tr>';
        let i = 0;
        Object.keys(output.attributes).forEach(function(key) {
            i++;
            list += '<tr><td>' + e(key) + '</td><td><input name="' + e(key) + '" class="form-control border-secondary" type="text" value="' + 
                e(output.attributes[key]) + '"/></td></tr>';
        });
        if (i > 0) {
            document.getElementById('btnOutputAttributesSave').removeAttribute('disabled');
        }
        else {
            document.getElementById('btnOutputAttributesSave').setAttribute('disabled', 'disabled');
        }
        document.getElementById('outputAttributesList').innerHTML = list;
    });
}

//eslint-disable-next-line no-unused-vars
function saveOutputAttributes() {
    let params = {};
    params.outputId =  parseInt(document.getElementById('modalOutputAttributesId').value);
    params.attributes = {};
    let el = document.getElementById('outputAttributesList').getElementsByTagName('input');
    for (let i = 0; i < el.length; i++) {
        params.attributes[el[i].name] = el[i].value;
    }
    sendAPI('MPD_API_PLAYER_OUTPUT_ATTRIBUTS_SET', params);
    modalOutputAttributes.hide();
}

function setCounter(currentSongId, totalTime, elapsedTime) {
    currentSong.totalTime = totalTime;
    currentSong.elapsedTime = elapsedTime;
    currentSong.currentSongId = currentSongId;

    const progressPx = totalTime > 0 ? Math.ceil(domCache.progress.offsetWidth * elapsedTime / totalTime) : 0;
    if (progressPx === 0) {
        domCache.progressBar.style.transition = 'none';
    }
    domCache.progressBar.style.width = progressPx + 'px'; 
    if (progressPx === 0) {    
        setTimeout(function() {
            domCache.progressBar.style.transition = progressBarTransition;
        }, 10);
    }
    
    if (totalTime <= 0) {
        domCache.progress.style.cursor = 'default';
    }
    else {
        domCache.progress.style.cursor = 'pointer';
    }

    let counterText = beautifySongDuration(elapsedTime) + "&nbsp;/&nbsp;" + beautifySongDuration(totalTime);
    domCache.counter.innerHTML = counterText;
    
    //Set playing track in queue view
    if (lastState) {
        if (lastState.currentSongId !== currentSongId) {
            let tr = document.getElementById('queueTrackId' + lastState.currentSongId);
            if (tr) {
                let durationTd = tr.querySelector('[data-col=Duration]');
                if (durationTd) {
                    durationTd.innerText = tr.getAttribute('data-duration');
                }
                let posTd = tr.querySelector('[data-col=Pos]');
                if (posTd) {
                    posTd.classList.remove('material-icons');
                    posTd.innerText = tr.getAttribute('data-songpos');
                }
                tr.classList.remove('font-weight-bold');
            }
            tr = document.getElementById('queueMiniTrackId' + lastState.currentSongId);
            if (tr) {
                let durationTd = tr.querySelector('[data-col=Duration]');
                if (durationTd) {
                    durationTd.innerText = tr.getAttribute('data-duration');
                }
                let posTd = tr.querySelector('[data-col=Pos]');
                if (posTd) {
                    posTd.classList.remove('material-icons');
                    posTd.innerText = tr.getAttribute('data-songpos');
                }
                tr.classList.remove('font-weight-bold');
            }
        }
    }
    let tr = document.getElementById('queueTrackId' + currentSongId);
    if (tr) {
        let durationTd = tr.querySelector('[data-col=Duration]');
        if (durationTd) {
            durationTd.innerHTML = counterText;
        }
        let posTd = tr.querySelector('[data-col=Pos]');
        if (posTd) {
            if (!posTd.classList.contains('material-icons')) {
                posTd.classList.add('material-icons');
                posTd.innerText = 'play_arrow';
            }
        }
        tr.classList.add('font-weight-bold');
    }
    tr = document.getElementById('queueMiniTrackId' + currentSongId);
    if (tr) {
        let durationTd = tr.querySelector('[data-col=Duration]');
        if (durationTd) {
            durationTd.innerHTML = counterText;
        }
        let posTd = tr.querySelector('[data-col=Pos]');
        if (posTd) {
            if (!posTd.classList.contains('material-icons')) {
                posTd.classList.add('material-icons');
                posTd.innerText = 'play_arrow';
            }
        }
        tr.classList.add('font-weight-bold');
    }

    if (progressTimer) {
        clearTimeout(progressTimer);
    }
    if (playstate === 'play') {
        progressTimer = setTimeout(function () {
            currentSong.elapsedTime++;
            requestAnimationFrame(function () {
                setCounter(currentSong.currentSongId, currentSong.totalTime, currentSong.elapsedTime);
            });
        }, 1000);
    }

    //synced lyrics
    if (showSyncedLyrics === true && settings.colsPlayback.includes('Lyrics')) {
        const sl = document.getElementById('currentLyrics');
        const toHighlight = sl.querySelector('[data-sec="' + elapsedTime + '"]');
        const highlighted = sl.getElementsByClassName('highlight')[0];
        if (highlighted !== toHighlight) {
            if (toHighlight !== null) {
                toHighlight.classList.add('highlight');
                if (highlighted !== undefined) {
                    highlighted.classList.remove('highlight');
                }
            }
        }
    }    
    
    if (progressTimer) {
        clearTimeout(progressTimer);
    }
    if (playstate === 'play') {
        progressTimer = setTimeout(function() {
            currentSong.elapsedTime ++;
            requestAnimationFrame(function() {
                setCounter(currentSong.currentSongId, currentSong.totalTime, currentSong.elapsedTime);
            });
        }, 1000);
    }
}

function parseState(obj) {
    if (JSON.stringify(obj.result) === JSON.stringify(lastState)) {
        toggleUI();
        return;
    }

    //Set play and queue state
    parseUpdateQueue(obj);
    
    //Set volume
    parseVolume(obj);

    //Set play counters
    setCounter(obj.result.currentSongId, obj.result.totalTime, obj.result.elapsedTime);
    
    //Get current song
    if (!lastState || lastState.currentSongId !== obj.result.currentSongId ||
        lastState.queueVersion !== obj.result.queueVersion)
    {
        sendAPI("MPD_API_PLAYER_CURRENT_SONG", {}, songChange);
    }
    //clear playback card if no current song
    if (obj.result.songPos === '-1') {
        domCache.currentTitle.innerText = 'Not playing';
        document.title = 'myMPD';
        domCache.footerTitle.innerText = '';
        domCache.footerTitle.removeAttribute('title');
        domCache.footerTitle.classList.remove('clickable');
        domCache.footerCover.classList.remove('clickable');
        clearCurrentCover();
        if (settings.bgCover === true) {
            clearBackgroundImage();
        }
        let pb = document.getElementById('cardPlaybackTags').getElementsByTagName('p');
        for (let i = 0; i < pb.length; i++) {
            pb[i].innerText = '';
        }
    }
    else {
        let cff = document.getElementById('currentFileformat');
        if (cff) {
            cff.getElementsByTagName('p')[0].innerText = fileformat(obj.result.audioFormat);
        }
    }

    lastState = obj.result;                    
    
    if (settings.mpdConnected === false || uiEnabled === false) {
        getSettings(true);
    }
}

function parseVolume(obj) {
    if (obj.result.volume === -1) {
        domCache.volumePrct.innerText = t('Volumecontrol disabled');
        domCache.volumeControl.classList.add('hide');
    } 
    else {
        domCache.volumeControl.classList.remove('hide');
        domCache.volumePrct.innerText = obj.result.volume + ' %';
        if (obj.result.volume === 0) {
            domCache.volumeMenu.firstChild.innerText = 'volume_off';
        }
        else if (obj.result.volume < 50) {
            domCache.volumeMenu.firstChild.innerText = 'volume_down';
        }
        else {
            domCache.volumeMenu.firstChild.innerText = 'volume_up';
        }
    }
    domCache.volumeBar.value = obj.result.volume;
}

function setBackgroundImage(url) {
    if (url === undefined) {
        clearBackgroundImage();
        return;
    }
    let old = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '-10') {
            old[i].remove();
        }
        else {
            old[i].style.zIndex = '-10';
            old[i].style.opacity = '0';
            //old[i].style.filter = '';
        }
    }
    let div = document.createElement('div');
    div.classList.add('albumartbg');
    div.style.filter = settings.bgCssFilter;
    div.style.backgroundImage = 'url("' + subdir + '/albumart/' + url + '")';
    div.style.opacity = 0;
    let body = document.getElementsByTagName('body')[0];
    body.insertBefore(div, body.firstChild);

    let img = new Image();
    img.onload = function() {
        document.querySelector('.albumartbg').style.opacity = 1;
    };
    img.src = subdir + '/albumart/' + url;
}

function clearBackgroundImage() {
    let old = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '-10') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '-10';
            old[i].style.opacity = '0';
            //old[i].style.filter = '';
        }
    }
}

function setCurrentCover(url) {
    _setCurrentCover(url, domCache.currentCover);
    _setCurrentCover(url, domCache.footerCover);
}

function _setCurrentCover(url, el) {
    if (url === undefined) {
        clearCurrentCover();
        return;
    }
    let old = el.querySelectorAll('.coverbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '2') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '2';
        }
    }

    let div = document.createElement('div');
    div.classList.add('coverbg', 'carousel');
    div.style.backgroundImage = 'url("' + subdir + '/albumart/' + url + '")';
    div.style.opacity = 0;
    div.setAttribute('data-uri', url);
    el.insertBefore(div, el.firstChild);

    let img = new Image();
    img.onload = function() {
        el.querySelector('.coverbg').style.opacity = 1;
    };
    img.src = subdir + '/albumart/' + url;
}

function clearCurrentCover() {
    _clearCurrentCover(domCache.currentCover);
    _clearCurrentCover(domCache.footerCover);
}

function _clearCurrentCover(el) {
    let old = el.querySelectorAll('.coverbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '2') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '2';
            old[i].style.opacity = '0';
        }
    }
}

function songChange(obj) {
    if (app.current.app === 'Playback') {
        getQueueMini(obj.result.pos);
    }
    let curSong = obj.result.Title + ':' + obj.result.Artist + ':' + obj.result.Album + ':' + obj.result.uri + ':' + obj.result.currentSongId;
    if (lastSong === curSong) {
        return;
    }
    let textNotification = '';
    let htmlNotification = '';
    let pageTitle = '';

    mediaSessionSetMetadata(obj.result.Title, obj.result.Artist, obj.result.Album, obj.result.uri);
    
    setCurrentCover(obj.result.uri);
    if (settings.bgCover === true && settings.featCoverimage === true) {
        setBackgroundImage(obj.result.uri);
    }
    
    domCache.footerArtist.classList.remove('clickable');
    domCache.footerAlbum.classList.remove('clickable');
    domCache.footerCover.classList.remove('clickable');

    if (obj.result.Artist !== undefined && obj.result.Artist.length > 0 && obj.result.Artist !== '-') {
        textNotification += obj.result.Artist;
        htmlNotification += obj.result.Artist;
        pageTitle += obj.result.Artist + ' - ';
        domCache.footerArtist.innerText = obj.result.Artist;
        domCache.footerArtist.setAttribute('data-name', encodeURI(obj.result.Artist));
        if (settings.featAdvsearch === true) {
            domCache.footerArtist.classList.add('clickable');
        }
    }
    else {
        domCache.footerArtist.innerText = '';
        domCache.footerArtist.setAttribute('data-name', '');
    }

    if (obj.result.Album !== undefined && obj.result.Album.length > 0 && obj.result.Album !== '-') {
        textNotification += ' - ' + obj.result.Album;
        htmlNotification += '<br/>' + obj.result.Album;
        domCache.footerAlbum.innerText = obj.result.Album;
        domCache.footerAlbum.setAttribute('data-name', encodeURI(obj.result.Album));
        domCache.footerAlbum.setAttribute('data-albumartist', encodeURI(obj.result[tagAlbumArtist]));
        if (settings.featAdvsearch === true) {
            domCache.footerAlbum.classList.add('clickable');
        }
    }
    else {
        domCache.footerAlbum.innerText = '';
        domCache.footerAlbum.setAttribute('data-name', '');
    }

    if (obj.result.Title !== undefined && obj.result.Title.length > 0) {
        pageTitle += obj.result.Title;
        domCache.currentTitle.innerText = obj.result.Title;
        domCache.currentTitle.setAttribute('data-uri', encodeURI(obj.result.uri));
        domCache.footerTitle.innerText = obj.result.Title;
        domCache.footerTitle.classList.add('clickable');
        domCache.footerCover.classList.add('clickable');
    }
    else {
        domCache.currentTitle.innerText = '';
        domCache.currentTitle.setAttribute('data-uri', '');
        domCache.footerTitle.innerText = '';
        domCache.footerTitle.setAttribute('data-name', '');
        domCache.footerTitle.classList.remove('clickable');
        domCache.footerCover.classList.remove('clickable');
    }
    document.title = 'myMPD: ' + pageTitle;
    domCache.footerCover.title = pageTitle;
    
    if (obj.result.uri !== undefined && obj.result.uri !== '' && obj.result.uri.indexOf('://') === -1) {
        domCache.footerTitle.classList.add('clickable');
    }
    else {
        domCache.footerTitle.classList.remove('clickable');
    }

    if (obj.result.uri !== undefined) {
        obj.result['Filetype'] = filetype(obj.result.uri);
        document.getElementById('addCurrentSongToPlaylist').removeAttribute('disabled');
    }
    else {
        obj.result['Filetype'] = '';
        document.getElementById('addCurrentSongToPlaylist').setAttribute('disabled', 'disabled');
    }
    
    if (settings.featStickers === true) {
        setVoteSongBtns(obj.result.like, obj.result.uri);
    }
    
    if (lastState) {
        obj.result['Fileformat'] = fileformat(lastState.audioFormat);
    }
    else {
        obj.result['Fileformat'] = '';
    }

    for (let i = 0; i < settings.colsPlayback.length; i++) {
        let c = document.getElementById('current' + settings.colsPlayback[i]);
        if (c && settings.colsPlayback[i] === 'Lyrics') {
            getLyrics(obj.result.uri, c.getElementsByTagName('p')[0]);
        }
        else if (c) {
            let value = obj.result[settings.colsPlayback[i]];
            if (value === undefined) {
                value = '';
            }
            if (settings.colsPlayback[i] === 'Duration') {
                value = beautifySongDuration(value);
            }
            else if (settings.colsPlayback[i] === 'LastModified') {
                value = localeDate(value);
            }
            else if (settings.colsPlayback[i].indexOf('MUSICBRAINZ') === 0) {
                value = getMBtagLink(settings.colsPlayback[i], obj.result[settings.colsPlayback[i]]);
            }
            else {
                value = e(value);
            }
            c.getElementsByTagName('p')[0].innerHTML = value;
            c.setAttribute('data-name', encodeURI(value));
            if (settings.colsPlayback[i] === 'Album' && obj.result[tagAlbumArtist] !== null) {
                c.setAttribute('data-albumartist', encodeURI(obj.result[tagAlbumArtist]));
            }
        }
    }
    
    document.getElementById('currentBooklet').innerHTML = obj.result.bookletPath === '' || obj.result.bookletPath === undefined|| settings.featBrowse === false ? '' : 
            '<span class="text-light material-icons">description</span>&nbsp;<a class="text-light" target="_blank" href="' + subdir + '/browse/music/' + 
            e(obj.result.bookletPath) + '">' + t('Download booklet') + '</a>';
    
    //Update Artist in queue view for http streams
    let playingTr = document.getElementById('queueTrackId' + obj.result.currentSongId);
    if (playingTr) {
        playingTr.getElementsByTagName('td')[1].innerText = obj.result.Title;
    }

    if (playstate === 'play') {
        showNotification(obj.result.Title, textNotification, htmlNotification, 'success');
    }
    
    lastSong = curSong;
    lastSongObj = obj.result;
}

//eslint-disable-next-line no-unused-vars
function gotoTagList() {
    appGoto(app.current.app, app.current.tab, app.current.view, '0', undefined, '-', '-', '-', '');
}

//eslint-disable-next-line no-unused-vars
function volumeStep(dir) {
    let inc = dir === 'up' ? settings.volumeStep : 0 - settings.volumeStep;
    chVolume(inc);
}

function chVolume(increment) {
    let newValue = parseInt(domCache.volumeBar.value) + increment;
    if (newValue < settings.volumeMin)  {
        newValue = settings.volumeMin;
    }
    else if (newValue > settings.volumeMax) {
        newValue = settings.volumeMax;
    }
    domCache.volumeBar.value = newValue;
    sendAPI("MPD_API_PLAYER_VOLUME_SET", {"volume": newValue});
}

//eslint-disable-next-line no-unused-vars
function clickTitle() {
    let uri = decodeURI(domCache.currentTitle.getAttribute('data-uri'));
    if (uri !== '' && uri.indexOf('://') === -1) {
        songDetails(uri);
    }
}

function mediaSessionSetPositionState(duration, position) {
    if (settings.mediaSession === true && 'mediaSession' in navigator && navigator.mediaSession.setPositionState) {
        if (position < duration) {
            //streams have position > duration
            navigator.mediaSession.setPositionState({
                duration: duration,
                position: position
            });
        }
    }
}

function mediaSessionSetState() {
    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        if (playstate === 'play') {
            navigator.mediaSession.playbackState = 'playing';
        }
        else {
            navigator.mediaSession.playbackState = 'paused';
        }
    }
}

function mediaSessionSetMetadata(title, artist, album, url) {
    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        let hostname = window.location.hostname;
        let protocol = window.location.protocol;
        let port = window.location.port;
        let artwork = protocol + '//' + hostname + (port !== '' ? ':' + port : '') + subdir + '/albumart/' + url;

        if (settings.coverimage === true) {
            //eslint-disable-next-line no-undef
            navigator.mediaSession.metadata = new MediaMetadata({
                title: title,
                artist: artist,
                album: album,
                artwork: [{src: artwork}]
            });
        }
        else {
            //eslint-disable-next-line no-undef
            navigator.mediaSession.metadata = new MediaMetadata({
                title: title,
                artist: artist,
                album: album
            });
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function focusTable(rownr, table) {
    if (table === undefined) {
        table = document.getElementById(app.current.app + (app.current.tab !== undefined ? app.current.tab : '') + (app.current.view !== undefined ? app.current.view : '') + 'List');
    }

    if (app.current.app === 'Browse' && app.current.tab === 'Database' && app.current.view === 'List') {
        const tables = document.getElementsByClassName('card-grid');
        if (tables.length === 0 ) {
            return; 
        }
        table = tables[0];
        for (let i = 0; i < tables.length; i++) {
            if (tables[i].classList.contains('selected')) {
                table = tables[i];
                break;
            }
        }
        table.focus();
        return;
    }
    else if (app.current.app === 'Home') {
        const tables = document.getElementsByClassName('home-icons');
        if (tables.length === 0 ) {
            return; 
        }
        table = tables[0];
        for (let i = 0; i < tables.length; i++) {
            if (tables[i].classList.contains('selected')) {
                table = tables[i];
                break;
            }
        }
        table.focus();
        return;
    }

    if (table !== null) {
        let sel = table.getElementsByClassName('selected');
        if (rownr === undefined) {
            if (sel.length === 0) {
                let row = table.getElementsByTagName('tbody')[0].rows[0];
                if (row.classList.contains('not-clickable')) {
                    row = table.getElementsByTagName('tbody')[0].rows[1];
                }
                row.focus();
                row.classList.add('selected');
            }
            else {
                sel[0].focus();
            }
        }
        else {
            if (sel && sel.length > 0) {
                sel[0].classList.remove('selected');
            }
            let rows = table.getElementsByTagName('tbody')[0].rows;
            let rowsLen = rows.length;
            if (rowsLen < rownr) {
                rownr = 0;
            }
            if (rowsLen > rownr) {
                rows[rownr].focus();
                rows[rownr].classList.add('selected');
            }
        }
        //insert goto parent row
        if (table.id === 'BrowseFilesystemList') {
            let tbody = table.getElementsByTagName('tbody')[0];
            if (tbody.rows.length > 0 && tbody.rows[0].getAttribute('data-type') !== 'parentDir' && app.current.search !== '') {
                let nrCells = table.getElementsByTagName('thead')[0].rows[0].cells.length;
                let uri = app.current.search.replace(/\/?([^/]+)$/,'');
                let row = tbody.insertRow(0);
                row.setAttribute('data-type', 'parentDir');
                row.setAttribute('tabindex', 0);
                row.setAttribute('data-uri', encodeURI(uri));
                row.innerHTML = '<td colspan="' + nrCells + '">..</td>';
            }
        }
        scrollFocusIntoView();
    }
}

function scrollFocusIntoView() {
    let el = document.activeElement;
    let posY = el.getBoundingClientRect().top;
    let height = el.offsetHeight;
    let headerHeight = el.parentNode.parentNode.offsetTop;
    if (window.innerHeight > window.innerWidth) {
        headerHeight += domCache.header.offsetHeight;
    }
    let footerHeight = domCache.footer.offsetHeight;
    let parentHeight = window.innerHeight - headerHeight - footerHeight;
    let treshold = height / 2;
    //console.log('posY: ' + posY);
    //console.log('height: ' + height);
    //console.log('treshold: ' + treshold);
    //console.log('parentHeight: ' + parentHeight);
    //console.log('headerHeight:' + headerHeight);
    //console.log('footerHeight:' + footerHeight);
    if (posY <= headerHeight + treshold) {
        //console.log('0, - height');
        window.scrollBy(0, - height);
    }
    else if (posY + height > parentHeight - treshold) {
        //console.log('0, height');
        window.scrollBy(0, height);
    }
}

function navigateTable(table, keyCode) {
    let cur = document.activeElement;
    if (cur) {
        let next = null;
        let handled = false;
        if (keyCode === 'ArrowDown') {
            next = cur.nextElementSibling;
            if (next.classList.contains('not-clickable')) {
                next = next.nextElementSibling;
            }
            handled = true;
        }
        else if (keyCode === 'ArrowUp') {
            next = cur.previousElementSibling;
            if (next.classList.contains('not-clickable')) {
                next = next.previousElementSibling;
            }
            handled = true;
        }
        else if (keyCode === ' ') {
            let popupBtn = cur.lastChild.firstChild;
            if (popupBtn.nodeName === 'A') {
                popupBtn.click();
            }
            handled = true;
        }
        else if (keyCode === 'Enter') {
            cur.firstChild.click();
            handled = true;
        }
        else if (keyCode === 'Escape') {
            cur.blur();
            cur.classList.remove('selected');
            handled = true;
        }
        if (handled === true) {
            event.preventDefault();
            event.stopPropagation();
        }
        if (next) {
            cur.classList.remove('selected');
            next.classList.add('selected');
            next.focus();
            scrollFocusIntoView();
        }
    }
}

function dragAndDropTable(table) {
    let tableBody = document.getElementById(table).getElementsByTagName('tbody')[0];
    tableBody.addEventListener('dragstart', function(event) {
        if (event.target.nodeName === 'TR') {
            event.target.classList.add('opacity05');
            event.dataTransfer.setDragImage(event.target, 0, 0);
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('Text', event.target.getAttribute('id'));
            dragEl = event.target.cloneNode(true);
        }
    }, false);
    tableBody.addEventListener('dragleave', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        if (target.nodeName === 'TR') {
            target.classList.remove('dragover');
        }
    }, false);
    tableBody.addEventListener('dragover', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        if (target.nodeName === 'TR') {
            target.classList.add('dragover');
        }
        event.dataTransfer.dropEffect = 'move';
    }, false);
    tableBody.addEventListener('dragend', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        if (document.getElementById(event.dataTransfer.getData('Text'))) {
            document.getElementById(event.dataTransfer.getData('Text')).classList.remove('opacity05');
        }
    }, false);
    tableBody.addEventListener('drop', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        let oldSongpos = document.getElementById(event.dataTransfer.getData('Text')).getAttribute('data-songpos');
        let newSongpos = target.getAttribute('data-songpos');
        document.getElementById(event.dataTransfer.getData('Text')).remove();
        dragEl.classList.remove('opacity05');
        tableBody.insertBefore(dragEl, target);
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        document.getElementById(table).classList.add('opacity05');
        if (app.current.app === 'Queue' && app.current.tab === 'Current') {
            sendAPI("MPD_API_QUEUE_MOVE_TRACK", {"from": oldSongpos, "to": newSongpos});
        }
        else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
            playlistMoveTrack(oldSongpos, newSongpos);
        }
    }, false);
}

function dragAndDropTableHeader(table) {
    let tableHeader;
    if (document.getElementById(table + 'List')) {
        tableHeader = document.getElementById(table + 'List').getElementsByTagName('tr')[0];
    }
    else {
        tableHeader = table.getElementsByTagName('tr')[0];
        table = 'BrowseDatabase';
    }

    tableHeader.addEventListener('dragstart', function(event) {
        if (event.target.nodeName === 'TH') {
            event.target.classList.add('opacity05');
            event.dataTransfer.setDragImage(event.target, 0, 0);
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('Text', event.target.getAttribute('data-col'));
            dragEl = event.target.cloneNode(true);
        }
    }, false);
    tableHeader.addEventListener('dragleave', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        if (event.target.nodeName === 'TH') {
            event.target.classList.remove('dragover-th');
        }
    }, false);
    tableHeader.addEventListener('dragover', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (event.target.nodeName === 'TH') {
            event.target.classList.add('dragover-th');
        }
        event.dataTransfer.dropEffect = 'move';
    }, false);
    tableHeader.addEventListener('dragend', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']')) {
            this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']').classList.remove('opacity05');
        }
    }, false);
    tableHeader.addEventListener('drop', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']').remove();
        dragEl.classList.remove('opacity05');
        tableHeader.insertBefore(dragEl, event.target);
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (document.getElementById(table + 'List')) {
            document.getElementById(table + 'List').classList.add('opacity05');
            saveCols(table);
        }
        else {
            saveCols(table, this.parentNode.parentNode);
        }
    }, false);
}

function setColTags(table) {
    let tags = settings.tags.slice();
    if (settings.featTags === false) {
        tags.push('Title');
    }
    tags.push('Duration');
    if (table === 'QueueCurrent' || table === 'BrowsePlaylistsDetail' || table === 'QueueLastPlayed' || table === 'QueueJukebox') {
        tags.push('Pos');
    }
    if (table === 'BrowseFilesystem') {
        tags.push('Type');
    }
    if (table === 'QueueLastPlayed') {
        tags.push('LastPlayed');
    }
    if (table === 'Search') {
        tags.push('LastModified');
    }
    if (table === 'Playback') {
        tags.push('Filetype');
        tags.push('Fileformat');
        tags.push('LastModified');
        if (settings.featLyrics === true) {
            tags.push('Lyrics');
        }
    }
    
    tags.sort();
    return tags;
}

function setColsChecklist(table) {
    let tagChks = '';
    let tags = setColTags(table);
    for (let i = 0; i < tags.length; i++) {
        if (table === 'Playback' && tags[i] === 'Title') {
            continue;
        }
        tagChks += '<div>' +
            '<button class="btn btn-secondary btn-xs clickable material-icons material-icons-small' +
            (settings['cols' + table].includes(tags[i]) ? ' active' : '') + '" name="' + tags[i] + '">' +
            (settings['cols' + table].includes(tags[i]) ? 'check' : 'radio_button_unchecked') + '</button>' +
            '<label class="form-check-label" for="' + tags[i] + '">&nbsp;&nbsp;' + t(tags[i]) + '</label>' +
            '</div>';
    }
    return tagChks;
}

function setCols(table) {
    let colsChkList = document.getElementById(table + 'ColsDropdown');
    if (colsChkList) {
        colsChkList.firstChild.innerHTML = setColsChecklist(table);
    }
    let sort = app.current.sort;
    
    if (table === 'Search' && app.apps.Search.sort === 'Title') {
        if (settings.tags.includes('Title')) {
            sort = 'Title';
        }
        else if (settings.featTags === false) {
            sort = 'Filename';
        }
        else {
            sort = '-';
        }
    }
    
    if (table !== 'Playback') {
        let heading = '';
        for (let i = 0; i < settings['cols' + table].length; i++) {
            let h = settings['cols' + table][i];
            heading += '<th draggable="true" data-col="' + h  + '">';
            if (h === 'Track' || h === 'Pos') {
                h = '#';
            }
            heading += t(h);

            if (table === 'Search' && (h === sort || '-' + h === sort) ) {
                let sortdesc = false;
                if (app.current.sort.indexOf('-') === 0) {
                    sortdesc = true;
                }
                heading += '<span class="sort-dir material-icons pull-right">' + (sortdesc === true ? 'arrow_drop_up' : 'arrow_drop_down') + '</span>';
            }
            heading += '</th>';
        }
        if (settings.featTags === true) {
            heading += '<th data-col="Action"><a data-title-phrase="' +t('Columns') + '" href="#" class="text-secondary align-middle material-icons material-icons-small">settings</a></th>';
        }
        else {
            heading += '<th></th>';
        }

        document.getElementById(table + 'List').getElementsByTagName('tr')[0].innerHTML = heading;
    }
}

function saveCols(table, tableEl) {
    let colsDropdown = document.getElementById(table + 'ColsDropdown');
    let header;
    if (tableEl === undefined) {
        header = document.getElementById(table + 'List').getElementsByTagName('tr')[0];
    }
    else if (typeof(tableEl) === 'string') {
        header = document.querySelector(tableEl).getElementsByTagName('tr')[0];
    }
    else {
        header = tableEl.getElementsByTagName('tr')[0];
    }
    if (colsDropdown) {
        let colInputs = colsDropdown.firstChild.getElementsByTagName('button');
        for (let i = 0; i < colInputs.length; i++) {
            if (colInputs[i].getAttribute('name') === null) {
                continue;
            }
            let th = header.querySelector('[data-col=' + colInputs[i].name + ']');
            if (colInputs[i].classList.contains('active') === false) {
                if (th) {
                    th.remove();
                }
            } 
            else if (!th) {
                th = document.createElement('th');
                th.innerText = colInputs[i].name;
                th.setAttribute('data-col', colInputs[i].name);
                header.insertBefore(th, header.lastChild);
            }
        }
    }
    
    let params = {"table": "cols" + table, "cols": []};
    let ths = header.getElementsByTagName('th');
    for (let i = 0; i < ths.length; i++) {
        let name = ths[i].getAttribute('data-col');
        if (name !== 'Action' && name !== null) {
            params.cols.push(name);
        }
    }
    sendAPI("MYMPD_API_COLS_SAVE", params, getSettings);
}

//eslint-disable-next-line no-unused-vars
function saveColsPlayback(table) {
    let colInputs = document.getElementById(table + 'ColsDropdown').firstChild.getElementsByTagName('button');
    let header = document.getElementById('cardPlaybackTags');

    for (let i = 0; i < colInputs.length -1; i++) {
        let th = document.getElementById('current' + colInputs[i].name);
        if (colInputs[i].classList.contains('active') === false) {
            if (th) {
                th.remove();
            }
        } 
        else if (!th) {
            th = document.createElement('div');
            th.innerHTML = '<small>' + t(colInputs[i].name) + '</small><p></p>';
            th.setAttribute('id', 'current' + colInputs[i].name);
            th.setAttribute('data-tag', colInputs[i].name);
            header.appendChild(th);
        }
    }
    
    let params = {"table": "cols" + table, "cols": []};
    let ths = header.getElementsByTagName('div');
    for (let i = 0; i < ths.length; i++) {
        let name = ths[i].getAttribute('data-tag');
        if (name) {
            params.cols.push(name);
        }
    }
    sendAPI("MYMPD_API_COLS_SAVE", params, getSettings);
}

function replaceTblRow(row, el) {
    let menuEl = row.querySelector('[data-popover]');
    let result = false;
    if (menuEl) {
        hideMenu();
    }
    if (row.classList.contains('selected')) {
        el.classList.add('selected');
        el.focus();
        result = true;
    }
    row.replaceWith(el);
    return result;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
var themes = {
    "theme-autodetect": "Autodetect",
    "theme-default": "Default",
    "theme-dark": "Dark",
    "theme-light": "Light"
};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function deleteTimer(timerid) {
    sendAPI("MYMPD_API_TIMER_RM", {"timerid": timerid}, showListTimer);
}

//eslint-disable-next-line no-unused-vars
function toggleTimer(target, timerid) {
    if (target.classList.contains('active')) {
        target.classList.remove('active');
        sendAPI("MYMPD_API_TIMER_TOGGLE", {"timerid": timerid, "enabled": false}, showListTimer);
    }
    else {
        target.classList.add('active');
        sendAPI("MYMPD_API_TIMER_TOGGLE", {"timerid": timerid, "enabled": true}, showListTimer);
    }
}

//eslint-disable-next-line no-unused-vars
function saveTimer() {
    let formOK = true;
    let nameEl = document.getElementById('inputTimerName');
    if (!validateNotBlank(nameEl)) {
        formOK = false;
    }
    let minOneDay = false;
    let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
    let weekdays = [];
    for (let i = 0; i < weekdayBtns.length; i++) {
        let checked = document.getElementById(weekdayBtns[i]).classList.contains('active') ? true : false;
        weekdays.push(checked);
        if (checked === true) {
            minOneDay = true;
        }
    }
    if (minOneDay === false) {
        formOK = false;
        document.getElementById('invalidTimerWeekdays').style.display = 'block';
    }
    else {
        document.getElementById('invalidTimerWeekdays').style.display = 'none';
    }
    let selectTimerAction = document.getElementById('selectTimerAction');
    let selectTimerPlaylist = document.getElementById('selectTimerPlaylist');
    let selectTimerHour = document.getElementById('selectTimerHour');
    let selectTimerMinute = document.getElementById('selectTimerMinute');
    let jukeboxMode = document.getElementById('btnTimerJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');

    if (selectTimerAction.selectedIndex === -1) {
        formOK = false;
        selectTimerAction.classList.add('is-invalid');
    }

    if (jukeboxMode === '0' &&
        selectTimerPlaylist.options[selectTimerPlaylist.selectedIndex].value === 'Database'&&
        selectTimerAction.options[selectTimerAction.selectedIndex].value === 'startplay')
    {
        formOK = false;
        document.getElementById('btnTimerJukeboxModeGroup').classList.add('is-invalid');
    }
    
    if (formOK === true) {
        let args = {};
        let argEls = document.getElementById('timerActionScriptArguments').getElementsByTagName('input');
        for (let i = 0; i < argEls.length; i ++) {
            args[argEls[i].getAttribute('data-name')] = argEls[i].value;
        }
        sendAPI("MYMPD_API_TIMER_SAVE", {
            "timerid": parseInt(document.getElementById('inputTimerId').value),
            "name": nameEl.value,
            "enabled": (document.getElementById('btnTimerEnabled').classList.contains('active') ? true : false),
            "startHour": parseInt(selectTimerHour.options[selectTimerHour.selectedIndex].value),
            "startMinute": parseInt(selectTimerMinute.options[selectTimerMinute.selectedIndex].value),
            "weekdays": weekdays,
            "action": selectTimerAction.options[selectTimerAction.selectedIndex].parentNode.getAttribute('data-value'),
            "subaction": selectTimerAction.options[selectTimerAction.selectedIndex].value,
            "volume": parseInt(document.getElementById('inputTimerVolume').value), 
            "playlist": selectTimerPlaylist.options[selectTimerPlaylist.selectedIndex].value,
            "jukeboxMode": parseInt(jukeboxMode),
            "arguments": args
            }, showListTimer);
    }
}

//eslint-disable-next-line no-unused-vars
function showEditTimer(timerid) {
    document.getElementById('timerActionPlay').classList.add('hide');
    document.getElementById('timerActionScript').classList.add('hide');
    document.getElementById('listTimer').classList.remove('active');
    document.getElementById('editTimer').classList.add('active');
    document.getElementById('listTimerFooter').classList.add('hide');
    document.getElementById('editTimerFooter').classList.remove('hide');
        
    if (timerid !== 0) {
        sendAPI("MYMPD_API_TIMER_GET", {"timerid": timerid}, parseEditTimer);
    }
    else {
        sendAPI("MPD_API_PLAYLIST_LIST", {"searchstr":"", "offset": 0, "limit": 0}, function(obj2) { 
            getAllPlaylists(obj2, 'selectTimerPlaylist', 'Database');
        });
        document.getElementById('inputTimerId').value = '0';
        document.getElementById('inputTimerName').value = '';
        toggleBtnChk('btnTimerEnabled', true);
        document.getElementById('selectTimerHour').value = '12';
        document.getElementById('selectTimerMinute').value = '0';
        document.getElementById('selectTimerAction').value = 'startplay';
        document.getElementById('inputTimerVolume').value = '50';
        document.getElementById('selectTimerPlaylist').value = 'Database';
        toggleBtnGroupValue(document.getElementById('btnTimerJukeboxModeGroup'), 1);
        let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
        for (let i = 0; i < weekdayBtns.length; i++) {
            toggleBtnChk(weekdayBtns[i], false);
        }
        document.getElementById('timerActionPlay').classList.remove('hide');
    }
    document.getElementById('inputTimerName').focus();
    removeIsInvalid(document.getElementById('editTimerForm'));    
    document.getElementById('invalidTimerWeekdays').style.display = 'none';
}

function parseEditTimer(obj) {
    let playlistValue = obj.result.playlist;
    sendAPI("MPD_API_PLAYLIST_LIST", {"searchstr":"", "offset": 0, "limit": 0}, function(obj2) { 
        getAllPlaylists(obj2, 'selectTimerPlaylist', playlistValue);
    });
    document.getElementById('inputTimerId').value = obj.result.timerid;
    document.getElementById('inputTimerName').value = obj.result.name;
    toggleBtnChk('btnTimerEnabled', obj.result.enabled);
    document.getElementById('selectTimerHour').value = obj.result.startHour;
    document.getElementById('selectTimerMinute').value = obj.result.startMinute;
    document.getElementById('selectTimerAction').value = obj.result.subaction;
    selectTimerActionChange(obj.result.arguments);
    document.getElementById('inputTimerVolume').value = obj.result.volume;
    toggleBtnGroupValue(document.getElementById('btnTimerJukeboxModeGroup'), obj.result.jukeboxMode);
    let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
    for (let i = 0; i < weekdayBtns.length; i++) {
        toggleBtnChk(weekdayBtns[i], obj.result.weekdays[i]);
    }
}

function selectTimerActionChange(values) {
    let el = document.getElementById('selectTimerAction');
    
    if (el.options[el.selectedIndex].value === 'startplay') {
        document.getElementById('timerActionPlay').classList.remove('hide');
        document.getElementById('timerActionScript').classList.add('hide');
    }
    else if (el.options[el.selectedIndex].parentNode.getAttribute('data-value') === 'script') {
        document.getElementById('timerActionScript').classList.remove('hide');
        document.getElementById('timerActionPlay').classList.add('hide');
        showTimerScriptArgs(el.options[el.selectedIndex], values);
    }
    else {
        document.getElementById('timerActionPlay').classList.add('hide');
        document.getElementById('timerActionScript').classList.add('hide');
    }
}

function showTimerScriptArgs(option, values) {
    if (values === undefined) {
        values = {};
    }
    let args = JSON.parse(option.getAttribute('data-arguments'));
    let list = '';
    for (let i = 0; i < args.arguments.length; i++) {
        list += '<div class="form-group row">' +
                  '<label class="col-sm-4 col-form-label" for="timerActionScriptArguments' + i + '">' + e(args.arguments[i]) + '</label>' +
                  '<div class="col-sm-8">' +
                    '<input name="timerActionScriptArguments' + i + '" class="form-control border-secondary" type="text" value="' +
                    (values[args.arguments[i]] ? e(values[args.arguments[i]]) : '') + '"' +
                    'data-name="' + args.arguments[i] + '">' +
                  '</div>' +
                '</div>';
    }
    if (args.arguments.length === 0) {
        list = 'No arguments';
    }
    document.getElementById('timerActionScriptArguments').innerHTML = list;
}

function showListTimer() {
    document.getElementById('listTimer').classList.add('active');
    document.getElementById('editTimer').classList.remove('active');
    document.getElementById('listTimerFooter').classList.remove('hide');
    document.getElementById('editTimerFooter').classList.add('hide');
    sendAPI("MYMPD_API_TIMER_LIST", {}, parseListTimer);
}

function parseListTimer(obj) {
    let tbody = document.getElementById('listTimer').getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    
    let activeRow = 0;
    let weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        let row = document.createElement('tr');
        row.setAttribute('data-id', obj.result.data[i].timerid);
        let tds = '<td>' + e(obj.result.data[i].name) + '</td>' +
                  '<td><button name="enabled" class="btn btn-secondary btn-xs clickable material-icons material-icons-small' +
                  (obj.result.data[i].enabled === true ? ' active' : '') + '">' +
                  (obj.result.data[i].enabled === true ? 'check' : 'radio_button_unchecked') + '</button></td>' +
                  '<td>' + zeroPad(obj.result.data[i].startHour, 2) + ':' + zeroPad(obj.result.data[i].startMinute,2) + ' ' + t('on') + ' ';
        let days = [];
        for (let j = 0; j < 7; j++) {
            if (obj.result.data[i].weekdays[j] === true) {
                days.push(t(weekdays[j]))
            }
        }
        tds += days.join(', ')  + '</td><td>' + prettyTimerAction(obj.result.data[i].action, obj.result.data[i].subaction) + '</td>' +
               '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">delete</a></td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= obj.result.returnedEntities; i --) {
        tr[i].remove();
    }

    if (obj.result.returnedEntities === 0) {
        tbody.innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="4">' + t('Empty list') + '</td></tr>';
    }     
}

function prettyTimerAction(action, subaction) {
    if (action === 'player' && subaction === 'startplay') {
        return t('Start playback');
    }
    if (action === 'player' && subaction === 'stopplay') {
        return t('Stop playback');
    }
    if (action === 'syscmd') {
        return t('System command') + ': ' + e(subaction);
    }
    if (action === 'script') {
        return t('Script') + ': ' + e(subaction);
    }
    return e(action) + ': ' + e(subaction);
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function saveTrigger() {
    let formOK = true;
    
    let nameEl = document.getElementById('inputTriggerName');
    if (!validatePlnameEl(nameEl)) {
        formOK = false;
    }
    
    if (formOK === true) {
        let args = {};
        let argEls = document.getElementById('triggerActionScriptArguments').getElementsByTagName('input');
        for (let i = 0; i < argEls.length; i ++) {
            args[argEls[i].getAttribute('data-name')] = argEls[i].value;
        }

        sendAPI("MPD_API_TRIGGER_SAVE", {
            "id": parseInt(document.getElementById('inputTriggerId').value),
            "name": nameEl.value,
            "event": getSelectValue('selectTriggerEvent'),
            "script": getSelectValue('selectTriggerScript'),
            "arguments": args
            }, showListTrigger, false);
    }
}

//eslint-disable-next-line no-unused-vars
function showEditTrigger(id) {
    document.getElementById('listTrigger').classList.remove('active');
    document.getElementById('newTrigger').classList.add('active');
    document.getElementById('listTriggerFooter').classList.add('hide');
    document.getElementById('newTriggerFooter').classList.remove('hide');
    
    const nameEl = document.getElementById('inputTriggerName');
    nameEl.classList.remove('is-invalid');
    nameEl.value = '';
    nameEl.focus();
    document.getElementById('inputTriggerId').value = '-1';
    document.getElementById('selectTriggerEvent').selectedIndex = 0;
    document.getElementById('selectTriggerScript').selectedIndex = 0;
    if (id > -1) {
        sendAPI("MPD_API_TRIGGER_GET", {"id": id}, parseTriggerEdit, false);
    }
    else {
        selectTriggerActionChange();
    }
}

function parseTriggerEdit(obj) {
    document.getElementById('inputTriggerId').value = obj.result.id;
    document.getElementById('inputTriggerName').value = obj.result.name;
    document.getElementById('selectTriggerEvent').value = obj.result.event;
    document.getElementById('selectTriggerScript').value = obj.result.script;
    selectTriggerActionChange(obj.result.arguments);
}

function selectTriggerActionChange(values) {
    let el = document.getElementById('selectTriggerScript');
    showTriggerScriptArgs(el.options[el.selectedIndex], values);
}

function showTriggerScriptArgs(option, values) {
    if (values === undefined) {
        values = {};
    }
    let args = JSON.parse(option.getAttribute('data-arguments'));
    let list = '';
    for (let i = 0; i < args.arguments.length; i++) {
        list += '<div class="form-group row">' +
                  '<label class="col-sm-4 col-form-label" for="triggerActionScriptArguments' + i + '">' + e(args.arguments[i]) + '</label>' +
                  '<div class="col-sm-8">' +
                    '<input name="triggerActionScriptArguments' + i + '" class="form-control border-secondary" type="text" value="' +
                    (values[args.arguments[i]] ? e(values[args.arguments[i]]) : '') + '"' +
                    'data-name="' + args.arguments[i] + '">' +
                  '</div>' +
                '</div>';
    }
    if (args.arguments.length === 0) {
        list = 'No arguments';
    }
    document.getElementById('triggerActionScriptArguments').innerHTML = list;
}

function showListTrigger() {
    document.getElementById('listTrigger').classList.add('active');
    document.getElementById('newTrigger').classList.remove('active');
    document.getElementById('listTriggerFooter').classList.remove('hide');
    document.getElementById('newTriggerFooter').classList.add('hide');
    sendAPI("MPD_API_TRIGGER_LIST", {}, parseTriggerList, false);
}

function deleteTrigger(id) {
    sendAPI("MPD_API_TRIGGER_DELETE", {"id": id}, function() {
        sendAPI("MPD_API_TRIGGER_LIST", {}, parseTriggerList, false);
    }, true);
}

function parseTriggerList(obj) {
    if (obj.result.data.length > 0) {
        let triggerList = '';
        for (let i = 0; i < obj.result.data.length; i++) {
            triggerList += '<tr data-trigger-id="' + encodeURI(obj.result.data[i].id) + '"><td class="' +
                (obj.result.data[i].name === settings.trigger ? 'font-weight-bold' : '') +
                '">' + e(obj.result.data[i].name) + 
                '</td>' +
                '<td>' + t(obj.result.data[i].eventName) + '</td>' +
                '<td>' + e(obj.result.data[i].script) + '</td>' +
                '<td data-col="Action">' +
                (obj.result.data[i].name === 'default' || obj.result.data[i].name === settings.trigger  ? '' : 
                    '<a href="#" title="' + t('Delete') + '" data-action="delete" class="material-icons color-darkgrey">delete</a>') +
                '</td></tr>';
        }
        document.getElementById('listTriggerList').innerHTML = triggerList;
    }
    else {
        document.getElementById('listTriggerList').innerHTML = '<tr class="not-clickable"><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="2">' + t('Empty list') + '</td></tr>';
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function escapeMPD(x) {
    return x.replace(/(["'])/g, function(m0, m1) {
        if (m1 === '"') return '\\"';
        else if (m1 === '\'') return '\\\'';
        else if (m1 === '\\') return '\\\\';
    });
}

function unescapeMPD(x) {
    return x.replace(/(\\'|\\"|\\\\)/g, function(m0, m1) {
        if (m1 === '\\"') return '"';
        else if (m1 === '\\\'') return '\'';
        else if (m1 === '\\\\') return '\\';
    });
}

function removeIsInvalid(el) {
    let els = el.querySelectorAll('.is-invalid');
    for (let i = 0; i < els.length; i++) {
        els[i].classList.remove('is-invalid');
    }
}

function getSelectValue(el) {
    if (typeof el === 'string')	{
        el = document.getElementById(el);
    }
    if (el && el.selectedIndex >= 0) {
        return el.options[el.selectedIndex].value;
    }
    return undefined;
}

function getSelectedOptionAttribute(selectId, attribute) {
    let el = document.getElementById(selectId);
    if (el && el.selectedIndex >= 0) {
        return el.options[el.selectedIndex].getAttribute(attribute);
    }
    return undefined;
}

function alignDropdown(el) {
    const x = getXpos(el.children[0]);
    
    if (x < domCache.body.offsetWidth * 0.66) {
        if (el.id === 'navState') {
            el.classList.remove('dropdown');
            el.classList.add('dropright');
        }
        else {
            el.getElementsByClassName('dropdown-menu')[0].classList.remove('dropdown-menu-right');
        }
    }
    else {
        el.getElementsByClassName('dropdown-menu')[0].classList.add('dropdown-menu-right');
        el.classList.add('dropdown');
        el.classList.remove('dropright');
    }
}

function getXpos(el) {
    var xPos = 0;
    while (el) {
        xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
        el = el.offsetParent;
    }
    return xPos;
}

function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

function dirname(uri) {
    return uri.replace(/\/[^/]*$/, '');
}

function basename(uri, removeQuery) {
    if (removeQuery === true) {
        return uri.split('/').reverse()[0].split(/[?#]/)[0];
    }
    else {
        return uri.split('/').reverse()[0];
    }
}

function filetype(uri) {
    if (uri === undefined) {
        return '';
    }
    let ext = uri.split('.').pop().toUpperCase();
    switch (ext) {
        case 'MP3':  return ext + ' - MPEG-1 Audio Layer III';
        case 'FLAC': return ext + ' - Free Lossless Audio Codec';
        case 'OGG':  return ext + ' - Ogg Vorbis';
        case 'OPUS': return ext + ' - Opus Audio';
        case 'WAV':  return ext + ' - WAVE Audio File';
        case 'WV':   return ext + ' - WavPack';
        case 'AAC':  return ext + ' - Advancded Audio Coding';
        case 'MPC':  return ext + ' - Musepack';
        case 'MP4':  return ext + ' - MPEG-4';
        case 'APE':  return ext + ' - Monkey Audio ';
        case 'WMA':  return ext + ' - Windows Media Audio';
        default:     return ext;
    }
}

function fileformat(audioformat) {
    return audioformat.bits + t('bits') + ' - ' + audioformat.sampleRate / 1000 + t('kHz');
}

function scrollToPosY(pos) {
    document.body.scrollTop = pos; // For Safari
    document.documentElement.scrollTop = pos; // For Chrome, Firefox, IE and Opera
}

function selectTag(btnsEl, desc, setTo) {
    let btns = document.getElementById(btnsEl);
    let aBtn = btns.querySelector('.active')
    if (aBtn) {
        aBtn.classList.remove('active');
    }
    aBtn = btns.querySelector('[data-tag=' + setTo + ']');
    if (aBtn) {
        aBtn.classList.add('active');
        if (desc !== undefined) {
            document.getElementById(desc).innerText = aBtn.innerText;
            document.getElementById(desc).setAttribute('data-phrase', aBtn.innerText);
        }
    }
}

function addTagList(el, list) {
    let tagList = '';
    if (list === 'searchtags') {
        if (settings.featTags === true) {
            tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="any">' + t('Any Tag') + '</button>';
        }
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="filename">' + t('Filename') + '</button>';
    }
    for (let i = 0; i < settings[list].length; i++) {
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="' + settings[list][i] + '">' + t(settings[list][i]) + '</button>';
    }
    if (el === 'BrowseNavFilesystemDropdown' || el === 'BrowseNavPlaylistsDropdown') {
        if (settings.featTags === true && settings.featAdvsearch === true) {
            tagList = '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Database">' + t('Database') + '</button>';
        }
        else {
            tagList = '';
        }
    }
    if (el === 'BrowseDatabaseByTagDropdown' || el === 'BrowseNavFilesystemDropdown' || el === 'BrowseNavPlaylistsDropdown') {
        if (el === 'BrowseDatabaseByTagDropdown') {
            tagList += '<div class="dropdown-divider"></div>';
        }
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block' + (el === 'BrowseNavPlaylistsDropdown' ? ' active' : '') + '" data-tag="Playlists">' + t('Playlists') + '</button>' +
            '<button type="button" class="btn btn-secondary btn-sm btn-block' + (el === 'BrowseNavFilesystemDropdown' ? ' active' : '') + '" data-tag="Filesystem">' + t('Filesystem') + '</button>'
    }
    else if (el === 'databaseSortTagsList') {
        if (settings.tags.includes('Date') === true && settings[list].includes('Date') === false) {
            tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Date">' + t('Date') + '</button>';
        }
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Last-Modified">' + t('Last modified') + '</button>';
    }
    document.getElementById(el).innerHTML = tagList;
}

function addTagListSelect(el, list) {
    let tagList = '';
    if (el === 'saveSmartPlaylistSort' || el === 'selectSmartplsSort') {
        tagList += '<option value="">' + t('Disabled') + '</option>';
        tagList += '<option value="shuffle">' + t('Shuffle') + '</option>';
        tagList += '<optgroup label="' + t('Sort by tag') + '">';
        tagList += '<option value="filename">' + t('Filename') + '</option>';
    }
    else if (el === 'selectJukeboxUniqueTag' && settings.browsetags.includes('Title') === false) {
        //Title tag should be always in the list
        tagList = '<option value="Title">' + t('Song') + '</option>';
    }
    for (let i = 0; i < settings[list].length; i++) {
        tagList += '<option value="' + settings[list][i] + '">' + t(settings[list][i]) + '</option>';
    }
    if (el === 'saveSmartPlaylistSort' || el === 'selectSmartplsSort') {
        tagList += '</optgroup>';
    }
    document.getElementById(el).innerHTML = tagList;
}

//eslint-disable-next-line no-unused-vars
function openModal(modal) {
    window[modal].show();
}

//eslint-disable-next-line no-unused-vars
function openDropdown(dropdown) {
    window[dropdown].toggle();
}

//eslint-disable-next-line no-unused-vars
function focusSearch() {
    if (app.current.app === 'Queue') {
        document.getElementById('searchqueuestr').focus();
    }
    else if (app.current.app === 'Search') {
        domCache.searchstr.focus();
    }
    else {
        appGoto('Search');
    }
}

function btnWaiting(btn, waiting) {
    if (waiting === true) {
        let spinner = document.createElement('span');
        spinner.classList.add('spinner-border', 'spinner-border-sm', 'mr-2');
        btn.insertBefore(spinner, btn.firstChild);
        btn.setAttribute('disabled', 'disabled');
    }
    else {
        btn.removeAttribute('disabled');
        if (btn.firstChild.nodeName === 'SPAN') {
            btn.firstChild.remove();
        }
    }
}

function toggleBtnGroupValue(btngrp, value) {
    let btns = btngrp.getElementsByTagName('button');
    let b = btns[0];
    let valuestr = value;
    if (isNaN(value) === false) {
        valuestr = value.toString();
    }
    for (let i = 0; i < btns.length; i++) {
        if (btns[i].getAttribute('data-value') === valuestr) {
            btns[i].classList.add('active');
            b = btns[i];
        }
        else {
            btns[i].classList.remove('active');
        }
    }
    return b;
}

function toggleBtnGroupValueCollapse(btngrp, collapse, value) {
    let activeBtn = toggleBtnGroupValue(btngrp, value);
    if (activeBtn.getAttribute('data-collapse') === 'show') {
        document.getElementById(collapse).classList.add('show');
    }
    else {
        document.getElementById(collapse).classList.remove('show');
    }
}

function toggleBtnGroup(btn) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    let btns = b.parentNode.getElementsByTagName('button');
    for (let i = 0; i < btns.length; i++) {
        if (btns[i] === b) {
            btns[i].classList.add('active');
        }
        else {
            btns[i].classList.remove('active');
        }
    }
    return b;
}

function getBtnGroupValue(btnGroup) {
    let activeBtn = document.getElementById(btnGroup).getElementsByClassName('active');
    if (activeBtn.length === 0) {
        activeBtn = document.getElementById(btnGroup).getElementsByTagName('button');    
    }
    return activeBtn[0].getAttribute('data-value');
}

//eslint-disable-next-line no-unused-vars
function toggleBtnGroupCollapse(btn, collapse) {
    let activeBtn = toggleBtnGroup(btn);
    if (activeBtn.getAttribute('data-collapse') === 'show') {
        if (document.getElementById(collapse).classList.contains('show') === false) {
            window[collapse].show();
        }
    }
    else {
        window[collapse].hide();
    }
}

function toggleBtn(btn, state) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    if (!b) {
        return;
    }
    if (state === undefined) {
        //toggle state
        state = b.classList.contains('active') ? false : true;
    }

    if (state === true || state === 1) {
        b.classList.add('active');
    }
    else {
        b.classList.remove('active');
    }
}

function toggleBtnChk(btn, state) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    if (!b) {
        return;
    }
    if (state === undefined) {
        //toggle state
        state = b.classList.contains('active') ? false : true;
    }

    if (state === true || state === 1) {
        b.classList.add('active');
        b.innerText = 'check';
        return true;
    }
    else {
        b.classList.remove('active');
        b.innerText = 'radio_button_unchecked';
        return false;
    }
}

function toggleBtnChkCollapse(btn, collapse, state) {
    let checked = toggleBtnChk(btn, state);
    if (checked === true) {
        document.getElementById(collapse).classList.add('show');
    }
    else{
        document.getElementById(collapse).classList.remove('show');
    }
}

function setPagination(total, returned) {
    let cat = (app.current.app === 'Playback' ? 'Browse' : app.current.app) + (app.current.tab === undefined ? '' : app.current.tab);
    let totalPages = app.current.limit > 0 ? Math.ceil(total / app.current.limit) : 1;
    if (totalPages === 0) {
        totalPages = 1;
    }
    let curPage = app.current.limit > 0 ? app.current.offset / app.current.limit + 1 : 1;
    
    const paginationHTML = '<button title="' + t('First page') + '" type="button" class="btn btn-group-prepend btn-secondary material-icons">first_page</button>' +
          '<button title="' + t('Previous page') + '" type="button" class="btn btn-group-prepend btn-secondary material-icons">navigate_before</button>' +
          '<div class="btn-group">' +
            '<button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown"></button>' +
            '<div class="dropdown-menu bg-lite-dark px-2 pages dropdown-menu-right"></div>' +
          '</div>' +
          '<button title="' + t('Next page') + '" type="button" class="btn btn-secondary btn-group-append material-icons">navigate_next</button>' +
          '<button title="' + t('Last page') + '" type="button" class="btn btn-secondary btn-group-append material-icons">last_page</button>';

    let bottomBarHTML = '<button type="button" class="btn btn-secondary material-icons" title="' + t('To top') + '">keyboard_arrow_up</button>' +
          '<div>' +
          '<select class="form-control custom-select border-secondary" title="' + t('Elements per page') + '">';
    let nrEls = [25, 50, 100, 200, 0];
    for (let i of nrEls) {
        bottomBarHTML += '<option value="' + i + '"' + (app.current.limit === i ? ' selected' : '') + '>' + (i > 0 ? i : t('All')) + '</option>';
    }
    bottomBarHTML += '</select>' +
          '</div>' +
          '<div id="' + cat + 'PaginationBottom" class="btn-group dropup pagination">' +
          paginationHTML +
          '</div>' +
          '</div>';

    const bottomBar = document.getElementById(cat + 'ButtonsBottom');
    bottomBar.innerHTML = bottomBarHTML;
    
    const buttons = bottomBar.getElementsByTagName('button');
    buttons[0].addEventListener('click', function() {
        event.preventDefault();
        scrollToPosY(0);
    }, false);
    
    bottomBar.getElementsByTagName('select')[0].addEventListener('change', function(event) {
        const newLimit = parseInt(getSelectValue(event.target));
        if (app.current.limit !== newLimit) {
            gotoPage(app.current.offset, newLimit);
        }
    }, false);
    
    document.getElementById(cat + 'PaginationTop').innerHTML = paginationHTML;
    
    const offsetLast = app.current.offset + app.current.limit;
    let p = [ document.getElementById(cat + 'PaginationTop'), document.getElementById(cat + 'PaginationBottom') ];
    
    for (let i = 0; i < p.length; i++) {
        const first = p[i].children[0];
        const prev = p[i].children[1];
        const page = p[i].children[2].children[0];
        const pages = p[i].children[2].children[1];
        const next = p[i].children[3];
        const last = p[i].children[4];
    
        page.innerText = curPage + ' / ' + totalPages;
        if (totalPages > 1) {
            page.removeAttribute('disabled');
            let pl = '';
            for (let j = 0; j < totalPages; j++) {
                let o = j * app.current.limit;
                pl += '<button data-offset="' + o + '" type="button" class="btn-sm btn btn-secondary' +
                      ( o === app.current.offset ? ' active' : '') + '">' +
                      ( j + 1) + '</button>';
            }
            pages.innerHTML = pl;
            page.classList.remove('nodropdown');
            pages.addEventListener('click', function(event) {
                if (event.target.nodeName === 'BUTTON') {
                    gotoPage(event.target.getAttribute('data-offset'));
                }
            }, false);
            //eslint-disable-next-line no-unused-vars
            const pagesDropdown = new BSN.Dropdown(page);
            
            let lastPageOffset = (totalPages - 1) * app.current.limit;
            if (lastPageOffset === app.current.offset) {
                last.setAttribute('disabled', 'disabled');
            }
            else {
                last.removeAttribute('disabled');
                last.classList.remove('hide');
                next.classList.remove('rounded-right');
                last.addEventListener('click', function() {
                    event.preventDefault();
                    gotoPage(lastPageOffset);
                }, false);
            }
        }
        else if (total === -1) {
            page.setAttribute('disabled', 'disabled');
            page.innerText = curPage;
            page.classList.add('nodropdown');
            last.setAttribute('disabled', 'disabled');
            last.classList.add('hide');
            next.classList.add('rounded-right');
        }
        else {
            page.setAttribute('disabled', 'disabled');
            page.classList.add('nodropdown');
            last.setAttribute('disabled', 'disabled');
        }
        
        if ((total > offsetLast && offsetLast > 0 ) || (total === -1 && returned >= app.current.limit)) {
            next.removeAttribute('disabled');
            p[i].classList.remove('hide');
            next.addEventListener('click', function() {
                event.preventDefault();
                gotoPage('next');
            }, false);
        }
        else {
            next.setAttribute('disabled', 'disabled');
            if (i === 0) {
                p[i].classList.add('hide');
            }
        }

        if (app.current.offset > 0) {
            prev.removeAttribute('disabled');
            p[i].classList.remove('hide');
            prev.addEventListener('click', function() {
                event.preventDefault();
                gotoPage('prev');
            }, false);
            first.removeAttribute('disabled');
            first.addEventListener('click', function() {
                event.preventDefault();
                gotoPage(0);
            }, false);
        }
        else {
            prev.setAttribute('disabled', 'disabled');
            first.setAttribute('disabled', 'disabled');
        }
    }
    
    //hide bottom pagination bar if returned < limit
    if (returned < app.current.limit) {
        document.getElementById(cat + 'ButtonsBottom').classList.add('hide');
    }
    else {
        document.getElementById(cat + 'ButtonsBottom').classList.remove('hide');
    }
}

function genId(x) {
    return 'id' + x.replace(/[^\w-]/g, '');
}

function parseCmd(event, href) {
    if (event !== null) {
        event.preventDefault();
    }
    let cmd = href;
    if (typeof(href) === 'string') {
        cmd = JSON.parse(href);
    }

    if (typeof window[cmd.cmd] === 'function') {
        switch(cmd.cmd) {
            case 'sendAPI':
                sendAPI(cmd.options[0].cmd, {}); 
                break;
            case 'toggleBtn':
            case 'toggleBtnChk':
            case 'toggleBtnGroup':
            case 'toggleBtnGroupCollapse':
            case 'zoomPicture':
            case 'setPlaySettings':
                window[cmd.cmd](event.target, ... cmd.options);
                break;
            case 'toggleBtnChkCollapse':
                window[cmd.cmd](event.target, undefined, ... cmd.options);
                break;
            default:
                window[cmd.cmd](... cmd.options);
        }
    }
    else {
        logError('Can not execute cmd: ' + cmd);
    }
}

function gotoPage(x, limit) {
    switch (x) {
        case 'next':
            app.current.offset = app.current.offset + app.current.limit;
            break;
        case 'prev':
            app.current.offset = app.current.offset - app.current.limit;
            if (app.current.offset < 0) {
                app.current.offset = 0;
            }
            break;
        default:
            app.current.offset = x;
    }
    if (limit !== undefined) {
        app.current.limit = limit;
        if (app.current.limit === 0) {
            app.current.offset = 0;
        }
        else if (app.current.offset % app.current.limit > 0) {
            app.current.offset = Math.floor(app.current.offset / app.current.limit);
        }
    }
    appGoto(app.current.app, app.current.tab, app.current.view, 
        app.current.offset, app.current.limit, app.current.filter, app.current.sort, app.current.tag, app.current.search, 0);
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2021 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function validateFilenameString(str) {
    if (str === '') {
        return false;
    }
    else if (str.match(/^[\w-.]+$/) !== null) {
        return true;
    }
    else {
        return false;
    }
}

function validateFilename(el) {
    if (validateFilenameString(el.value) === false) {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateFilenameList(el) {
    el.classList.remove('is-invalid');
    
    let filenames = el.value.split(',');
    for (let i = 0; i < filenames.length; i++) {
        if (validateFilenameString(filenames[i].trim()) === false) {
            el.classList.add('is-invalid');
            return false;
        }
    }
    return true;
}

function validatePath(el) {
    if (el.value === '') {
        el.classList.add('is-invalid');
        return false;
    }
    else if (el.value.match(/^\/[/.\w-]+$/) !== null) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}

function validatePlnameEl(el) {
    if (validatePlname(el.value) === false) {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validatePlname(x) {
    if (x === '') {
        return false;
    }
    else if (x.match(/\/|\r|\n|"|'/) === null) {
        return true;
    }
    else {
        return false;
    }
}

function validateNotBlank(el) {
    let value = el.value.replace(/\s/g, '');
    if (value === '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateInt(el) {
    let value = el.value.replace(/\d/g, '');
    if (value !== '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateFloat(el) {
    let value = el.value.replace(/[\d-.]/g, '');
    if (value !== '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateStream(el) {
    if (el.value.indexOf('://') > -1) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}

function validateHost(el) {
    if (el.value.match(/^([\w-.]+)$/) !== null) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}
