"use strict";
(function(A,e){"function"===typeof define&&define.amd?define([],e):"object"===typeof module&&module.exports?module.exports=e():(e=e(),A.Alert=e.Alert,A.Button=e.Button,A.Collapse=e.Collapse,A.Dropdown=e.Dropdown,A.Modal=e.Modal,A.Popover=e.Popover,A.Tab=e.Tab,A.Carousel=e.Carousel)})(this,function(){var A="undefined"!==typeof global?global:this||window,e=document,M=e.documentElement,Q=A.BSN={},E=Q.supports=[],T="onmouseleave"in e?["mouseenter","mouseleave"]:["mouseover","mouseout"],ha=/\b(top|bottom|left|right)+/,
V="WebkitTransition"in M.style||"transition"in M.style,ia="WebkitTransition"in M.style?"webkitTransitionEnd":"transitionend",ja="WebkitDuration"in M.style?"webkitTransitionDuration":"transitionDuration",N=function(a){a.focus?a.focus():a.setActive()},v=function(a,b){a.classList.add(b)},w=function(a,b){a.classList.remove(b)},r=function(a,b){return a.classList.contains(b)},F=function(a,b){return[].slice.call(a.getElementsByClassName(b))},y=function(a,b){b=b?b:e;return"object"===typeof a?a:b.querySelector(a)},
I=function(a,b){var g=b.charAt(0),f=b.substr(1);if("."===g)for(;a&&a!==e;a=a.parentNode){if(null!==y(b,a.parentNode)&&r(a,f))return a}else if("#"===g)for(;a&&a!==e;a=a.parentNode)if(a.id===f)return a;return!1},t=function(a,b,g,f){a.addEventListener(b,g,f||!1)},H=function(a,b,g,f){a.removeEventListener(b,g,f||!1)},U=function(a,b,g,f){t(a,b,function d(e){e.target===a&&(g(e),H(a,b,d,f))},f)},J=function(){var a=!1;try{var b=Object.defineProperty({},"passive",{get:function(){a=!0}});U(A,null,null,b)}catch(g){}return a}()?
{passive:!0}:!1,W=function(a){a=V?A.getComputedStyle(a)[ja]:0;a=parseFloat(a);return a="number"!==typeof a||isNaN(a)?0:1E3*a},K=function(a,b){var e=0;W(a)?U(a,ia,function(a){!e&&b(a);e=1}):setTimeout(function(){!e&&b();e=1},17)},z=function(a,b,e){a=new CustomEvent(a+".bs."+b,{cancelable:!0});a.relatedTarget=e;return a};Q.version="2.0.28";var X=function(a){a=y(a);var b=this,e=z("close","alert"),f=z("closed","alert"),k=I(a,".alert"),v=function(c){k=I(c.target,".alert");(a=y('[data-dismiss="alert"]',
k))&&k&&(a===c.target||a.contains(c.target))&&b.close()},d=function(){H(a,"click",v);k.parentNode.removeChild(k);k.dispatchEvent(f)};this.close=function(){k&&a&&r(k,"show")&&(k.dispatchEvent(e),e.defaultPrevented||(w(k,"show"),k&&(r(k,"fade")?K(k,d):d())))};"Alert"in a||t(a,"click",v);a.Alert=b};E.push(["Alert",X,'[data-dismiss="alert"]']);var Y=function(a){a=y(a);var b=!1,g=z("change","button"),f=function(a){32===(a.which||a.keyCode)&&a.target===e.activeElement&&C(a)},k=function(a){32===(a.which||
a.keyCode)&&a.preventDefault()},C=function(c){var e="LABEL"===c.target.tagName?c.target:"LABEL"===c.target.parentNode.tagName?c.target.parentNode:null;if(e){var f=F(e.parentNode,"btn"),d=e.getElementsByTagName("INPUT")[0];if(d){d.dispatchEvent(g);a.dispatchEvent(g);if("checkbox"===d.type){if(g.defaultPrevented)return;d.checked?(w(e,"active"),d.getAttribute("checked"),d.removeAttribute("checked"),d.checked=!1):(v(e,"active"),d.getAttribute("checked"),d.setAttribute("checked","checked"),d.checked=!0);
b||(b=!0)}if("radio"===d.type&&!b){if(g.defaultPrevented)return;if(!d.checked||0===c.screenX&&0==c.screenY)for(v(e,"active"),v(e,"focus"),d.setAttribute("checked","checked"),b=d.checked=!0,c=0,d=f.length;c<d;c++){var h=f[c],m=h.getElementsByTagName("INPUT")[0];h!==e&&r(h,"active")&&(m.dispatchEvent(g),w(h,"active"),m.removeAttribute("checked"),m.checked=!1)}}setTimeout(function(){b=!1},50)}}},d=function(a){v(a.target.parentNode,"focus")},c=function(a){w(a.target.parentNode,"focus")};if(!("Button"in
a))for(t(a,"click",C),t(a,"keyup",f),t(a,"keydown",k),k=F(a,"btn"),f=0;f<k.length;f++){var l=k[f].getElementsByTagName("INPUT")[0];t(l,"focus",d);t(l,"blur",c)}d=F(a,"btn");c=d.length;for(f=0;f<c;f++)!r(d[f],"active")&&y("input:checked",d[f])&&v(d[f],"active");a.Button=this};E.push(["Button",Y,'[data-toggle="buttons"]']);var Z=function(a,b){a=y(a);b=b||{};var e=null,f=null,k=this,C=a.getAttribute("data-parent"),d,c,l=z("show","collapse"),h=z("shown","collapse"),p=z("hide","collapse"),q=z("hidden",
"collapse"),B=function(a,c){a.dispatchEvent(l);l.defaultPrevented||(a.isAnimating=!0,v(a,"collapsing"),w(a,"collapse"),a.style.height=a.scrollHeight+"px",K(a,function(){a.isAnimating=!1;a.setAttribute("aria-expanded","true");c.setAttribute("aria-expanded","true");w(a,"collapsing");v(a,"collapse");v(a,"show");a.style.height="";a.dispatchEvent(h)}))},x=function(a,c){a.dispatchEvent(p);p.defaultPrevented||(a.isAnimating=!0,a.style.height=a.scrollHeight+"px",w(a,"collapse"),w(a,"show"),v(a,"collapsing"),
a.offsetWidth,a.style.height="0px",K(a,function(){a.isAnimating=!1;a.setAttribute("aria-expanded","false");c.setAttribute("aria-expanded","false");w(a,"collapsing");v(a,"collapse");a.style.height="";a.dispatchEvent(q)}))};this.toggle=function(a){a.preventDefault();r(f,"show")?k.hide():k.show()};this.hide=function(){f.isAnimating||(x(f,a),v(a,"collapsed"))};this.show=function(){e&&(c=(d=y(".collapse.show",e))&&(y('[data-target="#'+d.id+'"]',e)||y('[href="#'+d.id+'"]',e)));if(!f.isAnimating||d&&!d.isAnimating)c&&
d!==f&&(x(d,c),v(c,"collapsed")),B(f,a),w(a,"collapsed")};"Collapse"in a||t(a,"click",k.toggle);f=function(){var c=a.href&&a.getAttribute("href"),b=a.getAttribute("data-target");return(c=c||b&&"#"===b.charAt(0)&&b)&&y(c)}();f.isAnimating=!1;e=y(b.parent)||C&&I(a,C);a.Collapse=k};E.push(["Collapse",Z,'[data-toggle="collapse"]']);var aa=function(a,b){a=y(a);this.persist=!0===b||"true"===a.getAttribute("data-persist")||!1;var g=this,f=a.parentNode,k=null,C,d,c,l,h=y(".dropdown-menu",f),p=function(){for(var a=
h.children,c=[],b=0;b<a.length;b++){if(a[b].children.length)for(var e=0;e<a[b].children.length;e++)"A"===a[b].children[e].tagName&&c.push(a[b].children[e]);"A"===a[b].tagName&&c.push(a[b])}return c}(),q=function(a){(a.href&&"#"===a.href.slice(-1)||a.parentNode&&a.parentNode.href&&"#"===a.parentNode.href.slice(-1))&&this.preventDefault()},B=function(){var c=a.open?t:H;c(e,"click",x);c(e,"keydown",A);c(e,"keyup",n);c(e,"focus",x,!0)},x=function(c){if(void 0!==c.target.getAttribute){var b=c.target,e=
b&&(b.getAttribute("data-toggle")||b.parentNode&&"getAttribute"in b.parentNode&&b.parentNode.getAttribute("data-toggle"));if("focus"!==c.type||b!==a&&b!==h&&!h.contains(b))if(b!==h&&!h.contains(b)||!g.persist&&!e)k=b===a||a.contains(b)?a:null,G(),q.call(c,b)}},m=function(b){k=a;O();q.call(b,b.target)},A=function(a){var b=a.which||a.keyCode;38!==b&&40!==b||a.preventDefault()},n=function(b){b=b.which||b.keyCode;var c=e.activeElement,d=p.indexOf(c),f=c===a,l=h.contains(c);if((c=c.parentNode===h||c.parentNode.parentNode===
h)||f){do if(d=f?0:38===b?1<d?d-1:0:40===b?d<p.length-1?d+1:d:d,0===d||d===p.length-1)break;while(!p[d].offsetHeight);p[d]&&N(p[d])}(p.length&&c||!p.length&&(l||f)||!l)&&a.open&&27===b&&(g.toggle(),k=null)},O=function(){C=z("show","dropdown",k);f.dispatchEvent(C);C.defaultPrevented||(v(h,"show"),v(f,"show"),a.setAttribute("aria-expanded",!0),a.open=!0,H(a,"click",m),setTimeout(function(){N(h.getElementsByTagName("INPUT")[0]||a);B();d=z("shown","dropdown",k);f.dispatchEvent(d)},1))},G=function(){c=
z("hide","dropdown",k);f.dispatchEvent(c);c.defaultPrevented||(w(h,"show"),w(f,"show"),a.setAttribute("aria-expanded",!1),a.open=!1,B(),N(a),setTimeout(function(){t(a,"click",m)},1),l=z("hidden","dropdown",k),f.dispatchEvent(l))};a.open=!1;this.toggle=function(){r(f,"show")&&a.open?G():O()};"Dropdown"in a||(!1 in h&&h.setAttribute("tabindex","0"),t(a,"click",m));a.Dropdown=g};E.push(["Dropdown",aa,'[data-toggle="dropdown"]']);var ba=function(a,b){a=y(a);var g,f,k,C,d=a.getAttribute("data-target")||
a.getAttribute("href");d=y(d);var c=r(a,"modal")?a:d;r(a,"modal")&&(a=null);if(c){b=b||{};this.keyboard=!1===b.keyboard||"false"===c.getAttribute("data-keyboard")?!1:!0;this.backdrop="static"===b.backdrop||"static"===c.getAttribute("data-backdrop")?"static":!0;this.backdrop=!1===b.backdrop||"false"===c.getAttribute("data-backdrop")?!1:this.backdrop;this.animation=r(c,"fade")?!0:!1;this.content=b.content;c.isAnimating=!1;var l=this,h=null,p,q,B,x=F(M,"fixed-top").concat(F(M,"fixed-bottom")),m=function(){var a=
r(e.body,"modal-open"),b=A.getComputedStyle(e.body);b=parseInt(b.paddingRight,10);e.body.style.paddingRight=b+(a?0:p)+"px";c.style.paddingRight=p?p+"px":"";if(x.length)for(var d=0;d<x.length;d++)b=A.getComputedStyle(x[d]).paddingRight,x[d].style.paddingRight=parseInt(b)+(a?0:p)+"px"},D=function(){var a=e.createElement("div");a.className="modal-scrollbar-measure";e.body.appendChild(a);var b=a.offsetWidth-a.clientWidth;e.body.removeChild(a);return b},n=function(){(q=y(".modal-backdrop"))&&!F(e,"modal show")[0]&&
(e.body.removeChild(q),q=null);if(null===q&&(w(e.body,"modal-open"),e.body.style.paddingRight="",c.style.paddingRight="",x.length))for(var a=0;a<x.length;a++)x[a].style.paddingRight=""},O=function(a){a(A,"resize",l.update,J);a(c,"click",L);a(e,"keydown",R)},G=function(){c.style.display="block";p=D();m();!F(e,"modal show")[0]&&v(e.body,"modal-open");v(c,"show");c.setAttribute("aria-hidden",!1);r(c,"fade")?K(c,u):u()},u=function(){N(c);c.isAnimating=!1;O(t);f=z("shown","modal",h);c.dispatchEvent(f)},
P=function(){c.style.display="";a&&N(a);(q=y(".modal-backdrop"))&&r(q,"show")&&!F(e,"modal show")[0]?(w(q,"show"),K(q,n)):n();O(H);c.isAnimating=!1;C=z("hidden","modal");c.dispatchEvent(C)};b=function(b){if(!c.isAnimating){var e=b.target;e=e.hasAttribute("data-target")||e.hasAttribute("href")?e:e.parentNode;e!==a||r(c,"show")||(h=c.modalTrigger=a,l.show(),b.preventDefault())}};var R=function(a){c.isAnimating||l.keyboard&&27==a.which&&r(c,"show")&&l.hide()},L=function(a){if(!c.isAnimating){var b=a.target;
r(c,"show")&&("modal"===b.parentNode.getAttribute("data-dismiss")||"modal"===b.getAttribute("data-dismiss")||b===c&&"static"!==l.backdrop)&&(l.hide(),h=null,a.preventDefault())}};this.toggle=function(){r(c,"show")?this.hide():this.show()};this.show=function(){if(!r(c,"show")&&(g=z("show","modal",h),c.dispatchEvent(g),!g.defaultPrevented)){c.isAnimating=!0;var a=F(e,"modal show")[0];a&&a!==c&&("modalTrigger"in a&&a.modalTrigger.Modal.hide(),"Modal"in a&&a.Modal.hide());if(l.backdrop){var b=e.createElement("div");
q=y(".modal-backdrop");null===q&&(b.setAttribute("class","modal-backdrop"+(l.animation?" fade":"")),q=b,e.body.appendChild(q))}!q||a||r(q,"show")||(q.offsetWidth,B=W(q),v(q,"show"));a?G():setTimeout(G,q&&B?B:0)}};this.hide=function(){r(c,"show")&&(k=z("hide","modal"),c.dispatchEvent(k),k.defaultPrevented||(c.isAnimating=!0,w(c,"show"),c.setAttribute("aria-hidden",!0),r(c,"fade")?K(c,P):P()))};this.setContent=function(a){y(".modal-content",c).innerHTML=a};this.update=function(){r(c,"show")&&(p=D(),
m())};!a||"Modal"in a||t(a,"click",b);l.content&&l.setContent(l.content);a?(a.Modal=l,c.modalTrigger=a):c.Modal=l}};E.push(["Modal",ba,'[data-toggle="modal"]']);var ca=function(a,b){a=y(a);b=b||{};var g=a.getAttribute("data-trigger"),f=a.getAttribute("data-animation"),k=a.getAttribute("data-placement"),C=a.getAttribute("data-dismissible"),d=a.getAttribute("data-delay"),c=a.getAttribute("data-container"),l=z("show","popover"),h=z("shown","popover"),p=z("hide","popover"),q=z("hidden","popover"),B=y(b.container);
c=y(c);var x=I(a,".modal"),m=I(a,".fixed-top"),D=I(a,".fixed-bottom");this.template=b.template?b.template:null;this.trigger=b.trigger?b.trigger:g||"hover";this.animation=b.animation&&"fade"!==b.animation?b.animation:f||"fade";this.placement=b.placement?b.placement:k||"top";this.delay=parseInt(b.delay||d)||200;this.dismissible=b.dismissible||"true"===C?!0:!1;this.container=B?B:c?c:m?m:D?D:x?x:e.body;var n=this,O=b.title||a.getAttribute("data-title")||null,G=b.content||a.getAttribute("data-content")||
null;if(G||this.template){var u=null,F=0,R=this.placement,L=function(a){null!==u&&a.target===y(".close",u)&&n.hide()},E=function(b){"click"!=n.trigger&&"focus"!=n.trigger||n.dismissible||b(a,"blur",n.hide);n.dismissible&&b(e,"click",L);b(A,"resize",n.hide,J)},N=function(){E(t);a.dispatchEvent(h)},S=function(){E(H);n.container.removeChild(u);u=F=null;a.dispatchEvent(q)};this.toggle=function(){null===u?n.show():n.hide()};this.show=function(){clearTimeout(F);F=setTimeout(function(){if(null===u&&(a.dispatchEvent(l),
!l.defaultPrevented)){R=n.placement;O=b.title||a.getAttribute("data-title");G=(G=b.content||a.getAttribute("data-content"))?G.trim():null;u=e.createElement("div");var c=e.createElement("div");c.setAttribute("class","arrow");u.appendChild(c);null!==G&&null===n.template?(u.setAttribute("role","tooltip"),null!==O&&(c=e.createElement("h3"),c.setAttribute("class","popover-header"),c.innerHTML=n.dismissible?O+'<button type="button" class="close">\u00d7</button>':O,u.appendChild(c)),c=e.createElement("div"),
c.setAttribute("class","popover-body"),c.innerHTML=n.dismissible&&null===O?G+'<button type="button" class="close">\u00d7</button>':G,u.appendChild(c)):(c=e.createElement("div"),n.template=n.template.trim(),c.innerHTML=n.template,u.innerHTML=c.firstChild.innerHTML);n.container.appendChild(u);u.style.display="block";u.setAttribute("class","popover bs-popover-"+R+" "+n.animation);c=u;var d=R,f=n.container,h=c.offsetWidth,k=c.offsetHeight,m=M.clientWidth||e.body.clientWidth,p=M.clientHeight||e.body.clientHeight,
g=a.getBoundingClientRect();f=f===e.body?{y:A.pageYOffset||M.scrollTop,x:A.pageXOffset||M.scrollLeft}:{x:f.offsetLeft+f.scrollLeft,y:f.offsetTop+f.scrollTop};var q=g.right-g.left,t=g.bottom-g.top,w=r(c,"popover"),x=y(".arrow",c),C=0>g.top+t/2-k/2,z=0>g.left+q/2-h/2,B=g.left+h/2+q/2>=m,F=g.top+k/2+t/2>=p;var D=0>g.top-k;var L=0>g.left-h;p=g.top+k+t>=p;var E=g.left+h+q>=m;d=("left"===d||"right"===d)&&L&&E?"top":d;d="top"===d&&D?"bottom":d;d="bottom"===d&&p?"top":d;d="left"===d&&L?"right":d;d="right"===
d&&E?"left":d;-1===c.className.indexOf(d)&&(c.className=c.className.replace(ha,d));D=x.offsetWidth;L=x.offsetHeight;if("left"===d||"right"===d){var I="left"===d?g.left+f.x-h-(w?D:0):g.left+f.x+q;if(C){var H=g.top+f.y;var J=t/2-D}else F?(H=g.top+f.y-k+t,J=k-t/2-D):(H=g.top+f.y-k/2+t/2,J=k/2-(w?.9*L:L/2))}else if("top"===d||"bottom"===d)if(H="top"===d?g.top+f.y-k-(w?L:0):g.top+f.y+t,z){I=0;var P=g.left+q/2-D}else B?(I=m-1.01*h,P=h-(m-g.left)+q/2-D/2):(I=g.left+f.x-h/2+q/2,P=h/2-(w?D:D/2));c.style.top=
H+"px";c.style.left=I+"px";J&&(x.style.top=J+"px");P&&(x.style.left=P+"px");!r(u,"show")&&v(u,"show");n.animation?K(u,N):N()}},20)};this.hide=function(){clearTimeout(F);F=setTimeout(function(){u&&null!==u&&r(u,"show")&&(a.dispatchEvent(p),p.defaultPrevented||(w(u,"show"),n.animation?K(u,S):S()))},n.delay)};"Popover"in a||("hover"===n.trigger?(t(a,T[0],n.show),n.dismissible||t(a,T[1],n.hide)):"click"!=n.trigger&&"focus"!=n.trigger||t(a,n.trigger,n.toggle));a.Popover=n}};E.push(["Popover",ca,'[data-toggle="popover"]']);
var da=function(a,b){a=y(a);var e=a.getAttribute("data-height"),f,k,C,d;b=b||{};this.height=V?b.height||"true"===e:!1;var c=this,l,h=I(a,".nav"),p=!1,q=h&&y(".dropdown-toggle",h),B,x,m,D,n,A,G=function(){p.style.height="";w(p,"collapsing");h.isAnimating=!1},u=function(){p?n?G():setTimeout(function(){p.style.height=A+"px";p.offsetWidth;K(p,G)},50):h.isAnimating=!1;k=z("shown","tab",B);l.dispatchEvent(k)},E=function(){p&&(x.style["float"]="left",m.style["float"]="left",D=x.scrollHeight);f=z("show",
"tab",B);d=z("hidden","tab",l);l.dispatchEvent(f);f.defaultPrevented||(v(m,"active"),w(x,"active"),p&&(A=m.scrollHeight,n=A===D,v(p,"collapsing"),p.style.height=D+"px",p.offsetHeight,x.style["float"]="",m.style["float"]=""),r(m,"fade")?setTimeout(function(){v(m,"show");K(m,u)},20):u(),B.dispatchEvent(d))};if(h){h.isAnimating=!1;var H=function(){var a=F(h,"active"),b;1!==a.length||r(a[0].parentNode,"dropdown")?1<a.length&&(b=a[a.length-1]):b=a[0];return b};b=function(a){a.preventDefault();l=a.currentTarget;
h.isAnimating||r(l,"active")||c.show()};this.show=function(){l=l||a;m=y(l.getAttribute("href"));B=H();x=y(H().getAttribute("href"));C=z("hide","tab",l);B.dispatchEvent(C);C.defaultPrevented||(h.isAnimating=!0,w(B,"active"),B.setAttribute("aria-selected","false"),v(l,"active"),l.setAttribute("aria-selected","true"),q&&(r(a.parentNode,"dropdown-menu")?r(q,"active")||v(q,"active"):r(q,"active")&&w(q,"active")),r(x,"fade")?(w(x,"show"),K(x,E)):E())};"Tab"in a||t(a,"click",b);c.height&&(p=y(H().getAttribute("href")).parentNode);
a.Tab=c}};E.push(["Tab",da,'[data-toggle="tab"]']);var ea=function(a,b){a=y(a);b=b||{};var g=a.getAttribute("data-interval"),f=b.interval;g="false"===g?0:parseInt(g);var k="hover"===a.getAttribute("data-pause")||!1,C="true"===a.getAttribute("data-keyboard")||!1;this.keyboard=!0===b.keyboard||C;this.pause="hover"===b.pause||k?"hover":!1;this.interval="number"===typeof f?f:!1===f||0===g||!1===g?0:isNaN(g)?5E3:g;var d=this,c=a.index=0,l=a.timer=0,h=!1,p=!1,q=null,B=null,x=null,m=F(a,"carousel-item"),
D=m.length,n=this.direction="left",E=F(a,"carousel-control-prev")[0],G=F(a,"carousel-control-next")[0],u=(b=y(".carousel-indicators",a))&&b.getElementsByTagName("LI")||[];if(!(2>D)){f=function(){!1===d.interval||r(a,"paused")||(v(a,"paused"),!h&&(clearInterval(l),l=null))};g=function(){!1!==d.interval&&r(a,"paused")&&(w(a,"paused"),!h&&(clearInterval(l),l=null),!h&&d.cycle())};k=function(a){a.preventDefault();if(!h){if((a=a.target)&&!r(a,"active")&&a.getAttribute("data-slide-to"))c=parseInt(a.getAttribute("data-slide-to"),
10);else return!1;d.slideTo(c)}};C=function(a){a.preventDefault();h||(a=a.currentTarget||a.srcElement,a===G?c++:a===E&&c--,d.slideTo(c))};var I=function(a){if(!h){switch(a.which){case 39:c++;break;case 37:c--;break;default:return}d.slideTo(c)}},N=function(b){b(a,"touchmove",Q,J);b(a,"touchend",U,J)},L=function(b){p||(q=parseInt(b.touches[0].pageX),a.contains(b.target)&&(p=!0,N(t)))},Q=function(a){if(p){if(B=parseInt(a.touches[0].pageX),"touchmove"===a.type&&1<a.touches.length)return a.preventDefault(),
!1}else a.preventDefault()},U=function(b){if(p&&!h&&(x=B||parseInt(b.touches[0].pageX),p)){if(a.contains(b.target)&&a.contains(b.relatedTarget)||!(75>Math.abs(q-x)))B<q?c++:B>q&&c--,p=!1,d.slideTo(c);else return!1;N(H)}},S=function(a){for(var b=0,c=u.length;b<c;b++)w(u[b],"active");u[a]&&v(u[a],"active")};this.cycle=function(){l&&(clearInterval(l),l=null);l=setInterval(function(){var b=a.getBoundingClientRect();b.top<=(A.innerHeight||M.clientHeight)&&0<=b.bottom&&(c++,d.slideTo(c))},this.interval)};
this.slideTo=function(b){if(!h){var f=this.getActiveIndex();if(f!==b){if(f<b||0===f&&b===D-1)n=d.direction="left";else if(f>b||f===D-1&&0===b)n=d.direction="right";0>b?b=D-1:b>=D&&(b=0);c=b;var g="left"===n?"next":"prev";z.call(a,"slide","carousel",m[b]);h=!0;clearInterval(l);l=null;S(b);V&&r(a,"slide")?(v(m[b],"carousel-item-"+g),m[b].offsetWidth,v(m[b],"carousel-item-"+n),v(m[f],"carousel-item-"+n),K(m[b],function(c){c=c&&c.target!==m[b]?1E3*c.elapsedTime+100:20;h&&setTimeout(function(){h=!1;v(m[b],
"active");w(m[f],"active");w(m[b],"carousel-item-"+g);w(m[b],"carousel-item-"+n);w(m[f],"carousel-item-"+n);z.call(a,"slid","carousel",m[b]);e.hidden||!d.interval||r(a,"paused")||d.cycle()},c)})):(v(m[b],"active"),m[b].offsetWidth,w(m[f],"active"),setTimeout(function(){h=!1;d.interval&&!r(a,"paused")&&d.cycle();z.call(a,"slid","carousel",m[b])},100))}}};this.getActiveIndex=function(){return m.indexOf(F(a,"carousel-item active")[0])||0};"Carousel"in a||(d.pause&&d.interval&&(t(a,T[0],f),t(a,T[1],g),
t(a,"touchstart",f,J),t(a,"touchend",g,J)),1<m.length&&t(a,"touchstart",L,J),G&&t(G,"click",C),E&&t(E,"click",C),b&&t(b,"click",k),d.keyboard&&t(A,"keydown",I));0>d.getActiveIndex()&&(m.length&&v(m[0],"active"),u.length&&S(0));d.interval&&d.cycle();a.Carousel=d}};E.push(["Carousel",ea,'[data-ride="carousel"]']);var fa=Q.initCallback=function(a){a=a||e;for(var b=0,g=E.length;b<g;b++)for(var f=E[b][1],k=a.querySelectorAll(E[b][2]),r=0,d=k.length;r<d;r++)new f(k[r])};e.body?fa():t(e,"DOMContentLoaded",
function(){fa()});return{Alert:X,Button:Y,Collapse:Z,Dropdown:aa,Modal:ba,Popover:ca,Tab:da,Carousel:ea}});
var locales=[{"code":"de-DE","desc":"Deutsch"},{"code":"en-US","desc":"English"},{"code":"es-VE","desc":"Español"},{"code":"ko-KR","desc":"한국어"},{"code":"nl-NL","desc":"Nederlands"}];var phrases={"%{name} added to queue":{"de-DE":"%{name} hinzugefügt","es-VE":"%{name} agregado a la cola de reproducción","ko-KR":"순서에 %{name} 추가함","nl-NL":"%{name} toegevoegd"},"%{name} added to queue position %{to}":{"de-DE":"%{name} an Warteschlangenposition %{to} hinzugefügt","es-VE":"%{name} agregado a la cola de reproducción en la posición %{to}","ko-KR":"%{to} 순서 위치에 %{name} 추가함","nl-NL":"%{name} toegevoegd aan wachtrijpositie %{to}"},"1.0":{},"2.0":{},"2.1":{},"3.0":{},"About":{"de-DE":"Über myMPD","es-VE":"Acerca de","ko-KR":"정보","nl-NL":"Over myMPD"},"Action":{"de-DE":"Aktion","es-VE":"Acción","ko-KR":"기능","nl-NL":"Aktie"},"Add":{"de-DE":"Hinzufügen","es-VE":"Agregar","ko-KR":"추가","nl-NL":"Toevoegen"},"Add after current playing song":{"de-DE":"Nach aktuellem Lied hinzufügen","es-VE":"Añadir despues de la canción actual","ko-KR":"지금 연주 중인 곡 다음에 추가","nl-NL":"Als volgende afspelen"},"Add all to playlist":{"de-DE":"Alles zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar todo a lista de reproducción","ko-KR":"연주목록에 모두 추가","nl-NL":"Alle aan afspeellijst toevoegen"},"Add all to queue":{"de-DE":"Alles zur Warteschlange hinzufügen","es-VE":"Agregar todo a cola de reproducción","ko-KR":"순서에 모두 추가","nl-NL":"Alle aan wachtrij toevoegen"},"Add bookmark":{"de-DE":"Lesezeichen hinzufügen","es-VE":"Agregar marcador","ko-KR":"즐겨찾기 추가","nl-NL":"Voeg bladwijzer toe"},"Add random":{"de-DE":"Zufällig hinzufügen","es-VE":"Agregar aleatorio","ko-KR":"무작위 추가","nl-NL":"Voeg willekeurige toe"},"Add smart playlist":{"de-DE":"Neue intelligente Wiedergabeliste","es-VE":"Agregar Lista de reproducción inteligente","ko-KR":"스마트 연주목록 추가","nl-NL":"Slimme afspeellijst toevoegen"},"Add stream":{"de-DE":"Stream hinzufügen","es-VE":"Agregar fuente","ko-KR":"스트리밍 서비스 추가","nl-NL":"Stream toevoegen"},"Add to home screen":{"de-DE":"Zum Startbildschirm hinzufügen","es-VE":"Agregar a pantalla de inicio","ko-KR":"홈 화면에 추가","nl-NL":"Aan startscherm toevoegen"},"Add to playlist":{"de-DE":"Zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar a lista de reproducción","ko-KR":"연주목록에 추가","nl-NL":"Voeg toe aan afspeellijst "},"Add to queue":{"de-DE":"Zu Warteschlange hinzufügen","es-VE":"Agregar a la cola de reproducción","ko-KR":"순서에 추가","nl-NL":"Toevoegen aan wachtrij"},"Added %{uri} to playlist %{playlist}":{"de-DE":"%{uri} zu Wiedergabeliste %{playlist} hinzugefügt","es-VE":"%{uri} agregado a lista de reproducción %{playlist}","ko-KR":"%{uri}의 %{playlist} 연주목록 추가에 실패함","nl-NL":"%{uri} toegevoegd aan afspeellijst %{playlist}"},"Added all songs":{"de-DE":"Alle Lieder hinzugefügt","es-VE":"Agregadas todas las canciones","ko-KR":"모든 곡을 추가함","nl-NL":"Alle nummers toegevoegd"},"Added songs to %{playlist}":{"de-DE":"Lieder zur Wiedergabeliste %{playlist} hinzugefügt","es-VE":"Canciones agregadas a la lista de reproducción %{playlist}","ko-KR":"%{playlist}에 곡 추가함","nl-NL":"Nummers aan %{playlist} toegevoegd"},"Added songs to queue":{"de-DE":"Lieder zur Warteschlange hinzugefügt","es-VE":"Canciones agregadas a la cola de reproducción","ko-KR":"순서에 곡 추가함","nl-NL":"Nummer aan wachtrij toegevoegd"},"Added stream %{streamUri} to queue":{"de-DE":"Stream %{streamUri} zu Warteschlange hinzugefügt","es-VE":"Agregar Fuente %{streamUri} a la cola de reproducción","ko-KR":"%{streamUri} 스트리밍을 순서에 추가함","nl-NL":"Stream %{streamUri} aan wachtrij toevoegen"},"Adding random songs to queue failed":{"de-DE":"Zufällige Lieder konnten nicht zur Warteschlange hinzugefügt werden","es-VE":"Error al agregar canciones aleatorias a la cola de reproducción","ko-KR":"순서에 무작위 곡 추가 안 됨","nl-NL":"Toevoegen willekeurig nummer mislukt"},"Adding timer failed":{"de-DE":"Timer konnte nicht hinzugefügt werden","es-VE":"Fallo al agregar Temporizador","ko-KR":"타이머를 추가할 수 없음","nl-NL":"Toevoegen timer mislukt"},"Advanced":{"de-DE":"Erweitert","es-VE":"Avanzado","ko-KR":"고급","nl-NL":"Geavanceerd"},"AirPlay":{},"Akkordion Music Player":{},"Album":{"de-DE":"Album","es-VE":"Álbum","ko-KR":"음반","nl-NL":"Album"},"AlbumArtist":{"de-DE":"Album Interpret","en-US":"Albumartist","es-VE":"Artista álbum","ko-KR":"음반 연주가","nl-NL":"Albumartiest"},"AlbumArtistSort":{"de-DE":"Album Interpret","es-VE":"Artista álbum","ko-KR":"음반 연주가 정렬","nl-NL":"Albumartiest"},"AlbumSort":{"de-DE":"Album","es-VE":"Álbum","ko-KR":"음반 정렬","nl-NL":"Album"},"Albumart":{"de-DE":"Albumcover","es-VE":"Carátula del álbum","ko-KR":"음반 표지","nl-NL":"Albumcover"},"Albums":{"de-DE":"Alben","es-VE":"Álbumes","ko-KR":"음반","nl-NL":"Albums"},"Allo Boss DAC":{},"Allo Digione":{},"Allo Katana DAC":{},"Allo Piano DAC 2.0/2.1":{},"Allo Piano DAC Plus 2.1":{},"Allo Piano DAC Plus 2.1 with Kali":{},"Any Tag":{"de-DE":"Alle Tags","es-VE":"Cualquier etiqueta","ko-KR":"모든 태그","nl-NL":"Alle tags"},"Appearance":{"de-DE":"Design","es-VE":"Apariencia","ko-KR":"외관","nl-NL":"Uiterlijk"},"Append item to playlist":{"de-DE":"Ausgewähltes Element zu einer Wiedergabeliste hinzufügen","es-VE":"Agregar elemento a lista de reproducción","ko-KR":"연주목록에 항목 추가","nl-NL":"Selectie aan afspeellijst toevoegen"},"Append item to queue":{"de-DE":"Ausgewähltes Element an Warteschlange anhängen","es-VE":"Agregar elemento a la cola de reproducción","ko-KR":"순서에 항목 추가","nl-NL":"Selectie aan wachtrij toevoegen"},"Append to queue":{"de-DE":"An Warteschlange anhängen","es-VE":"Añadir a la cola de reproducción","ko-KR":"순서에 추가","nl-NL":"Toevoegen aan wachtrij"},"ApplePi-DAC (Orchard Audio)":{},"Apply":{"de-DE":"Anwenden","es-VE":"Aplicar","ko-KR":"적용","nl-NL":"Toepassen"},"Applying settings":{"de-DE":"Einstellungen werden angewendet","es-VE":"Aplicando configuraciones","ko-KR":"설정 적용","nl-NL":"Instellingen toepassen"},"Artist":{"de-DE":"Künstler","es-VE":"Artista","ko-KR":"연주가","nl-NL":"Artiest"},"ArtistSort":{"de-DE":"Künstler","es-VE":"Artista","ko-KR":"연주가 정렬","nl-NL":"Artiest"},"Artists":{"de-DE":"Interpreten","es-VE":"Artistas","ko-KR":"연주가","nl-NL":"Artiesten"},"Audio":{},"Audio Settings":{},"Audio settings":{},"Audioinjector.net audio add on":{},"Audioinjector.net ultra":{},"Audiophonics I-SABRE Q2M DAC":{},"Audioquality":{},"Audiosense-pi":{},"Author":{"de-DE":"Autor","es-VE":"Autor","ko-KR":"저자","nl-NL":"Auteur"},"Auto":{"de-DE":"Auto","es-VE":"Auto","ko-KR":"자동","nl-NL":"Auto"},"Autodetect":{"de-DE":"Automatisch","es-VE":"Auto detectar","ko-KR":"자동 감지","nl-NL":"Automatisch"},"Autoplay":{"de-DE":"Automatische Wiedergabe","es-VE":"Reproducción automática","ko-KR":"자동 연주","nl-NL":"Auto-afspelen"},"Backend uri":{"de-DE":"Einzuhängende URL","es-VE":"URL Back-End","ko-KR":"백엔드 URL","nl-NL":"Backend-url"},"Background":{"de-DE":"Hintergrund","es-VE":"Fondo","ko-KR":"배경","nl-NL":"Achtergrond"},"Background color":{"de-DE":"Hintergrundfarbe","es-VE":"Color de fondo","ko-KR":"배경색","nl-NL":"Achtergrondkleur"},"Best rated":{"de-DE":"Am Besten bewertet","es-VE":"Mejor calificado","ko-KR":"최고 평점","nl-NL":"Best beoordeeld"},"Blokas Labs pisound card":{},"Booklet":{"de-DE":"Booklet","es-VE":"Folleto","ko-KR":"책자","nl-NL":"Booklet"},"Booklet filename":{"de-DE":"Booklet Dateiname","es-VE":"Archivo de folleto","ko-KR":"책자 파일 이름","nl-NL":"Booklet bestandsnaam"},"Bookmark URI":{"de-DE":"Lesezeichen URL","es-VE":"URL de marcador","ko-KR":"즐겨찾기 주소","nl-NL":"Url bladwijzer"},"Bookmark name":{"de-DE":"Name","es-VE":"Nombre de marcador","ko-KR":"즐겨찾기 이름","nl-NL":"Naam"},"Bookmarks":{"de-DE":"Lesezeichen","es-VE":"Marcadores","ko-KR":"즐겨찾기","nl-NL":"Bladwijzers"},"Browse":{"de-DE":"Durchsuchen","es-VE":"Explorar","ko-KR":"열기","nl-NL":"Browse"},"Browse directories":{"de-DE":"Verzeichnisse anzeigen","es-VE":"Explorar directorios","ko-KR":"디렉터리 열기","nl-NL":"Browse bestanden"},"Browser default":{"de-DE":"Browsereinstellung","es-VE":"Por defecto del navegador","ko-KR":"기본 열기","nl-NL":"Browserinstelling"},"CSS filter":{"de-DE":"CSS Filter","es-VE":"Filtro CSS","ko-KR":"CSS 필터","nl-NL":"CSS filter"},"Calculate":{"de-DE":"Berechne Fingerabdruck","es-VE":"Calcular","ko-KR":"계산","nl-NL":"Bereken"},"Can not crop the queue":{"de-DE":"Die Warteschlange konnte nicht abgeschnitten werden","ko-KR":"순서에 남길 수 없음"},"Can not parse settings":{"de-DE":"Einstellungen können nicht geladen werden","es-VE":"Error al leer configuraciones","ko-KR":"설정을 분석할 수 없음","nl-NL":"Laden instellingen mislukt "},"Can not parse smart playlist file":{"de-DE":"Intelligente Wiedergabeliste konnte nicht geparsed werden","es-VE":"No se puede interpretar el archivo de lista de reproducción inteligente","ko-KR":"스마트 연주목록 파일을 분석할 수 없음","nl-NL":"Slimme afspeellijst kon niet worden ingelezen"},"Can not read smart playlist file":{"de-DE":"Intelligente Wiedergabeliste konnte nicht eingelesen werden","es-VE":"No se puede leer el archivo de lista de reproducción inteligente","ko-KR":"스마트 연주목록 파일을 읽을 수 없음","nl-NL":"Slimme afspeellijst kon niet worden gelezen"},"Can not start playing":{"de-DE":"Wiedergabe kann nicht gestartet werden","es-VE":"No se puede iniciar la reproducción","ko-KR":"연주를 시작할 수 없음","nl-NL":"Afspelen niet gestart"},"Can't access music directory":{"de-DE":"Musik Verzeichnis ist nicht verfügbar","es-VE":"No se puede acceder al directorio de música","ko-KR":"음원 디렉터리에 접근할 수 없음","nl-NL":"Map niet toegankelijk"},"Can't save setting %{setting}":{"de-DE":"%{setting} konnte nicht gespeichert werden","es-VE":"Error al guardar la configuración: %{setting}","ko-KR":"%{setting} 설정 저장할 수 없음","nl-NL":"Instelling %{setting} niet opgeslagen"},"Cancel":{"de-DE":"Abbrechen","es-VE":"Cancelar","ko-KR":"취소","nl-NL":"Annuleren"},"Check":{},"Check for updates":{},"Cirrus Logis Audio Card":{},"Clear":{"de-DE":"Löschen","es-VE":"Limpiar","ko-KR":"지우기","nl-NL":"Wissen"},"Clear app cache and reload":{"de-DE":"Browser Cache löschen und neu laden","es-VE":"Borrar caché de la app y recargar","ko-KR":"앱 캐시를 지우고 다시 읽기","nl-NL":"Wis app-cache en herlaad"},"Clear covercache":{"de-DE":"Covercache löschen","es-VE":"Limpiar Covercache","ko-KR":"표지 캐시 지우기","nl-NL":"Wis covercache"},"Clear playlist":{"de-DE":"Playlist leeren","es-VE":"Limpiar lista de reproducción","ko-KR":"연주목록 비우기","nl-NL":"Wis afspeellijst"},"Clear queue":{"de-DE":"Warteschlange leeren","es-VE":"Borrar cola de reproducción","ko-KR":"순서 비우기","nl-NL":"Wis wachtrij"},"Clearing bookmarks failed":{"de-DE":"Löschen aller Lesezeichen fehlgeschlagen","es-VE":"Error al borrar marcadores","ko-KR":"즐겨찾기 지우기 안 됨","nl-NL":"Wissen bladwijzers mislukt"},"Close":{"de-DE":"Schließen","es-VE":"Cerrar","ko-KR":"닫기","nl-NL":"Sluit"},"Collybia OS Version":{},"Comment":{"de-DE":"Kommentar","es-VE":"Comentario","ko-KR":"설명","nl-NL":"Commentaar"},"Composer":{"de-DE":"Komponist","es-VE":"Compositor","ko-KR":"작곡가","nl-NL":"Componist"},"Conductor":{"de-DE":"Dirigent","es-VE":"Director","ko-KR":"지휘자","nl-NL":"Dirigent"},"Connect to websocket":{"de-DE":"Websocketverbindung wird hergestellt","es-VE":"Conectando a websocket","ko-KR":"웹소켓에 연결","nl-NL":"Verbinden met websocket"},"Connected to MPD":{"de-DE":"Verbindung zu MPD hergestellt","es-VE":"Conectado a MPD","ko-KR":"MPD로 연결됨","nl-NL":"Verbonden met MPD"},"Connected to myMPD":{"de-DE":"Verbindung zu myMPD hergestellt","es-VE":"Conectado a myMPD","ko-KR":"myMPD로 연결됨","nl-NL":"Verbonden met myMPD"},"Connecting to stream...":{"de-DE":"Verbinde...","es-VE":"Conectando fuente...","ko-KR":"스트리밍에 연결 중...","nl-NL":"Verbinden..."},"Connection":{"de-DE":"Verbindung","es-VE":"Conexión","ko-KR":"연결","nl-NL":"Verbinding"},"Connection state":{"de-DE":"Verbindungsstatus","es-VE":"Estado de conexión","ko-KR":"연결 상태","nl-NL":"Status connectie"},"Consume":{"de-DE":"Konsumieren","es-VE":"Consumir","ko-KR":"써버리기","nl-NL":"Consumeren"},"Consume must be enabled":{"de-DE":"Konsumieren muss aktiviert sein","es-VE":"Modo Consumir debe estar habilitado","ko-KR":"소비를 선택해야 함","nl-NL":"Consumeren moet zijn ingeschakeld"},"Covergrid":{"de-DE":"Albumcover","es-VE":"Carátulas de álbum","ko-KR":"음반 표지 격자","nl-NL":"Covergrid"},"Create Playlist":{"de-DE":"Neue Wiedergabeliste erstellen","es-VE":"Crear lista de reproducción","ko-KR":"연주목록 만들기","nl-NL":"Afspeellijst maken"},"Crop":{"de-DE":"Abschneiden","es-VE":"Cortar","ko-KR":"잘라내기","nl-NL":"Inkorten"},"Crop queue":{"de-DE":"Warteschlange abschneiden","es-VE":"Cortar cola de reproducción","ko-KR":"순서 남기기","nl-NL":"Wachtrij inkorten"},"Crossfade":{"de-DE":"Crossfade","es-VE":"Fundido cruzado","ko-KR":"크로스페이드","nl-NL":"Crossfade"},"Current version":{},"DAC List":{},"DAC volume mode":{},"DB play time":{"de-DE":"Datenbank Wiedergabedauer","es-VE":"Tiempo de reproducción BD","ko-KR":"DB 연주 시간","nl-NL":"DB speeltijd"},"DB updated":{"de-DE":"Datenbank zuletzt aktualisiert","es-VE":"BD actualizada","ko-KR":"DB 업데이트됨","nl-NL":"DB geüpdatet"},"Dark":{"de-DE":"Dunkel","es-VE":"Oscuro","ko-KR":"어둠","nl-NL":"Donker"},"Database":{"de-DE":"Datenbank","es-VE":"Base de datos","ko-KR":"데이터 베이스","nl-NL":"Database"},"Database statistics":{"de-DE":"Datenbank Statistiken","es-VE":"Estadísticas de Base de datos","ko-KR":"데이터베이스 통계","nl-NL":"Database statistieken"},"Database successfully updated":{"de-DE":"Datenbank erfolgreich aktualisiert","es-VE":"Base de datos actualizada exitosamente","ko-KR":"데이터베이스 업데이트됨","nl-NL":"Database geüpdatet"},"Database update finished":{"de-DE":"Datenbankaktualisierung beendet","es-VE":"Finalizó la actualización de la base de datos","ko-KR":"데이터베이스 업데이트 마침","nl-NL":"Update database klaar"},"Database update started":{"de-DE":"Datenbankaktualisierung gestartet","es-VE":"Inició la actualización de la base de datos","ko-KR":"데이터베이스 업데이트 시작됨","nl-NL":"Updaten database gestart"},"Date":{"de-DE":"Datum","es-VE":"Año","ko-KR":"날짜","nl-NL":"Datum"},"Days":{"de-DE":"Tage","en-US":"Days","es-VE":"Dias","ko-KR":"일","nl-NL":"Dagen"},"Default":{"de-DE":"Standard","es-VE":"Por defecto","ko-KR":"기본","nl-NL":"Standaard"},"Definition":{"de-DE":"Definition","es-VE":"Definición","ko-KR":"결정","nl-NL":"Definitie"},"Delete":{"de-DE":"Löschen","es-VE":"Eliminar","ko-KR":"지우기","nl-NL":"Verwijder"},"Delete all playlists":{"de-DE":"Alle Wiedergabelisten löschen","es-VE":"Eliminar todas las listas de reproducción","ko-KR":"모든 연주목록 지움","nl-NL":"Alle afspeellijsten verwijderd"},"Delete all smart playlists":{"de-DE":"Alle Intelligenten Wiedergabelisten löschen","es-VE":"Eliminar todas las listas de reproducción inteligentes","ko-KR":"모든 스마트 연주목록 지움","nl-NL":"Verwijder alle afspeellijsten"},"Delete empty playlists":{"de-DE":"Alle leere Wiedergabelisten löschen","es-VE":"Eliminar listas de reproducción vacias","ko-KR":"빈 연주목록 지움","nl-NL":"Verwijderen lege afspeellijsten"},"Delete playlist":{"de-DE":"Wiedergabeliste löschen","es-VE":"Eliminar lista de reproducción","ko-KR":"연주목록 지우기","nl-NL":"Verwijder afspeellijst"},"Delete playlists":{"de-DE":"Wiedergabelisten löschen","es-VE":"Eliminar listas de reproducción","ko-KR":"연주목록 지움","nl-NL":"Verwijder afspeellijsten"},"Deleting bookmark failed":{"de-DE":"Lesezeichen konnte nicht gelöscht werden","es-VE":"Error al eliminar marcador","ko-KR":"즐겨찾기 지우기 안 됨","nl-NL":"Verwijderen bladwijzer mislukt"},"Deleting smart playlist failed":{"de-DE":"Intelligente Wiedergabeliste konnte nicht gelöscht werden","es-VE":"Error al eliminar lista de reproducción inteligente","ko-KR":"스마트 연주목록 지우기 안 됨","nl-NL":"Verwijderen slimme afspeellijst mislukt"},"Dependent on the size of your music collection this can take a while":{"de-DE":"Der Aktualisierungsvorgang kann einige Zeit in Anspruch nehmen","es-VE":"Dependiendo del tamaño de su colección de música, esto puede llevar un tiempo","ko-KR":"음원 크기에 따라 시간이 걸릴 수 있습니다","nl-NL":"Afhankelijk van de grootte van de muziekcollectie kan dit even duren"},"Descending":{"de-DE":"Absteigend","es-VE":"Descendiente","ko-KR":"내림차순","nl-NL":"Aflopend"},"Dion Audio LOCO DAC-AMP":{},"Dion Audio LOCO DAC-AMP v2":{},"Disabled":{"de-DE":"Deaktiviert","es-VE":"Desactivado","ko-KR":"사용 안 함","nl-NL":"Uitgeschakeld"},"Disc":{"de-DE":"CD","es-VE":"Disco","ko-KR":"디스크","nl-NL":"Cd"},"Dislike song":{"de-DE":"Schlechtes Lied","es-VE":"No me gusta esta canción","ko-KR":"곡 좋아하지 않음","nl-NL":"Dislike nummer"},"Download":{"de-DE":"Herunterladen","es-VE":"Descargar","ko-KR":"내려받기","nl-NL":"Download"},"Duration":{"de-DE":"Länge","es-VE":"Duración","ko-KR":"길이","nl-NL":"Duur"},"Edit playlist":{"de-DE":"Wiegergabeliste bearbeiten","es-VE":"Editar lista de reproducción","ko-KR":"연주목록 편집","nl-NL":"Bewerk afspeellijst"},"Edit smart playlist":{"de-DE":"Intelligente Wiedergabeliste bearbeiten","es-VE":"Editar lista de reproducción inteligente","ko-KR":"스마트 연주목록 편집","nl-NL":"Bewerk slimme afspeellijst"},"Empty list":{"de-DE":"Leere Liste","es-VE":"Lista vacía","ko-KR":"목록 비우기","nl-NL":"Lege lijst"},"Empty playlist":{"de-DE":"Leere Wiedergabeliste","es-VE":"Lista de reproducción vacía","ko-KR":"연주목록 비우기","nl-NL":"Lege afspeellijst"},"Empty queue":{"de-DE":"Leere Warteschlange","es-VE":"Cola de reproducción vavía","ko-KR":"순서 비우기","nl-NL":"Lege wachtrij"},"Enable DoP":{},"Enable jukebox if playlist is database":{"de-DE":"Jukebox muss aktiviert sein, wenn als Wiedergabeliste die Datenbank ausgewählt ist.","es-VE":"Habilite Jukebox si la lista de reproducción es la base de datos","ko-KR":"연주목록이 데이터베이스이면 뮤직박스 사용함","nl-NL":"Schakel jukebox in wanneer database als afspeellijst is geselecteerd"},"Enabled":{"de-DE":"Aktiv","es-VE":"Habilitado","ko-KR":"사용함","nl-NL":"Ingeschakeld"},"Enforce uniqueness":{"de-DE":"Erzwinge Eindeutigkeit","es-VE":"Hacer cumplir la singularidad","ko-KR":"유일성 강제","nl-NL":"Gelijkenis op basis van"},"Error":{"de-DE":"Fehler","es-VE":"Error","ko-KR":"오류","nl-NL":"Fout"},"Error in response to command: %{command}":{"de-DE":"Fehler beim Ausführen von %{command}","es-VE":"Error en respuesta al comando: %{command}","ko-KR":"명령어 오류: %{command}"},"Failed to execute cmd %{cmd}":{"de-DE":"Fehler beim Ausführen des Systembefehls %{cmd}","es-VE":"Error al ejecutar el comando: %{cmd}","ko-KR":"%{cmd} 명령어 실행 안 됨","nl-NL":"Uitvoeren mislukt cmd %{cmd}"},"Failed to open bookmarks file":{"de-DE":"Lesezeichen Datei konnte nicht geöffnet werden","es-VE":"Error al abrir el archivo de marcadores","ko-KR":"즐겨찾기 파일 열기 안 됨","nl-NL":"Openen bladwijzer mislukt"},"Failed to save playlist":{"de-DE":"Wiedergabeliste konnte nicht gespeichert werden","es-VE":"Error al guardar lista de reproducción","ko-KR":"연주목록 저장 안 됨","nl-NL":"Opslaan afspeellijst mislukt"},"Failed to send love message to channel":{"de-DE":"Lieblingslied Nachricht konnte nicht gesendet werden","es-VE":"Error al enviar Me gusta al canal","ko-KR":"채널에 애청곡 메시지 보내기 안 됨","nl-NL":"Versturen favoriet mislukt"},"Failed to set like, invalid like value":{"de-DE":"Wertung konnte nicht gesetzt werden, ungültiger Wert","es-VE":"Error al establecer me gusta, no válido","ko-KR":"잘못된 값으로 좋아요 설정 안 됨","nl-NL":"Like mislukt, ongeldige waarde"},"Failed to set like, invalid song uri":{"de-DE":"Wertung konnte nicht gesetzt werden, ungültige Lied URL","es-VE":"Error al establecer me gusta, URI de canción inválido","ko-KR":"잘못된 곡 주소로 좋아요 설정 안 됨","nl-NL":"Like mislukt, ongeldige url"},"Fe-Pi Audio Sound Card":{},"Fetch MPD settings":{"de-DE":"Lade MPD Einstellungen","es-VE":"Cargando configuraciones de myMPD","ko-KR":"MPD 설정 가져오기","nl-NL":"MPD-instellingen laden"},"Fetch myMPD settings":{"de-DE":"Lade myMPD Einstellungen","es-VE":"Cargando configuraciones de myMPD","ko-KR":"myMPD 설정 가져오기","nl-NL":"myMPD-instellingen laden"},"Fileformat":{"de-DE":"Dateiformat","es-VE":"Formato","ko-KR":"파일 포맷","nl-NL":"Bestandsformaat"},"Filename":{"de-DE":"Dateiname","es-VE":"Archivo","ko-KR":"파일 이름","nl-NL":"Bestandsnaam"},"Filesystem":{"de-DE":"Dateisystem","es-VE":"Sistema de archivos","ko-KR":"파일 시스템","nl-NL":"Bestanden"},"Filetype":{"de-DE":"Dateityp","es-VE":"Tipo","ko-KR":"파일 형식","nl-NL":"Bestandstype"},"Fingerprint":{"de-DE":"Fingerabdruck","es-VE":"Huella","ko-KR":"지문","nl-NL":"Fingerprint"},"Fingerprint command not supported":{"de-DE":"Fingerprint Befehl ist nicht unterstützt","es-VE":"Comando de huella no soportado","ko-KR":"지문 명령어 지원 안 됨","nl-NL":"Fingerprint commando niet ondersteund"},"Focus search":{"de-DE":"Gehe zur Suche","es-VE":"Centrar en búsqueda","ko-KR":"찾기로 가기","nl-NL":"Naar Zoeken"},"Focus table":{"de-DE":"In Tabelle navigieren","es-VE":"Centrar en tabla","ko-KR":"목록에서 찾기","nl-NL":"In tabel navigeren"},"Fri":{"de-DE":"Fr","es-VE":"Vie","ko-KR":"금","nl-NL":"Vr"},"From":{"de-DE":"Von","es-VE":"De","ko-KR":"원래","nl-NL":"Van"},"General":{"de-DE":"Allgemein","es-VE":"General","ko-KR":"일반","nl-NL":"Algemeen"},"Generate smart playlist per":{"de-DE":"Erstelle intelligente Wiedergabelisten für","es-VE":"Generar lista de reproducción inteligente por","ko-KR":"스마트 연주목록 생성","nl-NL":"Genereer slimme afspeellijst op basis van"},"Genre":{"de-DE":"Genre","es-VE":"Género","ko-KR":"장르","nl-NL":"Genre"},"Goto browse covergrid":{"de-DE":"Gehe zu Albumcover","es-VE":"Ir a explorar carátulas de álbumes","ko-KR":"음반 표지 격자 보기로 가기","nl-NL":"Covergrid openen"},"Goto browse database":{"de-DE":"Gehe zu Datenbank durchsuchen","es-VE":"Ir a explorar base de datos","ko-KR":"데이터베이스 열기로 가기","nl-NL":"Database openen"},"Goto browse filesystem":{"de-DE":"Gehe zu Dateisystem","es-VE":"Ir a explorar sistema de archivos","ko-KR":"파일 시스템 열기로 가기","nl-NL":"Bestandssysteem openen"},"Goto browse playlists":{"de-DE":"Gehe zu Wiedergabelisten","es-VE":"Ir a explorar listas de reproducción","ko-KR":"연주목록 열기로 가기","nl-NL":"Afspeellijsten openen"},"Goto last played":{"de-DE":"Gehe zu Zuletzt gespielt","es-VE":"Ir a última reproducción","ko-KR":"앞선 연주로 가기","nl-NL":"Laatst afgespeeld openen"},"Goto playback":{"de-DE":"Gehe zu Wiedergabe","es-VE":"Ir a lista de reproducción","ko-KR":"연주로 가기","nl-NL":"Afspelen openen"},"Goto queue":{"de-DE":"Gehe zu Warteschlange","es-VE":"Ir a cola de reproducción","ko-KR":"순서로 가기","nl-NL":"Wachtrij openen"},"Goto search":{"de-DE":"Gehe zur Suche","es-VE":"Ir a buscar","ko-KR":"찾기로 가기","nl-NL":"Zoeken openen"},"Grouping":{"de-DE":"Grupierung","es-VE":"Agrupación","ko-KR":"묶음","nl-NL":"Groepering"},"HIGH":{},"HI_RES":{},"Hardware":{},"HifiBerry DAC+ HD":{},"HifiBerry DAC+ADC":{},"HifiBerry DAC+ADC PRO":{},"HifiBerry DAC+DSP":{},"HifiBerry Digi and Digi+":{},"Hifiberry DAC":{},"Hifiberry DAC Plus":{},"Hifiberry Digi+ Pro":{},"Highlight color":{"de-DE":"Highlight Farbe","es-VE":"Color de realce","ko-KR":"강조색","nl-NL":"Markeerkleur"},"Homepage":{"de-DE":"Homepage","es-VE":"Página de Inicio","ko-KR":"홈페이지","nl-NL":"Website"},"Hours":{"de-DE":"Std","en-US":"Hrs","es-VE":"Horas","ko-KR":"시간","nl-NL":"h"},"IP-Address":{"de-DE":"IP-Adresse","es-VE":"Dirección IP","ko-KR":"IP 주소","nl-NL":"IP-adres"},"IQAudIO Digi":{},"IQaudio Codec":{},"IQaudio DAC":{},"IQaudio DAC+":{},"Info":{"de-DE":"Hinweis","es-VE":"Info","ko-KR":"정보","nl-NL":"Info"},"Initializing myMPD":{"de-DE":"Initialisiere myMPD","es-VE":"Inicializando myMPD","ko-KR":"myMPD 초기화","nl-NL":"Voorbereiden myMPD"},"Install":{},"Invalid API request":{"de-DE":"Ungültiger API Befehl","es-VE":"Solicitud API incorrecta","ko-KR":"잘못된 API 요구","nl-NL":"Ongeldig API-verzoek"},"Invalid CSS filter":{"de-DE":"Ungültiger CSS Filter","es-VE":"Filtro CSS inválido","ko-KR":"잘못된 CSS 필터","nl-NL":"Ongeldig CSS-filter"},"Invalid IP address":{},"Invalid MPD host":{"de-DE":"Ungültiger MPD Host","es-VE":"Servidor MPD inválido","ko-KR":"잘못된 MPD 호스트","nl-NL":"Ongeldige MPD host"},"Invalid MPD password":{"de-DE":"Ungültiges MPD Passwort","es-VE":"Contraseña MPD inválida","ko-KR":"잘못된 MPD 비밀번호","nl-NL":"Ongeldig MPD wachtwoord"},"Invalid MPD port":{"de-DE":"Ungültiger MPD Port","es-VE":"Puerto MPD inválido","ko-KR":"잘못된 MPD 포트","nl-NL":"Ongeldige MPD poort"},"Invalid URI":{"de-DE":"Ungültige URL","es-VE":"URL Inválida","ko-KR":"잘못된 주소","nl-NL":"Ongeldige url"},"Invalid backend uri":{"de-DE":"Ungültige einzuhängende URL","es-VE":"URL de Back-End inválida","ko-KR":"잘못된 백엔드 URL","nl-NL":"Ongeldige backend-url"},"Invalid channel name":{"de-DE":"Ungültiger Channel name","es-VE":"Nombre de canal inválido","ko-KR":"잘못된 채널 이름","nl-NL":"ongeldige naam"},"Invalid color":{"de-DE":"Ungültige Farbe","es-VE":"Color inválido","ko-KR":"잘못된 색상","nl-NL":"Ongeldige kleur"},"Invalid column":{"de-DE":"Ungültiger Spaltenname","ko-KR":"잘못된 열"},"Invalid filename":{"de-DE":"Ungültiger Dateiname","es-VE":"Nombre de archivo inválido","ko-KR":"잘못된 파일 이름","nl-NL":"Ongeldige bestandsnaam"},"Invalid message":{"de-DE":"Ungültige Zeichen in Nachricht","es-VE":"Mensaje inválido","ko-KR":"잘못된 메시지","nl-NL":"Ongeldig bericht"},"Invalid mount point":{"de-DE":"Ungültiger Einhängepunkt","es-VE":"Punto de montaje inválido","ko-KR":"잘못된 마운트 위치","nl-NL":"Ongeldig aankoppelpunt"},"Invalid music directory":{"de-DE":"Ungültiges Musikverzeichnis","es-VE":"Directorio de música inválido","ko-KR":"잘못된 음원 디렉터리","nl-NL":"Ongeldige muziekmap"},"Invalid name":{"de-DE":"Ungültiger Name","es-VE":"Nombre inválido","ko-KR":"잘못된 이름","nl-NL":"Ongeldige naam"},"Invalid number":{"de-DE":"Ungültige Zahl","es-VE":"Número inválido","ko-KR":"잘못된 숫자","nl-NL":"Ongeldig getal"},"Invalid prefix":{"de-DE":"Ungültiger Prefix","es-VE":"Prefijo inválido","ko-KR":"잘못된 덧붙임","nl-NL":"Ongeldig voorvoegsel"},"Invalid server":{},"Invalid size":{"de-DE":"Ungültige Größe","es-VE":"Tamaño inválido","ko-KR":"잘못된 크기","nl-NL":"Ongeldige grootte"},"Invalid type":{"de-DE":"Ungültiger Typ","es-VE":"Tipo inválido","ko-KR":"잘못된 형식","nl-NL":"Ongeldig type"},"JavaScript error":{"de-DE":"JavaScript Fehler","es-VE":"Error de JavaScript","ko-KR":"자바스크립트 오류","nl-NL":"JavaScript fout"},"JavaScript is disabled":{"de-DE":"JavaScript ist deaktiviert","es-VE":"JavaScript esta deshabilitado","ko-KR":"자바스크립트 사용 안 함","nl-NL":"JavaScript uitgeschakeld"},"Jukebox":{"de-DE":"Jukebox","es-VE":"Jukebox","ko-KR":"뮤직박스","nl-NL":"Jukebox"},"Jukebox mode":{"de-DE":"Jukebox Modus","es-VE":"Modo Jukebox","ko-KR":"뮤직박스 모드","nl-NL":"Jukebox-modus"},"JustBoom DAC Hat/Amp HAT/DAC Zero/Amp Zero":{},"JustBoom Digi & Digi Zero":{},"Justboom-dac and justboom-digi simultaneous usage":{},"Keep queue length":{"de-DE":"Warteschlangenlänge","es-VE":"Mantener longitud de cola de reproducción","ko-KR":"순서 길이 유지","nl-NL":"Aantal in wachtrij"},"LOSSLESS":{},"LOW":{},"Label":{"de-DE":"Herausgeber","es-VE":"Etiqueta","ko-KR":"음반사","nl-NL":"Label"},"Last modified":{"de-DE":"Zuletzt geändert","es-VE":"Últ. modificación","ko-KR":"앞서 수정함","nl-NL":"Laatst gewijzigd"},"Last played":{"de-DE":"Zuletzt gespielt","es-VE":"Última reproducción","ko-KR":"앞서 연주함","nl-NL":"Laatst afgespeeld"},"Last played list count":{"de-DE":"Anzahl zuletzt gespielte Lieder","es-VE":"Conteo reproducción de última lista","ko-KR":"앞선 연주 목록 개수","nl-NL":"Aantal laatst afgespeelde nummers"},"Last played older than (hours)":{"de-DE":"Zuletzte gespielt, vor mehr als (Stunden)","es-VE":"Última reproducción mas viejo que (horas)","ko-KR":"이전에 연주됨 (시간)","nl-NL":"Laatst afgespeeld, ouder dan (uur)"},"Last skipped":{"de-DE":"Zuletzt übersprungen","es-VE":"Última omisión","ko-KR":"앞서 건너뜀","nl-NL":"Laatst overgeslagen"},"LastModified":{"de-DE":"Zuletzt geändert","en-US":"Last modified","es-VE":"Últ. modif.","ko-KR":"마지막 수정","nl-NL":"Laatst gewijzigd"},"LastPlayed":{"de-DE":"Zuletzt gespielt","es-VE":"Última reproducción","ko-KR":"앞서 연주함","nl-NL":"Laatst afgespeeld"},"Latest version":{},"Leaving playlist as it is":{"de-DE":"Wiedergabeliste wird nicht verändert","es-VE":"Dejando la lista de reproducción como está","ko-KR":"연주목록을 그대로 둠","nl-NL":"Afspeellijst niet gewijzigd"},"Libmpdclient version":{"de-DE":"Libmpdclient Version","es-VE":"Versión Libmpdclient","ko-KR":"Libmpdclient 버전","nl-NL":"Versie libmpdclient"},"Libmympdclient version":{"de-DE":"Libmympdclient Version","es-VE":"Versión Libmympdclient","ko-KR":"Libmympdclient 버전","nl-NL":"Versie libmympdclient"},"Light":{"de-DE":"Hell","es-VE":"Claro","ko-KR":"밝음","nl-NL":"Licht"},"Like":{"de-DE":"Wertung","es-VE":"Me gusta","ko-KR":"좋아요","nl-NL":"Like"},"Like song":{"de-DE":"Gutes Lied","es-VE":"Me gusta esta canción","ko-KR":"곡 좋아요","nl-NL":"Like nummer"},"Local playback":{"de-DE":"Lokale Wiedergabe","es-VE":"Reproducción local","ko-KR":"로컬 연주","nl-NL":"Lokaal afspelen"},"Locale":{"de-DE":"Sprache","es-VE":"Idioma","ko-KR":"언어","nl-NL":"Taal"},"Love song":{"de-DE":"Lieblingslied","es-VE":"Me encanta esta canción","ko-KR":"애청곡","nl-NL":"Favoriet"},"Lyrics":{"de-DE":"Liedtext","es-VE":"Letras","ko-KR":"가사","nl-NL":"Songtekst"},"MPD channel":{"de-DE":"MPD Channel","es-VE":"Canal MPD","ko-KR":"MPD 채널","nl-NL":"MPD-kanaal"},"MPD channel not found":{"de-DE":"MPD Channel nicht gefunden","es-VE":"Canal MPD no encontrado","ko-KR":"MPD 채널 없음","nl-NL":"MPD-kanaal niet gevonden"},"MPD connected":{"de-DE":"MPD verbunden","es-VE":"MPD conectado","ko-KR":"MPD 연결됨","nl-NL":"MPD verbonden"},"MPD connection":{"de-DE":"MPD Verbindung","es-VE":"Conexión MPD","ko-KR":"MPD 연결","nl-NL":"MPD-verbinding"},"MPD connection error: %{error}":{"de-DE":"MPD Verbindungsfehler: %{error}","es-VE":"Error de conexión MPD: %{error}","ko-KR":"MPD 연결 오류: %{error}","nl-NL":"MPD verbindingsfout: %{error}"},"MPD disconnected":{"de-DE":"MPD nicht verbunden","es-VE":"MPD desconectado","ko-KR":"MPD 연결 끊어짐","nl-NL":"MPD niet verbonden"},"MPD host":{"de-DE":"MPD Host","es-VE":"Servidor MPD","ko-KR":"MPD 호스트","nl-NL":"MPD host"},"MPD password":{"de-DE":"MPD Passwort","es-VE":"Contraseña MPD","ko-KR":"MPD 비밀번호","nl-NL":"MPD wachtwoord"},"MPD port":{"de-DE":"MPD Port","es-VE":"Puerto MPD","ko-KR":"MPD 포트","nl-NL":"MPD poort"},"MPD stickers are disabled":{"de-DE":"MPD Sticker sind deaktiviert","es-VE":"Los Stickers MPD están deshabilitados","ko-KR":"MPD 스티커 사용 안 함","nl-NL":"MPD-stickers uitgeschakeld"},"MPD uptime":{"de-DE":"MPD Uptime","es-VE":"Tiempo de actividad MPD","ko-KR":"MPD 가동 시간","nl-NL":"MPD uptime"},"MUSICBRAINZ_ALBUMARTISTID":{"de-DE":"Musicbrainz AlbumArtist ID","es-VE":"Musicbrainz AlbumArtist ID","ko-KR":"뮤직브레인즈 음반 연주자 ID","nl-NL":"Musicbrainz AlbumArtist ID"},"MUSICBRAINZ_ALBUMID":{"de-DE":"Musicbrainz Album ID","es-VE":"Musicbrainz Album ID","ko-KR":"뮤직브레인즈 음반 ID","nl-NL":"Musicbrainz Album ID"},"MUSICBRAINZ_ARTISTID":{"de-DE":"Musicbrainz Künstler ID","es-VE":"Musicbrainz Artist ID","ko-KR":"뮤직브레인즈 연주자 ID","nl-NL":"Musicbrainz Ariest ID"},"MUSICBRAINZ_RELEASETRACKID":{"de-DE":"Musicbrainz Release Track ID","es-VE":"Musicbrainz Release Track ID","ko-KR":"뮤직브레인즈 발표 곡 ID","nl-NL":"Musicbrainz Release Track ID"},"MUSICBRAINZ_TRACKID":{"de-DE":"Musicbrainz Track ID","es-VE":"Musicbrainz Track ID","ko-KR":"뮤직브레인즈 곡 ID","nl-NL":"Musicbrainz Track ID"},"MUSICBRAINZ_WORKID":{"de-DE":"Musicbrainz Werk ID","es-VE":"Musicbrainz Work ID","ko-KR":"뮤직브레인즈 작품 ID","nl-NL":"Musicbrainz Werk ID"},"Mamboberry DACs":{},"Max. songs":{"de-DE":"Max. Lieder","es-VE":"Canciones max.","ko-KR":"최대 곡","nl-NL":"Max. nummers"},"Maxim MAX98357A":{},"Media session support":{"de-DE":"Media Session Unterstützung","es-VE":"Soporte de sesión de medios","ko-KR":"미디어 세션 지원","nl-NL":"Mediasessie ondersteuning"},"Message":{"de-DE":"Nachricht","es-VE":"Mensaje","ko-KR":"메시지","nl-NL":"Bericht"},"Min. value":{"de-DE":"Min. Wert","es-VE":"Valor min.","ko-KR":"최소 값","nl-NL":"Min. waarde"},"Minimum one weekday must be selected":{"de-DE":"Es muss mindestens ein Wochentag ausgewählt sein.","es-VE":"Debe seleccionar al menos un dia de la semana","ko-KR":"최소 일주일 선택해야 함","nl-NL":"Selecteer minimaal 1 weekdag"},"Minutes":{"de-DE":"Min","en-US":"Min","es-VE":"Min","ko-KR":"분","nl-NL":"min"},"Mixramp DB":{"de-DE":"Mixramp DB","es-VE":"Mixramp dB","ko-KR":"Mixramp DB","nl-NL":"Mixramp DB"},"Mixramp delay":{"de-DE":"Mixramp Verzögerung","es-VE":"Retraso Mixramp","ko-KR":"Mixramp 지연","nl-NL":"Mixramp-vertraging"},"Mon":{"de-DE":"Mo","es-VE":"Lun","ko-KR":"월","nl-NL":"Ma"},"Mongoose version":{"de-DE":"Mongoose Version","es-VE":"Versión Mongoose","ko-KR":"Mongoose 버전","nl-NL":"Versie Mongoose"},"Most played":{"de-DE":"Am Öftesten gespielt","es-VE":"Más reproducido","ko-KR":"자주 연주","nl-NL":"Meest afgespeeld"},"Mount point":{"de-DE":"Einhängepunkt","es-VE":"Punto de monaje","ko-KR":"마운트 위치","nl-NL":"Aankoppelpunt"},"Mounts":{"de-DE":"Einhängepunkte","es-VE":"Montar","ko-KR":"마운트","nl-NL":"Aankoppelpunten"},"Music directory":{"de-DE":"Musikverzeichnis","es-VE":"Directorio de música","ko-KR":"음원 디렉터리","nl-NL":"Muziekmap"},"Music directory not found":{"de-DE":"Musikverzeichnis nicht gefunden","es-VE":"Directorio de música no encontrado","ko-KR":"음원 디렉터리 없음","nl-NL":"Muziekmap niet gevonden"},"Music folder path in NAS (e.g. /music)":{},"Must be a number":{"de-DE":"Muss eine Zahl sein","es-VE":"Debe ser un número","ko-KR":"숫자여야 함","nl-NL":"Moet een getal zijn"},"Must be a number and equal or greater than zero":{"de-DE":"Muss eine Zahl größergleich 0 sein","es-VE":"Debe ser un número igual o mayor a cero","ko-KR":"숫자이고 0과 같거나 커야 함","nl-NL":"Getal moet gelijk of groter zijn dan 0"},"Must be a number and greater than zero":{"de-DE":"Muss eine Zahl größer als 0 sein","es-VE":"Debe ser un número mayor a cero","ko-KR":"0보다 큰 숫자여야 함","nl-NL":"Moet een getal zijn en groter dan 0"},"Must be a number smaller or equal 200":{"de-DE":"Muss eine Zahl kleinergleich 200 sein","es-VE":"Debe ser un número menor o igual a 200","ko-KR":"200이하의 숫자여야 함","nl-NL":"Getal moet kleiner zijn dan 200"},"NAS":{},"NAS IP address":{},"NFS":{},"Name":{"de-DE":"Name","es-VE":"Nombre","ko-KR":"이름","nl-NL":"Naam"},"Neighbors are disabled":{"de-DE":"Kein Neighbor Plugin aktiviert","ko-KR":"Neighbors 사용 안 함"},"New mount":{"de-DE":"Neuer Einhängepunkt","es-VE":"Nuevo punto de montaje","ko-KR":"새로운 마운트","nl-NL":"Nieuw aankoppelpunt"},"New playlist":{"de-DE":"Neue Wiedergabeliste","es-VE":"Nueva lista de reproducción","ko-KR":"새 연주목록","nl-NL":"Nieuwe afspeellijst"},"New timer":{"de-DE":"Neuer Timer","es-VE":"Nuevo Temporizador","ko-KR":"새로운 타이머","nl-NL":"Nieuwe Timer"},"Newest songs":{"de-DE":"Neueste Lieder","es-VE":"Canciones mas recientes","ko-KR":"새 곡","nl-NL":"Nieuwste nummers"},"Next page":{"de-DE":"Nächste Seite","es-VE":"Página siguiente","ko-KR":"다음 페이지","nl-NL":"Volgende pagina"},"Next song":{"de-DE":"Nächstes Lied","es-VE":"Canción siguiente","ko-KR":"다음 곡","nl-NL":"Volgende nummer"},"No albumart found by mpd":{"de-DE":"MPD konnte keine Cover finden","es-VE":"No se encontró carátula por MPD","ko-KR":"MPD가 음반 표지를 찾을 수 없음","nl-NL":"Geen albumcover gevonden door mpd"},"No bookmarks found":{"de-DE":"Keine Lesezeichen gefunden","es-VE":"No se encontraron marcadores","ko-KR":"즐겨찾기를 찾을 수 없음","nl-NL":"Geen bladwijzers gevonden"},"No current song":{"de-DE":"Kein Lied ausgwählt","es-VE":"No hay canción actual","ko-KR":"지금 곡 없음","nl-NL":"Geen nummer gekozen"},"No lyrics found":{"de-DE":"Kein Songtext gefunden","ko-KR":"가사 없음"},"No playlists found":{"de-DE":"Keine Wiedergabelisten gefunden","es-VE":"No se encontraron Listas de reproducción","ko-KR":"연주목록 찾을 수 없음","nl-NL":"Geen afspeellijsten gevonden"},"No response for method %{method}":{"de-DE":"Keine Rückmeldung für Aufruf %{method}","es-VE":"Sin respuesta para el método %{method}","ko-KR":"%{method} 응답 없음","nl-NL":"Geen antwoord op methode %{method}"},"No results, please refine your search":{"de-DE":"Keine Ergebnisse, bitte passe die Suche an","es-VE":"Sin resultados, cambie los parámetros de búsqueda","ko-KR":"결과가 없으므로, 맞게 찾아야 함","nl-NL":"Geen hits, gebruik andere zoekterm"},"No search expression defined":{"de-DE":"Kein Suchausdruck angegeben","es-VE":"Ninguna expresión de búsqueda definida","ko-KR":"찾을 문구 없음","nl-NL":"Zoekopdracht niet gedefinieerd"},"No such directory":{"de-DE":"Verzeichnis nicht gefunden","es-VE":"No se encontró ese directorio","ko-KR":"그런 디렉터리가 없음"},"None":{"de-DE":"Keines","es-VE":"Ninguno","ko-KR":"없음","nl-NL":"Geen"},"None (not applicable)":{},"Notifications":{"de-DE":"Hinweise","es-VE":"Notificaciones","ko-KR":"알림","nl-NL":"Notificaties"},"Notifications are blocked":{"de-DE":"Benachrichtungen sind nicht erlaubt","es-VE":"Las Notificaciones están bloqueadas","ko-KR":"알림 차단됨","nl-NL":"Meldingen zijn geblokkeerd"},"Num entries":{"de-DE":"%{smart_count} Eintrag |||| %{smart_count} Einträge","en-US":"%{smart_count} Entry |||| %{smart_count} Entries","es-VE":"%{smart_count} Entrada |||| %{smart_count} Entradas","ko-KR":"%{smart_count} 항목 |||| %{smart_count} 항목","nl-NL":"%{smart_count} entry |||| %{smart_count} entries"},"Num playlists":{"de-DE":"%{smart_count} Wiedergabeliste |||| %{smart_count} Wiedergabelisten","en-US":"%{smart_count} Playlist |||| %{smart_count} Playlists","es-VE":"%{smart_count} Lista de reproducción |||| %{smart_count} Listas de reproducción","ko-KR":"%{smart_count} 연주목록 |||| %{smart_count} 연주목록","nl-NL":"%{smart_count} afspeellijst |||| %{smart_count} afspeellijsten"},"Num songs":{"de-DE":"%{smart_count} Lied |||| %{smart_count} Lieder","en-US":"%{smart_count} Song |||| %{smart_count} Songs","es-VE":"%{smart_count} Canción |||| %{smart_count} Canciones","ko-KR":"%{smart_count} 곡 |||| %{smart_count} 곡","nl-NL":"%{smart_count} nummer |||| %{smart_count} nummers"},"Off":{"de-DE":"Deaktiviert","es-VE":"Apagado","ko-KR":"끄기","nl-NL":"Uit"},"On":{"de-DE":"Aktiv","es-VE":"On","ko-KR":"켜기","nl-NL":"Aan"},"On page notifications":{"de-DE":"Integrierte Hinweise","es-VE":"Notificaciones en la Página","ko-KR":"페이지에 알림","nl-NL":"Meldingen op pagina"},"Oneshot":{"de-DE":"Oneshot","es-VE":"Oneshot","ko-KR":"1회","nl-NL":"Oneshot"},"Open about":{"de-DE":"Öffne Über myMPD","es-VE":"Abrir acerca de ","ko-KR":"정보 열기","nl-NL":"Over myMPD openen"},"Open local player":{"de-DE":"Lokale Wiedergabe","es-VE":"Abrir reproductor local","ko-KR":"로컬 연주기 열기","nl-NL":"Lokaal afspelen"},"Open main menu":{"de-DE":"Öffne Hauptmenü","es-VE":"Abrir menú principal","ko-KR":"주 메뉴로 가기","nl-NL":"Hoofdmenu openen"},"Open settings":{"de-DE":"Einstellungen","es-VE":"Abrir configuraciones","ko-KR":"설정 열기","nl-NL":"Instellingen"},"Open song details":{"de-DE":"Lieddetails","es-VE":"Abrir detalles de canción","ko-KR":"곡 정보 열기","nl-NL":"Nummerdetails"},"Open volume menu":{"de-DE":"Öffne Lautstärkemenü","es-VE":"Abrir menú de volumen","ko-KR":"음량 메뉴 열기","nl-NL":"Volumeregeing openen"},"Order":{"de-DE":"Reihenfolge","es-VE":"Orden","ko-KR":"순서","nl-NL":"Volgorde"},"Other features":{"de-DE":"Weitere Features","es-VE":"Más funciones","ko-KR":"다른 기능","nl-NL":"Overige functies"},"Pagination":{"de-DE":"Seitenumbruch","es-VE":"Paginación","ko-KR":"페이지 매기기","nl-NL":"Paginagrootte"},"Password":{},"Password cannot be blank":{},"Path":{},"Path must start with a leading slash":{},"Performer":{"de-DE":"Aufführender","es-VE":"Interprete","ko-KR":"연주자","nl-NL":"Uitvoerend artiest"},"Pictures":{"de-DE":"Bilder","es-VE":"Imágenes","ko-KR":"그림","nl-NL":"Foto's "},"Play count":{"de-DE":"Wie oft gespielt","es-VE":"Conteo reproducciones","ko-KR":"연주 횟수","nl-NL":"Aantal x afgespeeld"},"Play time":{"de-DE":"Wiedergabedauer","es-VE":"Tiempo de reproducción","ko-KR":"연주 시간","nl-NL":"Gespeelde tijd"},"Playback":{"de-DE":"Wiedergabe","es-VE":"Reproducción","ko-KR":"연주","nl-NL":"Afspelen"},"Playback statistics":{"de-DE":"Wiedergabestatistiken","es-VE":"Estadísticas de reproducción","ko-KR":"연주 통계","nl-NL":"Afspeelgegevens"},"Playback statistics are disabled":{"de-DE":"Wiedergabestatistiken sind deaktiviert","es-VE":"Las estadísticas de reproducción están deshabilitadas","ko-KR":"연주 통계 사용 안 함","nl-NL":"Afspeelstatistieken uitgeschakeld"},"Playlist":{"de-DE":"Wiedergabeliste","es-VE":"Lista de reproducción","ko-KR":"연주목록","nl-NL":"Afspeellijst"},"Playlist is too small to shuffle":{"de-DE":"Wiedergabeliste ist zu klein um sie zu mischen","es-VE":"La lista de reproducción es muy pequeña para mezclar aleatoriamente","ko-KR":"연주목록이 너무 작아 뒤섞을 수 없음","nl-NL":"Afspeellijst te klein om te shufflen"},"Playlist is too small to sort":{"de-DE":"Wiedergabeliste ist zu klein um sie zu sortieren","es-VE":"Wiedergabeliste ist zu klein um sie zu sortieren","ko-KR":"연주목록이 너무 작아 정렬할 수 없음","nl-NL":"Afspeellijst te klein om te sorteren"},"Playlist name":{"de-DE":"Wiedergabelistenname","es-VE":"Nombre de lista de reproducción","ko-KR":"연주목록 이름","nl-NL":"Naam afspeellijst"},"Playlists":{"de-DE":"Wiedergabelisten","es-VE":"Listas de reproducción","ko-KR":"연주목록","nl-NL":"Afspeellijsten"},"Playlists are disabled":{"de-DE":"Wiedergabelisten sind deaktiviert","es-VE":"Listas de reproducción deshabilitadas","ko-KR":"연주목록 사용 안 함","nl-NL":"Afspeellijsten uitgeschakeld"},"Playlists deleted":{"de-DE":"Wiedergabeliste wurde gelöscht","es-VE":"Listas de reproducción eliminadas","ko-KR":"연주목록 지워짐","nl-NL":"Afspeellijsten verwijderd"},"Please choose playlist":{"de-DE":"Bitte Wiedergabeliste auswählen","es-VE":"Seleccione lista de reproducción","ko-KR":"연주목록을 선택합니다","nl-NL":"Aub afspeellijst kiezen"},"Port":{"de-DE":"Port","es-VE":"Puerto","ko-KR":"포트","nl-NL":"Poort"},"Pos":{"de-DE":"Pos","es-VE":"Pos","ko-KR":"위치","nl-NL":"Pos"},"Preview":{"de-DE":"Vorschau","es-VE":"Previsualizar","ko-KR":"미리 보기","nl-NL":"Voorbeeld"},"Previous page":{"de-DE":"Vorige Seite","es-VE":"Página anterior","ko-KR":"이전 페이지","nl-NL":"Vorige pagina"},"Previous song":{"de-DE":"Voriges Lied","es-VE":"Canción anterior","ko-KR":"이전 곡","nl-NL":"Vorig nummer"},"Protocol version":{"de-DE":"Protokoll Version","es-VE":"Versión de protocolo","ko-KR":"프로토콜 버전","nl-NL":"Versie protocol"},"Quantity":{"de-DE":"Anzahl","es-VE":"Cantidad","ko-KR":"갯수","nl-NL":"Aantal"},"Queue":{"de-DE":"Warteschlange","es-VE":"Cola de reproducción","ko-KR":"순서","nl-NL":"Wachtrij"},"Queue replaced with %{name}":{"de-DE":"Warteschlange mit %{name} ersetzt","es-VE":"Cola de reproducción reemplazada con %{name}","ko-KR":"%{name} 순서 바꿈","nl-NL":"Wachtrij vervangen door %{name}"},"RPi DAC":{},"RPi Proto":{},"Random":{"de-DE":"Zufall","es-VE":"Aleatorio","ko-KR":"무작위","nl-NL":"Willekeurig"},"Red Rocks Audio DigiDAC1":{},"Reload":{"de-DE":"Neu laden","es-VE":"Recargar","ko-KR":"다시 읽기","nl-NL":"Herladen"},"Remove":{"de-DE":"Entfernen","es-VE":"Remover","ko-KR":"지우기","nl-NL":"Verwijder"},"Remove all downwards":{"de-DE":"Aller Lieder darunter entfernen","es-VE":"Remover todo hacia abajo","ko-KR":"아래로 지우기","nl-NL":"Verwijder alle hieronder"},"Remove all upwards":{"de-DE":"Alle Lieder darüber entfernen","es-VE":"Remover todo hacia arriba","ko-KR":"위로 지우기","nl-NL":"Verwijder alle hierboven"},"Remove item from queue":{"de-DE":"Ausgewähltes Element aus Warteschlange entfernen","es-VE":"Eliminar elemento de la cola de reproducción","ko-KR":"순서에서 항목 지우기","nl-NL":"Verwijder selectie uit wachtrij"},"Rename playlist":{"de-DE":"Wiedergabeliste umbenennen","es-VE":"Renombrar lista de reproducción","ko-KR":"연주목록 이름 바꾸기","nl-NL":"Hernoem afspeellijst"},"Renaming playlist failed":{"de-DE":"Wiedergabeliste konnte nicht umbenannt werden","es-VE":"Error al renombrar lista de reproducción","ko-KR":"연주목록 이름 바꾸기 안 됨","nl-NL":"Hernoemen afspeellijst mislukt"},"Repeat":{"de-DE":"Wiederholen","es-VE":"Repetir","ko-KR":"다시","nl-NL":"Herhalen"},"Replace queue":{"de-DE":"Warteschlange ersetzen","es-VE":"Reemplazar cola de reproducción","ko-KR":"순서 바꾸기","nl-NL":"Vervang wachtrij"},"Replace queue with item":{"de-DE":"Warteschlange mit ausgewähltem Element ersetzen","es-VE":"Reemplazar cola de reproducción con esto","ko-KR":"순서에 항목 대체","nl-NL":"Vervang wachtrij met selectie"},"Replaygain":{"de-DE":"Lautstärkeanpassung","es-VE":"Volver a reproducir","ko-KR":"리플레이게인","nl-NL":"Replaygain"},"Rescan database":{"de-DE":"Datenbank neu einlesen","es-VE":"Reescanear base de datos","ko-KR":"데이터베이스 다시 검색","nl-NL":"Herscan database"},"Rescan directory":{"de-DE":"Verzeichnis neu einlesen","es-VE":"Reescanear directorio","ko-KR":"디렉터리 다시 검색","nl-NL":"Herscan map"},"Reset":{"de-DE":"Zurücksetzen","es-VE":"Restablecer","ko-KR":"다시 설정","nl-NL":"Reset"},"Reset settings":{"de-DE":"Einstellungen zurücksetzen","es-VE":"Restablecer configuraciones","ko-KR":"다시 설정 하기","nl-NL":"Reset instellingen"},"Roon":{},"Samba A (guest access)":{},"Samba B (access with credentials)":{},"Sat":{"de-DE":"Sa","es-VE":"Sáb","ko-KR":"토","nl-NL":"Za"},"Save":{"de-DE":"Speichern","es-VE":"Guardar","ko-KR":"저장","nl-NL":"Opslaan"},"Save as smart playlist":{"de-DE":"Als intelligente Wiedergabeliste speichern","es-VE":"Guardar como lista de reproducción inteligente","ko-KR":"스마트 연주목록 저장","nl-NL":"Als slimme afspeellijst opslaan"},"Save bookmark":{"de-DE":"Lesezeichen speichern","es-VE":"Guardad marcador","ko-KR":"즐겨찾기 저장","nl-NL":"Bladwijzer opslaan"},"Save queue":{"de-DE":"Warteschlange speichern","es-VE":"Guardar cola de reproducción","ko-KR":"순서 저장","nl-NL":"Wachtrij opslaan"},"Save smart playlist":{"de-DE":"Intelligente Wiedergabeliste sichern","es-VE":"Guardar lista de reproducción inteligente","ko-KR":"스마트 연주목록 저장","nl-NL":"Slimme afspeellijst opslaan"},"Saved smart playlist %{name}":{"de-DE":"Intelligente Wiedergabeliste %{name} gespeichert","es-VE":"Lista de reproducción inteligente guardada: %{name}","ko-KR":"%{name} 스마트 연주목록 저장함","nl-NL":"Slimme afspeellijst %{name} opgeslagen"},"Saving bookmark failed":{"de-DE":"Lesezeichen konnte nicht gespeichert werden","es-VE":"Error al guardar marcador","ko-KR":"즐겨찾기 저장 안 됨","nl-NL":"Opslaan bladwijzer mislukt"},"Scrobbled love":{"de-DE":"Lieblingslied wurde gescrobbelt","es-VE":"Me gusta recomendado","ko-KR":"애청곡 추천","nl-NL":"Favoriet werd gescrobbeld"},"Scrobbler integration":{"de-DE":"Scrobbler Integration","es-VE":"Scrobbler Integration","ko-KR":"추천 통합","nl-NL":"Scrobbler-integratie"},"Search":{"de-DE":"Suchen","es-VE":"Buscar","ko-KR":"찾기","nl-NL":"Zoeken"},"Search queue":{"de-DE":"Warteschlange durchsuchen","es-VE":"Buscar cola de reproducción","ko-KR":"순서 찾기","nl-NL":"Zoek in wachtrij"},"Searching...":{"de-DE":"Suche...","es-VE":"Buscando...","ko-KR":"찾는 중...","nl-NL":"Zoek..."},"Seconds":{"de-DE":"Sek","en-US":"Sec","es-VE":"Seg","ko-KR":"초","nl-NL":"sec"},"Select samba version":{},"Select tag to search":{"de-DE":"Tag zum Suchen auswählen","es-VE":"Seleccionar etiqueta para buscar","ko-KR":"찾을 태그 선택","nl-NL":"Selecteer tag om te zoeken"},"Select type":{},"Send love message":{"de-DE":"Sende Lieblingslied","es-VE":"Enviar mensaje de Me gusta","ko-KR":"애청 메시지 보내기","nl-NL":"Stuur favoriet"},"Settings":{"de-DE":"Einstellungen","es-VE":"Ajustes","ko-KR":"설정","nl-NL":"Instellingen"},"Shortcut":{"de-DE":"Tastenkürzel","es-VE":"Acceso directo","ko-KR":"단축키","nl-NL":"Sneltoets"},"Shortcuts":{"de-DE":"Tastenkombinationen","es-VE":"Accesos directos","ko-KR":"단축키","nl-NL":"Sneltoetsen"},"Show songs":{"de-DE":"Lieder anzeigen","es-VE":"Mostrar canciones","ko-KR":"곡 보기","nl-NL":"Toon nummers"},"Shuffle":{"de-DE":"Mischen","es-VE":"Aleatorio","ko-KR":"뒤섞기","nl-NL":"Shuffle"},"Shuffle playlist":{"de-DE":"Wiedergabeliste mischen","es-VE":"Mezclar aleatoriamente la lista de reproducción","ko-KR":"연주목록 뒤섞기","nl-NL":"Shuffle afspeellijst"},"Shuffle queue":{"de-DE":"Warteschlange mischen","es-VE":"Cola de reproducción aleatoria","ko-KR":"순서 뒤섞기","nl-NL":"Wachtrij shufflen"},"Shuffled playlist succesfully":{"de-DE":"Wiedergabeliste erfolgreich gemischt","es-VE":"Lista de reproducción mezclada aleatoriamente","ko-KR":"연주목록을 뒤섞음","nl-NL":"Afspeellijst geshuffled"},"Single":{"de-DE":"Nur ein Lied","es-VE":"Individual","ko-KR":"한 곡만","nl-NL":"Single"},"Size in px":{"de-DE":"Größe in PX","es-VE":"Tamaño en px","ko-KR":"픽셀 크기","nl-NL":"Grootte in px"},"Size normal":{"de-DE":"Normale Größe","es-VE":"Tamaño normal","ko-KR":"일반 크기","nl-NL":"Standaard formaat"},"Size small":{"de-DE":"Kleine Größe","es-VE":"Tamaño pequeño","ko-KR":"작은 크기","nl-NL":"Klein formaat"},"Skip count":{"de-DE":"Wie oft übersprungen","es-VE":"Conteo omisiones","ko-KR":"건너뛴 횟수","nl-NL":"Aantal x geskipt"},"Smart playlist":{"de-DE":"Intelligente Wiedergabeliste","es-VE":"Lista de reproducción inteligente","ko-KR":"스마트 연주목록","nl-NL":"Slimmme afspeellijst"},"Smart playlist %{playlist} updated":{"de-DE":"Intelligente Wiedergabeliste %{playlist} aktualisiert","es-VE":"Lista de reproducción %{playlist} actualizada","ko-KR":"%{playlist} 스마트 연주목록 업데이트함","nl-NL":"Slimmme afspeellijst %{playlist} geüpdatet"},"Smart playlists":{"de-DE":"Intelligente Wiedergabelisten","es-VE":"Listas de reproducción inteligentes","ko-KR":"스마트 연주목록","nl-NL":"Slimmme afspeellijsten"},"Smart playlists prefix":{"de-DE":"Prefix von Intelligenten Wiedergabelisten","es-VE":"Prefijo de listas de reproducción inteligente","ko-KR":"스마트 연주목록 덧붙임","nl-NL":"Voorvoegsel slimme afspeellijsten"},"Smart playlists update failed":{"de-DE":"Intelligente Wiedergabelisten konnten nicht aktualisiert werden","es-VE":"Error Actualizando listas de reproducción inteligentes","ko-KR":"스마트 연주목록 업데이트 안 됨","nl-NL":"Updaten slimmme afspeellijsten mislukt"},"Smart playlists updated":{"de-DE":"Intelligente Wiedergabelisten wurden aktualisiert","es-VE":"Listas de reproducción inteligentes actualizadas","ko-KR":"스마트 연주목록 업데이트됨","nl-NL":"Slimmme afspeellijsten geüpdatet"},"Software":{},"Song":{"de-DE":"Lied","es-VE":"Canción","ko-KR":"곡","nl-NL":"Nummer"},"Song details":{"de-DE":"Lieddetails","es-VE":"Detalles de canción","ko-KR":"곡 정보","nl-NL":"Nummerdetails"},"Songs":{"de-DE":"Lieder","es-VE":"Canciones","ko-KR":"곡","nl-NL":"Nummers"},"Sorry, your MPD version is too old":{"de-DE":"Entschuldige, deine MPD version ist zu alt","es-VE":"Su versión de MPD es muy vieja","ko-KR":"MPD 버전이 낮음","nl-NL":"Sorry, je MPD-versie is te oud"},"Sort by":{"de-DE":"Sortieren","es-VE":"Ordenar por","ko-KR":"정렬","nl-NL":"Sorteer op"},"Sort by tag":{"de-DE":"Sortiere nach Tag","es-VE":"Ordenar por etiqueta","ko-KR":"태그로 정렬","nl-NL":"Sorteer op tag"},"Sort playlist":{"de-DE":"Wiedergabeliste sortieren","es-VE":"Ordenar lista de reproducción","ko-KR":"연주목록 정렬","nl-NL":"Sorteer afspeellijst"},"Sorted playlist succesfully":{"de-DE":"Wiedergabeliste erfolgreich sortiert","es-VE":"Lista de reproducción ordenada","ko-KR":"연주목록 정렬함","nl-NL":"Afspeellijst gesorteerd"},"Specify":{"de-DE":"Manuell","es-VE":"Especificar","ko-KR":"지정","nl-NL":"Specifiek"},"Spotify":{},"Start":{"de-DE":"Start","es-VE":"Iniciar","ko-KR":"시작","nl-NL":"Start"},"Start playback":{"de-DE":"Wiedergabe starten","es-VE":"Iniciar reproducción","ko-KR":"연주 시작","nl-NL":"Start afspelen"},"Statistics":{"de-DE":"Statistiken","es-VE":"Estadísticas","ko-KR":"통계","nl-NL":"Gegevens"},"Sticker":{"de-DE":"Sticker","es-VE":"Sticker","ko-KR":"스티커","nl-NL":"Sticker"},"Stickers are disabled":{"de-DE":"Sticker sind deaktiviert","es-VE":"Los Stickers están deshabilitados","ko-KR":"스티커 사용 안 함","nl-NL":"Stickers uitgeschakeld"},"Stop playback":{"de-DE":"Wiedergabe anhalten","es-VE":"Detener reproducción","ko-KR":"연주 정지","nl-NL":"Stop afspelen"},"Stop playing":{"de-DE":"Stop","es-VE":"Stop","ko-KR":"정지","nl-NL":"Stop"},"Stream URI":{"de-DE":"Stream URL","es-VE":"URL Streaming","ko-KR":"스트리밍 주소","nl-NL":"Streaming url"},"Streaming":{},"Streaming Services":{},"Successfully cleared covercache":{"de-DE":"Covercache erfolgreich geleert","es-VE":"Covercache limpiado exitosamente","ko-KR":"표지 캐시 지우기 완료","nl-NL":"Covercache gewist"},"Successfully croped covercache":{"de-DE":"Covercache erfolgreich bereinigt","es-VE":"Covercache cortado exitosamente","ko-KR":"표지 캐시 잘라내기 완료","nl-NL":"Covercache opgeschoond"},"Successfully execute cmd %{cmd}":{"de-DE":"Systembefehl %{cmd} erfolgreich ausgeführt","es-VE":"Ejecutado %{cmd} exitosamente","ko-KR":"%{cmd} 명령어 실행함","nl-NL":"Systeemcommando %{cmd} uitgevoerd"},"Sucessfully added random songs to queue":{"de-DE":"Zufällige Lieder wurden zur Warteschlange hinzugefügt","es-VE":"Agregadas canciones aleatorias a la cola de reproducción exitosamente","ko-KR":"무작위 곡을 순서에 추가함","nl-NL":"Willekeurig nummer aan wachtrij toegevoegd"},"Sucessfully renamed playlist":{"de-DE":"Wiedergabeliste erfolgreich umbenannt","es-VE":"Lista de reproducción renombrada exitosamente","ko-KR":"연주목록 이름 바꿈","nl-NL":"Afspeellijst is hernoemd"},"Sun":{"de-DE":"So","es-VE":"Dom","ko-KR":"일","nl-NL":"Zo"},"System command":{"de-DE":"Systembefehl","es-VE":"Comando de sistema","ko-KR":"시스템 명령어","nl-NL":"Systeemcommando"},"System command not defined":{"de-DE":"Systembefehl nicht definiert","es-VE":"Comando del sistema no definido","ko-KR":"시스템 명령어 정의 안됨","nl-NL":"Systeemcommando niet bekend"},"System commands":{"de-DE":"Systembefehle","es-VE":"Comandos de sistema","ko-KR":"시스템 명령어","nl-NL":"Systemcommando"},"System commands are disabled":{"de-DE":"Systembefehle sind deaktiviert","es-VE":"Comandos del sistema deshabilitados","ko-KR":"시스템 명령어 사용 안 함","nl-NL":"Systeemcommando's uitgeschakeld"},"Tag":{"de-DE":"Tag","es-VE":"Etiqueta","ko-KR":"태그","nl-NL":"Tag"},"Tags":{"de-DE":"Tags","es-VE":"Etiquetas","ko-KR":"태그","nl-NL":"Tags"},"Tags to browse":{"de-DE":"Tags für die Datenbankanzeige","es-VE":"Etiquetas para explorar","ko-KR":"열 태그","nl-NL":"Tags om te browsen"},"Tags to search":{"de-DE":"Tags für die Suche","es-VE":"Etiquetas para buscar","ko-KR":"찾을 태그","nl-NL":"Tags om te zoeken"},"Tags to use":{"de-DE":"Genutzte Tags","es-VE":"Etiquetas para usar","ko-KR":"쓸 태그","nl-NL":"Te gebruiken tags"},"Theme":{"de-DE":"Design","es-VE":"Tema","ko-KR":"테마","nl-NL":"Thema"},"Thu":{"de-DE":"Do","es-VE":"Jue","ko-KR":"목","nl-NL":"Do"},"Tidal":{},"Timer":{"de-DE":"Timer","es-VE":"Temporizador","ko-KR":"타이머","nl-NL":"Timer"},"Timer with given id not found":{"de-DE":"Timer nicht gefunden","es-VE":"Temporizador no se encontró con ese ID","ko-KR":"타이머를 찾을 수 없음","nl-NL":"Timer niet gevonden"},"Timerange (days)":{"de-DE":"Tage","es-VE":"Tiempo (días)","ko-KR":"시간 범위 (날짜)","nl-NL":"Dagen"},"Title":{"de-DE":"Titel","es-VE":"Título","ko-KR":"제목","nl-NL":"Titel"},"To":{"de-DE":"Zu","es-VE":"Para","ko-KR":"바꿈","nl-NL":"Naar"},"To top":{"de-DE":"Nach oben","es-VE":"Arriba","ko-KR":"위로","nl-NL":"Omhoog"},"Toggle play / pause":{"de-DE":"Play / Pause","es-VE":"Play / Pausa","ko-KR":"연주 / 잠시 멈춤","nl-NL":"Play / Pause"},"Track":{"de-DE":"Liednummer","es-VE":"# Pista","ko-KR":"트랙","nl-NL":"Track"},"Tue":{"de-DE":"Di","es-VE":"Mar","ko-KR":"화","nl-NL":"Di"},"Type":{"de-DE":"Typ","es-VE":"Tipo","ko-KR":"형식","nl-NL":"Type"},"URI":{"de-DE":"URL","es-VE":"URL","ko-KR":"주소","nl-NL":"Url"},"Unknown album":{"de-DE":"Unbekanntes Album","es-VE":"Álbum desconocido","ko-KR":"모르는 음반","nl-NL":"Onbekend album"},"Unknown artist":{"de-DE":"Unbekannter Künstler","es-VE":"Artista desconocido","ko-KR":"모르는 연주자","nl-NL":"Onbekende artiest"},"Unknown request":{"de-DE":"Unbekannter Befehl","es-VE":"Solicitud desconocida","ko-KR":"알 수 없는 요구","nl-NL":"Onbekend verzoek"},"Unknown smart playlist type":{"de-DE":"Unbekannter intelligenter Wiedergabenlisten Typ","es-VE":"Tipo de lista de reproducción inteligente desconocido","ko-KR":"스마트 연주목록 형식을 알 수 없음","nl-NL":"Onbekend type afspeellijst"},"Unknown table %{table}":{"de-DE":"Unbekannte Tabelle %{table}","es-VE":"Tabla desconocida: %{table}","ko-KR":"%{table} 테이블 알 수 없음","nl-NL":"Onbekende tabel %{table}"},"Unmount":{"de-DE":"Aushängen","es-VE":"Desmontar","ko-KR":"언마운트","nl-NL":"Ontkoppelen"},"Update":{"de-DE":"Aktualisieren","es-VE":"Actualizar","ko-KR":"업데이트","nl-NL":"Updaten"},"Update database":{"de-DE":"Datenbank aktualisieren","es-VE":"Actualizar base de datos","ko-KR":"데이터베이스 업데이트","nl-NL":"Update database"},"Update directory":{"de-DE":"Verzeichnis aktualisieren","es-VE":"Actualizar directorio","ko-KR":"디렉터리 업데이트","nl-NL":"Update map"},"Update smart playlist":{"de-DE":"Intelligente Wiedergabeliste aktualisieren","es-VE":"Actualizar lista de reproducción inteligente","ko-KR":"스마트 연주목록 업데이트","nl-NL":"Update slimme afspeellijst"},"Update smart playlists":{"de-DE":"Intelligente Wiedergabelisten aktualisieren","es-VE":"Actualizar listas de reproducción inteligentes","ko-KR":"스마트 연주목록 업데이트","nl-NL":"Update slimme afspeellijsten"},"Update smart playlists (hours)":{"de-DE":"Intelligente Wiedergabelisten aktualisieren (Stunden)","es-VE":"Actualizar listas de reproducción inteligentes (horas)","ko-KR":"스마트 연주목록 업데이트 (시간)","nl-NL":"Update slimme afspeellijsten (uren)"},"Updating MPD database":{"de-DE":"MPD Datenbank wird aktualisiert","es-VE":"Actualizando base de datos MPD","ko-KR":"MPD 데이터베이스 업데이트 중","nl-NL":"MPD-database wordt geüpdatet"},"Updating of smart playlist %{playlist} failed":{"de-DE":"Intelligente Wiedergabeliste %{playlist} konnte nicht aktualisiert werden","es-VE":"Error actualizando de lista de reproducción inteligente %{playlist} ","ko-KR":"%{playlist} 스마트 연주목록 업데이트 안 됨","nl-NL":"Updaten slimmme afspeellijst %{playlist} mislukt "},"Username":{},"Username cannot be blank":{},"Version":{"de-DE":"Version","es-VE":"Versión","ko-KR":"버전","nl-NL":"Versie"},"View playlist":{"de-DE":"Wiedergabeliste anzeigen","es-VE":"Ver lista de reproducción","ko-KR":"연주목록 보기","nl-NL":"Bekijk afspeellijst"},"Volume":{"de-DE":"Lautstärke","es-VE":"Volumen","ko-KR":"음량","nl-NL":"Volume"},"Volume down":{"de-DE":"Leiser","es-VE":"Volumen -","ko-KR":"소리 작게","nl-NL":"Volume min"},"Volume up":{"de-DE":"Lauter","es-VE":"Volumen +","ko-KR":"소리 크게","nl-NL":"Volume plus"},"Volumecontrol disabled":{"de-DE":"Lautstärkeregelung deaktiviert","es-VE":"Control de volumen deshabilitado","ko-KR":"음량 조절 안 함","nl-NL":"Volumeregeling uitgeschakeld"},"Web notifications":{"de-DE":"Systemhinweise","es-VE":"Notificaciones Web","ko-KR":"웹 알림","nl-NL":"Webmeldingen"},"Webserver":{"de-DE":"Webserver","es-VE":"Servidor Web","ko-KR":"웹서버","nl-NL":"Webserver"},"Websocket connected":{"de-DE":"Websocket verbunden","es-VE":"Websocket conectado","ko-KR":"웹소켓 연결됨","nl-NL":"Websocket verbonden"},"Websocket connection":{"de-DE":"Websocket Verbindung","es-VE":"Conexión Websocket","ko-KR":"웹소켓 연결","nl-NL":"Connectie met Websocket"},"Websocket connection failed":{"de-DE":"Websocket Verbindung fehlgeschlagen","es-VE":"Error en la conexión con el Websocket","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Websocket Verbinding mislukt"},"Websocket connection failed, trying to reconnect":{"de-DE":"Websocket Verbindung fehlgeschlagen, versuche neue Verbindung","es-VE":"Error en la conexión Websocket, intentando reconectar","ko-KR":"웹소켓 연결이 안 되어, 다시 시도하는 중","nl-NL":"Websocket Verbinding mislukt, nieuwe poging"},"Websocket disconnected":{"de-DE":"Websocket nicht verbunden","es-VE":"Websocket desconectado","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Geen connectie met Websocket"},"Websocket is disconnected":{"de-DE":"Websocket ist nicht verbunden","es-VE":"Websocket está desconectado","ko-KR":"웹소켓 연결 안 됨","nl-NL":"Geen connectie met Websocket"},"Wed":{"de-DE":"Mit","es-VE":"Mié","ko-KR":"수","nl-NL":"Wo"},"Weekdays":{"de-DE":"Wochentage","es-VE":"Días de semana","ko-KR":"주일","nl-NL":"Weekdagen"},"Work":{"de-DE":"Werk","es-VE":"Trabajo","ko-KR":"작품","nl-NL":"Werk"},"Your NAS Settings":{},"bits":{"de-DE":"Bits","es-VE":"Bits","ko-KR":"비트","nl-NL":"bits"},"contains":{"de-DE":"enthält","es-VE":"contiene","ko-KR":"내용","nl-NL":"bevat"},"folder.jpg":{"de-DE":"folder.jpg","es-VE":"carpeta.jpg","ko-KR":"folder.jpg","nl-NL":"folder.jpg"},"http://uri.to/stream.mp3":{"de-DE":"http://url.zum/stream.mp3","es-VE":"http://url.to/stream.mp3","ko-KR":"http://주소/stream.mp3","nl-NL":"http://url.naar/stream.mp3"},"kHz":{"de-DE":"kHz","es-VE":"kHz","ko-KR":"kHz","nl-NL":"kHz"},"myMPD CA":{"de-DE":"myMPD Stammzertifikat","es-VE":"myMPD CA","ko-KR":"myMPD 인증서","nl-NL":"myMPD CA"},"myMPD installed as app":{"de-DE":"myMPD wurde als App installiert","es-VE":"myMPD instalado como aplicación","ko-KR":"myMPD가 앱으로 설치됨","nl-NL":"myMPD werd als app geïnstalleerd "},"myMPD is in readonly mode":{"de-DE":"myMPD ist im Readonly Modus","es-VE":"myMPD está en modo solo lectura","ko-KR":"읽기 전용 모드임","nl-NL":"myMPD is in alleen lezen modus"},"myMPD uptime":{"de-DE":"myMPD Uptime","es-VE":"Tiempo de actividad myMPD","ko-KR":"myMPD 가동 시간","nl-NL":"myMPD uptime"},"never":{"de-DE":"noch nie","es-VE":"nunca","ko-KR":"안 함","nl-NL":"nooit"},"newest":{"de-DE":"Neueste Lieder","es-VE":"más reciente","ko-KR":"최신","nl-NL":"Nieuwste nummers"},"on":{"de-DE":"an","es-VE":"on","ko-KR":"켜기","nl-NL":"aan"},"search":{"de-DE":"Suche","es-VE":"buscar","ko-KR":"찾기","nl-NL":"Zoek"},"sticker":{"de-DE":"Sticker","es-VE":"Sticker","ko-KR":"스티커","nl-NL":"Sticker"}};
var keymap={ArrowLeft:{cmd:"clickPrev",options:[],desc:"Previous song",key:"keyboard_arrow_left"},ArrowRight:{cmd:"clickNext",options:[],desc:"Next song",key:"keyboard_arrow_right"}," ":{cmd:"clickPlay",options:[],desc:"Toggle play / pause",key:"space_bar"},s:{cmd:"clickStop",options:[],desc:"Stop playing"},"-":{cmd:"volumeStep",options:["down"],desc:"Volume down"},"+":{cmd:"VolumeStep",options:["up"],desc:"Volume up"},c:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_CLEAR"}],desc:"Clear queue"},u:{cmd:"updateDB",
options:[],desc:"Update database"},r:{cmd:"rescanDB",options:[],desc:"Rescan database"},p:{cmd:"updateSmartPlaylists",options:[],desc:"Update smart playlists",req:"featSmartpls"},a:{cmd:"showAddToPlaylist",options:["stream",""],desc:"Add stream"},t:{cmd:"openModal",options:["modalSettings"],desc:"Open settings"},i:{cmd:"clickTitle",options:[],desc:"Open song details"},l:{cmd:"openDropdown",options:["dropdownLocalPlayer"],desc:"Open local player"},0:{cmd:"appGoto",options:["Playback"],desc:"Goto playback"},
1:{cmd:"appGoto",options:["Queue","Current"],desc:"Goto queue"},2:{cmd:"appGoto",options:["Queue","LastPlayed"],desc:"Goto last played"},3:{cmd:"appGoto",options:["Browse","Database"],desc:"Goto browse database",req:"featTags"},4:{cmd:"appGoto",options:["Browse","Playlists"],desc:"Goto browse playlists",req:"featPlaylists"},5:{cmd:"appGoto",options:["Browse","Filesystem"],desc:"Goto browse filesystem"},6:{cmd:"appGoto",options:["Browse","Covergrid"],desc:"Goto browse covergrid",req:"featTags"},7:{cmd:"appGoto",
options:["Search"],desc:"Goto search"},m:{cmd:"openDropdown",options:["dropdownMainMenu"],desc:"Open main menu"},v:{cmd:"openDropdown",options:["dropdownVolumeMenu"],desc:"Open volume menu"},S:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_SHUFFLE"}],desc:"Shuffle queue"},C:{cmd:"sendAPI",options:[{cmd:"MPD_API_QUEUE_CROP"}],desc:"Crop queue"},"?":{cmd:"openModal",options:["modalAbout"],desc:"Open about"},"/":{cmd:"focusSearch",options:[],desc:"Focus search"},n:{cmd:"focusTable",options:[],desc:"Focus table"},
q:{cmd:"queueSelectedItem",options:[!0],desc:"Append item to queue"},Q:{cmd:"queueSelectedItem",options:[!1],desc:"Replace queue with item"},d:{cmd:"dequeueSelectedItem",options:[],desc:"Remove item from queue"},x:{cmd:"addSelectedItemToPlaylist",options:[],desc:"Append item to playlist"}};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function sendAPI(method, params, callback, onerror) {
    let request = {"jsonrpc": "2.0", "id": 0, "method": method, "params": params};
    let ajaxRequest=new XMLHttpRequest();
    ajaxRequest.open('POST', subdir + '/api', true);
    ajaxRequest.setRequestHeader('Content-type', 'application/json');
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState === 4) {
            if (ajaxRequest.responseText !== '') {
                let obj = JSON.parse(ajaxRequest.responseText);
                if (obj.error) {
                    showNotification(t(obj.error.message, obj.error.data), '', '', 'danger');
                    logError(JSON.stringify(obj.error));
                }
                else if (obj.result && obj.result.message && obj.result.message !== 'ok') {
                    logDebug('Got API response: ' + JSON.stringify(obj.result));
                    showNotification(t(obj.result.message, obj.result.data), '', '', 'success');
                }
                else if (obj.result && obj.result.message && obj.result.message === 'ok') {
                    logDebug('Got API response: ' + JSON.stringify(obj.result));
                }
                else if (obj.result && obj.result.method) {
                    logDebug('Got API response of type: ' + obj.result.method);
                }
                else {
                    logError('Got invalid API response: ' + JSON.stringify(obj));
                    if (onerror !== true) {
                        return;
                    }
                }
                if (callback !== undefined && typeof(callback) === 'function') {
                    if (obj.result !== undefined || onerror === true) {
                        logDebug('Calling ' + callback.name);
                        callback(obj);
                    }
                    else {
                        logDebug('Undefined resultset, skip calling ' + callback.name);
                    }
                }
            }
            else {
                logError('Empty response for request: ' + JSON.stringify(request));
                if (onerror === true) {
                    if (callback !== undefined && typeof(callback) === 'function') {
                        logDebug('Got empty API response calling ' + callback.name);
                        callback('');
                    }
                }
            }
        }
    };
    ajaxRequest.send(JSON.stringify(request));
    logDebug('Send API request: ' + method);
}

function webSocketConnect() {
    if (socket !== null && socket.readyState === WebSocket.OPEN) {
        logInfo("Socket already connected");
        websocketConnected = true;
        return;
    }
    else if (socket !== null && socket.readyState === WebSocket.CONNECTING) {
        logInfo("Socket connection in progress");
        websocketConnected = false;
        return;
    }
    else {
        websocketConnected = false;
    }
    let wsUrl = getWsUrl();
    socket = new WebSocket(wsUrl);
    logInfo('Connecting to ' + wsUrl);

    try {
        socket.onopen = function() {
            logInfo('Websocket is connected');
            websocketConnected = true;
            if (websocketTimer !== null) {
                clearTimeout(websocketTimer);
                websocketTimer = null;
            }
        }

        socket.onmessage = function got_packet(msg) {
            var obj;
            try {
                obj = JSON.parse(msg.data);
                logDebug('Websocket notification: ' + JSON.stringify(obj));
            }
            catch(error) {
                logError('Invalid JSON data received: ' + msg.data);
                return;
            }

            switch (obj.method) {
                case 'welcome':
                    websocketConnected = true;
                    showNotification(t('Connected to myMPD') + ': ' + wsUrl, '', '', 'success');
                    appRoute();
                    sendAPI("MPD_API_PLAYER_STATE", {}, parseState, true);
                    break;
                case 'update_state':
                    obj.result = obj.params;
                    parseState(obj);
                    break;
                case 'mpd_disconnected':
                    if (progressTimer) {
                        clearTimeout(progressTimer);
                    }
                    getSettings(true);
                    break;
                case 'mpd_connected':
                    showNotification(t('Connected to MPD'), '', '', 'success');
                    sendAPI("MPD_API_PLAYER_STATE", {}, parseState);
                    getSettings(true);
                    break;
                case 'update_queue':
                    if (app.current.app === 'Queue') {
                        getQueue();
                    }
                    else if (app.current.app === 'Playback') {
                        getQueueMini(obj.params.songPos, true);
                    }
                    obj.result = obj.params;
                    parseUpdateQueue(obj);
                    break;
                case 'update_options':
                    getSettings();
                    break;
                case 'update_outputs':
                    sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {}, parseOutputs);
                    break;
                case 'update_started':
                    updateDBstarted(false);
                    break;
                case 'update_database':
                    //fall through
                case 'update_finished':
                    updateDBfinished(obj.method);
                    updateDBstats();
                    break;
                case 'update_volume':
                    obj.result = obj.params;
                    parseVolume(obj);
                    break;
                case 'update_stored_playlist':
                    if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
                        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": app.current.page, "filter": app.current.filter}, parsePlaylists);
                    }
                    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
                        sendAPI("MPD_API_PLAYLIST_CONTENT_LIST", {"offset": app.current.page, "filter": app.current.filter, "uri": app.current.search, "cols": settings.colsBrowsePlaylistsDetail}, parsePlaylists);
                    }
                    break;
                case 'update_lastplayed':
                    if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
                        sendAPI("MPD_API_QUEUE_LAST_PLAYED", {"offset": app.current.page, "cols": settings.colsQueueLastPlayed}, parseLastPlayed);
                    }
                    break;
                case 'error':
                    if (document.getElementById('alertMpdState').classList.contains('hide')) {
                        showNotification(t(obj.params.message), '', '', 'danger');
                    }
                    break;
                default:
                    break;
            }
        }

        socket.onclose = function(){
            logError('Websocket is disconnected');
            websocketConnected = false;
            if (appInited === true) {
                toggleUI();
                if (progressTimer) {
                    clearTimeout(progressTimer);
                }
            }
            else {
                showAppInitAlert(t('Websocket connection failed'));
                logError('Websocket connection failed.');
            }
            if (websocketTimer !== null) {
                clearTimeout(websocketTimer);
                websocketTimer = null;
            }
            websocketTimer = setTimeout(function() {
                logInfo('Reconnecting websocket');
                toggleAlert('alertMympdState', true, t('Websocket connection failed, trying to reconnect') + '&nbsp;&nbsp;<div class="spinner-border spinner-border-sm"></div>');
                webSocketConnect();
            }, 3000);
            socket = null;
        }

    } catch(error) {
        logError(error);
    }
}

function getWsUrl() {
    let hostname = window.location.hostname;
    let protocol = window.location.protocol;
    let port = window.location.port;
    
    if (protocol === 'https:') {
        protocol = 'wss://';
    }
    else {
        protocol = 'ws://';
    }

    let wsUrl = protocol + hostname + (port !== '' ? ':' + port : '') + subdir + '/ws/';
    return wsUrl;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

var openCoverId;

function gotoBrowse(x) {
    let tag = x.parentNode.getAttribute('data-tag');
    let name = decodeURI(x.parentNode.getAttribute('data-name'));
    if (tag !== '' && name !== '' && name !== '-' && settings.browsetags.includes(tag)) {
        appGoto('Browse', 'Database', tag, '0/-/-/' + name);
    }
}

function parseFilesystem(obj) {
    let list = app.current.app + (app.current.tab === 'Filesystem' ? app.current.tab : '');
    let table = document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List');
    let tbody = table.getElementsByTagName('tbody')[0];
    let colspan = settings['cols' + list].length;
    colspan--;

    if (obj.error) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t(obj.error.message) + '</td></tr>';
        document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List').classList.remove('opacity05');
        document.getElementById('cardFooterBrowse').innerText = '';
        return;
    }

    let nrItems = obj.result.returnedEntities;
    let tr = tbody.getElementsByTagName('tr');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    for (let i = 0; i < nrItems; i++) {
        let uri = encodeURI(obj.result.data[i].uri);
        let row = document.createElement('tr');
        let tds = '';
        row.setAttribute('data-type', obj.result.data[i].Type);
        row.setAttribute('data-uri', uri);
        row.setAttribute('tabindex', 0);
        if (obj.result.data[i].Type === 'song') {
            row.setAttribute('data-name', obj.result.data[i].Title);
        }
        else {
            row.setAttribute('data-name', obj.result.data[i].name);
        }
        
        switch(obj.result.data[i].Type) {
            case 'dir':
            case 'smartpls':
            case 'plist':
                for (let c = 0; c < settings['cols' + list].length; c++) {
                    tds += '<td data-col="' + settings['cols' + list][c] + '">';
                    if (settings['cols' + list][c] === 'Type') {
                        if (obj.result.data[i].Type === 'dir') {
                            tds += '<span class="material-icons">folder_open</span>';
                        }
                        else {
                            tds += '<span class="material-icons">' + (obj.result.data[i].Type === 'smartpls' ? 'queue_music' : 'list') + '</span>';
                        }
                    }
                    else if (settings['cols' + list][c] === 'Title') {
                        tds += e(obj.result.data[i].name);
                    }
                    tds += '</td>';
                }
                tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
                row.innerHTML = tds;
                break;
            case 'song':
                obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
                for (let c = 0; c < settings['cols' + list].length; c++) {
                    tds += '<td data-col="' + settings['cols' + list][c] + '">';
                    if (settings['cols' + list][c] === 'Type') {
                        tds += '<span class="material-icons">music_note</span>';
                    }
                    else {
                        tds += e(obj.result.data[i][settings['cols' + list][c]]);
                    }
                    tds += '</td>';
                }
                tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
                row.innerHTML = tds;
                break;
        }
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    if (navigate === true) {
        focusTable(0);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
                    
    if (nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    }
    document.getElementById(app.current.app + (app.current.tab === undefined ? '' : app.current.tab) + 'List').classList.remove('opacity05');
    document.getElementById('cardFooterBrowse').innerText = t('Num entries', obj.result.totalEntities);
}


function parseListDBtags(obj) {
    scrollToPosY(0);
    if (app.current.search !== '') {
        document.getElementById('BrowseDatabaseAlbumList').classList.remove('hide');
        document.getElementById('BrowseDatabaseTagList').classList.add('hide');
        document.getElementById('btnBrowseDatabaseByTag').parentNode.classList.add('hide');
        document.getElementById('btnBrowseDatabaseTag').parentNode.classList.remove('hide');
        document.getElementById('BrowseDatabaseAddAllSongs').parentNode.parentNode.classList.remove('hide');
        document.getElementById('BrowseDatabaseColsBtn').parentNode.classList.remove('hide');
        document.getElementById('btnBrowseDatabaseTag').innerHTML = '&laquo; ' + t(app.current.view);
        document.getElementById('BrowseDatabaseAlbumListCaption').innerHTML = '<h2>' + t(obj.result.searchtagtype) + ': ' + e(obj.result.searchstr) + '</h2><hr/>';
        document.getElementById('cardFooterBrowse').innerText = t('Num entries', obj.result.totalEntities);
        let nrItems = obj.result.returnedEntities;
        let cardContainer = document.getElementById('BrowseDatabaseAlbumList');
        let cards = cardContainer.getElementsByClassName('card');
        for (let i = 0; i < nrItems; i++) {
            let id = genId(obj.result.data[i].value);
            let card = document.createElement('div');
            card.classList.add('card', 'ml-4', 'mr-4', 'mb-4', 'w-100');
            card.setAttribute('id', 'card' + id);
            card.setAttribute('data-album', encodeURI(obj.result.data[i].value));
            let html = '<div class="card-header"><span id="albumartist' + id + '"></span> &ndash; ' + e(obj.result.data[i].value) + '</div>' +
                       '<div class="card-body"><div class="row">';
            if (settings.featCoverimage === true && settings.coverimage === true) {
                html += '<div class="col-md-auto"><a class="card-img-left album-cover-loading"></a></div>';
            }
            html += '<div class="col table-responsive-md"><table class="tblAlbumTitles table table-sm table-hover" tabindex="0" id="tbl' + id + '"><thead><tr></tr></thead><tbody class="clickable"></tbody>' +
                    '<tfoot class="bg-light border-bottom"></tfoot></table></div>' + 
                    '</div></div>' +
                    '</div><div class="card-footer"></div>';
            
            card.innerHTML = html;
            if (i < cards.length) {
                cards[i].replaceWith(card); 
            }
            else {
                cardContainer.append(card);
            }
            
            if ('IntersectionObserver' in window) {
                createListTitleObserver(document.getElementById('card' + id));
            }
            else {
                sendAPI("MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", {"album": obj.result.data[i].value, "search": app.current.search, "tag": app.current.view, "cols": settings.colsBrowseDatabase}, parseListTitles);
            }
        }
        let cardsLen = cards.length - 1;
        for (let i = cardsLen; i >= nrItems; i --) {
            cards[i].remove();
        }
        setPagination(obj.result.totalEntities, obj.result.returnedEntities);
        setCols('BrowseDatabase', '.tblAlbumTitles');
        let tbls = document.querySelectorAll('.tblAlbumTitles');
        for (let i = 0; i < tbls.length; i++) {
            dragAndDropTableHeader(tbls[i]);
        }
        document.getElementById('BrowseDatabaseAlbumList').classList.remove('opacity05');        
    }  
    else {
        document.getElementById('BrowseDatabaseAlbumList').classList.add('hide');
        document.getElementById('BrowseDatabaseTagList').classList.remove('hide');
        document.getElementById('btnBrowseDatabaseByTag').parentNode.classList.remove('hide');
        document.getElementById('BrowseDatabaseAddAllSongs').parentNode.parentNode.classList.add('hide');
        document.getElementById('BrowseDatabaseColsBtn').parentNode.classList.add('hide');
        document.getElementById('btnBrowseDatabaseTag').parentNode.classList.add('hide');
        document.getElementById('BrowseDatabaseTagListCaption').innerText = t(app.current.view);
        document.getElementById('cardFooterBrowse').innerText = t('Num entries', obj.result.totalEntities);
        let nrItems = obj.result.returnedEntities;
        let table = document.getElementById(app.current.app + app.current.tab + 'TagList');
        let tbody = table.getElementsByTagName('tbody')[0];
        let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
        let activeRow = 0;
        let tr = tbody.getElementsByTagName('tr');
        for (let i = 0; i < nrItems; i++) {
            let uri = encodeURI(obj.result.data[i].value);
            let row = document.createElement('tr');
            row.setAttribute('data-uri', uri);
            row.setAttribute('tabindex', 0);
            row.innerHTML='<td data-col="Type"><span class="material-icons">album</span></td>' +
                          '<td>' + e(obj.result.data[i].value) + '</td>';
            if (i < tr.length) {
                activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
            }
            else {
                tbody.append(row);
            }
        }
        let trLen = tr.length - 1;
        for (let i = trLen; i >= nrItems; i --) {
            tr[i].remove();
        }
        
        if (navigate === true) {
            focusTable(0);
        }
        
        setPagination(obj.result.totalEntities, obj.result.returnedEntities);

        if (nrItems === 0) {
            tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                              '<td>No entries found.</td></tr>';
        }
        document.getElementById('BrowseDatabaseTagList').classList.remove('opacity05');                              
    }
}

function createListTitleObserver(ele) {
  let options = {
    root: null,
    rootMargin: '0px',
  };

  let observer = new IntersectionObserver(getListTitles, options);
  observer.observe(ele);
}

function getListTitles(changes, observer) {
    changes.forEach(change => {
        if (change.intersectionRatio > 0) {
            observer.unobserve(change.target);
            let album = decodeURI(change.target.getAttribute('data-album'));
            sendAPI("MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", {"album": album, "search": app.current.search, "tag": app.current.view, "cols": settings.colsBrowseDatabase}, parseListTitles);
        }
    });
}

function parseListTitles(obj) {
    let id = genId(obj.result.Album);
    let card = document.getElementById('card' + id)
    let table = card.getElementsByTagName('table')[0];
    let tbody = card.getElementsByTagName('tbody')[0];
    let cardFooter = card.querySelector('.card-footer');
    let cardHeader = card.querySelector('.card-header');
    cardHeader.setAttribute('data-uri', encodeURI(obj.result.data[0].uri.replace(/\/[^/]+$/, '')));
    cardHeader.setAttribute('data-name', obj.result.Album);
    cardHeader.setAttribute('data-type', 'dir');
    cardHeader.addEventListener('click', function(event) {
        showMenu(this, event);
    }, false);
    cardHeader.classList.add('clickable');
    table.addEventListener('keydown', function(event) {
        navigateTable(this, event.key);
    }, false);
    let img = card.getElementsByTagName('a')[0];
    if (img && obj.result.data.length > 0) {
        img.style.backgroundImage = 'url("' + subdir + '/albumart/' + obj.result.data[0].uri + '"), url("' + subdir + '/assets/coverimage-loading.svg")';
        img.setAttribute('data-uri', encodeURI(obj.result.data[0].uri.replace(/\/[^/]+$/, '')));
        img.setAttribute('data-name', obj.result.Album);
        img.setAttribute('data-type', 'dir');
        img.addEventListener('click', function(event) {
            showMenu(this, event);
        }, false);
    }
    
    document.getElementById('albumartist' + id).innerText = obj.result.AlbumArtist;
  
    let titleList = '';
    let nrItems = obj.result.returnedEntities;
    for (let i = 0; i < nrItems; i++) {
        if (obj.result.data[i].Duration) {
            obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        }
        titleList += '<tr tabindex="0" data-type="song" data-name="' + obj.result.data[i].Title + '" data-uri="' + encodeURI(obj.result.data[i].uri) + '">';
        for (let c = 0; c < settings.colsBrowseDatabase.length; c++) {
            titleList += '<td data-col="' + settings.colsBrowseDatabase[c] + '">' + e(obj.result.data[i][settings.colsBrowseDatabase[c]]) + '</td>';
        }
        titleList += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td></tr>';
    }
    tbody.innerHTML = titleList;
    cardFooter.innerHTML = t('Num songs', obj.result.totalEntities) + ' &ndash; ' + beautifyDuration(obj.result.totalTime);

    tbody.parentNode.addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute('data-uri')), event.target.parentNode.getAttribute('data-name'));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);
}

function addAllFromBrowseFilesystem() {
    sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": app.current.search});
    showNotification(t('Added all songs'), '', '', 'success');
}

function addAllFromBrowseDatabasePlist(plist) {
    if (app.current.search.length >= 2) {
        sendAPI("MPD_API_DATABASE_SEARCH", {"plist": plist, "filter": app.current.view, "searchstr": app.current.search, "offset": 0, "cols": settings.colsSearch, "replace": false});
    }
}

function parseBookmarks(obj) {
    let list = '<table class="table table-sm table-dark table-borderless mb-0">';
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        list += '<tr data-id="' + obj.result.data[i].id + '" data-type="' + obj.result.data[i].type + '" ' +
                'data-uri="' + encodeURI(obj.result.data[i].uri) + '">' +
                '<td class="nowrap"><a class="text-light" href="#" data-href="goto">' + e(obj.result.data[i].name) + '</a></td>' +
                '<td><a class="text-light material-icons material-icons-small" href="#" data-href="edit">edit</a></td><td>' +
                '<a class="text-light material-icons material-icons-small" href="#" data-href="delete">delete</a></td></tr>';
    }
    if (obj.result.returnedEntities === 0) {
        list += '<tr><td class="text-light nowrap">' + t('No bookmarks found') + '</td></tr>';
    }
    list += '</table>';
    document.getElementById('BrowseFilesystemBookmarks').innerHTML = list;
}

function showBookmarkSave(id, name, uri, type) {
    document.getElementById('saveBookmarkName').classList.remove('is-invalid');
    document.getElementById('saveBookmarkId').value = id;
    document.getElementById('saveBookmarkName').value = name;
    document.getElementById('saveBookmarkUri').value = uri;
    document.getElementById('saveBookmarkType').value = type;
    modalSaveBookmark.show();
}

//eslint-disable-next-line no-unused-vars
function saveBookmark() {
    let id = parseInt(document.getElementById('saveBookmarkId').value);
    let name = document.getElementById('saveBookmarkName').value;
    let uri = document.getElementById('saveBookmarkUri').value;
    let type = document.getElementById('saveBookmarkType').value;
    if (name !== '') {
        sendAPI("MYMPD_API_BOOKMARK_SAVE", {"id": id, "name": name, "uri": uri, "type": type});
        modalSaveBookmark.hide();
    }
    else {
        document.getElementById('saveBookmarkName').classList.add('is-invalid');
    }
}

function parseCovergrid(obj) {
    let nrItems = obj.result.returnedEntities;
    let cardContainer = document.getElementById('BrowseCovergridList');
    let cols = cardContainer.getElementsByClassName('col');
    if (cols.length === 0) {
        cardContainer.innerHTML = '';
    }
    for (let i = 0; i < nrItems; i++) {
        let col = document.createElement('div');
        col.classList.add('col', 'px-0', 'flex-grow-0');
        if (obj.result.data[i].AlbumArtist === '') {
            obj.result.data[i].AlbumArtist = t('Unknown artist');
        }
        if (obj.result.data[i].Album === '') {
            obj.result.data[i].Album = t('Unknown album');
        }
        let id = genId('covergrid' + obj.result.data[i].Album + obj.result.data[i].AlbumArtist);
        let html = '<div class="card card-grid clickable" data-uri="' + encodeURI(obj.result.data[i].FirstSongUri) + '" ' + 
                       'data-album="' + encodeURI(obj.result.data[i].Album) + '" ' +
                       'data-albumartist="' + encodeURI(obj.result.data[i].AlbumArtist) + '" tabindex="0">' +
                   '<div class="card-header covergrid-header hide unvisible"></div>' +
                   '<div class="card-body album-cover-loading album-cover-grid bg-white" id="' + id + '"></div>' +
                   '<div class="card-footer card-footer-grid p-2" title="' + obj.result.data[i].AlbumArtist + ': ' + obj.result.data[i].Album + '">' +
                   obj.result.data[i].Album + '<br/><small>' + obj.result.data[i].AlbumArtist + '</small>' +
                   '</div></div>';
        col.innerHTML = html;
        let replaced = false;
        if (i < cols.length) {
            if (cols[i].firstChild.getAttribute('data-uri') !== col.firstChild.getAttribute('data-uri')) {
                cols[i].replaceWith(col);
                replaced = true;
            }
        }
        else {
            cardContainer.append(col);
            replaced = true;
        }
        if ('IntersectionObserver' in window && replaced === true) {
            let options = {
                root: null,
                rootMargin: '0px',
            };
            let observer = new IntersectionObserver(setGridImage, options);
            observer.observe(col);
        }
        else if (replaced === true) {
            col.firstChild.firstChild.style.backgroundImage = 'url("' + subdir + '/albumart/' + obj.result.data[i].uri + '")';
        }
        if (replaced === true) {
            col.firstChild.addEventListener('click', function(event) {
                if (event.target.classList.contains('card-body')) {
                    getCovergridTitleList(id);
                }
                else if (event.target.classList.contains('card-footer') ||
                    event.target.classList.contains('card-header')) {
                    showMenu(event.target, event);
                }
            }, false);
            col.firstChild.addEventListener('transitionend', function (event) {
                if (event.target.getElementsByClassName('card-body')[0].style.backgroundImage !== '' ||
                    openCoverId === undefined) {
                    return;
                }
                event.target.getElementsByTagName('table')[0].classList.remove('unvisible');
                event.target.getElementsByClassName('card-header')[0].classList.remove('unvisible');
            }, false);
            col.firstChild.addEventListener('keydown', function(event) {
                if (event.key === 'Escape') {
                    let cardBody = event.target.getElementsByClassName('card-body')[0];
                    let uri = decodeURI(cardBody.parentNode.getAttribute('data-uri'));
                    showGridImage(cardBody, uri);
                    openCoverId = undefined;
                }
                else if (event.key === 'Enter') {
                    getCovergridTitleList(id);
                    event.stopPropagation();
                    event.preventDefault();
                }
                else if (event.key === ' ') {
                    showMenu(event.target.getElementsByClassName('card-footer')[0], event);
                    event.stopPropagation();
                    event.preventDefault();
                }
            }, false);
        }
    }
    let colsLen = cols.length - 1;
    for (let i = colsLen; i >= nrItems; i --) {
        cols[i].remove();
    }
    
    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
                    
    if (nrItems === 0) {
        cardContainer.innerHTML = t('Empty list');
    }
    document.getElementById('BrowseCovergridList').classList.remove('opacity05');
    document.getElementById('cardFooterBrowse').innerText = gtPage('Num entries', obj.result.returnedEntities, obj.result.totalEntities);

    calcBoxHeight();
    closeCover();
    parseCovergridAlbum(obj);
}

function getCovergridTitleList(id) {
    closeCover(id);
    let cardBody = document.getElementById(id);
    let card = cardBody.parentNode;
    card.classList.add('opacity05');
    let s = document.getElementById('BrowseCovergridList').childNodes[1];
    let width;
    if (s) {
        let p = parseInt(window.getComputedStyle(document.getElementById('cardBrowseCovergrid'), null).getPropertyValue('padding-left'));
        width = s.offsetLeft + settings.covergridSize - p;
    }
    else {
        width = settings.covergridSize * 2 + 20;
    }
    cardBody.style.width = width + 'px';
    cardBody.parentNode.style.width = width + 'px';
    sendAPI("MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", {"album": decodeURI(card.getAttribute('data-album')),
        "search": decodeURI(card.getAttribute('data-albumartist')),
        "tag": "AlbumArtist", "cols": settings.colsBrowseDatabase}, parseCovergridTitleList);
}

function parseCovergridTitleList(obj) {
    let id = genId('covergrid' + obj.result.Album + obj.result.AlbumArtist);
    let cardBody = document.getElementById(id);
    
    let titleList = '<table class="table table-hover table-sm unvisible" tabindex="0"><thead>';
    for (let i = 0; i < settings.colsBrowseDatabase.length; i++) {
        let h = settings.colsBrowseDatabase[i];
        if (h === 'Track') {
            h = '#';
        }
        titleList += '<th class="border-top-0">' + t(h) + '</th>';
    }
    titleList += '<th class="border-top-0"></th></thead><tbody class="clickable">';
    let nrItems = obj.result.returnedEntities;
    for (let i = 0; i < nrItems; i++) {
        if (obj.result.data[i].Duration) {
            obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        }
        titleList += '<tr tabindex="0" data-type="song" data-name="' + obj.result.data[i].Title + '" data-uri="' + encodeURI(obj.result.data[i].uri) + '">';
        for (let c = 0; c < settings.colsBrowseDatabase.length; c++) {
            titleList += '<td data-col="' + settings.colsBrowseDatabase[c] + '">' + e(obj.result.data[i][settings.colsBrowseDatabase[c]]) + '</td>';
        }
        titleList += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td></tr>';
    }
    titleList += '</tbody></table>';

    let uri = decodeURI(cardBody.parentNode.getAttribute('data-uri'));
    let cardFooter = cardBody.parentNode.getElementsByClassName('card-footer')[0];
    let cardHeader = cardBody.parentNode.getElementsByClassName('card-header')[0];
    cardHeader.innerHTML = '<button class="close" type="button">&times;</button><img class="covergrid-header" src="' + subdir + '/albumart/' + uri + '"/>' +
        cardFooter.innerHTML + '';
    cardHeader.classList.remove('hide');
    cardFooter.classList.add('hide');
    
    cardBody.style.backgroundImage = '';
    cardBody.classList.remove('album-cover-loading');
    cardBody.style.height = 'auto';
    
    cardBody.innerHTML = titleList;
    cardBody.parentNode.classList.remove('opacity05');
    cardHeader.getElementsByClassName('close')[0].addEventListener('click', function(event) {
        event.stopPropagation();
        showGridImage(cardBody, uri);
        openCoverId = undefined;
    }, false);

    let table = cardBody.getElementsByTagName('table')[0];
    table.addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute('data-uri')), event.target.parentNode.getAttribute('data-name'));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);
    table.addEventListener('keydown', function(event) {
        navigateTable(this, event.key);
        if (event.key === 'Escape') {
            event.target.parentNode.parentNode.parentNode.parentNode.focus();
        }
    }, false);

    //fallback if transitionEnd is not fired
    setTimeout(function() {
        cardBody.getElementsByTagName('table')[0].classList.remove('unvisible');
        cardBody.parentNode.getElementsByClassName('card-header')[0].classList.remove('unvisible');
        scrollFocusIntoView();
    }, 500);
}

function showGridImage(cardBody, uri) {
    cardBody.innerHTML = '';
    cardBody.style.backgroundImage = 'url("' + subdir + '/albumart/' + uri + '")';
    cardBody.style.width =  'var(--mympd-covergridsize, 200px)';
    cardBody.style.height =  'var(--mympd-covergridsize, 200px)';
    cardBody.parentNode.style.width =  'var(--mympd-covergridsize, 200px)';
    cardBody.parentNode.getElementsByClassName('card-footer')[0].classList.remove('hide');
    cardBody.parentNode.getElementsByClassName('card-header')[0].classList.add('hide', 'unvisible');
}

function setGridImage(changes, observer) {
    changes.forEach(change => {
        if (change.intersectionRatio > 0) {
            observer.unobserve(change.target);
            let uri = decodeURI(change.target.firstChild.getAttribute('data-uri'));
            change.target.firstChild.getElementsByClassName('card-body')[0].style.backgroundImage = 'url("' + subdir + '/albumart/' + uri + '")';
        }
    });
}

function closeCover(id = undefined) {
    if (openCoverId !== undefined) {
        let cardBody = document.getElementById(openCoverId);
        let uri = decodeURI(cardBody.parentNode.getAttribute('data-uri'));
        showGridImage(cardBody, uri);
    }
    openCoverId = id;
}

function checkForUpdates() {
    sendAPI("MYMPD_API_CHECK_FOR_UPDATES", {}, parseCheck);

    btnWaiting(document.getElementById('btnCheckForUpdates'), true);
}

function parseCheck(obj) {
    document.getElementById('currentVersion').innerText = obj.result.currentVersion;
    document.getElementById('latestVersion').innerText = obj.result.latestVersion;

    if (obj.result.latestVersion !== '') {
        if (obj.result.updatesAvailable === true) {
            document.getElementById('lblInstallUpdates').innerText = 'New version available';
            document.getElementById('btnInstallUpdates').classList.remove('hide');
        }
        else {
            document.getElementById('lblInstallUpdates').innerText = 'System is up to date';
            document.getElementById('btnInstallUpdates').classList.add('hide');
        }
        document.getElementById('updateMsg').innerText = '';
    }
    else {
        document.getElementById('lblInstallUpdates').innerText = '';
        document.getElementById('btnInstallUpdates').classList.add('hide');
        document.getElementById('updateMsg').innerText = 'Cannot get latest version, please try again later';
    }

    btnWaiting(document.getElementById('btnCheckForUpdates'), false);
}

function installUpdates() {
    sendAPI("MYMPD_API_INSTALL_UPDATES", {}, parseInstall);

    document.getElementById('updateMsg').innerText = 'System will automatically reboot after installation';

    btnWaiting(document.getElementById('btnInstallUpdates'), true);
}

function parseInstall(obj) {
    if (obj.result.pacman === false) {
        document.getElementById('updateMsg').innerText = 'Update error, please try again later';
    }
    else if (obj.result.reboot === false) {
        document.getElementById('updateMsg').innerText = 'Reboot error, please reboot manually';
    }
    else {
        document.getElementById('updateMsg').innerText = '';
    }

    btnWaiting(document.getElementById('btnInstallUpdates'), false);
}

function parseCollybiaSettings() {
    document.getElementById('selectDac').value = settings.dac;
    document.getElementById('selectMixerType').value = settings.mixerType;
    toggleBtnChk('btnDop', settings.dop);

    document.getElementById('selectNsType').value = settings.nsType;
    document.getElementById('inputNsServer').value = settings.nsServer;
    document.getElementById('inputNsShare').value = settings.nsShare;
    document.getElementById('selectSambaVersion').value = settings.sambaVersion;
    document.getElementById('inputNsUsername').value = settings.nsUsername;
    document.getElementById('inputNsPassword').value = settings.nsPassword;

    if (settings.nsType === 0) {
        document.getElementById('nsServerShare').classList.add('hide');
        document.getElementById('sambaVersion').classList.add('hide');
        document.getElementById('nsCredentials').classList.add('hide');
        /* document.getElementById('inputNsServer').setAttribute('disabled', 'disabled');
        document.getElementById('inputNsShare').setAttribute('disabled', 'disabled');
        document.getElementById('inputNsUsername').setAttribute('disabled', 'disabled');
        document.getElementById('inputNsPassword').setAttribute('disabled', 'disabled'); */
    }
    else if (settings.nsType === 2) {
        document.getElementById('nsServerShare').classList.remove('hide');
        document.getElementById('sambaVersion').classList.remove('hide');
        document.getElementById('nsCredentials').classList.remove('hide');
    }
    else { // 1 or 3
        document.getElementById('nsServerShare').classList.remove('hide');
        if (settings.nsType === 1) {
            document.getElementById('sambaVersion').classList.remove('hide');
        }
        else {
            document.getElementById('sambaVersion').classList.add('hide');
        }
        document.getElementById('nsCredentials').classList.add('hide');
    }

    toggleBtnChk('btnAirplay', settings.airplay);
    toggleBtnChk('btnRoon', settings.roon);
    toggleBtnChk('btnSpotify', settings.spotify);
    toggleBtnChkCollapse('btnTidalEnabled', 'collapseTidal', settings.tidalEnabled);
    document.getElementById('inputTidalUsername').value = settings.tidalUsername;
    document.getElementById('inputTidalPassword').value = settings.tidalPassword;
    document.getElementById('selectTidalAudioquality').value = settings.tidalAudioquality;
}

function saveCollybiaSettings() {
    let formOK = true;

    let selectNsType = document.getElementById('selectNsType');
    let selectNsTypeValue = selectNsType.options[selectNsType.selectedIndex].value;
    let inputNsServer = document.getElementById('inputNsServer');
    let inputNsShare = document.getElementById('inputNsShare');
    let inputNsUsername = document.getElementById('inputNsUsername');
    let inputNsPassword = document.getElementById('inputNsPassword');

    if (selectNsTypeValue !== '0') {
        /* if (inputNsServer.value.indexOf('/') !== 0) {
            if (!validateHost(inputNsServer)) {
                formOK = false;
            }
        } */
        if (!validateIPAddress(inputNsServer)) {
            formOK = false;
        }
        if (!validatePath(inputNsShare)) {
            formOK = false;
        }
    }
    if (selectNsTypeValue === '2') {
        if (!validateNotBlank(inputNsUsername) || !validateNotBlank(inputNsPassword)) {
            formOK = false;
        }
    }

    let inputTidalUsername = document.getElementById('inputTidalUsername');
    let inputTidalPassword = document.getElementById('inputTidalPassword');
    if (document.getElementById('btnTidalEnabled').classList.contains('active')) {
        if (!validateNotBlank(inputTidalUsername) || !validateNotBlank(inputTidalPassword)) {
            formOK = false;
        }
    }

    if (formOK === true) {
        let selectDac = document.getElementById('selectDac');
        let selectMixerType = document.getElementById('selectMixerType');
        let selectSambaVersion = document.getElementById('selectSambaVersion');
        let selectTidalAudioquality = document.getElementById('selectTidalAudioquality');
        sendAPI("MYMPD_API_SETTINGS_SET", {
            "dac": selectDac.options[selectDac.selectedIndex].value,
            "mixerType": selectMixerType.options[selectMixerType.selectedIndex].value,
            "dop": (document.getElementById('btnDop').classList.contains('active') ? true : false),
            "nsType": parseInt(selectNsTypeValue),
            "nsServer": inputNsServer.value,
            "nsShare": inputNsShare.value,
            "sambaVersion": selectSambaVersion.options[selectSambaVersion.selectedIndex].value,
            "nsUsername": inputNsUsername.value,
            "nsPassword": inputNsPassword.value,
            "airplay": (document.getElementById('btnAirplay').classList.contains('active') ? true : false),
            "roon": (document.getElementById('btnRoon').classList.contains('active') ? true : false),
            "spotify": (document.getElementById('btnSpotify').classList.contains('active') ? true : false),
            "tidalEnabled": (document.getElementById('btnTidalEnabled').classList.contains('active') ? true : false),
            "tidalUsername": inputTidalUsername.value,
            "tidalPassword": inputTidalPassword.value,
            "tidalAudioquality": selectTidalAudioquality.options[selectTidalAudioquality.selectedIndex].value
        }, getSettings);
        modalCollybia.hide();
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
var keymap = {
    "ArrowLeft": {"cmd": "clickPrev", "options": [], "desc": "Previous song", "key": "keyboard_arrow_left"},
    "ArrowRight": {"cmd": "clickNext", "options": [], "desc": "Next song", "key": "keyboard_arrow_right"},
    " ": {"cmd": "clickPlay", "options": [], "desc": "Toggle play / pause", "key": "space_bar"},
    "s": {"cmd": "clickStop", "options": [], "desc": "Stop playing"},
    "-": {"cmd": "volumeStep", "options": ["down"], "desc": "Volume down"},
    "+": {"cmd": "VolumeStep", "options": ["up"], "desc": "Volume up"},
    "c": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CLEAR"}], "desc": "Clear queue"},
    "u": {"cmd": "updateDB", "options": [], "desc": "Update database"},
    "r": {"cmd": "rescanDB", "options": [], "desc": "Rescan database"},
    "p": {"cmd": "updateSmartPlaylists", "options": [], "desc": "Update smart playlists", "req": "featSmartpls"},
    "a": {"cmd": "showAddToPlaylist", "options": ["stream", ""], "desc": "Add stream"},
    "t": {"cmd": "openModal", "options": ["modalSettings"], "desc": "Open settings"},
    "i": {"cmd": "clickTitle", "options": [], "desc": "Open song details"},
    "l": {"cmd": "openDropdown", "options": ["dropdownLocalPlayer"], "desc": "Open local player"},
    "0": {"cmd": "appGoto", "options": ["Playback"], "desc": "Goto playback"},
    "1": {"cmd": "appGoto", "options": ["Queue", "Current"], "desc": "Goto queue"},
    "2": {"cmd": "appGoto", "options": ["Queue", "LastPlayed"], "desc": "Goto last played"},
    "3": {"cmd": "appGoto", "options": ["Browse", "Database"], "desc": "Goto browse database", "req": "featTags"},
    "4": {"cmd": "appGoto", "options": ["Browse", "Playlists"], "desc": "Goto browse playlists", "req": "featPlaylists"},
    "5": {"cmd": "appGoto", "options": ["Browse", "Filesystem"], "desc": "Goto browse filesystem"},
    "6": {"cmd": "appGoto", "options": ["Browse", "Covergrid"], "desc": "Goto browse covergrid", "req": "featTags"},
    "7": {"cmd": "appGoto", "options": ["Search"], "desc": "Goto search"},
    "m": {"cmd": "openDropdown", "options": ["dropdownMainMenu"], "desc": "Open main menu"},
    "v": {"cmd": "openDropdown", "options": ["dropdownVolumeMenu"], "desc": "Open volume menu"},
    "S": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_SHUFFLE"}], "desc": "Shuffle queue"},
    "C": {"cmd": "sendAPI", "options": [{"cmd": "MPD_API_QUEUE_CROP"}], "desc": "Crop queue"},
    "?": {"cmd": "openModal", "options": ["modalAbout"], "desc": "Open about"},
    "/": {"cmd": "focusSearch", "options": [], "desc": "Focus search"},
    "n": {"cmd": "focusTable", "options": [], "desc": "Focus table"},
    "q": {"cmd": "queueSelectedItem", "options": [true], "desc": "Append item to queue"},
    "Q": {"cmd": "queueSelectedItem", "options": [false], "desc": "Replace queue with item"},
    "d": {"cmd": "dequeueSelectedItem", "options": [], "desc": "Remove item from queue"},
    "x": {"cmd": "addSelectedItemToPlaylist", "options": [], "desc": "Append item to playlist"}
};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function e(x) {
    if (isNaN(x)) {
        return x.replace(/([<>"])/g, function(m0, m1) {
            if (m1 === '<') return '&lt;';
            else if (m1 === '>') return '&gt;';
            else if (m1 === '"') return '&quot;';
        });
    }
    else {
        return x;
    }
}

function t(phrase, number, data) {
    let result = undefined;
    if (isNaN(number)) {
        data = number;
    }

    if (phrases[phrase]) {
        result = phrases[phrase][locale];
        if (result === undefined) {
            if (locale !== 'en-US') {
                logWarn('Phrase "' + phrase + '" for locale ' + locale + ' not found');
            }
            result = phrases[phrase]['en-US'];
        }
    }
    if (result === undefined) {
        result = phrase;
    }

    if (isNaN(number) === false) {
        let p = result.split(' |||| ');
        if (p.length > 1) {
            result = p[smartCount(number)];
        }
        result = result.replace('%{smart_count}', number);
    }
    
    if (data !== null) {
        result = result.replace(/%\{(\w+)\}/g, function(m0, m1) {
            return data[m1];
        });
    }
    
    return e(result);
}

function smartCount(number) {
    if (number === 0) { return 1; }
    else if (number === 1) { return 0; }
    else { return 1; }
}

function localeDate(secs) {
    let d;
    if (secs === undefined) {
       d  = new Date();
    }
    else {
        d = new Date(secs * 1000);
    }
    return d.toLocaleString(locale);
}

function beautifyDuration(x) {
    let days = Math.floor(x / 86400);
    let hours = Math.floor(x / 3600) - days * 24;
    let minutes = Math.floor(x / 60) - hours * 60 - days * 1440;
    let seconds = x - days * 86400 - hours * 3600 - minutes * 60;

    return (days > 0 ? days + '\u2009'+ t('Days') + ' ' : '') +
        (hours > 0 ? hours + '\u2009' + t('Hours') + ' ' + 
        (minutes < 10 ? '0' : '') : '') + minutes + '\u2009' + t('Minutes') + ' ' + 
        (seconds < 10 ? '0' : '') + seconds + '\u2009' + t('Seconds');
}

function beautifySongDuration(x) {
    let hours = Math.floor(x / 3600);
    let minutes = Math.floor(x / 60) - hours * 60;
    let seconds = x - hours * 3600 - minutes * 60;

    return (hours > 0 ? hours + ':' + (minutes < 10 ? '0' : '') : '') + 
        minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
}

function gtPage(phrase, returnedEntities, totalEntities) {
    if (totalEntities > -1) {
        return t(phrase, totalEntities);
    }
    else if (returnedEntities + app.current.page < settings.maxElementsPerPage) {
        return t(phrase, returnedEntities);
    }
    else {
        return '> ' + t(phrase, settings.maxElementsPerPage);
    }
}

function i18nHtml(root) {
    let attributes = [['data-phrase', 'innerText'], ['data-title-phrase', 'title'], ['data-placeholder-phrase', 'placeholder']];
    for (let i = 0; i < attributes.length; i++) {
        let els = root.querySelectorAll('[' + attributes[i][0] + ']');
        let elsLen = els.length;
        for (let j = 0; j < elsLen; j++) {
            els[j][attributes[i][1]] = t(els[j].getAttribute(attributes[i][0]));
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function logError(line) {
    logLog(0, 'ERROR: ' + line);
}

function logWarn(line) {
    logLog(1, 'WARN: ' + line);
}

function logInfo(line) {
    logLog(2, 'INFO: ' + line);
}

function logVerbose(line) {
    logLog(3, 'VERBOSE: ' + line);
}

function logDebug(line) {
    logLog(4, 'DEBUG: ' + line);
}

function logLog(loglevel, line) {
    if (settings.loglevel >= loglevel) {
        if (loglevel === 0) {
            console.error(line);
        }
        else if (loglevel === 1) {
            console.warn(line);
        }
        else if (loglevel === 4) {
            console.debug(line);
        }
        else {
            console.log(line);
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

async function localplayerPlay() {
    let localPlayer = document.getElementById('localPlayer');
    if (localPlayer.paused) {
        try {
            await localPlayer.play();
        } 
        catch(err) {
            showNotification(t('Local playback'), t('Can not start playing'), '', 'danger');
        }
    }
}

//eslint-disable-next-line no-unused-vars
function addStream() {
    let streamUriEl = document.getElementById('streamUrl');
    if (validateStream(streamUriEl) === true) {
        sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": streamUriEl.value});
        modalAddToPlaylist.hide();
        showNotification(t('Added stream %{streamUri} to queue', {"streamUri": streamUriEl.value}), '', '', 'success');
    }
}

function seekRelativeForward() {
    seekRelative(5);
}

function seekRelativeBackward() {
    seekRelative(-5);
}

function seekRelative(offset) {
    sendAPI("MPD_API_SEEK_CURRENT", {"seek": offset, "relative": true});
}

//eslint-disable-next-line no-unused-vars
function clickPlay() {
    if (playstate !== 'play') {
        sendAPI("MPD_API_PLAYER_PLAY", {});
    }
    else {
        sendAPI("MPD_API_PLAYER_PAUSE", {});
    }
}

//eslint-disable-next-line no-unused-vars
function clickStop() {
    sendAPI("MPD_API_PLAYER_STOP", {});
}

//eslint-disable-next-line no-unused-vars
function clickPrev() {
    sendAPI("MPD_API_PLAYER_PREV", {});
}

//eslint-disable-next-line no-unused-vars
function clickNext() {
    sendAPI("MPD_API_PLAYER_NEXT", {});
}

//eslint-disable-next-line no-unused-vars
function execSyscmd(cmd) {
    sendAPI("MYMPD_API_SYSCMD", {"cmd": cmd});
}

//eslint-disable-next-line no-unused-vars
function clearCovercache() {
    sendAPI("MYMPD_API_COVERCACHE_CLEAR", {});
}

//eslint-disable-next-line no-unused-vars
function cropCovercache() {
    sendAPI("MYMPD_API_COVERCACHE_CROP", {});
}

//eslint-disable-next-line no-unused-vars
function updateDB(uri, showModal) {
    sendAPI("MPD_API_DATABASE_UPDATE", {"uri": uri});
    updateDBstarted(showModal);
}

//eslint-disable-next-line no-unused-vars
function rescanDB(uri, showModal) {
    sendAPI("MPD_API_DATABASE_RESCAN", {"uri": uri});
    updateDBstarted(showModal);
}

function updateDBstarted(showModal) {
    if (showModal === true) {
        document.getElementById('updateDBfinished').innerText = '';
        document.getElementById('updateDBfooter').classList.add('hide');
        let updateDBprogress = document.getElementById('updateDBprogress');
        updateDBprogress.style.width = '20px';
        updateDBprogress.style.marginLeft = '-20px';
        modalUpdateDB.show();
        updateDBprogress.classList.add('updateDBprogressAnimate');
    }

    showNotification(t('Database update started'), '', '', 'success');
}

function updateDBfinished(idleEvent) {
    if (document.getElementById('modalUpdateDB').classList.contains('show')) {
        _updateDBfinished(idleEvent);
    }
    else {
        //on small databases the modal opens after the finish event
        setTimeout(function() {
            _updateDBfinished(idleEvent);
        }, 100);
    }
}

function _updateDBfinished(idleEvent) {
    //spinner in mounts modal
    let el = document.getElementById('spinnerUpdateProgress');
    if (el) {
        let parent = el.parentNode;
        el.remove();
        for (let i = 0; i < parent.children.length; i++) {
            parent.children[i].classList.remove('hide');
        }
    }

    //update database modal
    if (document.getElementById('modalUpdateDB').classList.contains('show')) {
        if (idleEvent === 'update_database') {
            document.getElementById('updateDBfinished').innerText = t('Database successfully updated');
        }
        else if (idleEvent === 'update_finished') {
            document.getElementById('updateDBfinished').innerText = t('Database update finished');
        }
        let updateDBprogress = document.getElementById('updateDBprogress');
        updateDBprogress.classList.remove('updateDBprogressAnimate');
        updateDBprogress.style.width = '100%';
        updateDBprogress.style.marginLeft = '0px';
        document.getElementById('updateDBfooter').classList.remove('hide');
    }

    //general notification
    if (idleEvent === 'update_database') {
        showNotification(t('Database successfully updated'), '', '', 'success');
    }
    else if (idleEvent === 'update_finished') {
        showNotification(t('Database update finished'), '', '', 'success');
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function unmountMount(mountPoint) {
    sendAPI("MPD_API_MOUNT_UNMOUNT", {"mountPoint": mountPoint}, showListMounts);
}

//eslint-disable-next-line no-unused-vars
function mountMount() {
    let formOK = true;
    document.getElementById('errorMount').classList.add('hide');
    
    if (formOK === true) {
        sendAPI("MPD_API_MOUNT_MOUNT", {
            "mountUrl": getSelectValue('selectMountUrlhandler') + document.getElementById('inputMountUrl').value,
            "mountPoint": document.getElementById('inputMountPoint').value,
            }, showListMounts, true);
    }
}

//eslint-disable-next-line no-unused-vars
function updateMount(el, uri) {
    let parent = el.parentNode;
    for (let i = 0; i < parent.children.length; i++) {
        parent.children[i].classList.add('hide');
    }
    let spinner = document.createElement('div');
    spinner.setAttribute('id', 'spinnerUpdateProgress');
    spinner.classList.add('spinner-border', 'spinner-border-sm');
    el.parentNode.insertBefore(spinner, el);
    updateDB(uri, false);    
}

//eslint-disable-next-line no-unused-vars
function showEditMount(uri, storage) {
    document.getElementById('listMounts').classList.remove('active');
    document.getElementById('editMount').classList.add('active');
    document.getElementById('listMountsFooter').classList.add('hide');
    document.getElementById('editMountFooter').classList.remove('hide');
    document.getElementById('errorMount').classList.add('hide');

    let c = uri.match(/^(\w+:\/\/)(.+)$/);
    if (c !== null && c.length > 2) {
        document.getElementById('selectMountUrlhandler').value = c[1];
        document.getElementById('inputMountUrl').value = c[2];
        document.getElementById('inputMountPoint').value = storage;
    }
    else {
        document.getElementById('inputMountUrl').value = '';
        document.getElementById('inputMountPoint').value = '';
    }
    document.getElementById('inputMountUrl').focus();
    document.getElementById('inputMountUrl').classList.remove('is-invalid');
    document.getElementById('inputMountPoint').classList.remove('is-invalid');
}

function showListMounts(obj) {
    if (obj && obj.error && obj.error.message) {
        let emEl = document.getElementById('errorMount');
        emEl.innerText = obj.error.message;
        emEl.classList.remove('hide');
        return;
    }
    document.getElementById('listMounts').classList.add('active');
    document.getElementById('editMount').classList.remove('active');
    document.getElementById('listMountsFooter').classList.remove('hide');
    document.getElementById('editMountFooter').classList.add('hide');
    sendAPI("MPD_API_MOUNT_LIST", {}, parseListMounts);
}

function parseListMounts(obj) {
    let tbody = document.getElementById('listMounts').getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    
    let activeRow = 0;
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        let row = document.createElement('tr');
        row.setAttribute('data-url', encodeURI(obj.result.data[i].mountUrl));
        row.setAttribute('data-point', encodeURI(obj.result.data[i].mountPoint));
        if (obj.result.data[i].mountPoint === '') {
            row.classList.add('not-clickable');
        }
        let tds = '<td>' + (obj.result.data[i].mountPoint === '' ? '<span class="material-icons">home</span>' : e(obj.result.data[i].mountPoint)) + '</td>' +
                  '<td>' + e(obj.result.data[i].mountUrl) + '</td>';
        if (obj.result.data[i].mountPoint !== '') {
            tds += '<td data-col="Action">' + 
                   '<a href="#" title="' + t('Unmount') + '" data-action="unmount" class="material-icons color-darkgrey">delete</a>' +
                   '<a href="#" title="' + t('Update') + '" data-action="update"class="material-icons color-darkgrey">refresh</a>' +
                   '</td>';
        }
        else {
            tds += '<td>&nbsp;</td>';
        }
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= obj.result.returnedEntities; i --) {
        tr[i].remove();
    }

    if (obj.result.returnedEntities === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="4">' + t('Empty list') + '</td></tr>';
    }     
}

function parseNeighbors(obj) {
    let list = '';
    if (obj.error) {
        list = '<div class="list-group-item"><span class="material-icons">error_outline</span> ' + t(obj.error.message) + '</div>';
    }
    else {
        for (let i = 0; i < obj.result.returnedEntities; i++) {
            list += '<a href="#" class="list-group-item list-group-item-action" data-value="' + obj.result.data[i].uri + '">' + 
                    obj.result.data[i].uri + '<br/><small>' + obj.result.data[i].displayName + '</small></a>';
        }    
    }
    document.getElementById('dropdownNeighbors').children[0].innerHTML = list;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

/* Disable eslint warnings */
/* global Modal, Dropdown, Collapse, Popover, Carousel, phrases, locales */

var socket = null;
var lastSong = '';
var lastSongObj = {};
var lastState;
var currentSong = {};
var playstate = '';
var settingsLock = false;
var settingsParsed = false;
var settingsNew = {};
var settings = {};
settings.loglevel = 2;
var alertTimeout = null;
var progressTimer = null;
var deferredPrompt;
var dragEl;
var playlistEl;
var websocketConnected = false;
var websocketTimer = null;
var appInited = false;
var subdir = '';
var uiEnabled = true;
var locale = navigator.language || navigator.userLanguage;

var ligatureMore = 'menu';

var app = {};
app.apps = {
    "Playback": { "state": "0/AlbumArtist/AlbumArtist/", "scrollPos": 0 },
             "Queue":	   {
                  "active": "Current",
                  "tabs": { "Current": { "state": "0/any/-/", "scrollPos": 0 },
                            "LastPlayed": { "state": "0/any/-/", "scrollPos": 0 }
                          }
                  },
             "Browse":     { 
                  "active": "Covergrid", 
                  "tabs":  { "Filesystem": { "state": "0/-/-/", "scrollPos": 0 },
                             "Playlists":  { 
                                    "active": "All",
                                    "views": { "All":    { "state": "0/-/-/", "scrollPos": 0 },
                                               "Detail": { "state": "0/-/-/", "scrollPos": 0 }
                                    }
                             },
                             "Database":   { 
                                    "active": "AlbumArtist",
                                    "views": { 
                                     }
                             },
                             "Covergrid":  { "state": "0/AlbumArtist/AlbumArtist/", "scrollPos": 0 }
                  }
             },
             "Search": { "state": "0/any/-/", "scrollPos": 0 }
           };

app.current = { "app": "Playback", "tab": undefined, "view": undefined, "page": 0, "filter": "AlbumArtist", "search": "", "sort": "AlbumArtist", "scrollPos": 0 };
app.last = { "app": undefined, "tab": undefined, "view": undefined, "filter": "", "search": "", "sort": "", "scrollPos": 0 };

var domCache = {};
domCache.navbarBottomBtns = document.getElementById('navbar-bottom').getElementsByTagName('div');
domCache.navbarBottomBtnsLen = domCache.navbarBottomBtns.length;
domCache.cardHeaderBrowse = document.getElementById('cardHeaderBrowse').getElementsByTagName('a');
domCache.cardHeaderBrowseLen = domCache.cardHeaderBrowse.length;
domCache.cardHeaderQueue = document.getElementById('cardHeaderQueue').getElementsByTagName('a');
domCache.cardHeaderQueueLen = domCache.cardHeaderQueue.length;
domCache.cardHeaderSearch = document.getElementById('cardHeaderSearch').getElementsByTagName('a');
domCache.cardHeaderSearchLen = domCache.cardHeaderSearch.length;
domCache.counter = document.getElementById('counter');
domCache.volumePrct = document.getElementById('volumePrct');
domCache.volumeControl = document.getElementById('volumeControl');
domCache.volumeMenu = document.getElementById('volumeMenu');
domCache.btnsPlay = document.getElementsByClassName('btnPlay');
domCache.btnsPlayLen = domCache.btnsPlay.length;
domCache.btnPrev = document.getElementById('btnPrev');
domCache.btnNext = document.getElementById('btnNext');
domCache.progressBar = document.getElementById('progressBar');
domCache.volumeBar = document.getElementById('volumeBar');
domCache.outputs = document.getElementById('outputs');
domCache.btnAdd = document.getElementById('nav-add2homescreen');
domCache.currentCover = document.getElementById('currentCover');
domCache.currentTitle = document.getElementById('currentTitle');
domCache.btnVoteUp = document.getElementById('btnVoteUp');
domCache.btnVoteDown = document.getElementById('btnVoteDown');
domCache.badgeQueueItems = document.getElementById('badgeQueueItems');
domCache.searchstr = document.getElementById('searchstr');
domCache.searchCrumb = document.getElementById('searchCrumb');
domCache.body = document.getElementsByTagName('body')[0];

/* eslint-disable no-unused-vars */
var modalConnection = new Modal(document.getElementById('modalConnection'));
var modalSettings = new Modal(document.getElementById('modalSettings'));
var modalAbout = new Modal(document.getElementById('modalAbout')); 
var modalSaveQueue = new Modal(document.getElementById('modalSaveQueue'));
var modalAddToQueue = new Modal(document.getElementById('modalAddToQueue'));
var modalSongDetails = new Modal(document.getElementById('modalSongDetails'));
var modalAddToPlaylist = new Modal(document.getElementById('modalAddToPlaylist'));
var modalRenamePlaylist = new Modal(document.getElementById('modalRenamePlaylist'));
var modalUpdateDB = new Modal(document.getElementById('modalUpdateDB'));
var modalSaveSmartPlaylist = new Modal(document.getElementById('modalSaveSmartPlaylist'));
var modalDeletePlaylist = new Modal(document.getElementById('modalDeletePlaylist'));
var modalSaveBookmark = new Modal(document.getElementById('modalSaveBookmark'));
var modalTimer = new Modal(document.getElementById('modalTimer'));
var modalMounts = new Modal(document.getElementById('modalMounts'));
var modalCollybia = new Modal(document.getElementById('modalCollybia'));

var dropdownMainMenu; 
var dropdownVolumeMenu = new Dropdown(document.getElementById('volumeMenu'));
var dropdownBookmarks = new Dropdown(document.getElementById('BrowseFilesystemBookmark'));
var dropdownLocalPlayer = new Dropdown(document.getElementById('localPlaybackMenu'));
var dropdownPlay = new Dropdown(document.getElementById('btnPlayDropdown'));
var dropdownCovergridSort = new Dropdown(document.getElementById('btnCovergridSortDropdown'));
var dropdownNeighbors = new Dropdown(document.getElementById('btnDropdownNeighbors'));

var collapseDBupdate = new Collapse(document.getElementById('navDBupdate'));
var collapseSyscmds = new Collapse(document.getElementById('navSyscmds'));
var collapseJukeboxMode = new Collapse(document.getElementById('labelJukeboxMode'));
/* eslint-enable no-unused-vars */

function appPrepare(scrollPos) {
    if (app.current.app !== app.last.app || app.current.tab !== app.last.tab || app.current.view !== app.last.view) {
        //Hide all cards + nav
        for (let i = 0; i < domCache.navbarBottomBtnsLen; i++) {
            domCache.navbarBottomBtns[i].classList.remove('active');
        }
        document.getElementById('cardPlayback').classList.add('hide');
        document.getElementById('cardQueue').classList.add('hide');
        document.getElementById('cardBrowse').classList.add('hide');
        document.getElementById('cardSearch').classList.add('hide');
        for (let i = 0; i < domCache.cardHeaderBrowseLen; i++) {
            domCache.cardHeaderBrowse[i].classList.remove('active');
        }
        for (let i = 0; i < domCache.cardHeaderQueueLen; i++) {
            domCache.cardHeaderQueue[i].classList.remove('active');
        }
        for (let i = 0; i < domCache.cardHeaderSearchLen; i++) {
            domCache.cardHeaderSearch[i].classList.remove('active');
        }
        document.getElementById('cardQueueCurrent').classList.add('hide');
        document.getElementById('cardQueueLastPlayed').classList.add('hide');
        document.getElementById('cardBrowsePlaylists').classList.add('hide');
        document.getElementById('cardBrowseDatabase').classList.add('hide');
        document.getElementById('cardBrowseFilesystem').classList.add('hide');
        document.getElementById('cardBrowseCovergrid').classList.add('hide');
        //show active card + nav
        setGridPlayback();
        document.getElementById('card' + app.current.app).classList.remove('hide');
        if (document.getElementById('nav' + app.current.app)) {
            document.getElementById('nav' + app.current.app).classList.add('active');
        }
        if (app.current.tab !== undefined) {
            document.getElementById('card' + app.current.app + app.current.tab).classList.remove('hide');
            document.getElementById('card' + app.current.app + 'Nav' + app.current.tab).classList.add('active');    
        }
        scrollToPosY(scrollPos);
    }
    let list = document.getElementById(app.current.app + 
        (app.current.tab === undefined ? '' : app.current.tab) + 
        (app.current.view === undefined ? '' : app.current.view) + 'List');
    if (list) {
        list.classList.add('opacity05');
    }
    else if (app.current.app === 'Playback') {
        document.getElementById('QueueMiniList').classList.add('opacity05');
        document.getElementById('BrowseCovergridList').classList.add('opacity05');
    }
}

function appGoto(card, tab, view, state) {
    let scrollPos = 0;
    if (document.body.scrollTop) {
        scrollPos = document.body.scrollTop
    }
    else {
        scrollPos = document.documentElement.scrollTop;
    }
        
    if (app.apps[app.current.app].scrollPos !== undefined) {
        app.apps[app.current.app].scrollPos = scrollPos
    }
    else if (app.apps[app.current.app].tabs[app.current.tab].scrollPos !== undefined) {
        app.apps[app.current.app].tabs[app.current.tab].scrollPos = scrollPos
    }
    else if (app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos !== undefined) {
        app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos = scrollPos;
    }

    let hash = '';
    if (app.apps[card].tabs) {
        if (tab === undefined) {
            tab = app.apps[card].active;
        }
        if (app.apps[card].tabs[tab].views) {
            if (view === undefined) {
                view = app.apps[card].tabs[tab].active;
            }
            hash = '/' + card + '/' + tab +'/' + view + '!' + (state === undefined ? app.apps[card].tabs[tab].views[view].state : state);
        }
        else {
            hash = '/' + card +'/' + tab + '!' + (state === undefined ? app.apps[card].tabs[tab].state : state);
        }
    }
    else {
        hash = '/' + card + '!'+ (state === undefined ? app.apps[card].state : state);
    }
    location.hash = hash;
}

function appRoute() {
    if (settingsParsed === false) {
        appInitStart();
        return;
    }
    let hash = decodeURI(location.hash);
    let params = hash.match(/^#\/(\w+)\/?(\w+)?\/?(\w+)?!((\d+)\/([^/]+)\/([^/]+)\/(.*))$/);
    if (params) {
        app.current.app = params[1];
        app.current.tab = params[2];
        app.current.view = params[3];
        if (app.apps[app.current.app].state) {
            app.apps[app.current.app].state = params[4];
            app.current.scrollPos = app.apps[app.current.app].scrollPos;
        }
        else if (app.apps[app.current.app].tabs[app.current.tab].state) {
            app.apps[app.current.app].tabs[app.current.tab].state = params[4];
            app.apps[app.current.app].active = app.current.tab;
            app.current.scrollPos = app.apps[app.current.app].tabs[app.current.tab].scrollPos;
        }
        else if (app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].state) {
            app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].state = params[4];
            app.apps[app.current.app].active = app.current.tab;
            app.apps[app.current.app].tabs[app.current.tab].active = app.current.view;
            app.current.scrollPos = app.apps[app.current.app].tabs[app.current.tab].views[app.current.view].scrollPos;
        }
        app.current.page = parseInt(params[5]);
        app.current.filter = params[6];
        app.current.sort = params[7];
        app.current.search = params[8];
        setAppState(app.current.page, app.current.filter, app.current.sort, app.current.search);
    }
    else {
        appGoto('Playback');
        return;
    }

    appPrepare(app.current.scrollPos);

    if (app.current.app === 'Playback') {
        sendAPI("MPD_API_PLAYER_CURRENT_SONG", {}, songChange);
        getBrowseCovergrid();
    }    
    else if (app.current.app === 'Queue' && app.current.tab === 'Current' ) {
        selectTag('searchqueuetags', 'searchqueuetagsdesc', app.current.filter);
        getQueue();
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        sendAPI("MPD_API_QUEUE_LAST_PLAYED", {"offset": app.current.page, "cols": settings.colsQueueLastPlayed}, parseLastPlayed);
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": app.current.page, "filter": app.current.filter}, parsePlaylists);
        doSetFilterLetter('BrowsePlaylistsFilter');
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        sendAPI("MPD_API_PLAYLIST_CONTENT_LIST", {"offset": app.current.page, "filter": app.current.filter, "uri": app.current.search, "cols": settings.colsBrowsePlaylistsDetail}, parsePlaylists);
        doSetFilterLetter('BrowsePlaylistsFilter');
    }    
    else if (app.current.app === 'Browse' && app.current.tab === 'Database') {
        if (app.current.search !== '') {
            sendAPI("MPD_API_DATABASE_TAG_ALBUM_LIST", {"offset": app.current.page, "filter": app.current.filter, "search": app.current.search, "tag": app.current.view}, parseListDBtags);
            doSetFilterLetter('BrowseDatabaseFilter');
        }
        else {
            sendAPI("MPD_API_DATABASE_TAG_LIST", {"offset": app.current.page, "filter": app.current.filter, "tag": app.current.view}, parseListDBtags);
            doSetFilterLetter('BrowseDatabaseFilter');
            selectTag('BrowseDatabaseByTagDropdown', 'btnBrowseDatabaseByTag', app.current.view);
        }
    }    
    else if (app.current.app === 'Browse' && app.current.tab === 'Filesystem') {
        sendAPI("MPD_API_DATABASE_FILESYSTEM_LIST", {"offset": app.current.page, "path": (app.current.search ? app.current.search : "/"), "filter": app.current.filter, "cols": settings.colsBrowseFilesystem}, parseFilesystem, true);
        // Don't add all songs from root
        if (app.current.search) {
            document.getElementById('BrowseFilesystemAddAllSongs').removeAttribute('disabled');
            document.getElementById('BrowseFilesystemAddAllSongsBtn').removeAttribute('disabled');
        }
        else {
            document.getElementById('BrowseFilesystemAddAllSongs').setAttribute('disabled', 'disabled');
            document.getElementById('BrowseFilesystemAddAllSongsBtn').setAttribute('disabled', 'disabled');
        }
        // Create breadcrumb
        let breadcrumbs='<li class="breadcrumb-item"><a data-uri="" class="material-icons">home</a></li>';
        let pathArray = app.current.search.split('/');
        let pathArrayLen = pathArray.length;
        let fullPath = '';
        for (let i = 0; i < pathArrayLen; i++) {
            if (pathArrayLen - 1 === i) {
                breadcrumbs += '<li class="breadcrumb-item active">' + e(pathArray[i]) + '</li>';
                break;
            }
            fullPath += pathArray[i];
            breadcrumbs += '<li class="breadcrumb-item"><a class="text-body" href="#" data-uri="' + encodeURI(fullPath) + '">' + e(pathArray[i]) + '</a></li>';
            fullPath += '/';
        }
        document.getElementById('BrowseBreadcrumb').innerHTML = breadcrumbs;
        doSetFilterLetter('BrowseFilesystemFilter');
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Covergrid') {
        getBrowseCovergrid();
    }
    else if (app.current.app === 'Search') {
        domCache.searchstr.focus();
        if (settings.featAdvsearch) {
            let crumbs = '';
            let elements = app.current.search.substring(1, app.current.search.length - 1).split(' AND ');
            for (let i = 0; i < elements.length - 1 ; i++) {
                let value = elements[i].substring(1, elements[i].length - 1);
                crumbs += '<button data-filter="' + encodeURI(value) + '" class="btn btn-light mr-2">' + e(value) + '<span class="ml-2 badge badge-secondary">&times</span></button>';
            }
            domCache.searchCrumb.innerHTML = crumbs;
            if (domCache.searchstr.value === '' && elements.length >= 1) {
                let lastEl = elements[elements.length - 1].substring(1,  elements[elements.length - 1].length - 1);
                let lastElValue = lastEl.substring(lastEl.indexOf('\'') + 1, lastEl.length - 1);
                if (domCache.searchstr.value !== lastElValue) {
                    domCache.searchCrumb.innerHTML += '<button data-filter="' + encodeURI(lastEl) +'" class="btn btn-light mr-2">' + e(lastEl) + '<span href="#" class="ml-2 badge badge-secondary">&times;</span></button>';
                }
                let match = lastEl.substring(lastEl.indexOf(' ') + 1);
                match = match.substring(0, match.indexOf(' '));
                if (match === '')
                    match = 'contains';
                document.getElementById('searchMatch').value = match;
            }
        }
        else {
            if (domCache.searchstr.value === '' && app.current.search !== '') {
                domCache.searchstr.value = app.current.search;
            }
        }
        if (app.last.app !== app.current.app) {
            if (app.current.search !== '') {
                let colspan = settings['cols' + app.current.app].length;
                colspan--;
                document.getElementById('SearchList').getElementsByTagName('tbody')[0].innerHTML=
                    '<tr><td><span class="material-icons">search</span></td>' +
                    '<td colspan="' + colspan + '">' + t('Searching...') + '</td></tr>';
            }
        }

        if (domCache.searchstr.value.length >= 2 || domCache.searchCrumb.children.length > 0) {
            if (settings.featAdvsearch) {
                let sort = app.current.sort;
                let sortdesc = false;
                if (sort === '-') {
                    if (settings.tags.includes('Title')) {
                        sort = 'Title';
                    }
                    else {
                        sort = '-';
                    }
                    document.getElementById('SearchList').setAttribute('data-sort', sort);
                }
                else {
                    if (sort.indexOf('-') === 0) {
                        sortdesc = true;
                        sort = sort.substring(1);
                    }
                }
                sendAPI("MPD_API_DATABASE_SEARCH_ADV", {"plist": "", "offset": app.current.page, "sort": sort, "sortdesc": sortdesc, "expression": app.current.search, "cols": settings.colsSearch, "replace": false}, parseSearch);
            }
            else {
                sendAPI("MPD_API_DATABASE_SEARCH", {"plist": "", "offset": app.current.page, "filter": app.current.filter, "searchstr": app.current.search, "cols": settings.colsSearch, "replace": false}, parseSearch);
            }
        } else {
            document.getElementById('SearchList').getElementsByTagName('tbody')[0].innerHTML = '';
            document.getElementById('searchAddAllSongs').setAttribute('disabled', 'disabled');
            document.getElementById('searchAddAllSongsBtn').setAttribute('disabled', 'disabled');
            document.getElementById('panel-heading-search').innerText = '';
            document.getElementById('cardFooterSearch').innerText = '';
            document.getElementById('SearchList').classList.remove('opacity05');
            setPagination(0, 0);
        }
        selectTag('searchtags', 'searchtagsdesc', app.current.filter);
    }
    else {
        appGoto("Playback");
    }

    app.last.app = app.current.app;
    app.last.tab = app.current.tab;
    app.last.view = app.current.view;
}

function showAppInitAlert(text) {
    document.getElementById('splashScreenAlert').innerHTML = '<p class="text-danger">' + t(text) + '</p>' +
        '<p><a id="appReloadBtn" class="btn btn-danger text-light clickable">' + t('Reload') + '</a></p>';
    document.getElementById('appReloadBtn').addEventListener('click', function() {
        clearAndReload();
    }, false);
}


function clearAndReload() {
    if ('serviceWorker' in navigator) {
        caches.keys().then(function(cacheNames) {
            cacheNames.forEach(function(cacheName) {
                caches.delete(cacheName);
            });
        });
    }
    location.reload();
}

function appInitStart() {
    subdir = window.location.pathname.replace('/index.html', '').replace(/\/$/, '');
    let localeList = '<option value="default" data-phrase="Browser default"></option>';
    for (let i = 0; i < locales.length; i++) {
        localeList += '<option value="' + e(locales[i].code) + '">' + e(locales[i].desc) + ' (' + e(locales[i].code) + ')</option>';
    }
    document.getElementById('selectLocale').innerHTML = localeList;
    
    i18nHtml(document.getElementById('splashScreenAlert'));
    
    //register serviceworker
    let script = document.getElementsByTagName("script")[0].src.replace(/^.*[/]/, '');
    if (script !== 'combined.js') {
        settings.loglevel = 4;
    }
    if ('serviceWorker' in navigator && document.URL.substring(0, 5) === 'https' 
        && window.location.hostname !== 'localhost' && script === 'combined.js')
    {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('/sw.js', {scope: '/'}).then(function(registration) {
                // Registration was successful
                logInfo('ServiceWorker registration successful.');
                registration.update();
            }, function(err) {
                // Registration failed
                logError('ServiceWorker registration failed: ' + err);
            });
        });
    }

    appInited = false;
    document.getElementById('splashScreen').classList.remove('hide');
    document.getElementsByTagName('body')[0].classList.add('overflow-hidden');
    document.getElementById('splashScreenAlert').innerText = t('Fetch myMPD settings');

    getSettings(true);
    appInitWait();
}

function appInitWait() {
    setTimeout(function() {
        if (settingsParsed === 'true' && websocketConnected === true) {
            //app initialized
            document.getElementById('splashScreenAlert').innerText = t('Applying settings');
            document.getElementById('splashScreen').classList.add('hide-fade');
            setTimeout(function() {
                document.getElementById('splashScreen').classList.add('hide');
                document.getElementById('splashScreen').classList.remove('hide-fade');
                document.getElementsByTagName('body')[0].classList.remove('overflow-hidden');
            }, 500);
            appInit();
            appInited = true;
            return;
        }
        
        if (settingsParsed === 'true') {
            //parsed settings, now its save to connect to websocket
            document.getElementById('splashScreenAlert').innerText = t('Connect to websocket');
            webSocketConnect();
        }
        else if (settingsParsed === 'error') {
            return;
        }
        appInitWait();
    }, 500);
}

function appInit() {
    document.getElementById('btnChVolumeDown').addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);
    document.getElementById('btnChVolumeUp').addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);

    domCache.volumeBar.addEventListener('click', function(event) {
        event.stopPropagation();
    }, false);
    domCache.volumeBar.addEventListener('change', function() {
        sendAPI("MPD_API_PLAYER_VOLUME_SET", {"volume": domCache.volumeBar.value});
    }, false);

    domCache.progressBar.value = 0;
    domCache.progressBar.addEventListener('change', function() {
        if (currentSong && currentSong.currentSongId >= 0) {
            let seekVal = Math.ceil(currentSong.totalTime * (domCache.progressBar.value / 1000));
            sendAPI("MPD_API_PLAYER_SEEK", {"songid": currentSong.currentSongId, "seek": seekVal});
        }
    }, false);


    let collapseArrows = document.querySelectorAll('.subMenu');
    let collapseArrowsLen = collapseArrows.length;
    for (let i = 0; i < collapseArrowsLen; i++) {
        collapseArrows[i].addEventListener('click', function(event) {
            event.stopPropagation();
            event.preventDefault();
            let icon = this.getElementsByTagName('span')[0];
            icon.innerText = icon.innerText === 'keyboard_arrow_right' ? 'keyboard_arrow_down' : 'keyboard_arrow_right';
        }, false);
    }    
    
    document.getElementById('volumeMenu').parentNode.addEventListener('show.bs.dropdown', function () {
        sendAPI("MPD_API_PLAYER_OUTPUT_LIST", {}, parseOutputs);
    });
    
    document.getElementById('btnDropdownNeighbors').parentNode.addEventListener('show.bs.dropdown', function () {
        if (settings.featNeighbors === true) {
            sendAPI("MPD_API_MOUNT_NEIGHBOR_LIST", {}, parseNeighbors, true);
        }
        else {
            document.getElementById('dropdownNeighbors').children[0].innerHTML = 
                '<div class="list-group-item"><span class="material-icons">warning</span> ' + t('Neighbors are disabled') + '</div>';
        }
    });
    
    document.getElementById('dropdownNeighbors').children[0].addEventListener('click', function (event) {
        event.preventDefault();
        if (event.target.nodeName === 'A') {
            let c = event.target.getAttribute('data-value').match(/^(\w+:\/\/)(.+)$/);
            document.getElementById('selectMountUrlhandler').value = c[1];
            document.getElementById('inputMountUrl').value = c[2];
        }
    });
    
    document.getElementById('BrowseFilesystemBookmark').parentNode.addEventListener('show.bs.dropdown', function () {
        sendAPI("MYMPD_API_BOOKMARK_LIST", {"offset": 0}, parseBookmarks);
    });
    
    document.getElementById('playDropdown').parentNode.addEventListener('show.bs.dropdown', function () {
        showPlayDropdown();
    });

    document.getElementById('playDropdown').addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
    });
    
    let dropdowns = document.querySelectorAll('.dropdown-toggle');
    for (let i = 0; i < dropdowns.length; i++) {
        dropdowns[i].parentNode.addEventListener('show.bs.dropdown', function () {
            alignDropdown(this);
        });
    }
    
    document.getElementById('modalTimer').addEventListener('shown.bs.modal', function () {
        showListTimer();
    });

    document.getElementById('modalMounts').addEventListener('shown.bs.modal', function () {
        showListMounts();
    });
    
    document.getElementById('modalAbout').addEventListener('shown.bs.modal', function () {
        sendAPI("MPD_API_DATABASE_STATS", {}, parseStats);
        getServerinfo();
        let trs = '';
        for (let key in keymap) {
            if (keymap[key].req === undefined || settings[keymap[key].req] === true) {
                trs += '<tr><td><div class="key' + (keymap[key].key && keymap[key].key.length > 1 ? ' material-icons material-icons-small' : '') + 
                       '">' + (keymap[key].key !== undefined ? keymap[key].key : key ) + '</div></td><td>' + t(keymap[key].desc) + '</td></tr>';
            }
        }
        document.getElementById('tbodyShortcuts').innerHTML = trs;
    });
    
    document.getElementById('modalAddToPlaylist').addEventListener('shown.bs.modal', function () {
        if (!document.getElementById('addStreamFrm').classList.contains('hide')) {
            document.getElementById('streamUrl').focus();
            document.getElementById('streamUrl').value = '';
        }
        else {
            document.getElementById('addToPlaylistPlaylist').focus();
        }
    });
    
    document.getElementById('inputTimerVolume').addEventListener('change', function() {
        document.getElementById('textTimerVolume').innerHTML = this.value + '&nbsp;%';
    }, false);
    
    document.getElementById('selectTimerAction').addEventListener('change', function() {
        if (this.options[this.selectedIndex].value === 'startplay') {
            document.getElementById('timerActionPlay').classList.remove('hide');
        }
        else {
            document.getElementById('timerActionPlay').classList.add('hide');
        }
    }, false);
    
    let selectTimerHour = ''; 
    for (let i = 0; i < 24; i++) {
        selectTimerHour += '<option value="' + i + '">' + zeroPad(i, 2) + '</option>';
    }
    document.getElementById('selectTimerHour').innerHTML = selectTimerHour;
    
    let selectTimerMinute = ''; 
    for (let i = 0; i < 60; i = i + 5) {
        selectTimerMinute += '<option value="' + i + '">' + zeroPad(i, 2) + '</option>';
    }
    document.getElementById('selectTimerMinute').innerHTML = selectTimerMinute;
    

    document.getElementById('inputHighlightColor').addEventListener('change', function() {
        document.getElementById('highlightColorPreview').style.backgroundColor = this.value;
    }, false);
    
    document.getElementById('inputBgColor').addEventListener('change', function() {
        document.getElementById('bgColorPreview').style.backgroundColor = this.value;
    }, false);
    
    document.getElementById('modalAddToQueue').addEventListener('shown.bs.modal', function () {
        document.getElementById('inputAddToQueueQuantity').classList.remove('is-invalid');
        document.getElementById('warnJukeboxPlaylist2').classList.add('hide');
        if (settings.featPlaylists) {
            playlistEl = 'selectAddToQueuePlaylist';
            sendAPI("MPD_API_PLAYLIST_LIST", {"offset": 0, "filter": "-"}, getAllPlaylists);
        }
    });

    document.getElementById('modalUpdateDB').addEventListener('hidden.bs.modal', function () {
        document.getElementById('updateDBprogress').classList.remove('updateDBprogressAnimate');
    });
    
    document.getElementById('modalSaveQueue').addEventListener('shown.bs.modal', function () {
        let plName = document.getElementById('saveQueueName');
        plName.focus();
        plName.value = '';
        plName.classList.remove('is-invalid');
    });
        
    document.getElementById('modalSettings').addEventListener('shown.bs.modal', function () {
        this.focus();
        getSettings();
        document.getElementById('inputCrossfade').classList.remove('is-invalid');
        document.getElementById('inputMixrampdb').classList.remove('is-invalid');
        document.getElementById('inputMixrampdelay').classList.remove('is-invalid');
    });

    document.getElementById('modalCollybia').addEventListener('shown.bs.modal', function () {
        this.focus();
        getSettings();
        document.getElementById('inputNsServer').classList.remove('is-invalid');
        document.getElementById('inputNsShare').classList.remove('is-invalid');
        document.getElementById('inputNsUsername').classList.remove('is-invalid');
        document.getElementById('inputNsPassword').classList.remove('is-invalid');
    });

    document.getElementById('modalCollybia').addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
            saveCollybiaSettings();
            event.stopPropagation();
            event.preventDefault();
        }
    });

    document.getElementById('selectNsType').addEventListener('change', function () {
        let value = this.options[this.selectedIndex].value;
        if (value === '0') {
            document.getElementById('nsServerShare').classList.add('hide');
            document.getElementById('sambaVersion').classList.add('hide');
            document.getElementById('nsCredentials').classList.add('hide');
            document.getElementById('inputNsServer').value = '';
            document.getElementById('inputNsShare').value = '';
            document.getElementById('inputNsUsername').value = '';
            document.getElementById('inputNsPassword').value = '';
        }
        else if (value === '2') {
            document.getElementById('nsServerShare').classList.remove('hide');
            document.getElementById('sambaVersion').classList.remove('hide');
            document.getElementById('nsCredentials').classList.remove('hide');
        }
      else {
            document.getElementById('nsServerShare').classList.remove('hide');
            if (value === '1') {
                document.getElementById('sambaVersion').classList.remove('hide');
            }
            else {
                document.getElementById('sambaVersion').classList.add('hide');
            }
            document.getElementById('nsCredentials').classList.add('hide');
            document.getElementById('inputNsUsername').value = '';
            document.getElementById('inputNsPassword').value = '';
        }
    });

    document.getElementById('modalConnection').addEventListener('shown.bs.modal', function () {
        getSettings();
        document.getElementById('inputMpdHost').classList.remove('is-invalid');
        document.getElementById('inputMpdPort').classList.remove('is-invalid');
        document.getElementById('inputMpdPass').classList.remove('is-invalid');
    });

    document.getElementById('btnJukeboxModeGroup').addEventListener('mouseup', function () {
        setTimeout(function() {
            let value = document.getElementById('btnJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');
            if (value === '0') {
                document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
            }
            else if (value === '2') {
                document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
                document.getElementById('selectJukeboxPlaylist').value = 'Database';
            }
            else if (value === '1') {
                document.getElementById('inputJukeboxQueueLength').removeAttribute('disabled');
                document.getElementById('selectJukeboxPlaylist').removeAttribute('disabled');
            }
            if (value !== '0') {
                toggleBtnChk('btnConsume', true);            
            }
            checkConsume();
        }, 100);
    });
    
    document.getElementById('btnConsume').addEventListener('mouseup', function() {
        setTimeout(function() { 
            checkConsume(); 
        }, 100);
    });
    
    document.getElementById('btnStickers').addEventListener('mouseup', function() {
        setTimeout(function() {
            if (document.getElementById('btnStickers').classList.contains('active')) {
                document.getElementById('warnPlaybackStatistics').classList.add('hide');
                document.getElementById('inputJukeboxLastPlayed').removeAttribute('disabled');
            }
            else {
                document.getElementById('warnPlaybackStatistics').classList.remove('hide');
                document.getElementById('inputJukeboxLastPlayed').setAttribute('disabled', 'disabled');
            }
        }, 100);
    });
    
    document.getElementById('selectAddToQueueMode').addEventListener('change', function () {
        let value = this.options[this.selectedIndex].value;
        if (value === '2') {
            document.getElementById('inputAddToQueueQuantity').setAttribute('disabled', 'disabled');
            document.getElementById('selectAddToQueuePlaylist').setAttribute('disabled', 'disabled');
            document.getElementById('selectAddToQueuePlaylist').value = 'Database';
        }
        else if (value === '1') {
            document.getElementById('inputAddToQueueQuantity').removeAttribute('disabled');
            document.getElementById('selectAddToQueuePlaylist').removeAttribute('disabled');
        }
    });

    document.getElementById('addToPlaylistPlaylist').addEventListener('change', function () {
        if (this.options[this.selectedIndex].value === 'new') {
            document.getElementById('addToPlaylistNewPlaylistDiv').classList.remove('hide');
            document.getElementById('addToPlaylistNewPlaylist').focus();
        }
        else {
            document.getElementById('addToPlaylistNewPlaylistDiv').classList.add('hide');
        }
    }, false);
    
    document.getElementById('selectMusicDirectory').addEventListener('change', function () {
        if (this.options[this.selectedIndex].value === 'auto') {
            document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue;
            document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
        }
        else if (this.options[this.selectedIndex].value === 'none') {
            document.getElementById('inputMusicDirectory').value = '';
            document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
        }
        else {
            document.getElementById('inputMusicDirectory').value = '';
            document.getElementById('inputMusicDirectory').removeAttribute('readonly');
        }
    }, false);
    
    addFilterLetter('BrowseFilesystemFilterLetters');
    addFilterLetter('BrowseDatabaseFilterLetters');
    addFilterLetter('BrowsePlaylistsFilterLetters');

    document.getElementById('syscmds').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            parseCmd(event, event.target.getAttribute('data-href'));
        }
    }, false);

    let hrefs = document.querySelectorAll('[data-href]');
    let hrefsLen = hrefs.length;
    for (let i = 0; i < hrefsLen; i++) {
        if (hrefs[i].classList.contains('notclickable') === false) {
            hrefs[i].classList.add('clickable');
        }
        let parentInit = hrefs[i].parentNode.classList.contains('noInitChilds') ? true : false;
        if (parentInit === true) {
            //handler on parentnode
            continue;
        }
        hrefs[i].addEventListener('click', function(event) {
            parseCmd(event, this.getAttribute('data-href'));
        }, false);
    }

    let pd = document.getElementsByClassName('pages');
    let pdLen = pd.length;
    for (let i = 0; i < pdLen; i++) {
        pd[i].addEventListener('click', function(event) {
            if (event.target.nodeName === 'BUTTON') {
                gotoPage(event.target.getAttribute('data-page'));
            }
        }, false);
    }

    document.getElementById('cardPlaybackTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'H4') 
            gotoBrowse(event.target);
    }, false);

    document.getElementById('BrowseBreadcrumb').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            event.preventDefault();
            appGoto('Browse', 'Filesystem', undefined, '0/' + app.current.filter + '/' + app.current.sort + '/' + decodeURI(event.target.getAttribute('data-uri')));
        }
    }, false);
    
    document.getElementById('tbodySongDetails').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            if (event.target.id === 'calcFingerprint') {
                sendAPI("MPD_API_DATABASE_FINGERPRINT", {"uri": decodeURI(event.target.getAttribute('data-uri'))}, parseFingerprint);
                event.preventDefault();
                let parent = event.target.parentNode;
                let spinner = document.createElement('div');
                spinner.classList.add('spinner-border', 'spinner-border-sm');
                event.target.classList.add('hide');
                parent.appendChild(spinner);
            }
            else if (event.target.parentNode.getAttribute('data-tag') !== null) {
                modalSongDetails.hide();
                event.preventDefault();
                gotoBrowse(event.target);
            } 
        }
        else if (event.target.nodeName === 'BUTTON') { 
            if (event.target.getAttribute('data-href')) {
                parseCmd(event, event.target.getAttribute('data-href'));
            }
        }
    }, false);

    document.getElementById('outputs').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.stopPropagation();
            sendAPI("MPD_API_PLAYER_TOGGLE_OUTPUT", {"output": event.target.getAttribute('data-output-id'), "state": (event.target.classList.contains('active') ? 0 : 1)});
            toggleBtn(event.target.id);
        }
    }, false);
    
    document.getElementById('listTimerList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            showEditTimer(event.target.parentNode.getAttribute('data-id'));
        }
        else if (event.target.nodeName === 'A') {
            deleteTimer(event.target.parentNode.parentNode.getAttribute('data-id'));
        }
        else if (event.target.nodeName === 'BUTTON') {
            toggleTimer(event.target, event.target.parentNode.parentNode.getAttribute('data-id'));
        }
    }, false);

    document.getElementById('listMountsList').addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'TD') {
            if (event.target.parentNode.getAttribute('data-point') === '') {
                return false;
            }
            showEditMount(decodeURI(event.target.parentNode.getAttribute('data-url')),decodeURI(event.target.parentNode.getAttribute('data-point')));
        }
        else if (event.target.nodeName === 'A') {
            let action = event.target.getAttribute('data-action');
            let mountPoint = decodeURI(event.target.parentNode.parentNode.getAttribute('data-point'));
            if (action === 'unmount') {
                unmountMount(mountPoint);
            }
            else if (action === 'update') {
                updateMount(event.target, mountPoint);
            }
        }
    }, false);
    
    document.getElementById('QueueCurrentList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            sendAPI("MPD_API_PLAYER_PLAY_TRACK", {"track": event.target.parentNode.getAttribute('data-trackid')});
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);
    
    document.getElementById('QueueLastPlayedList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);    

    document.getElementById('QueueMiniList').addEventListener('click', function (event) {
        if (event.target.nodeName === 'TD') {
            sendAPI("MPD_API_PLAYER_PLAY_TRACK", { "track": event.target.parentNode.getAttribute('data-trackid') });
        }
    }, false);

    document.getElementById('BrowseFilesystemList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            switch(event.target.parentNode.getAttribute('data-type')) {
                case 'parentDir':
                case 'dir':
                    appGoto('Browse', 'Filesystem', undefined, '0/' + app.current.filter + '/' + app.current.sort + '/' + decodeURI(event.target.parentNode.getAttribute("data-uri")));
                    break;
                case 'song':
                    appendQueue('song', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
                    break;
                case 'plist':
                    appendQueue('plist', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
                    break;
            }
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseCovergridAlbumList').addEventListener('click', function (event) {
        if (event.target.nodeName === 'TD') {
            getCovergridTitle(event.target.parentNode);
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseCovergridTitleList').addEventListener('click', function (event) {
        if (event.target.nodeName === 'TD') {
            appendPlayQueue('song', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseFilesystemBookmarks').addEventListener('click', function(event) {
        if (event.target.nodeName === 'A') {
            let id = event.target.parentNode.parentNode.getAttribute('data-id');
            let type = event.target.parentNode.parentNode.getAttribute('data-type');
            let uri = decodeURI(event.target.parentNode.parentNode.getAttribute('data-uri'));
            let name = event.target.parentNode.parentNode.firstChild.innerText;
            let href = event.target.getAttribute('data-href');
            
            if (href === 'delete') {
                sendAPI("MYMPD_API_BOOKMARK_RM", {"id": id}, function() {
                    sendAPI("MYMPD_API_BOOKMARK_LIST", {"offset": 0}, parseBookmarks);
                });
                event.preventDefault();
                event.stopPropagation();
            }
            else if (href === 'edit') {
                showBookmarkSave(id, name, uri, type);
            }
            else if (href === 'goto') {
                appGoto('Browse', 'Filesystem', undefined, '0/-/-/' + uri );
            }
        }
    }, false);

    document.getElementById('BrowsePlaylistsAllList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('plist', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowsePlaylistsDetailList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('plist', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);    
    
    document.getElementById('BrowseDatabaseTagList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appGoto('Browse', 'Database', app.current.view, '0/-/-/' + event.target.parentNode.getAttribute('data-uri'));
        }
    }, false);
    
    document.getElementById('SearchList').addEventListener('click', function(event) {
        if (event.target.nodeName === 'TD') {
            appendQueue('song', decodeURI(event.target.parentNode.getAttribute("data-uri")), event.target.parentNode.getAttribute("data-name"));
        }
        else if (event.target.nodeName === 'A') {
            showMenu(event.target, event);
        }
    }, false);

    document.getElementById('BrowseFilesystemAddAllSongsDropdown').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            if (event.target.getAttribute('data-phrase') === 'Add all to queue') {
                addAllFromBrowseFilesystem();
            }
            else if (event.target.getAttribute('data-phrase') === 'Add all to playlist') {
                showAddToPlaylist(app.current.search, '');
            }
        }
    }, false);

    document.getElementById('searchAddAllSongsDropdown').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            if (event.target.getAttribute('data-phrase') === 'Add all to queue') {
                addAllFromSearchPlist('queue', null, false);
            }
            else if (event.target.getAttribute('data-phrase') === 'Add all to playlist') {
                showAddToPlaylist('SEARCH', '');
            }
            else if (event.target.getAttribute('data-phrase') === 'Save as smart playlist') {
                saveSearchAsSmartPlaylist();
            }
        }
    }, false);
    
    document.getElementById('BrowseDatabaseAddAllSongsDropdown').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            if (event.target.getAttribute('data-phrase') === 'Add all to queue') {
                addAllFromBrowseDatabasePlist('queue');
            }
            else if (event.target.getAttribute('data-phrase') === 'Add all to playlist') {
                showAddToPlaylist('DATABASE', '');
            }
        }
    }, false);

    document.getElementById('searchtags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            app.current.filter = event.target.getAttribute('data-tag');
            search(domCache.searchstr.value);
        }
    }, false);
    
    document.getElementById('searchCovergridTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            app.current.filter = event.target.getAttribute('data-tag');
            appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' + app.current.search);
        }
    }, false);
    
    document.getElementById('covergridSortDesc').addEventListener('click', function(event) {
        toggleBtnChk(this);
        event.stopPropagation();
        event.preventDefault();
        if (app.current.sort.charAt(0) === '-') {
            app.current.sort = app.current.sort.substr(1);
        }
        else {
            app.current.sort = '-' + app.current.sort;
        }
        appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' + app.current.search);
    }, false);

    document.getElementById('covergridSortTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.preventDefault();
            event.stopPropagation();
            app.current.sort = event.target.getAttribute('data-tag');
            appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' + app.current.search);
        }
    }, false);
    
    document.getElementById('searchCovergridStr').addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else {
            setAppState(0, app.current.filter, app.current.sort, this.value);
            appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' + this.value);
        }
    }, false);

    document.getElementById('dropdownSortPlaylistTags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            event.preventDefault();
            playlistSort(event.target.getAttribute('data-tag'));
        }
    }, false);

    document.getElementById('searchqueuestr').addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else {
            appGoto(app.current.app, app.current.tab, app.current.view, '0/' + app.current.filter + '/' + app.current.sort + '/' + this.value);
        }
    }, false);

    document.getElementById('searchqueuetags').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            appGoto(app.current.app, app.current.tab, app.current.view, app.current.page + '/' + event.target.getAttribute('data-tag') + '/' + app.current.sort  + '/' + app.current.search);
        }
    }, false);

    let colDropdowns = ['BrowseDatabaseColsDropdown', 'PlaybackColsDropdown'];
    for (let i = 0; i < colDropdowns.length; i++) {
        document.getElementById(colDropdowns[i]).addEventListener('click', function(event) {
            if (event.target.nodeName === 'BUTTON' && event.target.classList.contains('material-icons')) {
                event.stopPropagation();
                event.preventDefault();
                toggleBtnChk(event.target);
            }
        }, false);
    }
    
    document.getElementById('search').addEventListener('submit', function() {
        return false;
    }, false);

    document.getElementById('searchqueue').addEventListener('submit', function() {
        return false;
    }, false);
    
    document.getElementById('searchcovergrid').addEventListener('submit', function() {
        return false;
    }, false);

    domCache.searchstr.addEventListener('keyup', function(event) {
        if (event.key === 'Escape') {
            this.blur();
        }
        else if (event.key === 'Enter' && settings.featAdvsearch) {
            if (this.value !== '') {
                let match = document.getElementById('searchMatch');
                let li = document.createElement('button');
                li.classList.add('btn', 'btn-light', 'mr-2');
                li.setAttribute('data-filter', encodeURI(app.current.filter + ' ' + match.options[match.selectedIndex].value +' \'' + this.value + '\''));
                li.innerHTML = app.current.filter + ' ' + match.options[match.selectedIndex].value + ' \'' + e(this.value) + '\'<span class="ml-2 badge badge-secondary">&times;</span>';
                this.value = '';
                domCache.searchCrumb.appendChild(li);
            }
            else {
                search(this.value);
            }
        }
        else {
            search(this.value);
        }
    }, false);

    domCache.searchCrumb.addEventListener('click', function(event) {
        event.preventDefault();
        event.stopPropagation();
        if (event.target.nodeName === 'SPAN') {
            event.target.parentNode.remove();
            search('');
        }
        else if (event.target.nodeName === 'BUTTON') {
            let value = decodeURI(event.target.getAttribute('data-filter'));
            domCache.searchstr.value = value.substring(value.indexOf('\'') + 1, value.length - 1);
            let filter = value.substring(0, value.indexOf(' '));
            selectTag('searchtags', 'searchtagsdesc', filter);
            let match = value.substring(value.indexOf(' ') + 1);
            match = match.substring(0, match.indexOf(' '));
            document.getElementById('searchMatch').value = match;
            event.target.remove();
            search(domCache.searchstr.value);
        }
    }, false);

    document.getElementById('searchMatch').addEventListener('change', function() {
        search(domCache.searchstr.value);
    }, false);
    
    document.getElementById('SearchList').getElementsByTagName('tr')[0].addEventListener('click', function(event) {
        if (settings.featAdvsearch) {
            if (event.target.nodeName === 'TH') {
                if (event.target.innerHTML === '') {
                    return;
                }
                let col = event.target.getAttribute('data-col');
                if (col === 'Duration') {
                    return;
                }
                let sortcol = app.current.sort;
                let sortdesc = true;
                
                if (sortcol === col || sortcol === '-' + col) {
                    if (sortcol.indexOf('-') === 0) {
                        sortdesc = true;
                        col = sortcol.substring(1);
                    }
                    else {
                        sortdesc = false;
                    }
                }
                if (sortdesc === false) {
                    sortcol = '-' + col;
                    sortdesc = true;
                }
                else {
                    sortdesc = false;
                    sortcol = col;
                }
                
                let s = document.getElementById('SearchList').getElementsByClassName('sort-dir');
                for (let i = 0; i < s.length; i++) {
                    s[i].remove();
                }
                app.current.sort = sortcol;
                event.target.innerHTML = t(col) + '<span class="sort-dir material-icons pull-right">' + (sortdesc === true ? 'arrow_drop_up' : 'arrow_drop_down') + '</span>';
                appGoto(app.current.app, app.current.tab, app.current.view, app.current.page + '/' + app.current.filter + '/' + app.current.sort + '/' + app.current.search);
            }
        }
    }, false);

    document.getElementById('BrowseDatabaseByTagDropdown').addEventListener('click', function(event) {
        if (event.target.nodeName === 'BUTTON') {
            appGoto(app.current.app, app.current.tab, event.target.getAttribute('data-tag') , '0/' + app.current.filter + '/' + app.current.sort + '/' + app.current.search);
        }
    }, false);

    document.getElementsByTagName('body')[0].addEventListener('click', function() {
        hideMenu();
    }, false);

    dragAndDropTable('QueueCurrentList');
    dragAndDropTable('BrowsePlaylistsDetailList');
    dragAndDropTableHeader('QueueCurrent');
    dragAndDropTableHeader('QueueLastPlayed');
    dragAndDropTableHeader('Search');
    dragAndDropTableHeader('BrowseFilesystem');
    dragAndDropTableHeader('BrowsePlaylistsDetail');

    window.addEventListener('hashchange', appRoute, false);

    window.addEventListener('focus', function() {
        sendAPI("MPD_API_PLAYER_STATE", {}, parseState);
    }, false);


    document.addEventListener('keydown', function(event) {
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'SELECT' ||
            event.ctrlKey || event.altKey) {
            return;
        }
        let cmd = keymap[event.key];
        if (cmd && typeof window[cmd.cmd] === 'function') {
            if (keymap[event.key].req === undefined || settings[keymap[event.key].req] === true)
                parseCmd(event, cmd);
        }        
        
    }, false);
    

    let tables = document.getElementsByTagName('table');
    for (let i = 0; i < tables.length; i++) {
        tables[i].setAttribute('tabindex', 0);
        tables[i].addEventListener('keydown', function(event) {
            navigateTable(this, event.key);
        }, false);
    }

    let selectThemeHtml = '';
    Object.keys(themes).forEach(function(key) {
        selectThemeHtml += '<option value="' + key + '">' + t(themes[key]) + '</option>';
    });
    document.getElementById('selectTheme').innerHTML = selectThemeHtml;

    
    window.addEventListener('beforeinstallprompt', function(event) {
        // Prevent Chrome 67 and earlier from automatically showing the prompt
        event.preventDefault();
        // Stash the event so it can be triggered later.
        deferredPrompt = event;
    });
    
    window.addEventListener('beforeinstallprompt', function(event) {
        event.preventDefault();
        deferredPrompt = event;
        // Update UI notify the user they can add to home screen
        domCache.btnAdd.classList.remove('hide');
    });
    
    domCache.btnAdd.addEventListener('click', function() {
        // Hide our user interface that shows our A2HS button
        domCache.btnAdd.classList.add('hide');
        // Show the prompt
        deferredPrompt.prompt();
        // Wait for the user to respond to the prompt
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                logVerbose('User accepted the A2HS prompt');
            }
            else {
                logVerbose('User dismissed the A2HS prompt');
            }
            deferredPrompt = null;
        });
    });
    
    window.addEventListener('appinstalled', function() {
        logInfo('myMPD installed as app');
        showNotification(t('myMPD installed as app'), '', '', 'success');
    });

    window.addEventListener('beforeunload', function() {
        if (websocketTimer !== null) {
            clearTimeout(websocketTimer);
            websocketTimer = null;
        }
        if (socket !== null) {
            socket.onclose = function () {}; // disable onclose handler first
            socket.close();
            socket = null;
        }
        websocketConnected = false;
    });
    
    document.getElementById('localPlayer').addEventListener('canplay', function() {
        document.getElementById('alertLocalPlayback').classList.add('hide');
        if (settings.featLocalplayer === true && settings.localplayerAutoplay === true) {
            localplayerPlay();
        }
    });
    updateDBstats(); // update database stats (songs, playtime)
}

//Init app
window.onerror = function(msg, url, line) {
    logError('JavaScript error: ' + msg + ' (' + url + ': ' + line + ')');
    if (settings.loglevel >= 4) {
        if (appInited === true) {
            showNotification(t('JavaScript error'), msg + ' (' + url + ': ' + line + ')', '', 'danger');
        }
        else {
            showAppInitAlert(t('JavaScript error') + ': ' + msg + ' (' + url + ': ' + line + ')');
        }
    }
    return true;
};

appInitStart();
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function setStateIcon(state) {
    let stateIcon = document.getElementById('navState').children[0];
    let websocketStateIcon = document.getElementById('websocketState').children[0];
    let mpdStateIcon = document.getElementById('mpdState').children[0];
    let websocketStateText = document.getElementById('websocketState').getElementsByTagName('small')[0];
    let mpdStateText = document.getElementById('mpdState').getElementsByTagName('small')[0];
    
    if (websocketConnected === false) {
        stateIcon.innerText = 'cloud_off';
    }
    else if (settings.mpdConnected === false) {
        stateIcon.innerText = 'cloud_off';
    }
    else {
        if (state === 'newMessage') {
            stateIcon.innerText = 'chat';
        }
        else if (state === 'noMessage') {
            stateIcon.innerText = 'chat_bubble_outline';
        }
    }
    
    if (websocketConnected === false) {
        websocketStateIcon.innerText = 'cloud_off';
        websocketStateIcon.classList.remove('text-success');
        websocketStateText.innerText = t('Websocket disconnected');
    }
    else { 
        websocketStateIcon.innerText = 'cloud_done';
        websocketStateIcon.classList.add('text-success');
        websocketStateText.innerText = t('Websocket connected');
    }

    if (websocketConnected === false) { 
        mpdStateIcon.innerText = 'cloud_off';
        mpdStateIcon.classList.remove('text-success');
        mpdStateText.innerText = t('MPD disconnected');
    }
    else {
        mpdStateIcon.innerText = 'cloud_done';
        mpdStateIcon.classList.add('text-success');
        mpdStateText.innerText = t('MPD connected');
    }
}

function toggleAlert(alertBox, state, msg) {
    let mpdState = document.getElementById(alertBox);
    if (state === false) {
        mpdState.innerHTML = '';
        mpdState.classList.add('hide');
    }
    else {
        mpdState.innerHTML = msg;
        mpdState.classList.remove('hide');
    }
}

function showNotification(notificationTitle, notificationText, notificationHtml, notificationType) {
    if (settings.notificationWeb === true) {
        let notification = new Notification(notificationTitle, {icon: 'assets/favicon.ico', body: notificationText});
        setTimeout(notification.close.bind(notification), 3000);
    } 
    if (settings.notificationPage === true || notificationType === 'danger') {
        let alertBox;
        if (!document.getElementById('alertBox')) {
            alertBox = document.createElement('div');
            alertBox.setAttribute('id', 'alertBox');
            alertBox.classList.add('toast');
        }
        else {
            alertBox = document.getElementById('alertBox');
        }
        let toast = '<div class="toast-header">';
        if (notificationType === 'success' ) {
            toast += '<span class="material-icons text-success mr-2">info</span>';
        }
        else {
            toast += '<span class="material-icons text-danger mr-2">warning</span>';
        }
        toast += '<strong class="mr-auto">' + e(notificationTitle) + '</strong>' +
            '<button type="button" class="ml-2 mb-1 close">&times;</button></div>';
        if (notificationHtml !== '' || notificationText !== '') {
            toast += '<div class="toast-body">' + (notificationHtml === '' ? e(notificationText) : notificationHtml) + '</div>';
        }
        toast += '</div>';
        alertBox.innerHTML = toast;
        
        if (!document.getElementById('alertBox')) {
            document.getElementsByTagName('main')[0].append(alertBox);
            requestAnimationFrame(function() {
                document.getElementById('alertBox').classList.add('alertBoxActive');
            });
        }
        alertBox.getElementsByTagName('button')[0].addEventListener('click', function() {
            hideNotification();
        }, false);

        if (alertTimeout) {
            clearTimeout(alertTimeout);
        }
        alertTimeout = setTimeout(function() {
            hideNotification();
        }, 3000);
    }
    setStateIcon('newMessage');
    logMessage(notificationTitle, notificationText, notificationHtml, notificationType);
}

function logMessage(notificationTitle, notificationText, notificationHtml, notificationType) {
    if (notificationType === 'success') { notificationType = 'Info'; }
    else if (notificationType === 'danger') { notificationType = 'Error'; }
    
    let overview = document.getElementById('logOverview');

    let append = true;
    let lastEntry = overview.firstElementChild;
    if (lastEntry) {
        if (lastEntry.getAttribute('data-title') === notificationTitle) {
            append = false;        
        }
    }

    let entry = document.createElement('div');
    entry.classList.add('text-light');
    entry.setAttribute('data-title', notificationTitle);
    let occurence = 1;
    if (append === false) {
        occurence += parseInt(lastEntry.getAttribute('data-occurence'));
    }
    entry.setAttribute('data-occurence', occurence);
    entry.innerHTML = '<small>' + localeDate() + '&nbsp;&ndash;&nbsp;' + t(notificationType) +
        (occurence > 1 ? '&nbsp;(' + occurence + ')' : '') + '</small>' +
        '<p>' + e(notificationTitle) +
        (notificationHtml === '' && notificationText === '' ? '' :
        '<br/>' + (notificationHtml === '' ? e(notificationText) : notificationHtml)) +
        '</p>';

    if (append === true) {
        overview.insertBefore(entry, overview.firstElementChild);
    }
    else {
        overview.replaceChild(entry, lastEntry);
    }
   
    let overviewEls = overview.getElementsByTagName('div');
    if (overviewEls.length > 10) {
        overviewEls[10].remove();
    }

    document.getElementById('navState').children[0].classList.add('text-success');
    setTimeout(function() {
        document.getElementById('navState').children[0].classList.remove('text-success');
    }, 250);
}

//eslint-disable-next-line no-unused-vars
function clearLogOverview() {
    let overviewEls = document.getElementById('logOverview').getElementsByTagName('div');
    for (let i = overviewEls.length - 1; i >= 0; i--) {
        overviewEls[i].remove();
    }
    setStateIcon('noMessage');
}

function hideNotification() {
    if (alertTimeout) {
        clearTimeout(alertTimeout);
    }

    if (document.getElementById('alertBox')) {
        document.getElementById('alertBox').classList.remove('alertBoxActive');
        setTimeout(function() {
            let alertBox = document.getElementById('alertBox');
            if (alertBox) {
                alertBox.remove();
            }
        }, 750);
    }
}

function notificationsSupported() {
    return "Notification" in window;
}

function setElsState(tag, state) {
    let els = document.getElementsByTagName(tag);
    let elsLen = els.length;
    for (let i = 0; i < elsLen; i++) {
        if (state === 'disabled') {
            if (els[i].classList.contains('alwaysEnabled') === false) {
                if (els[i].getAttribute('disabled') === null) {
                    els[i].setAttribute('disabled', 'disabled');
                    els[i].classList.add('disabled');
                }
            }
        }
        else {
            if (els[i].classList.contains('disabled')) {
                els[i].removeAttribute('disabled');
                els[i].classList.remove('disabled');
            }
        }
    }
}

function toggleUI() {
    let state = 'disabled';
    if (websocketConnected === true && settings.mpdConnected === true) {
        state = 'enabled';
    }
    let enabled = state === 'disabled' ? false : true;
    if (enabled !== uiEnabled) {
        logDebug('Setting ui state to ' + state);
        setElsState('a', state);
        setElsState('input', state);
        setElsState('button', state);
        uiEnabled = enabled;
    }

    if (settings.mpdConnected === true) {
        toggleAlert('alertMpdState', false, '');
    }
    else {
        toggleAlert('alertMpdState', true, t('MPD disconnected'));
        logMessage(t('MPD disconnected'), '', '', 'danger');
    }

    if (websocketConnected === true) {
        toggleAlert('alertMympdState', false, '');
    }
    else {
        toggleAlert('alertMympdState', true, t('Websocket is disconnected'));
        logMessage(t('Websocket is disconnected'), '', '', 'danger');
    }
    setStateIcon();
}

function setGridPlayback() {
    let list = ['col-md-6', 'd-none', 'd-md-block'];
    let bts = document.getElementsByClassName('btnText');
    if (app.current.app === 'Playback') {
        document.getElementById('row1').classList.add('row');
        document.getElementById('col1').classList.add('col-md-6');
        document.getElementById('col2').classList.add(...list);
        document.getElementById('cardQueueMini').classList.remove('hide');
        document.getElementById('cardBrowse').classList.remove('hide');
        document.getElementById('cardHeaderBrowse').getElementsByTagName('ul')[0].classList.add('hide');
        document.getElementById('cardBrowseCovergrid').classList.remove('hide');
        for (let i = 0; i < bts.length; i++) {
            bts[i].classList.add('hide');
        }
    }
    else {
        document.getElementById('row1').classList.remove('row');
        document.getElementById('col1').classList.remove('col-md-6');
        document.getElementById('col2').classList.remove(...list);
        document.getElementById('cardQueueMini').classList.add('hide');
        document.getElementById('cardHeaderBrowse').getElementsByTagName('ul')[0].classList.remove('hide');
        for (let i = 0; i < bts.length; i++) {
            bts[i].classList.remove('hide');
        }
        document.getElementById('BrowseCovergridBox').style.height = '';
    }
}

function setAppState(page, filter, sort, search) {
    if (search === null) {
        search = '';
    }
    if (app.current.app === 'Playback') { // set BrowseCovergrid state
        app.apps['Browse'].tabs['Covergrid'].state = page + '/' + filter + '/' + sort + '/' + search;
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Covergrid') { // set Playback state
        app.apps['Playback'].state = page + '/' + filter + '/' + sort + '/' + search;
    }
}

function getBrowseCovergrid() {
    setCovergridList();

    document.getElementById('searchCovergridStr').value = app.current.search;
    selectTag('searchCovergridTags', 'searchCovergridTagsDesc', app.current.filter);
    let sort = app.current.sort;
    let sortdesc = false;
    if (app.current.sort.charAt(0) === '-') {
        sortdesc = true;
        sort = app.current.sort.substr(1);
        toggleBtnChk('covergridSortDesc', true);
    }
    else {
        toggleBtnChk('covergridSortDesc', false);
    }
    selectTag('covergridSortTags', undefined, sort);
    sendAPI("MPD_API_DATABASE_GET_ALBUMS", {
        "offset": app.current.page, "searchstr": app.current.search,
        "tag": app.current.filter, "sort": sort, "sortdesc": sortdesc
    }, parseCovergrid);
}

function setCovergridList() {
    if (document.getElementById('BrowseCovergridList').classList.contains('hide')) {
        document.getElementById('btnBrowseCovergridAlbum').parentNode.classList.add('hide');
        document.getElementById('BrowseCovergridTitleList').classList.add('hide');
        document.getElementById('BrowseCovergridAlbumList').classList.remove('hide');
    }
}

function gotoAlbumList() {
    document.getElementById('btnBrowseCovergridAlbum').parentNode.classList.add('hide');
    getBrowseCovergrid();
}

function parseCovergridAlbum(obj) {
    let colspan = 3;
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('BrowseCovergridAlbumList');
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    let activeRow = 0;
    for (let i = 0; i < nrItems; i++) {
        let row = document.createElement('tr');
        let tds = '';
        row.setAttribute('data-type', 'dir');
        let uri = dirname(obj.result.data[i].FirstSongUri);
        row.setAttribute('data-uri', encodeURI(uri));
        row.setAttribute('tabindex', 0);
        row.setAttribute('data-album', obj.result.data[i].Album);
        row.setAttribute('data-albumartist', obj.result.data[i].AlbumArtist);
        row.setAttribute('data-name', obj.result.data[i].Album);
        tds += '<td data-col="Type"><span class="material-icons">album</span></td>';
        tds += '<td data-col="Album">' + e(obj.result.data[i].Album) + '</td>';
        tds += '<td data-col="AlbumArtist">' + e(obj.result.data[i].AlbumArtist) + '</td>';
        tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i--) {
        tr[i].remove();
    }

    if (nrItems === 0)
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    document.getElementById('BrowseCovergridAlbumList').classList.remove('opacity05');
}

function getCovergridTitle(tr) {
    sendAPI("MPD_API_DATABASE_TAG_ALBUM_TITLE_LIST", {
        "album": decodeURI(tr.getAttribute('data-album')),
        "search": decodeURI(tr.getAttribute('data-albumartist')),
        "tag": "AlbumArtist", "cols": settings.colsBrowseDatabase
    }, parseCovergridTitle);
}

function parseCovergridTitle(obj) {
    document.getElementById('card' + app.current.app).scrollIntoView();
    document.getElementById('BrowseCovergridAlbumList').classList.add('hide');
    document.getElementById('BrowseCovergridTitleList').classList.remove('hide');
    document.getElementById('BrowseCovergridTitleList').getElementsByTagName('caption')[0].innerHTML =
        t(obj.result.AlbumArtist) + ' - ' + t(obj.result.Album);
    document.getElementById('btnBrowseCovergridAlbum').parentNode.classList.remove('hide');
    let colspan = 3;
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('BrowseCovergridTitleList');
    let albumuri = encodeURI(dirname(obj.result.data[0].uri)); // rplc
    table.setAttribute('data-uri', albumuri);
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    for (let i = 0; i < nrItems; i++) {
        let uri = encodeURI(obj.result.data[i].uri);
        let row = document.createElement('tr');
        let tds = '';
        row.setAttribute('data-type', obj.result.data[i].Type);
        row.setAttribute('data-uri', uri);
        row.setAttribute('tabindex', 0);
        row.setAttribute('data-name', obj.result.data[i].Title);
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        tds += '<td data-col="Track">' + e(obj.result.data[i].Track) + '</td>';
        tds += '<td data-col="Title">' + e(obj.result.data[i].Title) + '</td>';
        tds += '<td data-col="Duration">' + e(obj.result.data[i].Duration) + '</td>';
        tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
        row.innerHTML = tds;

        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i--) {
        tr[i].remove();
    }

    if (navigate === true) {
        focusTable(0);
    }

    if (nrItems === 0)
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';

    document.getElementById('cardFooterBrowse').innerHTML = t('Num songs', obj.result.totalEntities) + ' &ndash; ' + beautifyDuration(obj.result.totalTime);
    document.getElementById('BrowseCovergridTitleList').classList.remove('opacity05');
}

function getQueueMini(pos, updateFooter = false) {
    let colsQueueMini = ["Pos", "Title", "Artist", "Album", "Duration"];
    // footer
    sendAPI("MPD_API_QUEUE_LIST", { "offset": 0, "cols": [] }, parseQueueList);
    // list
    if (pos !== undefined && pos !== -1) {
        sendAPI("MPD_API_QUEUE_MINI", { "pos": pos, "cols": colsQueueMini }, parseQueueMini);
    }
    else if (pos === undefined) {
        let table = document.getElementById('QueueMiniList');
        let tbody = table.getElementsByTagName('tbody')[0];
        for (let i = tbody.rows.length - 1; i >= 0; i--) {
            tbody.deleteRow(i);
        }
        table.classList.add('opacity05');
    }
}

function parseQueueList(obj) {
    if (obj.result.totalTime && obj.result.totalTime > 0 && obj.result.totalEntities <= settings.maxElementsPerPage) {
        document.getElementById('cardFooterQueueMini').innerText = t('Num songs', obj.result.totalEntities) + ' – ' + beautifyDuration(obj.result.totalTime);
    }
    else if (obj.result.totalEntities > 0) {
        document.getElementById('cardFooterQueueMini').innerText = t('Num songs', obj.result.totalEntities);
    }
    else {
        document.getElementById('cardFooterQueueMini').innerText = '';
    }
}

function parseQueueMini(obj) {
    let colsQueueMini = ["Pos", "Title", "Artist", "Album", "Duration"];
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('QueueMiniList');
    let activeRow = 0;
    table.setAttribute('data-version', obj.result.queueVersion);
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].Pos++;
        let row = document.createElement('tr');
        row.setAttribute('data-trackid', obj.result.data[i].id);
        row.setAttribute('id', 'queueMiniTrackId' + obj.result.data[i].id);
        row.setAttribute('data-songpos', obj.result.data[i].Pos);
        row.setAttribute('data-duration', obj.result.data[i].Duration);
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < colsQueueMini.length; c++) {
            tds += '<td data-col="' + colsQueueMini[c] + '">' + e(obj.result.data[i][colsQueueMini[c]]) + '</td>';
        }
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i--) {
        tr[i].remove();
    }
    document.getElementById('QueueMiniList').classList.remove('opacity05');
}


function updateDBstats() {
    sendAPI("MPD_API_DATABASE_STATS", {}, parseDBstats);
}

function parseDBstats(obj) {
    document.getElementById('panel-heading-browse').innerHTML = 'Library total: Tracks ' + obj.result.songs + ' &bull; Time ' + beautifyDuration(obj.result.dbPlaytime);
}

function calcBoxHeight() {
    if (app.current.app === 'Playback') {
        let p = document.getElementById('cardPlayback').offsetHeight;
        let qm = document.getElementById('cardQueueMini').offsetHeight;
        let bcb = document.getElementById('BrowseCovergridButtons').offsetHeight;
        let bcbb = document.getElementById('BrowseCovergridButtonsBottom').offsetHeight;
        let fb = document.getElementById('cardFooterBrowse').offsetHeight;
        let boxHeight = p + qm - bcb - bcbb - fb - 54 - 54 - 1;
        document.getElementById('BrowseCovergridBox').style.height = boxHeight + 'px';
    }
}

window.onresize = function () {
    calcBoxHeight();
};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parsePlaylists(obj) {
    if (app.current.view === 'All') {
        document.getElementById('BrowsePlaylistsAllList').classList.remove('hide');
        document.getElementById('BrowsePlaylistsDetailList').classList.add('hide');
        document.getElementById('btnBrowsePlaylistsAll').parentNode.classList.add('hide');
        document.getElementById('playlistContentBtns').classList.add('hide');
        document.getElementById('smartPlaylistContentBtns').classList.add('hide');
        document.getElementById('btnAddSmartpls').parentNode.classList.remove('hide');
    } else {
        if (obj.result.uri.indexOf('.') > -1 || obj.result.smartpls === true) {
            document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-ro', 'true')
            document.getElementById('playlistContentBtns').classList.add('hide');
            document.getElementById('smartPlaylistContentBtns').classList.remove('hide');
        }
        else {
            document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-ro', 'false');
            document.getElementById('playlistContentBtns').classList.remove('hide');
            document.getElementById('smartPlaylistContentBtns').classList.add('hide');
        }
        document.getElementById('BrowsePlaylistsDetailList').setAttribute('data-uri', obj.result.uri);
        document.getElementById('BrowsePlaylistsDetailList').getElementsByTagName('caption')[0].innerHTML = 
            (obj.result.smartpls === true ? t('Smart playlist') : t('Playlist'))  + ': ' + obj.result.uri;
        document.getElementById('BrowsePlaylistsDetailList').classList.remove('hide');
        document.getElementById('BrowsePlaylistsAllList').classList.add('hide');
        document.getElementById('btnBrowsePlaylistsAll').parentNode.classList.remove('hide');
        document.getElementById('btnAddSmartpls').parentNode.classList.add('hide');
    }
            
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById(app.current.app + app.current.tab + app.current.view + 'List');
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    if (app.current.view === 'All') {
        for (let i = 0; i < nrItems; i++) {
            let uri = encodeURI(obj.result.data[i].uri);
            let row = document.createElement('tr');
            row.setAttribute('data-uri', uri);
            row.setAttribute('data-type', obj.result.data[i].Type);
            row.setAttribute('data-name', obj.result.data[i].name);
            row.setAttribute('tabindex', 0);
            row.innerHTML = '<td data-col="Type"><span class="material-icons">' + (obj.result.data[i].Type === 'smartpls' ? 'queue_music' : 'list') + '</span></td>' +
                            '<td>' + e(obj.result.data[i].name) + '</td>' +
                            '<td>'+ localeDate(obj.result.data[i].last_modified) + '</td>' +
                            '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
            if (i < tr.length) {
                activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
            }
            else {
                tbody.append(row);
            }
        }
        document.getElementById('cardFooterBrowse').innerText = gtPage('Num playlists', obj.result.returnedEntities, obj.result.totalEntities);
    }
    else if (app.current.view === 'Detail') {
        for (let i = 0; i < nrItems; i++) {
            let uri = encodeURI(obj.result.data[i].uri);
            let row = document.createElement('tr');
            if (obj.result.smartpls === false) {
                row.setAttribute('draggable','true');
            }
            row.setAttribute('id','playlistTrackId' + obj.result.data[i].Pos);
            row.setAttribute('data-type', obj.result.data[i].Type);
            row.setAttribute('data-uri', uri);
            row.setAttribute('data-name', obj.result.data[i].Title);
            row.setAttribute('data-songpos', obj.result.data[i].Pos);
            row.setAttribute('tabindex', 0);
            obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
            let tds = '';
            for (let c = 0; c < settings.colsBrowsePlaylistsDetail.length; c++) {
                tds += '<td data-col="' + settings.colsBrowsePlaylistsDetail[c] + '">' + e(obj.result.data[i][settings.colsBrowsePlaylistsDetail[c]]) + '</td>';
            }
            tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
            row.innerHTML = tds;

            if (i < tr.length) {
                activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
            }
            else {
                tbody.append(row);
            }
        }
        document.getElementById('cardFooterBrowse').innerText = gtPage('Num songs', obj.result.returnedEntities, obj.result.totalEntities);
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    if (navigate === true) {
        focusTable(0);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    
    if (nrItems === 0) {
        if (app.current.view === 'All') {
            tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                              '<td colspan="3">' + t('No playlists found') + '</td></tr>';
        }
        else {
            tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                              '<td colspan="' + (settings.colsBrowsePlaylistsDetail.length - 1) + '">' + t('Empty playlist') + '</td></tr>';
        }
    }
            
    document.getElementById(app.current.app + app.current.tab + app.current.view + 'List').classList.remove('opacity05');
}

//eslint-disable-next-line no-unused-vars
function playlistDetails(uri) {
    document.getElementById('BrowsePlaylistsAllList').classList.add('opacity05');
    appGoto('Browse', 'Playlists', 'Detail', '0/-/-/' + uri);
}

//eslint-disable-next-line no-unused-vars
function playlistClear() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_CLEAR", {"uri": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function playlistShuffle() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_SHUFFLE", {"uri": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function playlistSort(tag) {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_PLAYLIST_SORT", {"uri": uri, "tag": tag});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

function getAllPlaylists(obj) {
    let nrItems = obj.result.returnedEntities;
    let playlists = '';
    if (obj.result.offset === 0) {
        if (playlistEl === 'addToPlaylistPlaylist') {
            playlists = '<option value=""></option><option value="new">' + t('New playlist') + '</option>';
        }
        else if (playlistEl === 'selectJukeboxPlaylist' || 
                 playlistEl === 'selectAddToQueuePlaylist' ||
                 playlistEl === 'selectTimerPlaylist'
        ) {
            playlists = '<option value="Database">' + t('Database') + '</option>';
        }
    }
    for (let i = 0; i < nrItems; i++) {
        if (playlistEl === 'addToPlaylistPlaylist' && obj.result.data[i].Type === 'smartpls') {
            continue;
        }
        playlists += '<option value="' + e(obj.result.data[i].uri) + '"';
        if (playlistEl === 'selectJukeboxPlaylist' && obj.result.data[i].uri === settings.jukeboxPlaylist) {
            playlists += ' selected';
        }
        playlists += '>' + e(obj.result.data[i].uri) + '</option>';
    }
    if (obj.result.offset === 0) {
        document.getElementById(playlistEl).innerHTML = playlists;
    }
    else {
        document.getElementById(playlistEl).innerHTML += playlists;
    }
    
    if (obj.result.totalEntities > obj.result.returnedEntities + obj.result.offset && obj.result.returnedEntities > 0) {
        obj.result.offset += settings.maxElementsPerPage;
        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": obj.result.offset, "filter": "-"}, getAllPlaylists);
    }
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylists() {
    sendAPI("MPD_API_SMARTPLS_UPDATE_ALL", {});
}

//eslint-disable-next-line no-unused-vars
function removeFromPlaylist(uri, pos) {
    pos--;
    sendAPI("MPD_API_PLAYLIST_RM_TRACK", {"uri": uri, "track": pos});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function toggleAddToPlaylistFrm() {
    let btn = document.getElementById('toggleAddToPlaylistBtn');
    toggleBtn('toggleAddToPlaylistBtn');
    if (btn.classList.contains('active')) {
        document.getElementById('addToPlaylistFrm').classList.remove('hide');
        document.getElementById('addStreamFooter').classList.add('hide');
        document.getElementById('addToPlaylistFooter').classList.remove('hide');
    }    
    else {
        document.getElementById('addToPlaylistFrm').classList.add('hide');
        document.getElementById('addStreamFooter').classList.remove('hide');
        document.getElementById('addToPlaylistFooter').classList.add('hide');
    }
}

function parseSmartPlaylist(obj) {
    let nameEl = document.getElementById('saveSmartPlaylistName');
    nameEl.value = obj.result.playlist;
    nameEl.classList.remove('is-invalid');
    document.getElementById('saveSmartPlaylistType').value = t(obj.result.type);
    document.getElementById('saveSmartPlaylistType').setAttribute('data-value', obj.result.type);
    document.getElementById('saveSmartPlaylistSearch').classList.add('hide');
    document.getElementById('saveSmartPlaylistSticker').classList.add('hide');
    document.getElementById('saveSmartPlaylistNewest').classList.add('hide');
    let tagList;
    if (settings.featTags) {
        tagList = '<option value="any">' + t('Any Tag') + '</option>';
    }
    tagList += '<option value="filename">' + t('Filename') + '</option>';
    for (let i = 0; i < settings.searchtags.length; i++) {
        tagList += '<option value="' + settings.searchtags[i] + '">' + t(settings.searchtags[i]) + '</option>';
    }
    let elSelectSaveSmartPlaylistTag = document.getElementById('selectSaveSmartPlaylistTag');
    elSelectSaveSmartPlaylistTag.innerHTML = tagList;
    if (obj.result.type === 'search') {
        document.getElementById('saveSmartPlaylistSearch').classList.remove('hide');
        document.getElementById('selectSaveSmartPlaylistTag').value = obj.result.tag;
        document.getElementById('inputSaveSmartPlaylistSearchstr').value = obj.result.searchstr;
        if (settings.featAdvsearch && obj.result.tag === 'expression') {
            elSelectSaveSmartPlaylistTag.parentNode.parentNode.classList.add('hide');
            elSelectSaveSmartPlaylistTag.innerHTML = '<option value="expression">expression</option>';
            elSelectSaveSmartPlaylistTag.value = 'expression';
        }
        else {
            document.getElementById('selectSaveSmartPlaylistTag').parentNode.parentNode.classList.remove('hide');
        }
    }
    else if (obj.result.type === 'sticker') {
        document.getElementById('saveSmartPlaylistSticker').classList.remove('hide');
        document.getElementById('selectSaveSmartPlaylistSticker').value = obj.result.sticker;
        document.getElementById('inputSaveSmartPlaylistStickerMaxentries').value = obj.result.maxentries;
        document.getElementById('inputSaveSmartPlaylistStickerMinvalue').value = obj.result.minvalue;
    }
    else if (obj.result.type === 'newest') {
        document.getElementById('saveSmartPlaylistNewest').classList.remove('hide');
        let timerange = obj.result.timerange / 24 / 60 / 60;
        document.getElementById('inputSaveSmartPlaylistNewestTimerange').value = timerange;
    }
    modalSaveSmartPlaylist.show();
    nameEl.focus();
}

//eslint-disable-next-line no-unused-vars
function saveSmartPlaylist() {
    let name = document.getElementById('saveSmartPlaylistName').value;
    let type = document.getElementById('saveSmartPlaylistType').getAttribute('data-value');
    let sortEl = document.getElementById('saveSmartPlaylistSort');
    let sort = sortEl.options[sortEl.selectedIndex].value;
    if (validatePlname(name) === true) {
        if (type === 'search') {
            let tagEl = document.getElementById('selectSaveSmartPlaylistTag');
            let tag = tagEl.options[tagEl.selectedIndex].value;
            let searchstr = document.getElementById('inputSaveSmartPlaylistSearchstr').value;
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "tag": tag, "searchstr": searchstr, "sort": sort});
        }
        else if (type === 'sticker') {
            let stickerEl = document.getElementById('selectSaveSmartPlaylistSticker');
            let sticker = stickerEl.options[stickerEl.selectedIndex].value;
            let maxentriesEl = document.getElementById('inputSaveSmartPlaylistStickerMaxentries');
            if (!validateInt(maxentriesEl)) {
                return;
            }
            let minvalueEl = document.getElementById('inputSaveSmartPlaylistStickerMinvalue');
            if (!validateInt(minvalueEl)) {
                return;
            }
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "sticker": sticker, "maxentries": parseInt(maxentriesEl.value), 
                "minvalue": parseInt(minvalueEl.value), "sort": sort});
        }
        else if (type === 'newest') {
            let timerangeEl = document.getElementById('inputSaveSmartPlaylistNewestTimerange');
            if (!validateInt(timerangeEl)) {
                return;
            }
            let timerange = parseInt(timerangeEl.value) * 60 * 60 * 24;
            sendAPI("MPD_API_SMARTPLS_SAVE", {"type": type, "playlist": name, "timerange": timerange, "sort": sort});
        }
        else {
            document.getElementById('saveSmartPlaylistType').classList.add('is-invalid');
            return;
        }
        modalSaveSmartPlaylist.hide();
        showNotification(t('Saved smart playlist %{name}', {"name": name}), '', '', 'success');
    }
    else {
        document.getElementById('saveSmartPlaylistName').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function addSmartpls(type) {
    let obj = {"jsonrpc":"2.0", "id":0, "result": {"method":"MPD_API_SMARTPLS_GET"}};
    if (type === 'mostPlayed') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'mostPlayed';
        obj.result.type = 'sticker';
        obj.result.sticker = 'playCount';
        obj.result.maxentries = 200;
        obj.result.minvalue = 10;
    }
    else if (type === 'newest') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'newestSongs';
        obj.result.type = 'newest';
        obj.result.timerange = 14 * 24 * 60 * 60;
    }
    else if (type === 'bestRated') {
        obj.result.playlist = settings.smartplsPrefix + (settings.smartplsPrefix !== '' ? '-' : '') + 'bestRated';
        obj.result.type = 'sticker';
        obj.result.sticker = 'like';
        obj.result.maxentries = 200;
        obj.result.minvalue = 2;
    }
    parseSmartPlaylist(obj);
}

//eslint-disable-next-line no-unused-vars
function deletePlaylists() {
    let selectDeletePlaylists = document.getElementById('selectDeletePlaylists');
    let btnDeletePlaylists = document.getElementById('btnDeletePlaylists');
    btnWaiting(btnDeletePlaylists, true);
    sendAPI("MPD_API_PLAYLIST_RM_ALL", {"type": selectDeletePlaylists.options[selectDeletePlaylists.selectedIndex].value}, function() {
        btnWaiting(btnDeletePlaylists, false);
    });
}

//eslint-disable-next-line no-unused-vars
function showAddToPlaylistCurrentSong() {
    let uri = document.getElementById('currentTitle').getAttribute('data-uri');
    if (uri !== '') {
        showAddToPlaylist(uri, '');
    }
}

function showAddToPlaylist(uri, searchstr) {
    document.getElementById('addToPlaylistUri').value = uri;
    document.getElementById('addToPlaylistSearch').value = searchstr;
    document.getElementById('addToPlaylistPlaylist').innerHTML = '';
    document.getElementById('addToPlaylistNewPlaylist').value = '';
    document.getElementById('addToPlaylistNewPlaylistDiv').classList.add('hide');
    document.getElementById('addToPlaylistNewPlaylist').classList.remove('is-invalid');
    toggleBtn('toggleAddToPlaylistBtn',0);
    let streamUrl = document.getElementById('streamUrl')
    streamUrl.focus();
    streamUrl.value = '';
    streamUrl.classList.remove('is-invalid');
    if (uri !== 'stream') {
        document.getElementById('addStreamFooter').classList.add('hide');
        document.getElementById('addStreamFrm').classList.add('hide');
        document.getElementById('addToPlaylistFooter').classList.remove('hide');
        document.getElementById('addToPlaylistFrm').classList.remove('hide');
        document.getElementById('addToPlaylistCaption').innerText = t('Add to playlist');
    }
    else {
        document.getElementById('addStreamFooter').classList.remove('hide');
        document.getElementById('addStreamFrm').classList.remove('hide');
        document.getElementById('addToPlaylistFooter').classList.add('hide');
        document.getElementById('addToPlaylistFrm').classList.add('hide');
        document.getElementById('addToPlaylistCaption').innerText = t('Add stream');
    }
    modalAddToPlaylist.show();
    if (settings.featPlaylists) {
        playlistEl = 'addToPlaylistPlaylist';
        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": 0, "filter": "-"}, getAllPlaylists);
    }
}

//eslint-disable-next-line no-unused-vars
function addToPlaylist() {
    let uri = decodeURI(document.getElementById('addToPlaylistUri').value);
    if (uri === 'stream') {
        uri = document.getElementById('streamUrl').value;
        if (uri === '' || uri.indexOf('http') === -1) {
            document.getElementById('streamUrl').classList.add('is-invalid');
            return;
        }
    }
    let plistEl = document.getElementById('addToPlaylistPlaylist');
    let plist = plistEl.options[plistEl.selectedIndex].value;
    if (plist === 'new') {
        let newPl = document.getElementById('addToPlaylistNewPlaylist').value;
        if (validatePlname(newPl) === true) {
            plist = newPl;
        } else {
            document.getElementById('addToPlaylistNewPlaylist').classList.add('is-invalid');
            return;
        }
    }
    if (plist !== '') {
        if (uri === 'SEARCH') {
            addAllFromSearchPlist(plist, null, false);
        }
        if (uri === 'ALBUM') {
            let expression = document.getElementById('addToPlaylistSearch').value;
            addAllFromSearchPlist(plist, expression, false);
        }
        else if (uri === 'DATABASE') {
            addAllFromBrowseDatabasePlist(plist);
        }
        else {
            sendAPI("MPD_API_PLAYLIST_ADD_TRACK", {"uri": uri, "plist": plist});
        }
        modalAddToPlaylist.hide();
    }
    else {
        document.getElementById('addToPlaylistPlaylist').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function showRenamePlaylist(from) {
    document.getElementById('renamePlaylistTo').classList.remove('is-invalid');
    modalRenamePlaylist.show();
    document.getElementById('renamePlaylistFrom').value = from;
    document.getElementById('renamePlaylistTo').value = '';
}

//eslint-disable-next-line no-unused-vars
function renamePlaylist() {
    let from = document.getElementById('renamePlaylistFrom').value;
    let to = document.getElementById('renamePlaylistTo').value;
    if (to !== from && validatePlname(to) === true && validatePlname(from) === true) {
        sendAPI("MPD_API_PLAYLIST_RENAME", {"from": from, "to": to});
        modalRenamePlaylist.hide();
    }
    else {
        document.getElementById('renamePlaylistTo').classList.add('is-invalid');
    }
}

//eslint-disable-next-line no-unused-vars
function showSmartPlaylist(playlist) {
    sendAPI("MPD_API_SMARTPLS_GET", {"playlist": playlist}, parseSmartPlaylist);
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylist(playlist) {
    sendAPI("MPD_API_SMARTPLS_UPDATE", {"playlist": playlist});
}

//eslint-disable-next-line no-unused-vars
function updateSmartPlaylistClick() {
    let uri = document.getElementById('BrowsePlaylistsDetailList').getAttribute('data-uri');
    sendAPI("MPD_API_SMARTPLS_UPDATE", {"playlist": uri});
    document.getElementById('BrowsePlaylistsDetailList').classList.add('opacity05');    
}

//eslint-disable-next-line no-unused-vars
function showDelPlaylist(uri) {
    document.getElementById('deletePlaylist').value = uri;
    modalDeletePlaylist.show();
}

//eslint-disable-next-line no-unused-vars
function delPlaylist() {
    let uri = document.getElementById('deletePlaylist').value;
    sendAPI("MPD_API_PLAYLIST_RM", {"uri": uri});
    modalDeletePlaylist.hide();
}

function playlistMoveTrack(from, to) {
    sendAPI("MPD_API_PLAYLIST_MOVE_TRACK", {"plist": app.current.search, "from": from, "to": to});
}

//eslint-disable-next-line no-unused-vars
function addSelectedItemToPlaylist() {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id === 'BrowsePlaylistsAllList') {
            return;
        }
        showAddToPlaylist(item.getAttribute('data-uri'), '');
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function b64EncodeUnicode(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
            return String.fromCharCode('0x' + p1);
    }));
}

function b64DecodeUnicode(str) {
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

function addMenuItem(href, text) {
    return '<a class="dropdown-item" href="#" data-href=\'' + b64EncodeUnicode(JSON.stringify(href)) + '\'>' + text +'</a>';
}

function hideMenu() {
    let menuEl = document.querySelector('[data-popover]');
    if (menuEl) {
        new Popover(menuEl, {});
        menuEl.Popover.hide();
        menuEl.removeAttribute('data-popover');
        if (menuEl.parentNode.parentNode.classList.contains('selected')) {
            focusTable(undefined, menuEl.parentNode.parentNode.parentNode.parentNode);
        }
        else if (app.current.app === 'Browse' && app.current.tab === 'Covergrid') {
            focusTable(undefined, menuEl.parentNode.parentNode.parentNode.parentNode);
        }
    }
}

function showMenu(el, event) {
    event.preventDefault();
    event.stopPropagation();
    hideMenu();
    if (el.getAttribute('data-init')) {
        return;
    }
    if (el.parentNode.nodeName === 'TH') {
        showMenuTh(el);
    }
    else {
        showMenuTd(el);
    }
}

function showMenuTh(el) {
    let table = app.current.app + (app.current.tab !== undefined ? app.current.tab : '') + (app.current.view !== undefined ? app.current.view : '');
    let menu = '<form class="p-2" id="colChecklist' + table + '">';
    menu += setColsChecklist(table);
    menu += '<button class="btn btn-success btn-block btn-sm mt-2">' + t('Apply') + '</button>';
    menu += '</form>';
    new Popover(el, { trigger: 'click', delay: 0, dismissible: true, template: '<div class="popover" role="tooltip">' +
        '<div class="arrow"></div>' +
        '<div class="popover-content" id="' + table + 'ColsDropdown' + '">' + menu + '</div>' +
        '</div>', content: ' '});
    let popoverInit = el.Popover;
    el.setAttribute('data-init', 'true');
    el.addEventListener('shown.bs.popover', function(event) {
        event.target.setAttribute('data-popover', 'true');
        document.getElementById('colChecklist' + table).addEventListener('click', function(eventClick) {
            if (eventClick.target.nodeName === 'BUTTON' && eventClick.target.classList.contains('material-icons')) {
                toggleBtnChk(eventClick.target);
                eventClick.preventDefault();
                eventClick.stopPropagation();
            }
            else if (eventClick.target.nodeName === 'BUTTON') {
                eventClick.preventDefault();
                saveCols(table);
            }
        }, false);
    }, false);
    popoverInit.show();
}

function showMenuTd(el) {
    let type = el.getAttribute('data-type');
    let uri = decodeURI(el.getAttribute('data-uri'));
    let name = decodeURI(el.getAttribute('data-name'));
    let nextsongpos = 0;
    if (type === null || uri === '') {
        type = el.parentNode.parentNode.getAttribute('data-type');
        uri = decodeURI(el.parentNode.parentNode.getAttribute('data-uri'));
        name = el.parentNode.parentNode.getAttribute('data-name');
    }
    
    if (lastState) {
        nextsongpos = lastState.nextSongPos;
    }

    let menu = '';
    if ((app.current.app === 'Browse' && app.current.tab === 'Filesystem') || app.current.app === 'Search' ||
        (app.current.app === 'Browse' && app.current.tab === 'Database') ||
        (app.current.app === 'Browse' && app.current.tab === 'Covergrid' && el.nodeName === 'A')) {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            (type === 'song' ? addMenuItem({"cmd": "appendAfterQueue", "options": [type, uri, nextsongpos, name]}, t('Add after current playing song')) : '') +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (type !== 'plist' && type !== 'smartpls' && settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (type === 'song' ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '') +
            (type === 'plist' || type === 'smartpls' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('View playlist')) : '') +
            (type === 'dir' && settings.featBookmarks ? addMenuItem({"cmd": "showBookmarkSave", "options": [-1, name, uri, type]}, t('Add bookmark')) : '');
        if (app.current.tab === 'Filesystem') {
            menu += (type === 'dir' ? addMenuItem({"cmd": "updateDB", "options": [dirname(uri), true]}, t('Update directory')) : '') +
                (type === 'dir' ? addMenuItem({"cmd": "rescanDB", "options": [dirname(uri), true]}, t('Rescan directory')) : '');
        }
        if (app.current.app === 'Search') {
            //songs must be arragend in one album per folder
            let baseuri = dirname(uri);
            menu += '<div class="dropdown-divider"></div>' +
                '<a class="dropdown-item" id="advancedMenuLink" data-toggle="collapse" href="#advancedMenu"><span class="material-icons material-icons-small-left">keyboard_arrow_right</span>Album actions</a>' +
                '<div class="collapse" id="advancedMenu">' +
                    addMenuItem({"cmd": "appendQueue", "options": [type, baseuri, name]}, t('Append to queue')) +
                    addMenuItem({"cmd": "appendAfterQueue", "options": [type, baseuri, nextsongpos, name]}, t('Add after current playing song')) +
                    addMenuItem({"cmd": "replaceQueue", "options": [type, baseuri, name]}, t('Replace queue')) +
                    (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [baseuri, ""]}, t('Add to playlist')) : '') +
                '</div>';
        }
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'All') {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('View playlist')) : addMenuItem({"cmd": "playlistDetails", "options": [uri]}, t('Edit playlist')))+
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "showSmartPlaylist", "options": [uri]}, t('Edit smart playlist')) : '') +
            (settings.smartpls === true && type === 'smartpls' ? addMenuItem({"cmd": "updateSmartPlaylist", "options": [uri]}, t('Update smart playlist')) : '') +
            addMenuItem({"cmd": "showRenamePlaylist", "options": [uri]}, t('Rename playlist')) + 
            addMenuItem({"cmd": "showDelPlaylist", "options": [uri]}, t('Delete playlist'));
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        let x = document.getElementById('BrowsePlaylistsDetailList');
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (x.getAttribute('data-ro') === 'false' ? addMenuItem({"cmd": "removeFromPlaylist", "options": [x.getAttribute('data-uri'), 
                    el.parentNode.parentNode.getAttribute('data-songpos')]}, t('Remove')) : '') +
            (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'Current') {
        menu += addMenuItem({"cmd": "delQueueSong", "options": ["single", el.parentNode.parentNode.getAttribute('data-trackid')]}, t('Remove')) +
            addMenuItem({"cmd": "delQueueSong", "options": ["range", 0, el.parentNode.parentNode.getAttribute('data-songpos')]}, t('Remove all upwards')) +
            addMenuItem({"cmd": "delQueueSong", "options": ["range", (parseInt(el.parentNode.parentNode.getAttribute('data-songpos'))-1), -1]}, t('Remove all downwards')) +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        menu += addMenuItem({"cmd": "appendQueue", "options": [type, uri, name]}, t('Append to queue')) +
            addMenuItem({"cmd": "replaceQueue", "options": [type, uri, name]}, t('Replace queue')) +
            (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": [uri, ""]}, t('Add to playlist')) : '') +
            (uri.indexOf('http') === -1 ? addMenuItem({"cmd": "songDetails", "options": [uri]}, t('Song details')) : '');
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Covergrid' && el.nodeName === 'DIV') {
        let album = decodeURI(el.parentNode.getAttribute('data-album'));
        let albumArtist = decodeURI(el.parentNode.getAttribute('data-albumartist'));
        let expression = '((Album == \'' + album + '\') AND (AlbumArtist == \'' + albumArtist + '\'))';
        let id = el.parentNode.getElementsByClassName('card-body')[0].getAttribute('id');
        menu += addMenuItem({"cmd": "getCovergridTitleList", "options": [id]}, t('Show songs')) +
            addMenuItem({"cmd": "addAllFromSearchPlist", "options": ["queue", expression, false]}, t('Append to queue')) +
            addMenuItem({"cmd": "addAllFromSearchPlist", "options": ["queue", expression, true]}, t('Replace queue')) +
            (settings.featPlaylists ? addMenuItem({"cmd": "showAddToPlaylist", "options": ["ALBUM", expression]}, t('Add to playlist')) : '');
    }

    new Popover(el, { trigger: 'click', delay: 0, dismissible: true, template: '<div class="popover" role="tooltip">' +
        '<div class="arrow"></div>' +
        '<div class="popover-content">' + menu + '</div>' +
        '</div>', content: ' '});
    let popoverInit = el.Popover;
    el.setAttribute('data-init', 'true');
    el.addEventListener('shown.bs.popover', function(event) {
        event.target.setAttribute('data-popover', 'true');
        document.getElementsByClassName('popover-content')[0].addEventListener('click', function(eventClick) {
            eventClick.preventDefault();
            eventClick.stopPropagation();
            if (eventClick.target.nodeName === 'A') {
                let dh = eventClick.target.getAttribute('data-href');
                if (dh) {
                    let cmd = JSON.parse(b64DecodeUnicode(dh));
                    parseCmd(event, cmd);
                    hideMenu();
                }
            }
        }, false);
        document.getElementsByClassName('popover-content')[0].addEventListener('keydown', function(eventKey) {
            eventKey.preventDefault();
            eventKey.stopPropagation();
            if (eventKey.key === 'ArrowDown' || eventKey.key === 'ArrowUp') {
                let menuItemsHtml = this.getElementsByTagName('a');
                let menuItems = Array.prototype.slice.call(menuItemsHtml);
                let idx = menuItems.indexOf(document.activeElement);
                do {
                    idx = eventKey.key === 'ArrowUp' ? (idx > 1 ? idx - 1 : 0)
                                                 : eventKey.key === 'ArrowDown' ? ( idx < menuItems.length - 1 ? idx + 1 : idx)
                                                                            : idx;
                    if ( idx === 0 || idx === menuItems.length -1 ) {
                        break;
                    }
                } while ( !menuItems[idx].offsetHeight )
                menuItems[idx] && menuItems[idx].focus();
            }
            else if (eventKey.key === 'Enter') {
                eventKey.target.click();
            }
            else if (eventKey.key === 'Escape') {
                hideMenu();
            }
        }, false);
        let collapseLink = document.getElementById('advancedMenuLink');
        if (collapseLink) {
            collapseLink.addEventListener('click', function() {
                let icon = this.getElementsByTagName('span')[0];
                if (icon.innerText === 'keyboard_arrow_right') {
                    icon.innerText = 'keyboard_arrow_down';
                }
                else {
                    icon.innerText = 'keyboard_arrow_right';
                }
            }, false);
            new Collapse(collapseLink);
        }
        document.getElementsByClassName('popover-content')[0].firstChild.focus();
    }, false);
    popoverInit.show();
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parseUpdateQueue(obj) {
    //Set playstate
    if (obj.result.state === 1) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].innerText = 'play_arrow';
        }
        playstate = 'stop';
    }
    else if (obj.result.state === 2) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].innerText = 'pause';
        }
        playstate = 'play';
    }
    else {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].innerText = 'play_arrow';
        }
	playstate = 'pause';
    }

    if (obj.result.queueLength === 0) {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].setAttribute('disabled', 'disabled');
        }
    }
    else {
        for (let i = 0; i < domCache.btnsPlayLen; i++) {
            domCache.btnsPlay[i].removeAttribute('disabled');
        }
    }

    mediaSessionSetState();
    mediaSessionSetPositionState(obj.result.totalTime, obj.result.elapsedTime);

    domCache.badgeQueueItems.innerText = obj.result.queueLength;
    
    if (obj.result.nextSongPos === -1 && settings.jukeboxMode === false) {
        domCache.btnNext.setAttribute('disabled', 'disabled');
    }
    else {
        domCache.btnNext.removeAttribute('disabled');
    }
    
    if (obj.result.songPos <= 0) {
        domCache.btnPrev.setAttribute('disabled', 'disabled');
    }
    else {
        domCache.btnPrev.removeAttribute('disabled');
    }
}

function getQueue() {
    if (app.current.search.length >= 2) {
        sendAPI("MPD_API_QUEUE_SEARCH", {"filter": app.current.filter, "offset": app.current.page, "searchstr": app.current.search, "cols": settings.colsQueueCurrent}, parseQueue);
    }
    else {
        sendAPI("MPD_API_QUEUE_LIST", {"offset": app.current.page, "cols": settings.colsQueueCurrent}, parseQueue);
    }
}

function parseQueue(obj) {
    if (obj.result.totalTime && obj.result.totalTime > 0 && obj.result.totalEntities <= settings.maxElementsPerPage ) {
        document.getElementById('cardFooterQueue').innerText = t('Num songs', obj.result.totalEntities) + ' – ' + beautifyDuration(obj.result.totalTime);
    }
    else if (obj.result.totalEntities > 0) {
        document.getElementById('cardFooterQueue').innerText = t('Num songs', obj.result.totalEntities);
    }
    else {
        document.getElementById('cardFooterQueue').innerText = '';
    }

    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('QueueCurrentList');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    table.setAttribute('data-version', obj.result.queueVersion);
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].Pos++;
        let row = document.createElement('tr');
        row.setAttribute('draggable', 'true');
        row.setAttribute('data-trackid', obj.result.data[i].id);
        row.setAttribute('id','queueTrackId' + obj.result.data[i].id);
        row.setAttribute('data-songpos', obj.result.data[i].Pos);
        row.setAttribute('data-duration', obj.result.data[i].Duration);
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < settings.colsQueueCurrent.length; c++) {
            tds += '<td data-col="' + settings.colsQueueCurrent[c] + '">' + e(obj.result.data[i][settings.colsQueueCurrent[c]]) + '</td>';
        }
        tds += '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a></td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }

    let colspan = settings['colsQueueCurrent'].length;
    colspan--;

    if (obj.result.method === 'MPD_API_QUEUE_SEARCH' && nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('No results, please refine your search') + '</td></tr>';
    }
    else if (obj.result.method === 'MPD_API_QUEUE_ADD_TRACK' && nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="' + colspan + '">' + t('Empty queue') + '</td></tr>';
    }

    if (navigate === true) {
        focusTable(activeRow);
    }
    
    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    document.getElementById('QueueCurrentList').classList.remove('opacity05');
}

function parseLastPlayed(obj) {
    document.getElementById('cardFooterQueue').innerText = t('Num songs', obj.result.totalEntities);
    let nrItems = obj.result.returnedEntities;
    let table = document.getElementById('QueueLastPlayedList');
    let navigate = document.activeElement.parentNode.parentNode === table ? true : false;
    let activeRow = 0;
    let tbody = table.getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    for (let i = 0; i < nrItems; i++) {
        obj.result.data[i].Duration = beautifySongDuration(obj.result.data[i].Duration);
        obj.result.data[i].LastPlayed = localeDate(obj.result.data[i].LastPlayed);
        let row = document.createElement('tr');
        row.setAttribute('data-uri', obj.result.data[i].uri);
        row.setAttribute('data-name', obj.result.data[i].Title);
        row.setAttribute('data-type', 'song');
        row.setAttribute('tabindex', 0);
        let tds = '';
        for (let c = 0; c < settings.colsQueueLastPlayed.length; c++) {
            tds += '<td data-col="' + settings.colsQueueLastPlayed[c] + '">' + e(obj.result.data[i][settings.colsQueueLastPlayed[c]]) + '</td>';
        }
        tds += '<td data-col="Action">';
        if (obj.result.data[i].uri !== '') {
            tds += '<a href="#" class="material-icons color-darkgrey">' + ligatureMore + '</a>';
        }
        tds += '</td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= nrItems; i --) {
        tr[i].remove();
    }                    

    let colspan = settings['colsQueueLastPlayed'].length;
    colspan--;
    
    if (nrItems === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
            '<td colspan="' + colspan + '">' + t('Empty list') + '</td></tr>';
    }

    if (navigate === true) {
        focusTable(activeRow);
    }

    setPagination(obj.result.totalEntities, obj.result.returnedEntities);
    document.getElementById('QueueLastPlayedList').classList.remove('opacity05');
}

//eslint-disable-next-line no-unused-vars
function queueSelectedItem(append) {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id === 'QueueCurrentList') {
            return;
        }
        if (append === true) {
            appendQueue(item.getAttribute('data-type'), item.getAttribute('data-uri'), item.getAttribute('data-name'));
        }
        else {
            replaceQueue(item.getAttribute('data-type'), item.getAttribute('data-uri'), item.getAttribute('data-name'));
        }
    }
}

//eslint-disable-next-line no-unused-vars
function dequeueSelectedItem() {
    let item = document.activeElement;
    if (item) {
        if (item.parentNode.parentNode.id !== 'QueueCurrentList') {
            return;
        }
        delQueueSong('single', item.getAttribute('data-trackid'));
    }
}

function appendQueue(type, uri, name) {
    switch(type) {
        case 'song':
        case 'dir':
            sendAPI("MPD_API_QUEUE_ADD_TRACK", {"uri": uri});
            showNotification(t('%{name} added to queue', {"name": name}), '', '', 'success');
            break;
        case 'plist':
            sendAPI("MPD_API_QUEUE_ADD_PLAYLIST", {"plist": uri});
            showNotification(t('%{name} added to queue', {"name": name}), '', '', 'success');
            break;
    }
}

//eslint-disable-next-line no-unused-vars
function appendAfterQueue(type, uri, to, name) {
    switch(type) {
        case 'song':
            sendAPI("MPD_API_QUEUE_ADD_TRACK_AFTER", {"uri": uri, "to": to});
            to++;
            showNotification(t('%{name} added to queue position %{to}', {"name": name, "to": to}), '', '', 'success');
            break;
    }
}

function replaceQueue(type, uri, name) {
    switch(type) {
        case 'song':
        case 'dir':
            sendAPI("MPD_API_QUEUE_REPLACE_TRACK", {"uri": uri});
            showNotification(t('Queue replaced with %{name}', {"name": name}), '', '', 'success');
            break;
        case 'plist':
            sendAPI("MPD_API_QUEUE_REPLACE_PLAYLIST", {"plist": uri});
            showNotification(t('Queue replaced with %{name}', {"name": name}), '', '', 'success');
            break;
    }
}

//eslint-disable-next-line no-unused-vars
function addToQueue() {
    let formOK = true;
    let inputAddToQueueQuantityEl = document.getElementById('inputAddToQueueQuantity');
    if (!validateInt(inputAddToQueueQuantityEl)) {
        formOK = false;
    }
    
    let selectAddToQueueMode = document.getElementById('selectAddToQueueMode');
    let jukeboxMode = selectAddToQueueMode.options[selectAddToQueueMode.selectedIndex].value

    let selectAddToQueuePlaylist = document.getElementById('selectAddToQueuePlaylist');
    let jukeboxPlaylist = selectAddToQueuePlaylist.options[selectAddToQueuePlaylist.selectedIndex].value;
    
    if (jukeboxMode === '1' && settings.featSearchwindow === false && jukeboxPlaylist === 'Database') {
        document.getElementById('warnJukeboxPlaylist2').classList.remove('hide');
        formOK = false;
    }
    
    if (formOK === true) {
        sendAPI("MPD_API_QUEUE_ADD_RANDOM", {
            "mode": jukeboxMode,
            "playlist": jukeboxPlaylist,
            "quantity": document.getElementById('inputAddToQueueQuantity').value
        });
        modalAddToQueue.hide();
    }
}

//eslint-disable-next-line no-unused-vars
function saveQueue() {
    let plName = document.getElementById('saveQueueName').value;
    if (validatePlname(plName) === true) {
        sendAPI("MPD_API_QUEUE_SAVE", {"plist": plName});
        modalSaveQueue.hide();
    }
    else {
        document.getElementById('saveQueueName').classList.add('is-invalid');
    }
}

function delQueueSong(mode, start, end) {
    if (mode === 'range') {
        sendAPI("MPD_API_QUEUE_RM_RANGE", {"start": start, "end": end});
    }
    else if (mode === 'single') {
        sendAPI("MPD_API_QUEUE_RM_TRACK", { "track": start});
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function search(x) {
    if (settings.featAdvsearch) {
        let expression = '(';
        let crumbs = domCache.searchCrumb.children;
        for (let i = 0; i < crumbs.length; i++) {
            expression += '(' + decodeURI(crumbs[i].getAttribute('data-filter')) + ')';
            if (x !== '') expression += ' AND ';
        }
        if (x !== '') {
            let match = document.getElementById('searchMatch');
            expression += '(' + app.current.filter + ' ' + match.options[match.selectedIndex].value + ' \'' + x +'\'))';
        }
        else
            expression += ')';
        if (expression.length <= 2)
            expression = '';
        appGoto('Search', undefined, undefined, '0/' + app.current.filter + '/' + app.current.sort + '/' + encodeURI(expression));
    }
    else
        appGoto('Search', undefined, undefined, '0/' + app.current.filter + '/' + app.current.sort + '/' + x);
}

function parseSearch(obj) {
    document.getElementById('panel-heading-search').innerText = gtPage('Num songs', obj.result.returnedEntities, obj.result.totalEntities);
    document.getElementById('cardFooterSearch').innerText = gtPage('Num songs', obj.result.returnedEntities, obj.result.totalEntities);
    
    if (obj.result.returnedEntities > 0) {
        document.getElementById('searchAddAllSongs').removeAttribute('disabled');
        document.getElementById('searchAddAllSongsBtn').removeAttribute('disabled');
    } 
    else {
        document.getElementById('searchAddAllSongs').setAttribute('disabled', 'disabled');
        document.getElementById('searchAddAllSongsBtn').setAttribute('disabled', 'disabled');
    }
    parseFilesystem(obj);
}

function saveSearchAsSmartPlaylist() {
    parseSmartPlaylist({"jsonrpc":"2.0","id":0,"result":{"method":"MPD_API_SMARTPLS_GET", 
        "playlist":"",
        "type":"search",
        "tag": app.current.filter,
        "searchstr": app.current.search}});
}

function addAllFromSearchPlist(plist, searchstr, replace) {
    if (searchstr === null) {
        searchstr = app.current.search;    
    }
    if (settings.featAdvsearch) {
        sendAPI("MPD_API_DATABASE_SEARCH_ADV", {"plist": plist, 
            "sort": "", 
            "sortdesc": false, 
            "expression": searchstr,
            "offset": 0, 
            "cols": settings.colsSearch, 
            "replace": replace});
    }
    else {
        sendAPI("MPD_API_DATABASE_SEARCH", {"plist": plist, 
            "filter": app.current.filter, 
            "searchstr": searchstr,
            "offset": 0, 
            "cols": settings.colsSearch, 
            "replace": replace});
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function saveConnection() {
    let formOK = true;
    let mpdHostEl = document.getElementById('inputMpdHost');
    let mpdPortEl = document.getElementById('inputMpdPort');
    let mpdPassEl = document.getElementById('inputMpdPass');
    let musicDirectoryEl  = document.getElementById('selectMusicDirectory');
    let musicDirectory = musicDirectoryEl.options[musicDirectoryEl.selectedIndex].value;
    
    if (musicDirectory === 'custom') {
        let musicDirectoryValueEl  = document.getElementById('inputMusicDirectory');
        if (!validatePath(musicDirectoryValueEl)) {
            formOK = false;        
        }
        musicDirectory = musicDirectoryValueEl.value;
    }    
    
    if (mpdPortEl.value === '') {
        mpdPortEl.value = '6600';
    }
    if (mpdHostEl.value.indexOf('/') !== 0) {
        if (!validateInt(mpdPortEl)) {
            formOK = false;        
        }
        if (!validateHost(mpdHostEl)) {
            formOK = false;        
        }
    }
    if (formOK === true) {
        sendAPI("MYMPD_API_CONNECTION_SAVE", {"mpdHost": mpdHostEl.value, "mpdPort": mpdPortEl.value, "mpdPass": mpdPassEl.value, "musicDirectory": musicDirectory}, getSettings);
        modalConnection.hide();    
    }
}

function getSettings(onerror) {
    if (settingsLock === false) {
        settingsLock = true;
        sendAPI("MYMPD_API_SETTINGS_GET", {}, getMpdSettings, onerror);
    }
}

function getMpdSettings(obj) {
    if (obj !== '' && obj.result) {
        settingsNew = obj.result;
        document.getElementById('splashScreenAlert').innerText = t('Fetch MPD settings');
        sendAPI("MPD_API_SETTINGS_GET", {}, joinSettings, true);
    }
    else {
        settingsParsed = 'error';
        if (appInited === false) {
            showAppInitAlert(obj === '' ? t('Can not parse settings') : t(obj.error.message));
        }
        return false;
    }
}

function joinSettings(obj) {
    if (obj !== '' && obj.result) {
        for (let key in obj.result) {
            settingsNew[key] = obj.result[key];
        }
    }
    else {
        settingsParsed = 'error';
        if (appInited === false) {
            showAppInitAlert(obj === '' ? t('Can not parse settings') : t(obj.error.message));
        }
        settingsNew.mpdConnected = false;
    }
    settings = Object.assign({}, settingsNew);
    settingsLock = false;
    parseSettings();
    toggleUI();
    sendAPI("MPD_API_URLHANDLERS", {}, parseUrlhandlers,false);
    btnWaiting(document.getElementById('btnApplySettings'), false);
}

function parseUrlhandlers(obj) {
    let storagePlugins = '';
    for (let i = 0; i < obj.result.data.length; i++) {
        switch(obj.result.data[i]) {
            case 'http://':
            case 'https://':
            case 'nfs://':
            case 'smb://':
                storagePlugins += '<option value="' + obj.result.data[i] + '">' + obj.result.data[i] + '</option>';
                break;
        }
    }
    storagePlugins += '<option value="udisks://">udisks://</option>';
    document.getElementById('selectMountUrlhandler').innerHTML = storagePlugins;
}

function checkConsume() {
    let stateConsume = document.getElementById('btnConsume').classList.contains('active') ? true : false;
    let stateJukeboxMode = getBtnGroupValue('btnJukeboxModeGroup');
    if (stateJukeboxMode > 0 && stateConsume === false) {
        document.getElementById('warnConsume').classList.remove('hide');
    }
    else {
        document.getElementById('warnConsume').classList.add('hide');
    }
}

function parseSettings() {
    if (settings.locale === 'default') {
        locale = navigator.language || navigator.userLanguage;
    }
    else {
        locale = settings.locale;
    }

    let setTheme = settings.theme;
    if (settings.theme === 'theme-autodetect') {
        setTheme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'theme-dark' : 'theme-default';
    }    

    Object.keys(themes).forEach(function(key) {
        if (key === setTheme) {
            domCache.body.classList.add(key);
        }
        else {
            domCache.body.classList.remove(key);
        }
    });
    
    document.getElementById('selectTheme').value = settings.theme;
    
    if (settings.mpdConnected === true) {
        parseMPDSettings();
    }
    
    if (settings.mpdHost.indexOf('/') !== 0) {
        document.getElementById('mpdInfo_host').innerText = settings.mpdHost + ':' + settings.mpdPort;
    }
    else {
        document.getElementById('mpdInfo_host').innerText = settings.mpdHost;
    }
    
    document.getElementById('inputMpdHost').value = settings.mpdHost;
    document.getElementById('inputMpdPort').value = settings.mpdPort;
    document.getElementById('inputMpdPass').value = settings.mpdPass;

    let btnNotifyWeb = document.getElementById('btnNotifyWeb');
    document.getElementById('warnNotifyWeb').classList.add('hide');
    if (notificationsSupported()) {
        if (Notification.permission !== 'granted') {
            if (settings.notificationWeb === true) {
                document.getElementById('warnNotifyWeb').classList.remove('hide');
            }
            settings.notificationWeb = false;
        }
        if (Notification.permission === 'denied') {
            document.getElementById('warnNotifyWeb').classList.remove('hide');
        }
        toggleBtnChk('btnNotifyWeb', settings.notificationWeb);
        btnNotifyWeb.removeAttribute('disabled');
    }
    else {
        btnNotifyWeb.setAttribute('disabled', 'disabled');
        toggleBtnChk('btnNotifyWeb', false);
    }
    
    toggleBtnChk('btnNotifyPage', settings.notificationPage);
    toggleBtnChk('btnMediaSession', settings.mediaSession);
    toggleBtnChkCollapse('btnFeatLocalplayer', 'collapseLocalplayer', settings.featLocalplayer);
    toggleBtnChk('btnLocalplayerAutoplay', settings.localplayerAutoplay);
    toggleBtnChk('btnFeatTimer', settings.featTimer);
    toggleBtnChk('btnBookmarks', settings.featBookmarks);
    toggleBtnChk('btnFeatLyrics', settings.featLyrics);

    if (settings.streamUrl === '') {
        document.getElementById('selectStreamMode').value = 'port';
        document.getElementById('inputStreamUrl').value = settings.streamPort;
    }
    else {
        document.getElementById('selectStreamMode').value = 'url';
        document.getElementById('inputStreamUrl').value = settings.streamUrl;
    }
    toggleBtnChkCollapse('btnCoverimage', 'collapseAlbumart', settings.coverimage);

    document.getElementById('inputBookletName').value = settings.bookletName;
    
    document.getElementById('selectLocale').value = settings.locale;
    document.getElementById('inputCoverimageName').value = settings.coverimageName;

    document.getElementById('inputCoverimageSize').value = settings.coverimageSize;
    document.getElementById('inputCovergridSize').value = settings.covergridSize;

    document.documentElement.style.setProperty('--mympd-coverimagesize', settings.coverimageSize + "px");
    calcBoxHeight();
    document.documentElement.style.setProperty('--mympd-covergridsize', settings.covergridSize + "px");
    document.documentElement.style.setProperty('--mympd-highlightcolor', settings.highlightColor);
    
    document.getElementById('inputHighlightColor').value = settings.highlightColor;
    document.getElementById('inputBgColor').value = settings.bgColor;
    document.getElementsByTagName('body')[0].style.backgroundColor = settings.bgColor;
    
    document.getElementById('highlightColorPreview').style.backgroundColor = settings.highlightColor;
    document.getElementById('bgColorPreview').style.backgroundColor = settings.bgColor;

    toggleBtnChkCollapse('btnBgCover', 'collapseBackground', settings.bgCover);
    document.getElementById('inputBgCssFilter').value = settings.bgCssFilter;    

    let albumartbg = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < albumartbg.length; i++) {
	albumartbg[i].style.filter = settings.bgCssFilter;
    }

    toggleBtnChkCollapse('btnLoveEnable', 'collapseLove', settings.love);
    document.getElementById('inputLoveChannel').value = settings.loveChannel;
    document.getElementById('inputLoveMessage').value = settings.loveMessage;
    
    document.getElementById('inputMaxElementsPerPage').value = settings.maxElementsPerPage;
    toggleBtnChk('btnStickers', settings.stickers);
    document.getElementById('inputLastPlayedCount').value = settings.lastPlayedCount;
    
    toggleBtnChkCollapse('btnSmartpls', 'collapseSmartpls', settings.smartpls);
    
    let features = ["featLocalplayer", "featSyscmds", "featMixramp", "featCacert", "featBookmarks", 
        "featRegex", "featTimer", "featLyrics"];
    for (let j = 0; j < features.length; j++) {
        let Els = document.getElementsByClassName(features[j]);
        let ElsLen = Els.length;
        let displayEl = settings[features[j]] === true ? '' : 'none';
        for (let i = 0; i < ElsLen; i++) {
            Els[i].style.display = displayEl;
        }
    }
    
    let readonlyEls = document.getElementsByClassName('warnReadonly');
    for (let i = 0; i < readonlyEls.length; i++) {
        if (settings.readonly === false) {
            readonlyEls[i].classList.add('hide');
        }
        else {
            readonlyEls[i].classList.remove('hide');
        }
    }
    if (settings.readonly === true) {
        document.getElementById('btnBookmarks').setAttribute('disabled', 'disabled');
        document.getElementsByClassName('groupClearCovercache')[0].classList.add('hide');
    }
    else {
        document.getElementById('btnBookmarks').removeAttribute('disabled');
        document.getElementsByClassName('groupClearCovercache')[0].classList.remove('hide');
    }
    
    let timerActions = '<option value="startplay">' + t('Start playback') + '</option>' +
        '<option value="stopplay">' + t('Stop playback') + '</option>';

    if (settings.featSyscmds) {
        let syscmdsMaxListLen = 4;
        let syscmdsList = '';
        let syscmdsListLen = settings.syscmdList.length;
        if (syscmdsListLen > 0) {
            timerActions += '<optgroup label="' + t('System command') + '">';
            syscmdsList = syscmdsListLen > syscmdsMaxListLen ? '' : '<div class="dropdown-divider"></div>';
            for (let i = 0; i < syscmdsListLen; i++) {
                if (settings.syscmdList[i] === 'HR') {
                    syscmdsList += '<div class="dropdown-divider"></div>';
                }
                else {
                    syscmdsList += '<a class="dropdown-item text-light alwaysEnabled" href="#" data-href=\'{"cmd": "execSyscmd", "options": ["' + 
                        e(settings.syscmdList[i]) + '"]}\'>' + e(settings.syscmdList[i]) + '</a>';
                    timerActions += '<option value="' + e(settings.syscmdList[i]) + '">' + e(settings.syscmdList[i]) + '</option>';
                }
            }
        }
        document.getElementById('syscmds').innerHTML = syscmdsList;
        timerActions += '</optgroup>';
        
        if (syscmdsListLen > syscmdsMaxListLen) {
            document.getElementById('navSyscmds').classList.remove('hide');
            document.getElementById('syscmds').classList.add('collapse', 'menu-indent');
        }
        else {
            document.getElementById('navSyscmds').classList.add('hide');
            document.getElementById('syscmds').classList.remove('collapse', 'menu-indent');
        }
    }
    else {
        document.getElementById('syscmds').innerHTML = '';
    }
    
    document.getElementById('selectTimerAction').innerHTML = timerActions;
    

    dropdownMainMenu = new Dropdown(document.getElementById('mainMenu'));
    
    toggleBtnGroupValueCollapse(document.getElementById('btnJukeboxModeGroup'), 'collapseJukeboxMode', settings.jukeboxMode);
    document.getElementById('selectJukeboxUniqueTag').value = settings.jukeboxUniqueTag;
    document.getElementById('inputJukeboxQueueLength').value = settings.jukeboxQueueLength;
    document.getElementById('inputJukeboxLastPlayed').value = settings.jukeboxLastPlayed;
    
    if (settings.jukeboxMode === 0) {
        document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
    }
    else if (settings.jukeboxMode === 2) {
        document.getElementById('inputJukeboxQueueLength').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').setAttribute('disabled', 'disabled');
        document.getElementById('selectJukeboxPlaylist').value = 'Database';
    }
    else if (settings.jukeboxMode === 1) {
        document.getElementById('inputJukeboxQueueLength').removeAttribute('disabled');
        document.getElementById('selectJukeboxPlaylist').removeAttribute('disabled');
    }

    document.getElementById('inputSmartplsPrefix').value = settings.smartplsPrefix;
    document.getElementById('inputSmartplsInterval').value = settings.smartplsInterval / 60 / 60;
    document.getElementById('selectSmartplsSort').value = settings.smartplsSort;

    if (settings.featLocalplayer === true) {
        if (settings.streamUrl === '') {
            settings.mpdstream = 'http://';
            if (settings.mpdHost.match(/^127\./) !== null || settings.mpdHost === 'localhost' || settings.mpdHost.match(/^\//) !== null) {
                settings.mpdstream += window.location.hostname;
            }
            else {
                settings.mpdstream += settings.mpdHost;
            }
            settings.mpdstream += ':' + settings.streamPort + '/';
        } 
        else {
            settings.mpdstream = settings.streamUrl;
        }
        let localPlayer = document.getElementById('localPlayer');
        if (localPlayer.src !== settings.mpdstream) {
            localPlayer.pause();
            document.getElementById('alertLocalPlayback').classList.remove('hide');
            localPlayer.src = settings.mpdstream;
            localPlayer.load();
        }
    }
    
    if (settings.musicDirectory === 'auto') {
        document.getElementById('selectMusicDirectory').value = settings.musicDirectory;
        document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue !== undefined ? settings.musicDirectoryValue : '';
        document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
    }
    else if (settings.musicDirectory === 'none') {
        document.getElementById('selectMusicDirectory').value = settings.musicDirectory;
        document.getElementById('inputMusicDirectory').value = '';
        document.getElementById('inputMusicDirectory').setAttribute('readonly', 'readonly');
    }
    else {
        document.getElementById('selectMusicDirectory').value = 'custom';
        document.getElementById('inputMusicDirectory').value = settings.musicDirectoryValue;
        document.getElementById('inputMusicDirectory').removeAttribute('readonly');
    }

    if (app.current.app === 'Queue' && app.current.tab === 'Current') {
        getQueue();
    }
    else if (app.current.app === 'Queue' && app.current.tab === 'LastPlayed') {
        appRoute();
    }
    else if (app.current.app === 'Search') {
        appRoute();
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Filesystem') {
        appRoute();
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
        appRoute();
    }
    else if (app.current.app === 'Browse' && app.current.tab === 'Database' && app.current.search !== '') {
        appRoute();
    }
    else if (app.current.app === 'Playback') {
        getBrowseCovergrid();
    }

    i18nHtml(document.getElementsByTagName('body')[0]);

    checkConsume();

    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        navigator.mediaSession.setActionHandler('play', clickPlay);
        navigator.mediaSession.setActionHandler('pause', clickPlay);
        navigator.mediaSession.setActionHandler('stop', clickStop);
        navigator.mediaSession.setActionHandler('seekbackward', seekRelativeBackward);
        navigator.mediaSession.setActionHandler('seekforward', seekRelativeForward);
        navigator.mediaSession.setActionHandler('previoustrack', clickPrev);
        navigator.mediaSession.setActionHandler('nexttrack', clickNext);
        
        if (!navigator.mediaSession.setPositionState) {
            logDebug('mediaSession.setPositionState not supported by browser');
        }
    }
    else {
        logDebug('mediaSession not supported by browser');
    }
    parseCollybiaSettings();

    settingsParsed = 'true';
}

function parseMPDSettings() {
    toggleBtnChk('btnRandom', settings.random);
    toggleBtnChk('btnConsume', settings.consume);
    toggleBtnChk('btnRepeat', settings.repeat);
    toggleBtnChk('btnAutoPlay', settings.autoPlay);

    toggleBtnGroupValue(document.getElementById('btnSingleGroup'), settings.single);
    toggleBtnGroupValue(document.getElementById('btnReplaygainGroup'), settings.replaygain);
    
    document.getElementById('inputCrossfade').value = settings.crossfade;
    document.getElementById('inputMixrampdb').value = settings.mixrampdb;
    document.getElementById('inputMixrampdelay').value = settings.mixrampdelay;
    
    if (settings.coverimage === false || settings.featTags === false || 
        settings.tags.includes('AlbumArtist') === false || settings.tags.includes('Album') === false
        || settings.tags.includes('Track') === false || settings.featAdvsearch === false) 
    {
        settings.featCovergrid = false;
    }
    else {
        settings.featCovergrid = true;
    }
    
        
    if (settings.featLibrary === true && settings.publish === true) {
        settings['featBrowse'] = true;    
    }
    else {
        settings['featBrowse'] = false;
    }

    let features = ['featStickers', 'featSmartpls', 'featPlaylists', 'featTags', 'featCoverimage', 'featAdvsearch',
        'featLove', 'featSingleOneshot', 'featCovergrid', 'featBrowse', "featMounts", "featNeighbors"];
    for (let j = 0; j < features.length; j++) {
        let Els = document.getElementsByClassName(features[j]);
        let ElsLen = Els.length;
        let displayEl = settings[features[j]] === true ? '' : 'none';
        if (features[j] === 'featCoverimage' && settings.coverimage === false) {
            displayEl = 'none';
        }
        for (let i = 0; i < ElsLen; i++) {
            Els[i].style.display = displayEl;
        }
    }
    
    if (settings.featPlaylists === false && settings.smartpls === true) {
        document.getElementById('warnSmartpls').classList.remove('hide');
    }
    else {
        document.getElementById('warnSmartpls').classList.add('hide');
    }
    
    if (settings.featPlaylists === true && settings.readonly === false) {
        document.getElementById('btnSmartpls').removeAttribute('disabled');
    }
    else {
        document.getElementById('btnSmartpls').setAttribute('disabled', 'disabled');
    }

    if (settings.featStickers === false && settings.stickers === true) {
        document.getElementById('warnStickers').classList.remove('hide');
    }
    else {
        document.getElementById('warnStickers').classList.add('hide');
    }
    
    if (settings.featStickers === false || settings.stickers === false || settings.featStickerCache === false) {
        document.getElementById('warnPlaybackStatistics').classList.remove('hide');
        document.getElementById('inputJukeboxLastPlayed').setAttribute('disabled', 'disabled');
    }
    else {
        document.getElementById('warnPlaybackStatistics').classList.add('hide');
        document.getElementById('inputJukeboxLastPlayed').removeAttribute('disabled');
    }
    
    if (settings.featLove === false && settings.love === true) {
        document.getElementById('warnScrobbler').classList.remove('hide');
    }
    else {
        document.getElementById('warnScrobbler').classList.add('hide');
    }
    
    if (settings.featLibrary === false && settings.coverimage === true) {
        document.getElementById('warnAlbumart').classList.remove('hide');
    }
    else {
        document.getElementById('warnAlbumart').classList.add('hide');
    }
    if (settings.musicDirectoryValue === '' && settings.musicDirectory !== 'none') {
        document.getElementById('warnMusicDirectory').classList.remove('hide');
    }
    else {
        document.getElementById('warnMusicDirectory').classList.add('hide');
    }

    document.getElementById('warnJukeboxPlaylist').classList.add('hide');

    if (settings.bgCover === true && settings.featCoverimage === true && settings.coverimage === true) {
        setBackgroundImage(lastSongObj.uri);
    }
    else {
        clearBackgroundImage();
    }
    
    settings.tags.sort();
    settings.searchtags.sort();
    settings.browsetags.sort();
    filterCols('colsSearch');
    filterCols('colsQueueCurrent');
    filterCols('colsQueueLastPlayed');
    filterCols('colsBrowsePlaylistsDetail');
    filterCols('colsBrowseFilesystem');
    filterCols('colsBrowseDatabase');
    filterCols('colsPlayback');
    
    if (settings.featTags === false) {
        app.apps.Browse.active = 'Filesystem';
        app.apps.Search.state = '0/filename/-/';
        app.apps.Queue.state = '0/filename/-/';
        settings.colsQueueCurrent = ["Pos", "Title", "Duration"];
        settings.colsQueueLastPlayed = ["Pos", "Title", "LastPlayed"];
        settings.colsSearch = ["Title", "Duration"];
        settings.colsBrowseFilesystem = ["Type", "Title", "Duration"];
        settings.colsBrowseDatabase = ["Track", "Title", "Duration"];
        settings.colsPlayback = [];
    }
    else {
        let pbtl = '';
        for (let i = 0; i < settings.colsPlayback.length; i++) {
            pbtl += '<div id="current' + settings.colsPlayback[i]  + '" data-tag="' + settings.colsPlayback[i] + '" ' +
                    (settings.colsPlayback[i] === 'Lyrics' ? '' : 'data-name="' + (lastSongObj[settings.colsPlayback[i]] ? encodeURI(lastSongObj[settings.colsPlayback[i]]) : '') + '"') +
                    '>' +
                    '<small>' + t(settings.colsPlayback[i]) + '</small>' +
                    '<p';
            if (settings.browsetags.includes(settings.colsPlayback[i])) {
                pbtl += ' class="clickable"';
            }
            pbtl += '>';
            if (settings.colsPlayback[i] === 'Duration') {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? beautifySongDuration(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            else if (settings.colsPlayback[i] === 'LastModified') {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? localeDate(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            else if (settings.colsPlayback[i] === 'Fileformat') {
                pbtl += (lastState ? fileformat(lastState.audioFormat) : '');
            }
            else {
                pbtl += (lastSongObj[settings.colsPlayback[i]] ? e(lastSongObj[settings.colsPlayback[i]]) : '');
            }
            pbtl += '</p></div>';
        }
        document.getElementById('cardPlaybackTags').innerHTML = pbtl;
        let cl = document.getElementById('currentLyrics');
        if (cl && lastSongObj.uri) {
            let el = cl.getElementsByTagName('small')[0];
            el.classList.add('clickable');
            el.addEventListener('click', function(event) {
                event.target.parentNode.children[1].classList.toggle('expanded');
            }, false);
            getLyrics(lastSongObj.uri, cl.getElementsByTagName('p')[0]);
        }
    }

    if (!settings.tags.includes('AlbumArtist') && settings.featTags) {
        if (settings.tags.includes('Artist')) {
            app.apps.Browse.tabs.Database.active = 'Artist';
        }
        else {
            app.apps.Browse.tabs.Database.active = settings.tags[0];
        }
    }
    if (settings.tags.includes('Title')) {
        app.apps.Search.state = '0/any/Title/';
    }
    
    if (settings.featPlaylists) {
        playlistEl = 'selectJukeboxPlaylist';
        sendAPI("MPD_API_PLAYLIST_LIST", {"offset": 0, "filter": "-"}, getAllPlaylists);
    }
    else {
        document.getElementById('selectJukeboxPlaylist').innerHTML = '<option value="Database">' + t('Database') + '</option>';
    }

    setCols('QueueCurrent');
    setCols('Search');
    setCols('QueueLastPlayed');
    setCols('BrowseFilesystem');
    setCols('BrowsePlaylistsDetail');
    setCols('BrowseDatabase', '.tblAlbumTitles');
    setCols('Playback');

    addTagList('BrowseDatabaseByTagDropdown', 'browsetags');
    addTagList('searchqueuetags', 'searchtags');
    addTagList('searchtags', 'searchtags');
    addTagList('searchCovergridTags', 'browsetags');
    addTagList('covergridSortTagsList', 'browsetags');
    addTagList('dropdownSortPlaylistTags', 'tags');
    addTagList('saveSmartPlaylistSort', 'tags');
    
    addTagListSelect('selectSmartplsSort', 'tags');
    addTagListSelect('saveSmartPlaylistSort', 'tags');
    addTagListSelect('selectJukeboxUniqueTag', 'browsetags');
    
    for (let i = 0; i < settings.tags.length; i++) {
        app.apps.Browse.tabs.Database.views[settings.tags[i]] = { "state": "0/-/-/", "scrollPos": 0 };
    }
    
    initTagMultiSelect('inputEnabledTags', 'listEnabledTags', settings.allmpdtags, settings.tags);
    initTagMultiSelect('inputSearchTags', 'listSearchTags', settings.tags, settings.searchtags);
    initTagMultiSelect('inputBrowseTags', 'listBrowseTags', settings.tags, settings.browsetags);
    initTagMultiSelect('inputGeneratePlsTags', 'listGeneratePlsTags', settings.browsetags, settings.generatePlsTags);
}

//eslint-disable-next-line no-unused-vars
function resetSettings() {
    sendAPI("MYMPD_API_SETTINGS_RESET", {}, getSettings);
}

//eslint-disable-next-line no-unused-vars
function saveSettings(closeModal) {
    let formOK = true;

    let inputCrossfade = document.getElementById('inputCrossfade');
    if (!inputCrossfade.getAttribute('disabled')) {
        if (!validateInt(inputCrossfade)) {
            formOK = false;
        }
    }

    let inputJukeboxQueueLength = document.getElementById('inputJukeboxQueueLength');
    if (!validateInt(inputJukeboxQueueLength)) {
        formOK = false;
    }

    let inputJukeboxLastPlayed = document.getElementById('inputJukeboxLastPlayed');
    if (!validateInt(inputJukeboxLastPlayed)) {
        formOK = false;
    }
    
    let selectStreamModeEl = document.getElementById('selectStreamMode');
    let streamUrl = '';
    let streamPort = '';
    let inputStreamUrl = document.getElementById('inputStreamUrl');
    if (selectStreamModeEl.options[selectStreamModeEl.selectedIndex].value === 'port') {
        streamPort = inputStreamUrl.value;
        if (!validateInt(inputStreamUrl)) {
            formOK = false;
        }
    }
    else {
        streamUrl = inputStreamUrl.value;
        if (!validateStream(inputStreamUrl)) {
            formOK = false;
        }
    }

    let inputCovergridSize = document.getElementById('inputCovergridSize');
    if (!validateInt(inputCovergridSize)) {
        formOK = false;
    }

    let inputCoverimageSize = document.getElementById('inputCoverimageSize');
    if (!validateInt(inputCoverimageSize)) {
        formOK = false;
    }
    
    let inputCoverimageName = document.getElementById('inputCoverimageName');
    if (!validateFilenameList(inputCoverimageName)) {
        formOK = false;
    }
    
    let inputBookletName = document.getElementById('inputBookletName');
    if (!validateFilename(inputBookletName)) {
        formOK = false;
    }
    
    let inputMaxElementsPerPage = document.getElementById('inputMaxElementsPerPage');
    if (!validateInt(inputMaxElementsPerPage)) {
        formOK = false;
    }
    if (parseInt(inputMaxElementsPerPage.value) > 200) {
        formOK = false;
    }
    
    let inputLastPlayedCount = document.getElementById('inputLastPlayedCount');
    if (!validateInt(inputLastPlayedCount)) {
        formOK = false;
    }
    
    if (document.getElementById('btnLoveEnable').classList.contains('active')) {
        let inputLoveChannel = document.getElementById('inputLoveChannel');
        let inputLoveMessage = document.getElementById('inputLoveMessage');
        if (!validateNotBlank(inputLoveChannel) || !validateNotBlank(inputLoveMessage)) {
            formOK = false;
        }
    }

    if (settings.featMixramp === true) {
        let inputMixrampdb = document.getElementById('inputMixrampdb');
        if (!inputMixrampdb.getAttribute('disabled')) {
            if (!validateFloat(inputMixrampdb)) {
                formOK = false;
            } 
        }
        let inputMixrampdelay = document.getElementById('inputMixrampdelay');
        if (!inputMixrampdelay.getAttribute('disabled')) {
            if (inputMixrampdelay.value === 'nan') {
                inputMixrampdelay.value = '-1';
            }
            if (!validateFloat(inputMixrampdelay)) {
                formOK = false;
            }
        }
    }
    
    let inputSmartplsInterval = document.getElementById('inputSmartplsInterval');
    if (!validateInt(inputSmartplsInterval)) {
        formOK = false;
    }
    let smartplsInterval = document.getElementById('inputSmartplsInterval').value * 60 * 60;

    let singleState = getBtnGroupValue('btnSingleGroup');
    let jukeboxMode = getBtnGroupValue('btnJukeboxModeGroup');
    let replaygain = getBtnGroupValue('btnReplaygainGroup');
    let jukeboxUniqueTag = document.getElementById('selectJukeboxUniqueTag');
    let jukeboxUniqueTagValue = jukeboxUniqueTag.options[jukeboxUniqueTag.selectedIndex].value;

    let selectJukeboxPlaylist = document.getElementById('selectJukeboxPlaylist');
    let jukeboxPlaylist = selectJukeboxPlaylist.options[selectJukeboxPlaylist.selectedIndex].value;
    
    if (jukeboxMode === '2') {
        jukeboxUniqueTagValue = 'Album';
    }
    
    if (jukeboxMode === '1' && settings.featSearchwindow === false && jukeboxPlaylist === 'Database') {
        formOK = false;
        document.getElementById('warnJukeboxPlaylist').classList.remove('hide');
    }
    
    if (formOK === true) {
        let selectLocale = document.getElementById('selectLocale');
        let selectTheme = document.getElementById('selectTheme');
        sendAPI("MYMPD_API_SETTINGS_SET", {
            "consume": (document.getElementById('btnConsume').classList.contains('active') ? 1 : 0),
            "random": (document.getElementById('btnRandom').classList.contains('active') ? 1 : 0),
            "single": parseInt(singleState),
            "repeat": (document.getElementById('btnRepeat').classList.contains('active') ? 1 : 0),
            "replaygain": replaygain,
            "crossfade": document.getElementById('inputCrossfade').value,
            "mixrampdb": (settings.featMixramp === true ? document.getElementById('inputMixrampdb').value : settings.mixrampdb),
            "mixrampdelay": (settings.featMixramp === true ? document.getElementById('inputMixrampdelay').value : settings.mixrampdelay),
            "notificationWeb": (document.getElementById('btnNotifyWeb').classList.contains('active') ? true : false),
            "notificationPage": (document.getElementById('btnNotifyPage').classList.contains('active') ? true : false),
            "mediaSession": (document.getElementById('btnMediaSession').classList.contains('active') ? true : false),
            "jukeboxMode": parseInt(jukeboxMode),
            "jukeboxPlaylist": jukeboxPlaylist,
            "jukeboxQueueLength": parseInt(document.getElementById('inputJukeboxQueueLength').value),
            "jukeboxLastPlayed": parseInt(document.getElementById('inputJukeboxLastPlayed').value),
            "jukeboxUniqueTag": jukeboxUniqueTagValue,
            "autoPlay": (document.getElementById('btnAutoPlay').classList.contains('active') ? true : false),
            "bgCover": (document.getElementById('btnBgCover').classList.contains('active') ? true : false),
            "bgColor": document.getElementById('inputBgColor').value,
            "bgCssFilter": document.getElementById('inputBgCssFilter').value,
            "featLocalplayer": (document.getElementById('btnFeatLocalplayer').classList.contains('active') ? true : false),
            "localplayerAutoplay": (document.getElementById('btnLocalplayerAutoplay').classList.contains('active') ? true : false),
            "streamUrl": streamUrl,
            "streamPort": parseInt(streamPort),
            "coverimage": (document.getElementById('btnCoverimage').classList.contains('active') ? true : false),
            "coverimageName": document.getElementById('inputCoverimageName').value,
            "coverimageSize": document.getElementById('inputCoverimageSize').value,
            "covergridSize": document.getElementById('inputCovergridSize').value,
            "locale": selectLocale.options[selectLocale.selectedIndex].value,
            "love": (document.getElementById('btnLoveEnable').classList.contains('active') ? true : false),
            "loveChannel": document.getElementById('inputLoveChannel').value,
            "loveMessage": document.getElementById('inputLoveMessage').value,
            "bookmarks": (document.getElementById('btnBookmarks').classList.contains('active') ? true : false),
            "maxElementsPerPage": document.getElementById('inputMaxElementsPerPage').value,
            "stickers": (document.getElementById('btnStickers').classList.contains('active') ? true : false),
            "lastPlayedCount": document.getElementById('inputLastPlayedCount').value,
            "smartpls": (document.getElementById('btnSmartpls').classList.contains('active') ? true : false),
            "smartplsPrefix": document.getElementById('inputSmartplsPrefix').value,
            "smartplsInterval": smartplsInterval,
            "smartplsSort": document.getElementById('selectSmartplsSort').value,
            "taglist": getTagMultiSelectValues(document.getElementById('listEnabledTags'), false),
            "searchtaglist": getTagMultiSelectValues(document.getElementById('listSearchTags'), false),
            "browsetaglist": getTagMultiSelectValues(document.getElementById('listBrowseTags'), false),
            "generatePlsTags": getTagMultiSelectValues(document.getElementById('listGeneratePlsTags'), false),
            "theme": selectTheme.options[selectTheme.selectedIndex].value,
            "highlightColor": document.getElementById('inputHighlightColor').value,
            "timer": (document.getElementById('btnFeatTimer').classList.contains('active') ? true : false),
            "bookletName": document.getElementById('inputBookletName').value,
            "lyrics": (document.getElementById('btnFeatLyrics').classList.contains('active') ? true : false)
        }, getSettings);
        if (closeModal === true) {
            modalSettings.hide();
        }
        else {
            btnWaiting(document.getElementById('btnApplySettings'), true);
        }
    }
}

function getTagMultiSelectValues(taglist, translated) {
    let values = [];
    let chkBoxes = taglist.getElementsByTagName('button');
    for (let i = 0; i < chkBoxes.length; i++) {
        if (chkBoxes[i].classList.contains('active')) {
            if (translated === true) {
                values.push(t(chkBoxes[i].name));
            }
            else {
                values.push(chkBoxes[i].name);
            }
        }
    }
    if (translated === true) {
        return values.join(', ');
    }
    return values.join(',');
}

function initTagMultiSelect(inputId, listId, allTags, enabledTags) {
    let values = [];
    let list = '';
    for (let i = 0; i < allTags.length; i++) {
        if (enabledTags.includes(allTags[i])) {
            values.push(t(allTags[i]));
        }
        list += '<div class="form-check">' +
            '<button class="btn btn-secondary btn-xs clickable material-icons material-icons-small' + 
            (enabledTags.includes(allTags[i]) ? ' active' : '') + '" name="' + allTags[i] + '">' +
            (enabledTags.includes(allTags[i]) ? 'check' : 'radio_button_unchecked') + '</button>' +
            '<label class="form-check-label" for="' + allTags[i] + '">&nbsp;&nbsp;' + t(allTags[i]) + '</label>' +
            '</div>';
    }
    document.getElementById(listId).innerHTML = list;

    let inputEl = document.getElementById(inputId);
    inputEl.value = values.join(', ');
    if (inputEl.getAttribute('data-init') === 'true') {
        return;
    }
    inputEl.setAttribute('data-init', 'true');
    document.getElementById(listId).addEventListener('click', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (event.target.nodeName === 'BUTTON') {
            toggleBtnChk(event.target);
            event.target.parentNode.parentNode.parentNode.previousElementSibling.value = getTagMultiSelectValues(event.target.parentNode.parentNode, true);
        }
    });
}

function filterCols(x) {
    let tags = settings.tags.slice();
    if (settings.featTags === false) {
        tags.push('Title');
    }
    tags.push('Duration');
    if (x === 'colsQueueCurrent' || x === 'colsBrowsePlaylistsDetail' || x === 'colsQueueLastPlayed') {
        tags.push('Pos');
    }
    else if (x === 'colsBrowseFilesystem') {
        tags.push('Type');
    }
    if (x === 'colsQueueLastPlayed') {
        tags.push('LastPlayed');
    }
    if (x === 'colsPlayback') {
        tags.push('Filetype');
        tags.push('Fileformat');
        tags.push('LastModified');
        if (settings.featLyrics === true) {
            tags.push('Lyrics');
        }
    }
    let cols = [];
    for (let i = 0; i < settings[x].length; i++) {
        if (tags.includes(settings[x][i])) {
            cols.push(settings[x][i]);
        }
    }
    settings[x] = cols;
    logDebug('Columns for ' + x + ': ' + cols);
}

//eslint-disable-next-line no-unused-vars
function toggleBtnNotifyWeb() {
    let btnNotifyWeb = document.getElementById('btnNotifyWeb');
    let notifyWebState = btnNotifyWeb.classList.contains('active') ? true : false;
    if (notificationsSupported()) {
        if (notifyWebState === false) {
            Notification.requestPermission(function (permission) {
                if (!('permission' in Notification)) {
                    Notification.permission = permission;
                }
                if (permission === 'granted') {
                    toggleBtnChk('btnNotifyWeb', true);
                    settings.notificationWeb = true;
                    document.getElementById('warnNotifyWeb').classList.add('hide');
                } 
                else {
                    toggleBtnChk('btnNotifyWeb', false);
                    settings.notificationWeb = false;
                    document.getElementById('warnNotifyWeb').classList.remove('hide');
                }
            });
        }
        else {
            toggleBtnChk('btnNotifyWeb', false);
            settings.notificationWeb = false;
            document.getElementById('warnNotifyWeb').classList.add('hide');
        }
    }
    else {
        toggleBtnChk('btnNotifyWeb', false);
        settings.notificationWeb = false;
    }
}

//eslint-disable-next-line no-unused-vars
function setPlaySettings(el) {
    if (el.parentNode.classList.contains('btn-group')) {
        toggleBtnGroup(el);
    }
    else {
        toggleBtnChk(el);
    }
    if (el.parentNode.id === 'playDropdownBtnJukeboxModeGroup') {
        if (el.parentNode.getElementsByClassName('active')[0].getAttribute('data-value') !== '0') {
            toggleBtnChk('playDropdownBtnConsume', true);            
        }
    }
    else if (el.id === 'playDropdownBtnConsume') {
        if (el.classList.contains('active') === false) {
            toggleBtnGroupValue(document.getElementById('playDropdownBtnJukeboxModeGroup'), 0);
        }
    }

    savePlaySettings();
}

function showPlayDropdown() {
    toggleBtnChk(document.getElementById('playDropdownBtnRandom'), settings.random);
    toggleBtnChk(document.getElementById('playDropdownBtnConsume'), settings.consume);
    toggleBtnChk(document.getElementById('playDropdownBtnRepeat'), settings.repeat);
    toggleBtnChk(document.getElementById('playDropdownBtnRandom'), settings.random);
    toggleBtnGroupValue(document.getElementById('playDropdownBtnSingleGroup'), settings.single);
    toggleBtnGroupValue(document.getElementById('playDropdownBtnJukeboxModeGroup'), settings.jukeboxMode);
}

function savePlaySettings() {
    let singleState = document.getElementById('playDropdownBtnSingleGroup').getElementsByClassName('active')[0].getAttribute('data-value');
    let jukeboxMode = document.getElementById('playDropdownBtnJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');
    sendAPI("MYMPD_API_SETTINGS_SET", {
        "consume": (document.getElementById('playDropdownBtnConsume').classList.contains('active') ? 1 : 0),
        "random": (document.getElementById('playDropdownBtnRandom').classList.contains('active') ? 1 : 0),
        "single": parseInt(singleState),
        "repeat": (document.getElementById('playDropdownBtnRepeat').classList.contains('active') ? 1 : 0),
        "jukeboxMode": parseInt(jukeboxMode)
        }, getSettings);
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function songDetails(uri) {
    sendAPI("MPD_API_DATABASE_SONGDETAILS", {"uri": uri}, parseSongDetails);
    modalSongDetails.show();
}

function parseFingerprint(obj) {
    let textarea = document.createElement('textarea');
    textarea.value = obj.result.fingerprint;
    textarea.classList.add('form-control', 'text-monospace', 'small');
    let fpTd = document.getElementById('fingerprint');
    fpTd.innerHTML = '';
    fpTd.appendChild(textarea);
}

function parseSongDetails(obj) {
    let modal = document.getElementById('modalSongDetails');
    modal.getElementsByClassName('album-cover')[0].style.backgroundImage = 'url("' + subdir + '/albumart/' + obj.result.uri + '"), url("' + subdir + '/assets/coverimage-loading.svg")';
    
    let elH1s = modal.getElementsByTagName('h1');
    for (let i = 0; i < elH1s.length; i++) {
        elH1s[i].innerText = obj.result.Title;
    }
    
    let songDetailsHTML = '';
    for (let i = 0; i < settings.tags.length; i++) {
        if (settings.tags[i] === 'Title' || obj.result[settings.tags[i]] === '-') {
            continue;
        }
        songDetailsHTML += '<tr><th>' + t(settings.tags[i]) + '</th><td data-tag="' + settings.tags[i] + '" data-name="' + encodeURI(obj.result[settings.tags[i]]) + '">';
        if (settings.browsetags.includes(settings.tags[i]) && obj.result[settings.tags[i]] !== '-') {
            songDetailsHTML += '<a class="text-success" href="#">' + e(obj.result[settings.tags[i]]) + '</a>';
        }
        else {
            songDetailsHTML += obj.result[settings.tags[i]];
        }
        songDetailsHTML += '</td></tr>';
    }
    songDetailsHTML += '<tr><th>' + t('Duration') + '</th><td>' + beautifyDuration(obj.result.Duration) + '</td></tr>';
    if (settings.featLibrary === true && settings.publish === true) {
        songDetailsHTML += '<tr><th>' + t('Filename') + '</th><td><a class="breakAll text-success" href="/browse/music/' + 
            encodeURI(obj.result.uri) + '" target="_blank" title="' + e(obj.result.uri) + '">' + 
            e(basename(obj.result.uri)) + '</a></td></tr>';
    }
    else {
        songDetailsHTML += '<tr><th>' + t('Filename') + '</th><td class="breakAll"><span title="' + e(obj.result.uri) + '">' + 
            e(basename(obj.result.uri)) + '</span></td></tr>';
    }
    songDetailsHTML += '<tr><th>' + t('Filetype') + '</th><td>' + filetype(obj.result.uri) + '</td></tr>';
    songDetailsHTML += '<tr><th>' + t('LastModified') + '</th><td>' + localeDate(obj.result.LastModified) + '</td></tr>';
    if (settings.featFingerprint === true) {
        songDetailsHTML += '<tr><th>' + t('Fingerprint') + '</th><td class="breakAll" id="fingerprint"><a class="text-success" data-uri="' + 
            encodeURI(obj.result.uri) + '" id="calcFingerprint" href="#">' + t('Calculate') + '</a></td></tr>';
    }
    if (obj.result.booklet === true && settings.publish === true) {
        songDetailsHTML += '<tr><th>' + t('Booklet') + '</th><td><a class="text-success" href="/browse/music/' + dirname(obj.result.uri) + '/' + settings.bookletName + '" target="_blank">' + t('Download') + '</a></td></tr>';
    }
    if (settings.featStickers === true) {
        songDetailsHTML += '<tr><th colspan="2" class="pt-3"><h5>' + t('Statistics') + '</h5></th></tr>' +
            '<tr><th>' + t('Play count') + '</th><td>' + obj.result.playCount + '</td></tr>' +
            '<tr><th>' + t('Skip count') + '</th><td>' + obj.result.skipCount + '</td></tr>' +
            '<tr><th>' + t('Last played') + '</th><td>' + (obj.result.lastPlayed === 0 ? t('never') : localeDate(obj.result.lastPlayed)) + '</td></tr>' +
            '<tr><th>' + t('Last skipped') + '</th><td>' + (obj.result.lastSkipped === 0 ? t('never') : localeDate(obj.result.lastSkipped)) + '</td></tr>' +
            '<tr><th>' + t('Like') + '</th><td>' +
              '<div class="btn-group btn-group-sm">' +
                '<button title="' + t('Dislike song') + '" id="btnVoteDown2" data-href=\'{"cmd": "voteSong", "options": [0]}\' class="btn btn-sm btn-light material-icons">thumb_down</button>' +
                '<button title="' + t('Like song') + '" id="btnVoteUp2" data-href=\'{"cmd": "voteSong", "options": [2]}\' class="btn btn-sm btn-light material-icons">thumb_up</button>' +
              '</div>' +
            '</td></tr>';
    }
    
    document.getElementById('tbodySongDetails').innerHTML = songDetailsHTML;
    setVoteSongBtns(obj.result.like, obj.result.uri);
    
    if (settings.featLyrics === true) {
        getLyrics(obj.result.uri, document.getElementById('lyricsText'));
    }

    let showPictures = false;
    if (obj.result.images.length > 0 && settings.featLibrary === true && settings.publish === true) {
        showPictures = true;
    }
    else if (settings.coverimage === true) {
        showPictures = true;
    }
    
    let pictureEls = document.getElementsByClassName('featPictures');
    for (let i = 0; i < pictureEls.length; i++) {
        if (showPictures === true) {
            pictureEls[i].classList.remove('hide');
        }
        else {
            pictureEls[i].classList.add('hide');
        }
    }
    
    if (showPictures === true) {
        //add uri to image list to get embedded albumart
        let images = [ subdir + '/albumart/' + obj.result.uri ];
        //add all but coverfiles to image list
        for (let i = 0; i < obj.result.images.length; i++) {
            if (isCoverfile(obj.result.images[i]) === false) {
                images.push(subdir + '/browse/music/' + obj.result.images[i]);
            }
        }
    
        let carousel = '<div id="songPicsCarousel" class="carousel slide" data-ride="carousel">' +
            '<ol class="carousel-indicators">';
        for (let i = 0; i < images.length; i++) {
            carousel += '<li data-target="#songPicsCarousel" data-slide-to="' + i + '"' +
                (i === 0 ? ' class="active"' : '') + '></li>';
        }    
        carousel += '</ol>' +
            '<div class="carousel-inner" role="listbox">';
        for (let i = 0; i < images.length; i++) {
            carousel += '<div class="carousel-item' + (i === 0 ? ' active' : '') + '"><div></div></div>';
        }
        carousel += '</div>' +
            '<a class="carousel-control-prev" href="#songPicsCarousel" data-slide="prev">' +
                '<span class="carousel-control-prev-icon"></span>' +
            '</a>' +
            '<a class="carousel-control-next" href="#songPicsCarousel" data-slide="next">' +
                '<span class="carousel-control-next-icon"></span>' +
            '</a>' +
            '</div>';
    
        document.getElementById('tabSongPics').innerHTML = carousel;
        let carouselItems = document.getElementById('tabSongPics').getElementsByClassName('carousel-item');
        for (let i = 0; i < carouselItems.length; i++) {
            carouselItems[i].children[0].style.backgroundImage = 'url("' + encodeURI(images[i]) + '")';
        }
        let myCarousel = document.getElementById('songPicsCarousel');
        //eslint-disable-next-line no-undef, no-unused-vars
        let myCarouselInit = new Carousel(myCarousel, {
            interval: false,
            pause: false
        });
    }
    else {
        document.getElementById('tabSongPics').innerText = '';
    }
}

function isCoverfile(uri) {
    let filename = basename(uri).toLowerCase();
    let fileparts = filename.split('.');
    
    let extensions = ['png', 'jpg', 'jpeg', 'svg', 'webp', 'tiff', 'bmp'];
    let coverimageNames = settings.coverimageName.split(',');
    for (let i = 0; i < coverimageNames.length; i++) {
        let name = coverimageNames[i].trim();
        if (filename === name) {
            return true;
        }
        if (fileparts[1]) {
            if (name === fileparts[0] && extensions.includes(fileparts[1])) {
                return true;
            }
        }
    }
    return false;
}

function getLyrics(uri, el) {
    el.classList.add('opacity05');
    let ajaxRequest=new XMLHttpRequest();
    
    ajaxRequest.open('GET', subdir + '/lyrics/' + uri, true);
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState === 4) {
            el.innerText = ajaxRequest.responseText === 'No lyrics found' ? t(ajaxRequest.responseText) : ajaxRequest.responseText;
            el.classList.remove('opacity05');
        }
    };
    ajaxRequest.send();
}

//eslint-disable-next-line no-unused-vars
function loveSong() {
    sendAPI("MPD_API_LOVE", {});
}

//eslint-disable-next-line no-unused-vars
function voteSong(vote) {
    let uri = decodeURI(domCache.currentTitle.getAttribute('data-uri'));
    if (uri === '') {
        return;
    }
        
    if (vote === 2 && domCache.btnVoteUp.classList.contains('highlight')) {
        vote = 1;
    }
    else if (vote === 0 && domCache.btnVoteDown.classList.contains('highlight')) {
        vote = 1;
    }
    sendAPI("MPD_API_LIKE", {"uri": uri, "like": vote});
    setVoteSongBtns(vote, uri);
}

function setVoteSongBtns(vote, uri) {
    domCache.btnVoteUp2 = document.getElementById('btnVoteUp2');
    domCache.btnVoteDown2 = document.getElementById('btnVoteDown2');

    if (uri === '' || uri.indexOf('://') > -1) {
        domCache.btnVoteUp.setAttribute('disabled', 'disabled');
        domCache.btnVoteDown.setAttribute('disabled', 'disabled');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.setAttribute('disabled', 'disabled');
            domCache.btnVoteDown2.setAttribute('disabled', 'disabled');
        }
    } else {
        domCache.btnVoteUp.removeAttribute('disabled');
        domCache.btnVoteDown.removeAttribute('disabled');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.removeAttribute('disabled');
            domCache.btnVoteDown2.removeAttribute('disabled');
        }
    }
    
    if (vote === 0) {
        domCache.btnVoteUp.classList.remove('highlight');
        domCache.btnVoteDown.classList.add('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.remove('highlight');
            domCache.btnVoteDown2.classList.add('highlight');
        }
    } else if (vote === 1) {
        domCache.btnVoteUp.classList.remove('highlight');
        domCache.btnVoteDown.classList.remove('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.remove('highlight');
            domCache.btnVoteDown2.classList.remove('highlight');
        }
    } else if (vote === 2) {
        domCache.btnVoteUp.classList.add('highlight');
        domCache.btnVoteDown.classList.remove('highlight');
        if (domCache.btnVoteUp2) {
            domCache.btnVoteUp2.classList.add('highlight');
            domCache.btnVoteDown2.classList.remove('highlight');
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function parseStats(obj) {
    document.getElementById('mpdstats_artists').innerText =  obj.result.artists;
    document.getElementById('mpdstats_albums').innerText = obj.result.albums;
    document.getElementById('mpdstats_songs').innerText = obj.result.songs;
    document.getElementById('mpdstats_dbPlaytime').innerText = beautifyDuration(obj.result.dbPlaytime);
    document.getElementById('mpdstats_playtime').innerText = beautifyDuration(obj.result.playtime);
    document.getElementById('mpdstats_uptime').innerText = beautifyDuration(obj.result.uptime);
    document.getElementById('mpdstats_mympd_uptime').innerText = beautifyDuration(obj.result.myMPDuptime);
    document.getElementById('mpdstats_dbUpdated').innerText = localeDate(obj.result.dbUpdated);
    document.getElementById('mympdVersion').innerText = obj.result.mympdVersion;
    document.getElementById('mpdInfo_version').innerText = obj.result.mpdVersion;
    document.getElementById('mpdInfo_libmpdclientVersion').innerText = obj.result.libmpdclientVersion;
    document.getElementById('mpdInfo_libmympdclientVersion').innerText = obj.result.libmympdclientVersion;
}

function getServerinfo() {
    let ajaxRequest=new XMLHttpRequest();
    ajaxRequest.open('GET', subdir + '/api/serverinfo', true);
    ajaxRequest.onreadystatechange = function() {
        if (ajaxRequest.readyState === 4) {
            let obj = JSON.parse(ajaxRequest.responseText);
            document.getElementById('wsIP').innerText = obj.result.ip;
            document.getElementById('wsMongooseVersion').innerText = obj.result.version;
        }
    };
    ajaxRequest.send();
}

function parseOutputs(obj) {
    let btns = '';
    for (let i = 0; i < obj.result.numOutputs; i++) {
        btns += '<button id="btnOutput' + obj.result.data[i].id +'" data-output-id="' + obj.result.data[i].id + '" class="btn btn-secondary btn-block';
        if (obj.result.data[i].state === 1) {
            btns += ' active';
        }
        btns += '"><span class="material-icons float-left">volume_up</span> ' + e(obj.result.data[i].name) + '</button>';
    }
    domCache.outputs.innerHTML = btns;
}

function setCounter(currentSongId, totalTime, elapsedTime) {
    currentSong.totalTime = totalTime;
    currentSong.elapsedTime = elapsedTime;
    currentSong.currentSongId = currentSongId;

    domCache.progressBar.value = Math.floor(1000 * elapsedTime / totalTime);

    let counterText = beautifySongDuration(elapsedTime) + "&nbsp;/&nbsp;" + beautifySongDuration(totalTime);
    domCache.counter.innerHTML = counterText;
    
    //Set playing track in queue view
    if (lastState) {
        if (lastState.currentSongId !== currentSongId) {
            let tr = document.getElementById('queueTrackId' + lastState.currentSongId);
            if (tr) {
                let durationTd = tr.querySelector('[data-col=Duration]');
                if (durationTd) {
                    durationTd.innerText = tr.getAttribute('data-duration');
                }
                let posTd = tr.querySelector('[data-col=Pos]');
                if (posTd) {
                    posTd.classList.remove('material-icons');
                    posTd.innerText = tr.getAttribute('data-songpos');
                }
                tr.classList.remove('font-weight-bold');
            }
        }
    }
    let tr = document.getElementById('queueTrackId' + currentSongId);
    if (tr) {
        let durationTd = tr.querySelector('[data-col=Duration]');
        if (durationTd) {
            durationTd.innerHTML = counterText;
        }
        let posTd = tr.querySelector('[data-col=Pos]');
        if (posTd) {
            if (!posTd.classList.contains('material-icons')) {
                posTd.classList.add('material-icons');
                posTd.innerText = 'play_arrow';
            }
        }
        tr.classList.add('font-weight-bold');
    }
    
    if (progressTimer) {
        clearTimeout(progressTimer);
    }
    if (playstate === 'play') {
        progressTimer = setTimeout(function() {
            currentSong.elapsedTime ++;
            requestAnimationFrame(function() {
                setCounter(currentSong.currentSongId, currentSong.totalTime, currentSong.elapsedTime);
            });
        }, 1000);
    }
}

function parseState(obj) {
    if (JSON.stringify(obj.result) === JSON.stringify(lastState)) {
        toggleUI();
        return;
    }

    //Set play and queue state
    parseUpdateQueue(obj);
    
    //Set volume
    parseVolume(obj);

    //Set play counters
    setCounter(obj.result.currentSongId, obj.result.totalTime, obj.result.elapsedTime);
    
    //Get current song
    if (!lastState || lastState.currentSongId !== obj.result.currentSongId ||
        lastState.queueVersion !== obj.result.queueVersion)
    {
        sendAPI("MPD_API_PLAYER_CURRENT_SONG", {}, songChange);
    }
    //clear playback card if no current song
    if (obj.result.songPos === '-1') {
        domCache.currentTitle.innerText = 'Not playing';
        document.title = 'myMPD';
        let headerTitle = document.getElementById('headerTitle');
        headerTitle.innerText = '';
        headerTitle.removeAttribute('title');
        headerTitle.classList.remove('clickable');
        clearCurrentCover();
        if (settings.bgCover === true) {
            clearBackgroundImage();
        }
        let pb = document.getElementById('cardPlaybackTags').getElementsByTagName('p');
        for (let i = 0; i < pb.length; i++) {
            pb[i].innerText = '';
        }
    }
    else {
        let cff = document.getElementById('currentFileformat');
        if (cff) {
            cff.getElementsByTagName('p')[0].innerText = fileformat(obj.result.audioFormat);
        }
    }

    lastState = obj.result;                    
    
    if (settings.mpdConnected === false || uiEnabled === false) {
        getSettings(true);
    }
}

function parseVolume(obj) {
    if (obj.result.volume === -1) {
        domCache.volumePrct.innerText = t('Volumecontrol disabled');
        domCache.volumeControl.classList.add('hide');
    } 
    else {
        domCache.volumeControl.classList.remove('hide');
        domCache.volumePrct.innerText = obj.result.volume + ' %';
        if (obj.result.volume === 0) {
            domCache.volumeMenu.innerText = 'volume_off';
        }
        else if (obj.result.volume < 50) {
            domCache.volumeMenu.innerText = 'volume_down';
        }
        else {
            domCache.volumeMenu.innerText = 'volume_up';
        }
    }
    domCache.volumeBar.value = obj.result.volume;
}

function setBackgroundImage(url) {
    if (url === undefined) {
        clearBackgroundImage();
        return;
    }
    let old = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '-10') {
            old[i].remove();
        }
        else {
            old[i].style.zIndex = '-10';
        }
    }
    let div = document.createElement('div');
    div.classList.add('albumartbg');
    div.style.filter = settings.bgCssFilter;
    div.style.backgroundImage = 'url("' + subdir + '/albumart/' + url + '")';
    div.style.opacity = 0;
    let body = document.getElementsByTagName('body')[0];
    body.insertBefore(div, body.firstChild);

    let img = new Image();
    img.onload = function() {
        document.querySelector('.albumartbg').style.opacity = 1;
    };
    img.src = subdir + '/albumart/' + url;
}

function clearBackgroundImage() {
    let old = document.querySelectorAll('.albumartbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '-10') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '-10';
            old[i].style.opacity = '0';
        }
    }
}

function setCurrentCover(url) {
    if (url === undefined) {
        clearCurrentCover();
        return;
    }
    let old = domCache.currentCover.querySelectorAll('.coverbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '2') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '2';
        }
    }

    let div = document.createElement('div');
    div.classList.add('coverbg');
    div.style.backgroundImage = 'url("' + subdir + '/albumart/' + url + '")';
    div.style.opacity = 0;
    domCache.currentCover.insertBefore(div, domCache.currentCover.firstChild);

    let img = new Image();
    img.onload = function() {
        domCache.currentCover.querySelector('.coverbg').style.opacity = 1;
    };
    img.src = subdir + '/albumart/' + url;
}

function clearCurrentCover() {
    let old = domCache.currentCover.querySelectorAll('.coverbg');
    for (let i = 0; i < old.length; i++) {
        if (old[i].style.zIndex === '2') {
            old[i].remove();        
        }
        else {
            old[i].style.zIndex = '2';
            old[i].style.opacity = '0';
        }
    }
}

function songChange(obj) {
    let curSong = obj.result.Title + ':' + obj.result.Artist + ':' + obj.result.Album + ':' + obj.result.uri + ':' + obj.result.currentSongId;
    if (lastSong === curSong) {
        return;
    }
    let textNotification = '';
    let htmlNotification = '';
    let pageTitle = '';

    mediaSessionSetMetadata(obj.result.Title, obj.result.Artist, obj.result.Album, obj.result.uri);
    
    setCurrentCover(obj.result.uri);
    if (settings.bgCover === true && settings.featCoverimage === true) {
        setBackgroundImage(obj.result.uri);
    }

    if (obj.result.Artist !== undefined && obj.result.Artist.length > 0 && obj.result.Artist !== '-') {
        textNotification += obj.result.Artist;
        htmlNotification += obj.result.Artist;
        pageTitle += obj.result.Artist + ' - ';
    } 

    if (obj.result.Album !== undefined && obj.result.Album.length > 0 && obj.result.Album !== '-') {
        textNotification += ' - ' + obj.result.Album;
        htmlNotification += '<br/>' + obj.result.Album;
    }

    if (obj.result.Title !== undefined && obj.result.Title.length > 0) {
        pageTitle += obj.result.Title;
        domCache.currentTitle.innerText = obj.result.Title;
        domCache.currentTitle.setAttribute('data-uri', encodeURI(obj.result.uri));
    }
    else {
        domCache.currentTitle.innerText = '';
        domCache.currentTitle.setAttribute('data-uri', '');
    }
    document.title = 'myMPD: ' + pageTitle;
    let headerTitle = document.getElementById('headerTitle');
    headerTitle.innerText = pageTitle;
    headerTitle.title = pageTitle;
    
    if (obj.result.uri !== undefined && obj.result.uri !== '' && obj.result.uri.indexOf('://') === -1) {
        headerTitle.classList.add('clickable');
    }
    else {
        headerTitle.classList.remove('clickable');
    }

    if (obj.result.uri !== undefined) {
        if (settings.featStickers === true) {
            setVoteSongBtns(obj.result.like, obj.result.uri);
        }
        obj.result['Filetype'] = filetype(obj.result.uri);
    }
    else {
        obj.result['Filetype'] = '';
    }
    
    if (lastState) {
        obj.result['Fileformat'] = fileformat(lastState.audioFormat);
    }
    else {
        obj.result['Fileformat'] = '';
    }

    for (let i = 0; i < settings.colsPlayback.length; i++) {
        let c = document.getElementById('current' + settings.colsPlayback[i]);
        if (c && settings.colsPlayback[i] === 'Lyrics') {
            getLyrics(obj.result.uri, c.getElementsByTagName('p')[0]);
        }
        else if (c) {
            let value = obj.result[settings.colsPlayback[i]];
            if (value === undefined) {
                value = '';
            }
            if (settings.colsPlayback[i] === 'Duration') {
                value = beautifySongDuration(value);
            }
            else if (settings.colsPlayback[i] === 'LastModified') {
                value = localeDate(value);
            }
            c.getElementsByTagName('p')[0].innerText = value;
            c.setAttribute('data-name', encodeURI(value));
        }
    }
    
    //Update Artist in queue view for http streams
    let playingTr = document.getElementById('queueTrackId' + obj.result.currentSongId);
    if (playingTr) {
        playingTr.getElementsByTagName('td')[1].innerText = obj.result.Title;
    }

    if (playstate === 'play') {
        showNotification(obj.result.Title, textNotification, htmlNotification, 'success');
    }
    
    lastSong = curSong;
    lastSongObj = obj.result;
}

//eslint-disable-next-line no-unused-vars
function gotoTagList() {
    appGoto(app.current.app, app.current.tab, app.current.view, '0/-/-/');
}

//eslint-disable-next-line no-unused-vars
function volumeStep(dir) {
    let inc = dir === 'up' ? settings.volumeStep : 0 - settings.volumeStep;
    chVolume(inc);
}

function chVolume(increment) {
    let newValue = parseInt(domCache.volumeBar.value) + increment;
    if (newValue < 0)  {
        newValue = 0;
    }
    else if (newValue > 100) {
        newValue = 100;
    }
    domCache.volumeBar.value = newValue;
    sendAPI("MPD_API_PLAYER_VOLUME_SET", {"volume": newValue});
}

//eslint-disable-next-line no-unused-vars
function clickTitle() {
    let uri = decodeURI(domCache.currentTitle.getAttribute('data-uri'));
    if (uri !== '' && uri.indexOf('://') === -1) {
        songDetails(uri);
    }
}

function mediaSessionSetPositionState(duration, position) {
    if (settings.mediaSession === true && 'mediaSession' in navigator && navigator.mediaSession.setPositionState) {
        navigator.mediaSession.setPositionState({
            duration: duration,
            position: position
        });
    }
}

function mediaSessionSetState() {
    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        if (playstate === 'play') {
            navigator.mediaSession.playbackState = 'playing';
        }
        else {
            navigator.mediaSession.playbackState = 'paused';
        }
    }
}

function mediaSessionSetMetadata(title, artist, album, url) {
    if (settings.mediaSession === true && 'mediaSession' in navigator) {
        let hostname = window.location.hostname;
        let protocol = window.location.protocol;
        let port = window.location.port;
        let artwork = protocol + '//' + hostname + (port !== '' ? ':' + port : '') + subdir + '/albumart/' + url;

        if (settings.coverimage === true) {
            //eslint-disable-next-line no-undef
            navigator.mediaSession.metadata = new MediaMetadata({
                title: title,
                artist: artist,
                album: album,
                artwork: [{src: artwork}]
            });
        }
        else {
            //eslint-disable-next-line no-undef
            navigator.mediaSession.metadata = new MediaMetadata({
                title: title,
                artist: artist,
                album: album
            });
        }
    }
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function focusTable(rownr, table) {
    if (table === undefined) {
        table = document.getElementById(app.current.app + (app.current.tab !== undefined ? app.current.tab : '') + (app.current.view !== undefined ? app.current.view : '') + 'List');
        //support for BrowseDatabaseAlbum list
        if (table === null) {
            table = document.getElementById(app.current.app + app.current.tab + 'TagList');
        }
        //support for BrowseDatabaseAlbum cards
        if (app.current.app === 'Browse' && app.current.tab === 'Database' && 
            !document.getElementById('BrowseDatabaseAlbumList').classList.contains('hide'))
        {
            table = document.getElementById('BrowseDatabaseAlbumList').getElementsByTagName('table')[0];
        }
    }

    if (app.current.app === 'Browse' && app.current.tab === 'Covergrid' &&
            table.getElementsByTagName('tbody').length === 0) 
    {
        table = document.getElementsByClassName('card-grid')[0];
        table.focus();        
        return;
    }

    if (table !== null) {
        let sel = table.getElementsByClassName('selected');
        if (rownr === undefined) {
            if (sel.length === 0) {
                let row = table.getElementsByTagName('tbody')[0].rows[0];
                row.focus();
                row.classList.add('selected');
            }
            else {
                sel[0].focus();
            }
        }
        else {
            if (sel && sel.length > 0) {
                sel[0].classList.remove('selected');
            }
            let rows = table.getElementsByTagName('tbody')[0].rows;
            let rowsLen = rows.length;
            if (rowsLen < rownr) {
                rownr = 0;
            }
            if (rowsLen > rownr) {
                rows[rownr].focus();
                rows[rownr].classList.add('selected');
            }
        }
        //insert goto parent row
        if (table.id === 'BrowseFilesystemList') {
            let tbody = table.getElementsByTagName('tbody')[0];
            if (tbody.rows.length > 0 && tbody.rows[0].getAttribute('data-type') !== 'parentDir' && app.current.search !== '') {
                let nrCells = table.getElementsByTagName('thead')[0].rows[0].cells.length;
                let uri = app.current.search.replace(/\/?([^/]+)$/,'');
                let row = tbody.insertRow(0);
                row.setAttribute('data-type', 'parentDir');
                row.setAttribute('tabindex', 0);
                row.setAttribute('data-uri', encodeURI(uri));
                row.innerHTML = '<td colspan="' + nrCells + '">..</td>';
            }
        }
        scrollFocusIntoView();
    }
}

function scrollFocusIntoView() {
    let el = document.activeElement;
    let posY = el.getBoundingClientRect().top;
    let height = el.offsetHeight;
    
    if (posY < 74) {
        window.scrollBy(0, - 74);
    }
    else if (posY + height > window.innerHeight - 74) {
        window.scrollBy(0, 74);
    }
}

function navigateTable(table, keyCode) {
    let cur = document.activeElement;
    if (cur) {
        let next = null;
        let handled = false;
        if (keyCode === 'ArrowDown') {
            next = cur.nextElementSibling;
            handled = true;
        }
        else if (keyCode === 'ArrowUp') {
            next = cur.previousElementSibling;
            handled = true;
        }
        else if (keyCode === ' ') {
            let popupBtn = cur.lastChild.firstChild;
            if (popupBtn.nodeName === 'A') {
                popupBtn.click();
            }
            handled = true;
        }
        else if (keyCode === 'Enter') {
            cur.firstChild.click();
            handled = true;
        }
        else if (keyCode === 'Escape') {
            cur.blur();
            cur.classList.remove('selected');
            handled = true;
        }
        //only for BrowseDatabaseAlbum cards
        else if (app.current.app === 'Browse' && app.current.tab === 'Database' && 
                 !document.getElementById('BrowseDatabaseAlbumList').classList.contains('hide') &&
                 (keyCode === 'n' || keyCode === 'p')) {
            let tablesHtml = document.getElementById('BrowseDatabaseAlbumList').getElementsByTagName('table');
            let tables = Array.prototype.slice.call(tablesHtml);
            let idx = document.activeElement.nodeName === 'TR' ? tables.indexOf(document.activeElement.parentNode.parentNode)
                                                              : tables.indexOf(document.activeElement);
            idx = event.key === 'p' ? (idx > 1 ? idx - 1 : 0)
                                   : event.key === 'n' ? ( idx < tables.length - 1 ? ( document.activeElement.nodeName === 'TR' ? idx + 1 : idx )
                                                                                  : idx)
                                                      : idx;
            
            if (tables[idx].getElementsByTagName('tbody')[0].rows.length > 0) {
                next = tables[idx].getElementsByTagName('tbody')[0].rows[0];
            }
            else {
                //Titlelist not loaded yet, scroll table into view
                tables[idx].focus();
                scrollFocusIntoView();
            }
            handled = true;
        }
        if (handled === true) {
            event.preventDefault();
            event.stopPropagation();
        }
        if (next) {
            cur.classList.remove('selected');
            next.classList.add('selected');
            next.focus();
            scrollFocusIntoView();
        }
    }
}

function dragAndDropTable(table) {
    let tableBody=document.getElementById(table).getElementsByTagName('tbody')[0];
    tableBody.addEventListener('dragstart', function(event) {
        if (event.target.nodeName === 'TR') {
            event.target.classList.add('opacity05');
            event.dataTransfer.setDragImage(event.target, 0, 0);
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('Text', event.target.getAttribute('id'));
            dragEl = event.target.cloneNode(true);
        }
    }, false);
    tableBody.addEventListener('dragleave', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        if (target.nodeName === 'TR') {
            target.classList.remove('dragover');
        }
    }, false);
    tableBody.addEventListener('dragover', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        if (target.nodeName === 'TR') {
            target.classList.add('dragover');
        }
        event.dataTransfer.dropEffect = 'move';
    }, false);
    tableBody.addEventListener('dragend', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        if (document.getElementById(event.dataTransfer.getData('Text'))) {
            document.getElementById(event.dataTransfer.getData('Text')).classList.remove('opacity05');
        }
    }, false);
    tableBody.addEventListener('drop', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (dragEl.nodeName !== 'TR') {
            return;
        }
        let target = event.target;
        if (event.target.nodeName === 'TD') {
            target = event.target.parentNode;
        }
        let oldSongpos = document.getElementById(event.dataTransfer.getData('Text')).getAttribute('data-songpos');
        let newSongpos = target.getAttribute('data-songpos');
        document.getElementById(event.dataTransfer.getData('Text')).remove();
        dragEl.classList.remove('opacity05');
        tableBody.insertBefore(dragEl, target);
        let tr = tableBody.getElementsByClassName('dragover');
        let trLen = tr.length;
        for (let i = 0; i < trLen; i++) {
            tr[i].classList.remove('dragover');
        }
        document.getElementById(table).classList.add('opacity05');
        if (app.current.app === 'Queue' && app.current.tab === 'Current') {
            sendAPI("MPD_API_QUEUE_MOVE_TRACK", {"from": oldSongpos, "to": newSongpos});
        }
        else if (app.current.app === 'Browse' && app.current.tab === 'Playlists' && app.current.view === 'Detail') {
            playlistMoveTrack(oldSongpos, newSongpos);
        }
    }, false);
}

function dragAndDropTableHeader(table) {
    let tableHeader;
    if (document.getElementById(table + 'List')) {
        tableHeader = document.getElementById(table + 'List').getElementsByTagName('tr')[0];
    }
    else {
        tableHeader = table.getElementsByTagName('tr')[0];
        table = 'BrowseDatabase';
    }

    tableHeader.addEventListener('dragstart', function(event) {
        if (event.target.nodeName === 'TH') {
            event.target.classList.add('opacity05');
            event.dataTransfer.setDragImage(event.target, 0, 0);
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('Text', event.target.getAttribute('data-col'));
            dragEl = event.target.cloneNode(true);
        }
    }, false);
    tableHeader.addEventListener('dragleave', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        if (event.target.nodeName === 'TH') {
            event.target.classList.remove('dragover-th');
        }
    }, false);
    tableHeader.addEventListener('dragover', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (event.target.nodeName === 'TH') {
            event.target.classList.add('dragover-th');
        }
        event.dataTransfer.dropEffect = 'move';
    }, false);
    tableHeader.addEventListener('dragend', function(event) {
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']')) {
            this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']').classList.remove('opacity05');
        }
    }, false);
    tableHeader.addEventListener('drop', function(event) {
        event.stopPropagation();
        event.preventDefault();
        if (dragEl.nodeName !== 'TH') {
            return;
        }
        this.querySelector('[data-col=' + event.dataTransfer.getData('Text') + ']').remove();
        dragEl.classList.remove('opacity05');
        tableHeader.insertBefore(dragEl, event.target);
        let th = tableHeader.getElementsByClassName('dragover-th');
        let thLen = th.length;
        for (let i = 0; i < thLen; i++) {
            th[i].classList.remove('dragover-th');
        }
        if (document.getElementById(table + 'List')) {
            document.getElementById(table + 'List').classList.add('opacity05');
            saveCols(table);
        }
        else {
            saveCols(table, this.parentNode.parentNode);
        }
    }, false);
}

function setColTags(table) {
    let tags = settings.tags.slice();
    if (settings.featTags === false) {
        tags.push('Title');
    }
    tags.push('Duration');
    if (table === 'QueueCurrent' || table === 'BrowsePlaylistsDetail' || table === 'QueueLastPlayed') {
        tags.push('Pos');
    }
    if (table === 'BrowseFilesystem') {
        tags.push('Type');
    }
    if (table === 'QueueLastPlayed') {
        tags.push('LastPlayed');
    }
    if (table === 'Playback') {
        tags.push('Filetype');
        tags.push('Fileformat');
        tags.push('LastModified');
        if (settings.featLyrics === true) {
            tags.push('Lyrics');
        }
    }
    
    tags.sort();
    return tags;
}

function setColsChecklist(table) {
    let tagChks = '';
    let tags = setColTags(table);
    
    for (let i = 0; i < tags.length; i++) {
        if (table === 'Playback' && tags[i] === 'Title') {
            continue;
        }
        tagChks += '<div>' +
            '<button class="btn btn-secondary btn-xs clickable material-icons material-icons-small' +
            (settings['cols' + table].includes(tags[i]) ? ' active' : '') + '" name="' + tags[i] + '">' +
            (settings['cols' + table].includes(tags[i]) ? 'check' : 'radio_button_unchecked') + '</button>' +
            '<label class="form-check-label" for="' + tags[i] + '">&nbsp;&nbsp;' + t(tags[i]) + '</label>' +
            '</div>';
    }
    return tagChks;
}

function setCols(table, className) {
    let colsChkList = document.getElementById(table + 'ColsDropdown');
    if (colsChkList) {
        colsChkList.firstChild.innerHTML = setColsChecklist(table);
    }
    let sort = app.current.sort;
    
    if (table === 'Search' && app.apps.Search.state === '0/any/Title/') {
        if (settings.tags.includes('Title')) {
            sort = 'Title';
        }
        else if (settings.featTags === false) {
            sort = 'Filename';
        }
        else {
            sort = '-';
        }
    }
    
    if (table !== 'Playback') {
        let heading = '';
        for (let i = 0; i < settings['cols' + table].length; i++) {
            let h = settings['cols' + table][i];
            heading += '<th draggable="true" data-col="' + h  + '">';
            if (h === 'Track' || h === 'Pos') {
                h = '#';
            }
            heading += t(h);

            if (table === 'Search' && (h === sort || '-' + h === sort) ) {
                let sortdesc = false;
                if (app.current.sort.indexOf('-') === 0) {
                    sortdesc = true;
                }
                heading += '<span class="sort-dir material-icons pull-right">' + (sortdesc === true ? 'arrow_drop_up' : 'arrow_drop_down') + '</span>';
            }
            heading += '</th>';
        }
        if (settings.featTags === true && table !== 'BrowseDatabase') {
            heading += '<th data-col="Action"><a href="#" class="text-secondary align-middle material-icons material-icons-small">settings</a></th>';
        }
        else {
            heading += '<th></th>';
        }

        if (className === undefined) {
            document.getElementById(table + 'List').getElementsByTagName('tr')[0].innerHTML = heading;
        }
        else {
            let tbls = document.querySelectorAll(className);
            for (let i = 0; i < tbls.length; i++) {
                tbls[i].getElementsByTagName('tr')[0].innerHTML = heading;
            }
        }
    }
}

function saveCols(table, tableEl) {
    let colsDropdown = document.getElementById(table + 'ColsDropdown');
    let header;
    if (tableEl === undefined) {
        header = document.getElementById(table + 'List').getElementsByTagName('tr')[0];
    }
    else if (typeof(tableEl) === 'string') {
        header = document.querySelector(tableEl).getElementsByTagName('tr')[0];
    }
    else {
        header = tableEl.getElementsByTagName('tr')[0];
    }
    if (colsDropdown) {
        let colInputs = colsDropdown.firstChild.getElementsByTagName('button');
        for (let i = 0; i < colInputs.length; i++) {
            if (colInputs[i].getAttribute('name') === null) {
                continue;
            }
            let th = header.querySelector('[data-col=' + colInputs[i].name + ']');
            if (colInputs[i].classList.contains('active') === false) {
                if (th) {
                    th.remove();
                }
            } 
            else if (!th) {
                th = document.createElement('th');
                th.innerText = colInputs[i].name;
                th.setAttribute('data-col', colInputs[i].name);
                header.insertBefore(th, header.lastChild);
            }
        }
    }
    
    let params = {"table": "cols" + table, "cols": []};
    let ths = header.getElementsByTagName('th');
    for (let i = 0; i < ths.length; i++) {
        let name = ths[i].getAttribute('data-col');
        if (name !== 'Action' && name !== null) {
            params.cols.push(name);
        }
    }
    sendAPI("MYMPD_API_COLS_SAVE", params, getSettings);
}

//eslint-disable-next-line no-unused-vars
function saveColsPlayback(table) {
    let colInputs = document.getElementById(table + 'ColsDropdown').firstChild.getElementsByTagName('button');
    let header = document.getElementById('cardPlaybackTags');

    for (let i = 0; i < colInputs.length -1; i++) {
        let th = document.getElementById('current' + colInputs[i].name);
        if (colInputs[i].classList.contains('active') === false) {
            if (th) {
                th.remove();
            }
        } 
        else if (!th) {
            th = document.createElement('div');
            th.innerHTML = '<small>' + t(colInputs[i].name) + '</small><p></p>';
            th.setAttribute('id', 'current' + colInputs[i].name);
            th.setAttribute('data-tag', colInputs[i].name);
            header.appendChild(th);
        }
    }
    
    let params = {"table": "cols" + table, "cols": []};
    let ths = header.getElementsByTagName('div');
    for (let i = 0; i < ths.length; i++) {
        let name = ths[i].getAttribute('data-tag');
        if (name) {
            params.cols.push(name);
        }
    }
    sendAPI("MYMPD_API_COLS_SAVE", params, getSettings);
}

function replaceTblRow(row, el) {
    let menuEl = row.querySelector('[data-popover]');
    let result = false;
    if (menuEl) {
        hideMenu();
    }
    if (row.classList.contains('selected')) {
        el.classList.add('selected');
        el.focus();
        result = true;
    }
    row.replaceWith(el);
    return result;
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
var themes = {
    "theme-autodetect": "Autodetect",
    "theme-default": "Default",
    "theme-dark": "Dark",
    "theme-light": "Light"
};
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

//eslint-disable-next-line no-unused-vars
function deleteTimer(timerid) {
    sendAPI("MYMPD_API_TIMER_RM", {"timerid": timerid}, showListTimer);
}

//eslint-disable-next-line no-unused-vars
function toggleTimer(target, timerid) {
    if (target.classList.contains('active')) {
        target.classList.remove('active');
        sendAPI("MYMPD_API_TIMER_TOGGLE", {"timerid": timerid, "enabled": false}, showListTimer);
    }
    else {
        target.classList.add('active');
        sendAPI("MYMPD_API_TIMER_TOGGLE", {"timerid": timerid, "enabled": true}, showListTimer);
    }
}

//eslint-disable-next-line no-unused-vars
function saveTimer() {
    let formOK = true;
    let nameEl = document.getElementById('inputTimerName');
    if (!validateNotBlank(nameEl)) {
        formOK = false;
    }
    let minOneDay = false;
    let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
    let weekdays = [];
    for (let i = 0; i < weekdayBtns.length; i++) {
        let checked = document.getElementById(weekdayBtns[i]).classList.contains('active') ? true : false;
        weekdays.push(checked);
        if (checked === true) {
            minOneDay = true;
        }
    }
    if (minOneDay === false) {
        formOK = false;
        document.getElementById('invalidTimerWeekdays').style.display = 'block';
    }
    else {
        document.getElementById('invalidTimerWeekdays').style.display = 'none';
    }
    let selectTimerAction = document.getElementById('selectTimerAction');
    let selectTimerPlaylist = document.getElementById('selectTimerPlaylist');
    let selectTimerHour = document.getElementById('selectTimerHour');
    let selectTimerMinute = document.getElementById('selectTimerMinute');
    let jukeboxMode = document.getElementById('btnTimerJukeboxModeGroup').getElementsByClassName('active')[0].getAttribute('data-value');

    if (jukeboxMode === '0' &&
        selectTimerPlaylist.options[selectTimerPlaylist.selectedIndex].value === 'Database'&&
        selectTimerAction.options[selectTimerAction.selectedIndex].value === 'startplay')
    {
        formOK = false;
        document.getElementById('btnTimerJukeboxModeGroup').classList.add('is-invalid');
    }
    if (formOK === true) {
        sendAPI("MYMPD_API_TIMER_SAVE", {
            "timerid": parseInt(document.getElementById('inputTimerId').value),
            "name": nameEl.value,
            "enabled": (document.getElementById('btnTimerEnabled').classList.contains('active') ? true : false),
            "startHour": parseInt(selectTimerHour.options[selectTimerHour.selectedIndex].value),
            "startMinute": parseInt(selectTimerMinute.options[selectTimerMinute.selectedIndex].value),
            "weekdays": weekdays,
            "action": selectTimerAction.options[selectTimerAction.selectedIndex].value,
            "volume": parseInt(document.getElementById('inputTimerVolume').value), 
            "playlist": selectTimerPlaylist.options[selectTimerPlaylist.selectedIndex].value,
            "jukeboxMode": parseInt(jukeboxMode),
            }, showListTimer);
    }
}

//eslint-disable-next-line no-unused-vars
function showEditTimer(timerid) {
    document.getElementById('timerActionPlay').classList.add('hide');
    document.getElementById('listTimer').classList.remove('active');
    document.getElementById('editTimer').classList.add('active');
    document.getElementById('listTimerFooter').classList.add('hide');
    document.getElementById('editTimerFooter').classList.remove('hide');
    playlistEl = 'selectTimerPlaylist';
    sendAPI("MPD_API_PLAYLIST_LIST", {"offset": 0, "filter": "-"}, getAllPlaylists);
    if (timerid !== 0) {
        sendAPI("MYMPD_API_TIMER_GET", {"timerid": timerid}, parseEditTimer);
    }
    else {
        document.getElementById('inputTimerId').value = '0';
        document.getElementById('inputTimerName').value = '';
        toggleBtnChk('btnTimerEnabled', true);
        document.getElementById('selectTimerHour').value = '12';
        document.getElementById('selectTimerMinute').value = '0';
        document.getElementById('selectTimerAction').value = 'startplay';
        document.getElementById('inputTimerVolume').value = '50';
        document.getElementById('selectTimerPlaylist').value = 'Database';
        toggleBtnGroupValue(document.getElementById('btnTimerJukeboxModeGroup'), 1);
        let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
        for (let i = 0; i < weekdayBtns.length; i++) {
            toggleBtnChk(weekdayBtns[i], false);
        }
        document.getElementById('timerActionPlay').classList.remove('hide');
    }
    document.getElementById('inputTimerName').focus();
    document.getElementById('inputTimerName').classList.remove('is-invalid');
    document.getElementById('btnTimerJukeboxModeGroup').classList.remove('is-invalid');
    document.getElementById('invalidTimerWeekdays').style.display = 'none';
}

function parseEditTimer(obj) {
    if (obj.result.action === 'startplay') {
        document.getElementById('timerActionPlay').classList.remove('hide');
    }
    else {
        document.getElementById('timerActionPlay').classList.add('hide');
    }
    document.getElementById('inputTimerId').value = obj.result.timerid;
    document.getElementById('inputTimerName').value = obj.result.name;
    toggleBtnChk('btnTimerEnabled', obj.result.enabled);
    document.getElementById('selectTimerHour').value = obj.result.startHour;
    document.getElementById('selectTimerMinute').value = obj.result.startMinute;
    document.getElementById('selectTimerAction').value = obj.result.action;
    document.getElementById('inputTimerVolume').value = obj.result.volume;
    document.getElementById('selectTimerPlaylist').value = obj.result.playlist;
    toggleBtnGroupValue(document.getElementById('btnTimerJukeboxModeGroup'), obj.result.jukeboxMode);
    let weekdayBtns = ['btnTimerMon', 'btnTimerTue', 'btnTimerWed', 'btnTimerThu', 'btnTimerFri', 'btnTimerSat', 'btnTimerSun'];
    for (let i = 0; i < weekdayBtns.length; i++) {
        toggleBtnChk(weekdayBtns[i], obj.result.weekdays[i]);
    }
}

function showListTimer() {
    document.getElementById('listTimer').classList.add('active');
    document.getElementById('editTimer').classList.remove('active');
    document.getElementById('listTimerFooter').classList.remove('hide');
    document.getElementById('editTimerFooter').classList.add('hide');
    sendAPI("MYMPD_API_TIMER_LIST", {}, parseListTimer);
}

function parseListTimer(obj) {
    let tbody = document.getElementById('listTimer').getElementsByTagName('tbody')[0];
    let tr = tbody.getElementsByTagName('tr');
    
    let activeRow = 0;
    let weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    for (let i = 0; i < obj.result.returnedEntities; i++) {
        let row = document.createElement('tr');
        row.setAttribute('data-id', obj.result.data[i].timerid);
        let tds = '<td>' + e(obj.result.data[i].name) + '</td>' +
                  '<td><button name="enabled" class="btn btn-secondary btn-xs clickable material-icons material-icons-small' +
                  (obj.result.data[i].enabled === true ? ' active' : '') + '">' +
                  (obj.result.data[i].enabled === true ? 'check' : 'radio_button_unchecked') + '</button></td>' +
                  '<td>' + zeroPad(obj.result.data[i].startHour, 2) + ':' + zeroPad(obj.result.data[i].startMinute,2) + ' ' + t('on') + ' ';
        let days = [];
        for (let j = 0; j < 7; j++) {
            if (obj.result.data[i].weekdays[j] === true) {
                days.push(t(weekdays[j]))
            }
        }
        tds += days.join(', ')  + '</td><td>' + t(obj.result.data[i].action) + '</td>' +
               '<td data-col="Action"><a href="#" class="material-icons color-darkgrey">delete</a></td>';
        row.innerHTML = tds;
        if (i < tr.length) {
            activeRow = replaceTblRow(tr[i], row) === true ? i : activeRow;
        }
        else {
            tbody.append(row);
        }
    }
    let trLen = tr.length - 1;
    for (let i = trLen; i >= obj.result.returnedEntities; i --) {
        tr[i].remove();
    }

    if (obj.result.returnedEntities === 0) {
        tbody.innerHTML = '<tr><td><span class="material-icons">error_outline</span></td>' +
                          '<td colspan="4">' + t('Empty list') + '</td></tr>';
    }     
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function getSelectValue(selectId) {
    let el = document.getElementById(selectId);
    return el.options[el.selectedIndex].value;
}

function alignDropdown(el) {
    if (getXpos(el.children[0]) > domCache.body.offsetWidth * 0.66) {
        el.getElementsByClassName('dropdown-menu')[0].classList.add('dropdown-menu-right');
    }
    else {
        el.getElementsByClassName('dropdown-menu')[0].classList.remove('dropdown-menu-right');
    }
}

function getXpos(el) {
    var xPos = 0;
    while (el) {
        xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
        el = el.offsetParent;
    }
    return xPos;
}

function zeroPad(num, places) {
  var zero = places - num.toString().length + 1;
  return Array(+(zero > 0 && zero)).join("0") + num;
}

function dirname(uri) {
    return uri.replace(/\/[^/]*$/, '');
}

function basename(uri) {
   return uri.split('/').reverse()[0];
}

function filetype(uri) {
    if (uri === undefined) {
        return '';
    }
    let ext = uri.split('.').pop().toUpperCase();
    switch (ext) {
        case 'MP3':  return ext + ' - MPEG-1 Audio Layer III';
        case 'FLAC': return ext + ' - Free Lossless Audio Codec';
        case 'OGG':  return ext + ' - Ogg Vorbis';
        case 'OPUS': return ext + ' - Opus Audio';
        case 'WAV':  return ext + ' - WAVE Audio File';
        case 'WV':   return ext + ' - WavPack';
        case 'AAC':  return ext + ' - Advancded Audio Coding';
        case 'MPC':  return ext + ' - Musepack';
        case 'MP4':  return ext + ' - MPEG-4';
        case 'APE':  return ext + ' - Monkey Audio ';
        case 'WMA':  return ext + ' - Windows Media Audio';
        default:     return ext;
    }
}

function fileformat(audioformat) {
    return audioformat.bits + t('bits') + ' - ' + audioformat.sampleRate / 1000 + t('kHz');
}

function scrollToPosY(pos) {
    document.body.scrollTop = pos; // For Safari
    document.documentElement.scrollTop = pos; // For Chrome, Firefox, IE and Opera

    if (app.current.app === 'Playback') {
        document.getElementById('BrowseCovergridBox').scrollTop = 0;
    }
}

function doSetFilterLetter(x) {
    let af = document.getElementById(x + 'Letters').getElementsByClassName('active')[0];
    if (af) {
        af.classList.remove('active');
    }
    let filter = app.current.filter;
    if (filter === '0') {
        filter = '#';
    }
    
    document.getElementById(x).innerHTML = '<span class="material-icons">filter_list</span>' + (filter !== '-' ? ' ' + filter : '');
    
    if (filter !== '-') {
        let btns = document.getElementById(x + 'Letters').getElementsByTagName('button');
        let btnsLen = btns.length;
        for (let i = 0; i < btnsLen; i++) {
            if (btns[i].innerText === filter) {
                btns[i].classList.add('active');
                break;
            }
        }
    }
}

function addFilterLetter(x) {
    let filter = '<button class="mr-1 mb-1 btn btn-sm btn-secondary material-icons material-icons-small">delete</button>' +
        '<button class="mr-1 mb-1 btn btn-sm btn-secondary">#</button>';
    for (let i = 65; i <= 90; i++) {
        filter += '<button class="mr-1 mb-1 btn-sm btn btn-secondary">' + String.fromCharCode(i) + '</button>';
    }

    let letters = document.getElementById(x);
    letters.innerHTML = filter;
    
    letters.addEventListener('click', function(event) {
        switch (event.target.innerText) {
            case 'delete':
                filter = '-';
                break;
            case '#':
                filter = '0';
                break;
            default:
                filter = event.target.innerText;
        }
        appGoto(app.current.app, app.current.tab, app.current.view, '0/' + filter + '/' + app.current.sort + '/' + app.current.search);
    }, false);
}

function selectTag(btnsEl, desc, setTo) {
    let btns = document.getElementById(btnsEl);
    let aBtn = btns.querySelector('.active')
    if (aBtn) {
        aBtn.classList.remove('active');
    }
    aBtn = btns.querySelector('[data-tag=' + setTo + ']');
    if (aBtn) {
        aBtn.classList.add('active');
        if (desc !== undefined) {
            document.getElementById(desc).innerText = aBtn.innerText;
            document.getElementById(desc).setAttribute('data-phrase', aBtn.innerText);
        }
    }
}

function addTagList(el, list) {
    let tagList = '';
    if (list === 'searchtags') {
        if (settings.featTags === true) {
            tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="any">' + t('Any Tag') + '</button>';
        }
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="filename">' + t('Filename') + '</button>';
    }
    for (let i = 0; i < settings[list].length; i++) {
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="' + settings[list][i] + '">' + t(settings[list][i]) + '</button>';
    }
    if (el === 'covergridSortTagsList') {
        if (settings.tags.includes('Date')) {
            tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Date">' + t('Date') + '</button>';
        }
        tagList += '<button type="button" class="btn btn-secondary btn-sm btn-block" data-tag="Last-Modified">' + t('Last modified') + '</button>';
    }
    document.getElementById(el).innerHTML = tagList;
}

function addTagListSelect(el, list) {
    let tagList = '';
    if (el === 'saveSmartPlaylistSort' || el === 'selectSmartplsSort') {
        tagList += '<option value="">' + t('Disabled') + '</option>';
        tagList += '<option value="shuffle">' + t('Shuffle') + '</option>';
        tagList += '<optgroup label="' + t('Sort by tag') + '">';
        tagList += '<option value="filename">' + t('Filename') + '</option>';
    }
    else if (el === 'selectJukeboxUniqueTag' && settings.browsetags.includes('Title') === false) {
        //Title tag should be always in the list
        tagList = '<option value="Title">' + t('Song') + '</option>';
    }
    for (let i = 0; i < settings[list].length; i++) {
        tagList += '<option value="' + settings[list][i] + '">' + t(settings[list][i]) + '</option>';
    }
    if (el === 'saveSmartPlaylistSort' || el === 'selectSmartplsSort') {
        tagList += '</optgroup>';
    }
    document.getElementById(el).innerHTML = tagList;
}

//eslint-disable-next-line no-unused-vars
function openModal(modal) {
    window[modal].show();
}

//eslint-disable-next-line no-unused-vars
function openDropdown(dropdown) {
    window[dropdown].toggle();
}

//eslint-disable-next-line no-unused-vars
function focusSearch() {
    if (app.current.app === 'Queue') {
        document.getElementById('searchqueuestr').focus();
    }
    else if (app.current.app === 'Search') {
        domCache.searchstr.focus();
    }
    else {
        appGoto('Search');
    }
}

function btnWaiting(btn, waiting) {
    if (waiting === true) {
        let spinner = document.createElement('span');
        spinner.classList.add('spinner-border', 'spinner-border-sm', 'mr-2');
        btn.insertBefore(spinner, btn.firstChild);
        btn.setAttribute('disabled', 'disabled');
    }
    else {
        btn.removeAttribute('disabled');
        if (btn.firstChild.nodeName === 'SPAN') {
            btn.firstChild.remove();
        }
    }
}

function toggleBtnGroupValue(btngrp, value) {
    let btns = btngrp.getElementsByTagName('button');
    let b = btns[0];
    let valuestr = value;
    if (isNaN(value) === false) {
        valuestr = value.toString();
    }
    for (let i = 0; i < btns.length; i++) {
        if (btns[i].getAttribute('data-value') === valuestr) {
            btns[i].classList.add('active');
            b = btns[i];
        }
        else {
            btns[i].classList.remove('active');
        }
    }
    return b;
}

function toggleBtnGroupValueCollapse(btngrp, collapse, value) {
    let activeBtn = toggleBtnGroupValue(btngrp, value);
    if (activeBtn.getAttribute('data-collapse') === 'show') {
        document.getElementById(collapse).classList.add('show');
    }
    else {
        document.getElementById(collapse).classList.remove('show');
    }
}

function toggleBtnGroup(btn) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    let btns = b.parentNode.getElementsByTagName('button');
    for (let i = 0; i < btns.length; i++) {
        if (btns[i] === b) {
            btns[i].classList.add('active');
        }
        else {
            btns[i].classList.remove('active');
        }
    }
    return b;
}

function getBtnGroupValue(btnGroup) {
    let activeBtn = document.getElementById(btnGroup).getElementsByClassName('active');
    if (activeBtn.length === 0) {
        activeBtn = document.getElementById(btnGroup).getElementsByTagName('button');    
    }
    return activeBtn[0].getAttribute('data-value');
}

//eslint-disable-next-line no-unused-vars
function toggleBtnGroupCollapse(btn, collapse) {
    let activeBtn = toggleBtnGroup(btn);
    if (activeBtn.getAttribute('data-collapse') === 'show') {
        if (document.getElementById(collapse).classList.contains('show') === false) {
            window[collapse].show();
        }
    }
    else {
        window[collapse].hide();
    }
}

function toggleBtn(btn, state) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    if (!b) {
        return;
    }
    if (state === undefined) {
        //toggle state
        state = b.classList.contains('active') ? false : true;
    }

    if (state === true || state === 1) {
        b.classList.add('active');
    }
    else {
        b.classList.remove('active');
    }
}

function toggleBtnChk(btn, state) {
    let b = btn;
    if (typeof btn === 'string') {
        b = document.getElementById(btn);
    }
    if (!b) {
        return;
    }
    if (state === undefined) {
        //toggle state
        state = b.classList.contains('active') ? false : true;
    }

    if (state === true || state === 1) {
        b.classList.add('active');
        b.innerText = 'check';
        return true;
    }
    else {
        b.classList.remove('active');
        b.innerText = 'radio_button_unchecked';
        return false;
    }
}

function toggleBtnChkCollapse(btn, collapse, state) {
    let checked = toggleBtnChk(btn, state);
    if (checked === true) {
        document.getElementById(collapse).classList.add('show');
    }
    else{
        document.getElementById(collapse).classList.remove('show');
    }
}

function setPagination(total, returned, limit = settings.maxElementsPerPage) {
      let cat = app.current.app === 'Playback' ? 'BrowseCovergrid' : app.current.app + app.current.tab;
       if (app.current.app === 'Search') {
	cat = app.current.app + (app.current.tab === undefined ? '': app.current.tab);
       }
    let totalPages = Math.ceil(total / limit);
    if (totalPages === 0) {
        totalPages = 1;
    }
    let p = [ document.getElementById(cat + 'PaginationTop'), document.getElementById(cat + 'PaginationBottom') ];
    
    for (let i = 0; i < p.length; i++) {
        let prev = p[i].children[0];
        let page = p[i].children[1].children[0];
        let pages = p[i].children[1].children[1];
        let next = p[i].children[2];
    
        page.innerText = (app.current.page / limit + 1) + ' / ' + totalPages;
        if (totalPages > 1) {
            page.removeAttribute('disabled');
            let pl = '';
            for (let j = 0; j < totalPages; j++) {
                pl += '<button data-page="' + (j * limit) + '" type="button" class="mr-1 mb-1 btn-sm btn btn-secondary">' +
                    (j + 1) + '</button>';
            }
            pages.innerHTML = pl;
            page.classList.remove('nodropdown');
        }
        else if (total === -1) {
            page.setAttribute('disabled', 'disabled');
            page.innerText = (app.current.page / limit + 1);
            page.classList.add('nodropdown');
        }
        else {
            page.setAttribute('disabled', 'disabled');
            page.classList.add('nodropdown');
        }

        if (total > app.current.page + limit || total === -1 && returned >= limit) {
            next.removeAttribute('disabled');
            p[i].classList.remove('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.remove('hide');
        }
        else {
            next.setAttribute('disabled', 'disabled');
            p[i].classList.add('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.add('hide');
        }

        if (app.current.page > 0) {
            prev.removeAttribute('disabled');
            p[i].classList.remove('hide');
            document.getElementById(cat + 'ButtonsBottom').classList.remove('hide');
        }
        else {
            prev.setAttribute('disabled', 'disabled');
        }
    }
}

function genId(x) {
    return 'id' + x.replace(/[^\w-]/g, '');
}

function parseCmd(event, href) {
    event.preventDefault();
    let cmd = href;
    if (typeof(href) === 'string') {
        cmd = JSON.parse(href);
    }

    if (typeof window[cmd.cmd] === 'function') {
        switch(cmd.cmd) {
            case 'sendAPI':
                sendAPI(cmd.options[0].cmd, {}); 
                break;
            case 'toggleBtn':
            case 'toggleBtnChk':
            case 'toggleBtnGroup':
            case 'toggleBtnGroupCollapse':
            case 'setPlaySettings':
                window[cmd.cmd](event.target, ... cmd.options);
                break;
            case 'toggleBtnChkCollapse':
                window[cmd.cmd](event.target, undefined, ... cmd.options);
                break;
            default:
                window[cmd.cmd](... cmd.options);
        }
    }
    else {
        logError('Can not execute cmd: ' + cmd);
    }
}

function gotoPage(x) {
    switch (x) {
        case 'next':
            app.current.page += settings.maxElementsPerPage;
            break;
        case 'prev':
            app.current.page -= settings.maxElementsPerPage;
            if (app.current.page < 0) {
                app.current.page = 0;
            }
            break;
        default:
            app.current.page = x;
    }
    setAppState(app.current.page, app.current.filter, app.current.sort, app.current.search);
    appGoto(app.current.app, app.current.tab, app.current.view, app.current.page + '/' + app.current.filter + '/' + app.current.sort + '/' + app.current.search);
}
/*
 SPDX-License-Identifier: GPL-2.0-or-later
 myMPD (c) 2018-2020 Juergen Mang <mail@jcgames.de>
 https://github.com/jcorporation/mympd
*/

function validateFilenameString(str) {
    if (str === '') {
        return false;
    }
    else if (str.match(/^[\w-.]+$/) !== null) {
        return true;
    }
    else {
        return false;
    }
}

function validateFilename(el) {
    if (validateFilenameString(el.value) === false) {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateFilenameList(el) {
    el.classList.remove('is-invalid');
    
    let filenames = el.value.split(',');
    for (let i = 0; i < filenames.length; i++) {
        if (validateFilenameString(filenames[i].trim()) === false) {
            el.classList.add('is-invalid');
            return false;
        }
    }
    return true;
}

function validatePath(el) {
    if (el.value === '') {
        el.classList.add('is-invalid');
        return false;
    }
    else if (el.value.match(/^\/[/.\w-]+$/) !== null) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}

function validatePlname(x) {
    if (x === '') {
        return false;
    }
    else if (x.match(/\/|\r|\n|"|'/) === null) {
        return true;
    }
    else {
        return false;
    }
}

function validateNotBlank(el) {
    let value = el.value.replace(/\s/g, '');
    if (value === '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateInt(el) {
    let value = el.value.replace(/\d/g, '');
    if (value !== '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateFloat(el) {
    let value = el.value.replace(/[\d-.]/g, '');
    if (value !== '') {
        el.classList.add('is-invalid');
        return false;
    }
    else {
        el.classList.remove('is-invalid');
        return true;
    }
}

function validateStream(el) {
    if (el.value.indexOf('://') > -1) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}

function validateHost(el) {
    if (el.value.match(/^([\w-.]+)$/) !== null) {
        el.classList.remove('is-invalid');
        return true;
    }
    else {
        el.classList.add('is-invalid');
        return false;
    }
}
